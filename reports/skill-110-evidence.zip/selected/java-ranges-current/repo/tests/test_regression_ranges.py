import subprocess
subprocess.run(["java", "RegressionRanges.java"], check=True)
