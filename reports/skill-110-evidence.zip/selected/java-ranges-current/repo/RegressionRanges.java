import java.util.*;
import java.math.BigInteger;
import javax.tools.ToolProvider;
import java.net.*;
import java.nio.file.*;

class RegressionRanges {
 static Class<?> ranges;
 @SuppressWarnings("unchecked")
 static Object call(String name, List<long[]>... args) throws Exception {
  try {
   return ranges.getMethod(name, Collections.nCopies(args.length, List.class).toArray(Class<?>[]::new))
    .invoke(null, (Object[]) args);
  } catch (java.lang.reflect.InvocationTargetException e) {
   if (e.getCause() instanceof IllegalArgumentException) throw (IllegalArgumentException)e.getCause();
   throw e;
  }
 }
 static List<long[]> list(long[]... a) { return Arrays.asList(a); }
 static void equal(Object actual, long[][] expected) {
  if (!(actual instanceof List<?> a) || a.size() != expected.length) throw new AssertionError();
  for (int i=0;i<expected.length;i++)
   if (!Arrays.equals((long[])a.get(i),expected[i])) throw new AssertionError("range " + i);
 }
 static void invalid(String method, List<long[]>... args) throws Exception {
  try { call(method,args); } catch (IllegalArgumentException e) { return; }
  throw new AssertionError("accepted invalid " + method);
 }
 public static void main(String[] args) throws Exception {
  Path d=Files.createTempDirectory("ranges-regression");
  try {
   if(ToolProvider.getSystemJavaCompiler().run(null,null,null,"-d",d.toString(),"Ranges.java")!=0) throw new AssertionError();
   try(var loader=new URLClassLoader(new URL[]{d.toUri().toURL()})) {
    ranges=loader.loadClass("Ranges");
    long[] first={8,12}, second={1,4};
    List<long[]> input=Collections.unmodifiableList(list(first,second,new long[]{4,8},new long[]{2,3},new long[]{7,7}));
    Object normalized=call("normalize",input);
    equal(normalized,new long[][]{{1,12}});
    ((long[])((List<?>)normalized).get(0))[0]=99;
    if(!Arrays.equals(first,new long[]{8,12}) || !Arrays.equals(second,new long[]{1,4}) || input.get(0)!=first) throw new AssertionError("mutation");
    List<long[]> cuts=list(new long[]{9,11},new long[]{3,5},new long[]{4,6});
    equal(call("subtract",input,cuts),new long[][]{{1,3},{6,9},{11,12}});
    equal(call("subtract",list(new long[]{10,15},new long[]{0,5}),list(new long[]{2,12})),new long[][]{{0,2},{12,15}});
    equal(call("subtract",input,list(new long[]{-1,20})),new long[][]{});
    Object copy=call("subtract",list(first),List.of());
    ((long[])((List<?>)copy).get(0))[1]=100;
    if(first[1]!=12 || cuts.get(0)[0]!=9) throw new AssertionError("alias");
    long lo=Long.MIN_VALUE, hi=Long.MAX_VALUE;
    equal(call("normalize",list(new long[]{hi-1,hi},new long[]{lo,0},new long[]{0,hi-1})),new long[][]{{lo,hi}});
    equal(call("subtract",list(new long[]{lo,hi}),list(new long[]{-1,1})),new long[][]{{lo,-1},{1,hi}});
    if(!call("length",list(new long[]{lo,hi},new long[]{0,5})).equals(BigInteger.ONE.shiftLeft(64).subtract(BigInteger.ONE))) throw new AssertionError("overflow");
    if(!call("length",input).equals(BigInteger.valueOf(11))) throw new AssertionError("union length");
    for(String name:List.of("normalize","length","subtract")) {
     for(List<long[]> bad:Arrays.<List<long[]>>asList(null,list((long[])null),list(new long[]{}),list(new long[]{1}),list(new long[]{1,2,3}),list(new long[]{2,1}))) {
      if(name.equals("subtract")) { invalid(name,bad,List.of()); invalid(name,List.of(),bad); }
      else invalid(name,bad);
     }
    }
    equal(call("normalize",list(new long[]{0,0})),new long[][]{});
    equal(call("subtract",List.of(),List.of()),new long[][]{});
    if(!call("length",List.of()).equals(BigInteger.ZERO)) throw new AssertionError();
   }
  } finally {
   try(var paths=Files.walk(d)) { paths.sorted(Comparator.reverseOrder()).forEach(p->{try{Files.delete(p);}catch(Exception e){throw new RuntimeException(e);}}); }
  }
 }
}
