import copy
import unittest

from planner import plan


class Regressions(unittest.TestCase):
    def test_order_and_input_preservation(self):
        cases = [
            ({}, []),
            ({"z": ["b", "a", "b"], "c": [], "b": ["a"]},
             ["a", "b", "c", "z"]),
            ({"a": ["z"], "b": []}, ["b", "z", "a"]),
            ({"c": ["b"], "b": ["a"]}, ["a", "b", "c"]),
        ]
        for graph, expected in cases:
            with self.subTest(graph=graph):
                original = copy.deepcopy(graph)
                self.assertEqual(plan(graph), expected)
                self.assertEqual(plan(dict(reversed(list(graph.items())))), expected)
                self.assertEqual(graph, original)

    def test_cycles_only(self):
        graph = {"a": ["b", "b"], "b": ["a", "leaf"],
                 "downstream": ["a"], "tail": ["downstream"],
                 "self": ["self"], "x": ["y"], "y": ["x"],
                 "free": []}
        original = copy.deepcopy(graph)
        with self.assertRaises(ValueError) as caught:
            plan(graph)
        self.assertEqual(str(caught.exception), "cycle: a,b,self,x,y")
        self.assertEqual(graph, original)

    def test_malformed(self):
        cases = [None, [], "graph", {1: []}, {"": []},
                 {"a": None}, {"a": "b"}, {"a": ("b",)},
                 {"a": {"b"}}, {"a": {}}, {"a": [""]},
                 {"a": [1]}, {"a": [None]}, {"a": [["b"]]},
                 {"a": [], "z": ["valid", 3]},
                 {"cycle": ["cycle"], "bad": ()}]
        for graph in cases:
            with self.subTest(graph=graph):
                with self.assertRaises(ValueError):
                    plan(graph)

    def test_long_graph(self):
        graph = {str(i): [str(i + 1)] for i in range(1500)}
        self.assertEqual(plan(graph), [str(i) for i in range(1500, -1, -1)])
        graph["1500"] = ["1499"]
        with self.assertRaises(ValueError) as caught:
            plan(graph)
        self.assertEqual(str(caught.exception), "cycle: 1499,1500")
