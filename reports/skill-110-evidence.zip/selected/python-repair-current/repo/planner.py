import heapq


def plan(graph):
    if not isinstance(graph, dict):
        raise ValueError("graph must be a dict")
    for node, dependencies in graph.items():
        if not isinstance(node, str) or not node:
            raise ValueError("invalid node")
        if not isinstance(dependencies, list) or any(
            not isinstance(dep, str) or not dep for dep in dependencies
        ):
            raise ValueError("invalid dependencies")

    dependencies = {node: set(deps) for node, deps in graph.items()}
    for deps in graph.values():
        for dep in deps:
            dependencies.setdefault(dep, set())
    dependents = {node: set() for node in dependencies}
    for node, deps in dependencies.items():
        for dep in deps:
            dependents[dep].add(node)
    remaining = {node: len(deps) for node, deps in dependencies.items()}
    ready = [node for node, count in remaining.items() if count == 0]
    heapq.heapify(ready)
    order = []
    while ready:
        node = heapq.heappop(ready)
        order.append(node)
        for dependent in dependents[node]:
            remaining[dependent] -= 1
            if remaining[dependent] == 0:
                heapq.heappush(ready, dependent)
    if len(order) == len(dependencies):
        return order

    # Iterative Kosaraju traversal avoids a recursion limit on long graphs.
    seen = set()
    finished = []
    for root in dependencies:
        if root in seen:
            continue
        seen.add(root)
        stack = [(root, iter(dependencies[root]))]
        while stack:
            node, children = stack[-1]
            child = next(children, None)
            if child is None:
                finished.append(node)
                stack.pop()
            elif child not in seen:
                seen.add(child)
                stack.append((child, iter(dependencies[child])))
    seen.clear()
    cyclic = set()
    for root in reversed(finished):
        if root in seen:
            continue
        seen.add(root)
        component = set()
        stack = [root]
        while stack:
            node = stack.pop()
            component.add(node)
            for child in dependents[node]:
                if child not in seen:
                    seen.add(child)
                    stack.append(child)
        if len(component) > 1 or root in dependencies[root]:
            cyclic.update(component)
    raise ValueError("cycle: " + ",".join(sorted(cyclic)))
