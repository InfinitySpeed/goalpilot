function copyJSON(value: unknown, active = new Set<object>()): unknown {
  if (value === null || typeof value === 'string' || typeof value === 'boolean') return value;
  if (typeof value === 'number' && Number.isFinite(value)) return value;
  if (typeof value !== 'object' || value === null) throw new Error('Invalid JSON value');
  const array = Array.isArray(value);
  if (!array && Object.getPrototypeOf(value) !== Object.prototype && Object.getPrototypeOf(value) !== null)
    throw new Error('Invalid JSON object');
  if (active.has(value)) throw new Error('Cyclic JSON value');
  active.add(value);
  try {
    const result: any = array ? [] : {};
    if (array) {
      const items = value as unknown[];
      for (let i = 0; i < items.length; i++) {
        const descriptor = Object.getOwnPropertyDescriptor(items, String(i));
        if (!descriptor || !('value' in descriptor)) throw new Error('Invalid JSON array');
        result.push(copyJSON(descriptor.value, active));
      }
    }
    for (const key of Reflect.ownKeys(value)) {
      if (array && key === 'length') continue;
      if (typeof key !== 'string') throw new Error('Invalid JSON property');
      if (array && /^(0|[1-9][0-9]*)$/.test(key) && Number(key) < (value as unknown[]).length) continue;
      if (array) throw new Error('Invalid JSON array property');
      const descriptor = Object.getOwnPropertyDescriptor(value, key)!;
      if (!('value' in descriptor)) throw new Error('Invalid JSON property');
      Object.defineProperty(result, key, {value: copyJSON(descriptor.value, active), enumerable: true, writable: true, configurable: true});
    }
    return result;
  } finally { active.delete(value); }
}

export class Store {
  revision = 0;
  private entries = new Map<string, {value: unknown, version: number}>();
  get(key: string): {value: unknown, version: number} | undefined {
    const entry = this.entries.get(key);
    return entry && {value: copyJSON(entry.value), version: entry.version};
  }
  keys(): string[] { return [...this.entries.keys()]; }
  apply(ops: unknown): {revision: number, changed: string[]} {
    if (!Array.isArray(ops)) throw new Error('Expected operation array');
    if (!ops.length) return {revision: this.revision, changed: []};
    const revision = this.revision + 1;
    const next = new Map(this.entries);
    const changed = new Set<string>();
    for (const op of ops) {
      if (op === null || typeof op !== 'object' || Array.isArray(op) ||
          (Object.getPrototypeOf(op) !== Object.prototype && Object.getPrototypeOf(op) !== null) ||
          (op.type !== 'put' && op.type !== 'delete') || typeof op.key !== 'string' || !op.key.length)
        throw new Error('Invalid operation');
      if ('expectedVersion' in op && (!Number.isInteger(op.expectedVersion) || op.expectedVersion < 0 ||
          op.expectedVersion !== (next.get(op.key)?.version ?? 0))) throw new Error('Version conflict');
      if (op.type === 'put') next.set(op.key, {value: copyJSON(op.value), version: revision});
      else next.delete(op.key);
      changed.add(op.key);
    }
    this.entries = next;
    this.revision = revision;
    return {revision, changed: [...changed]};
  }
}
