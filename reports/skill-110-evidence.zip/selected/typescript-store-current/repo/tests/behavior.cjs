const assert = require('node:assert/strict');
const {Store} = require(process.env.STORE_MODULE);
const s = new Store();
const put = (key,value,expectedVersion) => ({type:'put',key,value,...(expectedVersion === undefined ? {} : {expectedVersion})});
assert.deepEqual(s.apply([]), {revision:0,changed:[]});
const input = {nested:[{a:1}], ['__proto__']:{safe:true}};
s.apply([put('a',input,0),put('__proto__',null),put('b',2)]);
input.nested[0].a = 7;
const output = s.get('a'); output.value.nested[0].a = 8; output.version = 9;
assert.equal(s.get('a').value.nested[0].a,1);
assert.equal(s.get('a').version,1);
assert.deepEqual(s.get('a').value.__proto__,{safe:true});
const keys = s.keys(); keys.reverse();
assert.deepEqual(s.keys(),['a','__proto__','b']);
const cycle = {}; cycle.self = cycle;
for (const bad of [undefined,NaN,Infinity,()=>{},1n,new Date(),cycle,[undefined],new Array(1),{x:undefined}]) {
  assert.throws(()=>s.apply([{type:'delete',key:'a'},put('new',1),put('bad',bad)]));
  assert.equal(s.revision,1);
  assert.deepEqual(s.keys(),['a','__proto__','b']);
  assert.equal(s.get('a').version,1);
  assert.equal(s.get('a').value.nested[0].a,1);
}
for (const bad of [null,{},[null],[{type:'wat',key:'a'}],[put('',1)],[{type:'delete',key:'a',expectedVersion:-1}],[{type:'delete',key:'a',expectedVersion:0.5}],[{type:'delete',key:'a',expectedVersion:0}]]) {
  assert.throws(()=>s.apply(bad)); assert.equal(s.revision,1);
}
assert.throws(()=>s.apply([put('a',3,1),put('a',4,1)]));
assert.equal(s.get('a').value.nested[0].a,1);
assert.deepEqual(s.apply([{type:'delete',key:'a',expectedVersion:1},put('a',3,0),put('a',4,2),{type:'delete',key:'missing',expectedVersion:0},put('temp',false),{type:'delete',key:'temp'}]),{revision:2,changed:['a','missing','temp']});
assert.deepEqual(s.keys(),['__proto__','b','a']);
assert.deepEqual(s.get('a'),{value:4,version:2});
assert.deepEqual(s.apply([]),{revision:2,changed:[]});
assert.equal(s.get('temp'),undefined);
const shared = {x:1}; s.apply([put('shared',[shared,shared])]);
assert.deepEqual(s.get('shared').value,[{x:1},{x:1}]);
