package quota

import (
 "reflect"
 "sync"
 "testing"
)

func TestConstruction(t *testing.T) {
 for _, c := range []struct{ l int; w int64 }{{0,1},{-1,1},{1,0},{1,-1}} {
  if q,e := New(c.l,c.w); q != nil || e == nil { t.Fatalf("New(%v): %v %v",c,q,e) }
 }
}
func TestRollingContract(t *testing.T) {
 q,e := New(5,10); if e != nil { t.Fatal(e) }
 for i,c := range []struct{k string; n int64; w int; ok,err bool}{
  {"a",0,2,true,false}, {"a",0,3,true,false},
  {"b",0,5,true,false}, {"a",9,1,false,false},
  {"a",10,4,true,false}, {"a",10,1,true,false},
  {"a",9,1,false,true}, {"a",20,5,true,false},
 } {
  ok,e := q.Allow(c.k,c.n,c.w)
  if ok != c.ok || (e != nil) != c.err { t.Fatalf("case %d: %v %v",i,ok,e) }
 }
 q.Reset("a")
 if ok,e := q.Allow("a",0,5); !ok || e != nil { t.Fatal(ok,e) }
 if ok,e := q.Allow("b",0,1); ok || e != nil { t.Fatal("reset affected other key",ok,e) }
 q.Reset(""); q.Reset("missing")
}
func TestRejectionsDoNotMutate(t *testing.T) {
 q,_ := New(5,10)
 q.Allow("a",0,1); q.Allow("a",5,4)
 before := keyState{last:q.keys["a"].last, entries:append([]entry(nil),q.keys["a"].entries...)}
 for _,c := range []struct{k string; n int64; w int; err bool}{
  {"a",10,2,false}, {"a",100,0,true}, {"a",100,6,true},
  {"a",100,-1,true}, {"a",-1,1,true}, {"a",4,1,true},
  {"",100,1,true}, {"new",-1,1,true},
 } {
  ok,e := q.Allow(c.k,c.n,c.w)
  if ok || (e != nil) != c.err { t.Fatalf("%v: %v %v",c,ok,e) }
  if len(q.keys) != 1 || !reflect.DeepEqual(before,q.keys["a"]) { t.Fatalf("mutated on %v",c) }
 }
 if ok,e := q.Allow("a",5,1); ok || e != nil { t.Fatal("denial advanced clock",ok,e) }
}
func TestLargeValues(t *testing.T) {
 max := int(^uint(0)>>1)
 q,_ := New(max,1<<63-1)
 if ok,e := q.Allow("a",0,max); !ok || e != nil { t.Fatal(ok,e) }
 if ok,e := q.Allow("a",1,max); ok || e != nil { t.Fatal(ok,e) }
 if ok,e := q.Allow("a",1<<63-1,max); !ok || e != nil { t.Fatal(ok,e) }
}
func TestConcurrent(t *testing.T) {
 q,_ := New(20,10)
 var wg sync.WaitGroup
 var mu sync.Mutex
 accepted := 0
 for i:=0;i<100;i++ { wg.Add(1); go func(){ defer wg.Done(); ok,e:=q.Allow("a",0,1); if e != nil {t.Error(e)}; if ok {mu.Lock();accepted++;mu.Unlock()} }() }
 wg.Wait()
 if accepted != 20 { t.Fatal(accepted) }
 for i:=0;i<100;i++ {wg.Add(1);go func(){defer wg.Done();q.Reset("a");q.Allow("a",0,1)}()}
 wg.Wait()
}
