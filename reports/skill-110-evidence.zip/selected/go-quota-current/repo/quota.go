package quota

import (
 "errors"
 "sync"
)

type entry struct { at int64; weight int }
type keyState struct { last int64; entries []entry }
type Quota struct {
 mu sync.Mutex
 limit int
 window int64
 keys map[string]keyState
}

func New(limit int, window int64) (*Quota, error) {
 if limit <= 0 || window <= 0 { return nil, errors.New("capacity and window must be positive") }
 return &Quota{limit:limit, window:window, keys:make(map[string]keyState)}, nil
}

func (q *Quota) Allow(key string, now int64, weight int) (bool, error) {
 q.mu.Lock()
 defer q.mu.Unlock()
 if key == "" || now < 0 || weight <= 0 || weight > q.limit { return false, errors.New("invalid key, timestamp or weight") }
 state, exists := q.keys[key]
 if exists && now < state.last { return false, errors.New("timestamp precedes last acceptance") }
 cutoff := now - q.window
 first, used := 0, 0
 for first < len(state.entries) && state.entries[first].at <= cutoff { first++ }
 for _, e := range state.entries[first:] { used += e.weight }
 if weight > q.limit-used { return false, nil }
 // Commit expiration and the clock only after acceptance.
 entries := append([]entry(nil), state.entries[first:]...)
 entries = append(entries, entry{now, weight})
 q.keys[key] = keyState{last:now, entries:entries}
 return true, nil
}

func (q *Quota) Reset(key string) {
 q.mu.Lock()
 defer q.mu.Unlock()
 delete(q.keys, key)
}
