from pathlib import Path
import json,shutil,subprocess,tempfile,os,sys,time,hashlib
BASE=Path('/workspace/goalpilot-runs/goalpilot-native-only-2026-10-24');ROWS=json.loads((BASE/'holdout.json').read_text());
ENV={'pallets__flask-4045':('pallets__flask-4045','src'),'psf__requests-2317':('psf__requests-863',None),'pytest-dev__pytest-7220':('pytest-dev__pytest-6116','src')}
def run(case,arm,rep):
 row=ROWS[case]; trial=BASE/'trials'/f'{case}-{arm}-r{rep}';repo=trial/'repo'; env_name,pythonpath=ENV[case];python=BASE/'envs'/env_name/'bin/python';nodes=json.loads(row['FAIL_TO_PASS']);patch=row.get('test_patch','')
 with tempfile.TemporaryDirectory(prefix='gp-native-holdout-') as td:
  root=Path(td);base=root/'base';shutil.copytree(BASE/'tasks'/case,base)
  patchfile=root/'holdout.patch';patchfile.write_text(patch)
  applied=subprocess.run(['git','apply',str(patchfile)],cwd=base,capture_output=True,text=True)
  if applied.returncode:return {'case':case,'arm':arm,'repeat':rep,'result':'grader_patch_unavailable','patch_sha256':hashlib.sha256(patch.encode()).hexdigest(),'stderr':applied.stderr[-500:]}
  work=root/'repo';shutil.copytree(repo,work);mapping=[]
  for node in nodes:
   source,caseid=node.split('::',1);src=base/source
   if not src.is_file():return {'case':case,'arm':arm,'repeat':rep,'result':'grader_source_missing','node':node}
   stem=src.stem+'_holdout'+src.suffix
   dest=src.with_name(stem);rel=dest.relative_to(base);out=work/rel;out.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,out)
   mapping.append((rel.as_posix(),caseid))
  env=os.environ.copy();env['PYTHONWARNINGS']='ignore::DeprecationWarning'
  if pythonpath:env['PYTHONPATH']=pythonpath
  else:env.pop('PYTHONPATH',None)
  argv=[str(python),'-m','pytest','-q']
  for filepath,caseid in mapping:argv.append(filepath+'::'+caseid)
  start=time.monotonic()
  try:r=subprocess.run(argv,cwd=work,env=env,capture_output=True,text=True,timeout=90)
  except subprocess.TimeoutExpired as exc:return {'case':case,'arm':arm,'repeat':rep,'result':'grader_timeout','seconds':round(time.monotonic()-start,2),'nodes':len(nodes)}
  return {'case':case,'arm':arm,'repeat':rep,'result':'pass' if r.returncode==0 else 'fail','returncode':r.returncode,'seconds':round(time.monotonic()-start,2),'nodes':len(nodes),'stdout_tail':(r.stdout+'\n'+r.stderr)[-1200:]}
if __name__=='__main__':print(json.dumps(run(*sys.argv[1:2],sys.argv[2],int(sys.argv[3])),ensure_ascii=False))
