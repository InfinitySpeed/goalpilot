from pathlib import Path
import hashlib,json,os,shutil,subprocess,sys,time
ROOT=Path('/workspace/goalpilot-public')
BASE=Path('/workspace/goalpilot-runs/goalpilot-native-only-2026-10-24')
TASKS=BASE/'tasks';TRIALS=BASE/'trials';ROWS=json.loads((BASE/'holdout.json').read_text())
VENV={'pallets__flask-4045':BASE/'envs/pallets__flask-4045/bin','psf__requests-2317':BASE/'envs/psf__requests-863/bin','pytest-dev__pytest-7220':BASE/'envs/pytest-dev__pytest-6116/bin'}
sys.path.insert(0,str(ROOT))
from goalpilot.rpc import AppServerAdapter
from evaluation.native_goals.adapter import NativeGoalAdapter
from goalpilot.engine import token_totals
INSTALL_ROOT=BASE/'staged-goalpilot'
def stage_installer():
 if INSTALL_ROOT.exists():shutil.rmtree(INSTALL_ROOT)
 INSTALL_ROOT.mkdir(parents=True)
 for name in ('install.py','PORTABLE_SKILL.json'):shutil.copy2(ROOT/name,INSTALL_ROOT/name)
 for name in ('skills/goalpilot','skills/goalpilot-016','integrations/native'):shutil.copytree(ROOT/name,INSTALL_ROOT/name)
 metadata=json.loads((INSTALL_ROOT/'PORTABLE_SKILL.json').read_text())
 source=metadata['active_native_workflow']['source_files']
 for name in source:source[name]=sha(INSTALL_ROOT/name)
 (INSTALL_ROOT/'PORTABLE_SKILL.json').write_text(json.dumps(metadata,indent=2)+'\n')

def put(p,v):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,indent=2,ensure_ascii=False)+'\n')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
class CandidateAdapter(AppServerAdapter):
 def __init__(self,skill):super().__init__('gpt-6.1-sol',executable='/opt/codex/bin/codex',effort='low');self.skill=skill
 def _request(self,method,params,deadline):
  if method=='thread/start':params={**params,'ephemeral':False,'sandbox':'workspace-write'}
  if method=='turn/start':params={**params,'input':[*params['input'],{'type':'skill','name':'goalpilot','path':str(self.skill/'SKILL.md')}]}
  return super()._request(method,params,deadline)
def run(case,arm,rep):
 row=ROWS[case];name=f'{case}-{arm}-r{rep}';folder=TRIALS/name;repo=folder/'repo'
 if folder.exists():raise RuntimeError('preserving existing trial '+str(folder))
 folder.mkdir(parents=True);shutil.copytree(TASKS/case,repo,symlinks=False)
 goal=row['problem_statement'];(folder/'goal.txt').write_text(goal,encoding='utf-8')
 basefiles={p.relative_to(repo).as_posix():sha(p) for p in sorted(repo.rglob('*')) if p.is_file() and '.git' not in p.parts}
 put(folder/'started.json',{'instance_id':case,'repo':row['repo'],'base_commit':row['base_commit'],'dataset':'princeton-nlp/SWE-bench_Lite test split','arm':arm,'repeat':rep,'goal_sha256':hashlib.sha256(goal.encode()).hexdigest(),'base_files_sha256':basefiles,'cache_control':'provider cache cannot be disabled','comparison':'matched Codex native /goal only; no previous GoalPilot arm'})
 skill=repo/'.agents/skills/goalpilot';envbin=VENV[case];os.environ['PATH']=str(envbin)+os.pathsep+os.environ.get('PATH','')
 if case.startswith(('pallets__flask','pytest-dev')):os.environ['PYTHONPATH']='src'
 else:os.environ.pop('PYTHONPATH',None)
 if arm=='goalpilot':
  stage_installer()
  result_install=subprocess.run([sys.executable,str(INSTALL_ROOT/'install.py'),'--profile','stable','--host','codex','--target',str(skill)],capture_output=True,text=True,timeout=60)
  if result_install.returncode:raise RuntimeError(result_install.stdout+'\n'+result_install.stderr)
  put(folder/'install.json',json.loads(result_install.stdout))
  evidence=Path('/tmp/goalpilot-native-paired-evidence')/name
  test_prefix='/usr/bin/env '+('PYTHONPATH=src ' if case.startswith(('pallets__flask','pytest-dev')) else '')+str(envbin/'python')+' -m pytest'
  rules=RULES+'\nFor project tests, use this exact absolute command prefix: '+test_prefix+'.'
  prompt=('$goalpilot\n'+goal+'\n\n'+rules+'\n\nBefore freezing acceptance, inspect the final diff and ensure each changed test file has a required direct check. If verification fails or test files change after delivery, amend the acceptance using the native command: amend RUN --criteria-file JSON --reason "specific gap". Preserve the original criterion quotes and failed attempt. Use --wall-seconds 420 --max-verifications 5. Report the exact final test commands and blockers.\nGoalPilot evidence directory: '+str(evidence))
  start=time.monotonic()
  with CandidateAdapter(skill) as adapter:result=adapter.execute(prompt,repo,600,folder/'caller')
  elapsed=time.monotonic()-start;status=None
  if (evidence/'session.json').exists():
   sr=subprocess.run([sys.executable,str(skill/'scripts/native.py'),'status',str(evidence)],capture_output=True,text=True)
   (folder/'goalpilot-status.txt').write_text(sr.stdout+'\n'+sr.stderr)
   try:status=json.loads(sr.stdout)
   except ValueError:status={'status':'invalid','stdout':sr.stdout[-1000:]}
  mode='goalpilot'
 elif arm=='native':
  test_prefix='/usr/bin/env '+('PYTHONPATH=src ' if case.startswith(('pallets__flask','pytest-dev')) else '')+str(envbin/'python')+' -m pytest'
  objective=goal+'\n\n'+RULES+'\nFor project tests, use this exact absolute command prefix: '+test_prefix+'.'
  start=time.monotonic()
  with NativeGoalAdapter('gpt-6.1-sol',executable='/opt/codex/bin/codex',effort='low') as adapter:result=adapter.execute_goal(objective,repo,600,folder/'caller')
  elapsed=time.monotonic()-start;status=result.telemetry.get('native_goal_at_stop');mode='codex-native-goal'
 else:raise ValueError('arm')
 put(folder/'caller-result.json',result.to_dict());usage=token_totals([{'result':result.to_dict()}])
 out={'instance_id':case,'arm':arm,'repeat':rep,'mode':mode,'wall_seconds':elapsed,'usage':usage,'returncode':result.returncode,'timed_out':result.timed_out,'fatal':result.fatal,'usage_complete':result.usage_complete,'status':status,'final_message':result.message[-3000:]}
 put(folder/'result.json',out);print(json.dumps(out,ensure_ascii=False),flush=True)
RULES='''Constraints: do not use network or nested agents/models. Do not inspect files outside this task repository, the installed skill, or the session evidence. Do not inspect hidden tests, benchmark records, or sibling trials. Use the project virtualenv Python on PATH for pytest. Preserve existing behavior except where this request explicitly changes it. Verify the requested behavior and relevant regressions. Report completion only when the evidence supports it.'''
if __name__=='__main__':run(sys.argv[1],sys.argv[2],sys.argv[3])
