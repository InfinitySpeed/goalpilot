"""Reproducible local proxy for file relevance under the unchanged 18k context budget."""
import importlib.util
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('native_context',ROOT/'integrations/native/native.py')
native=importlib.util.module_from_spec(spec);spec.loader.exec_module(native)
goal='Repair auth token expiry contract and preserve its regression tests'
payload={'AGENTS.md':'rules '*200,'README.md':'overview '*100,
        'src/auth_token_expiry.py':'relevant source '*140,
        'tests/test_auth_token_expiry.py':'relevant test '*140}
payload.update({f'docs/aaa_{i:02}.md':'unrelated '*650 for i in range(24)})
relevant={'src/auth_token_expiry.py','tests/test_auth_token_expiry.py'}

def selected(order):
    used=0;kept=[]
    for name in order:
        if used>=18000:break
        text=payload[name];room=18000-used-len(name)-40
        if room<=0:break
        limit=min(len(text),6000,room)
        used+=len(f'FILE {name} complete={limit==len(text)}\n')+limit+1
        kept.append(name)
    return used,kept

baseline_chars,baseline=selected(sorted(payload,key=lambda n:(Path(n).name not in ('AGENTS.md','README.md','package.json','pyproject.toml','Makefile','Cargo.toml','go.mod'),n)))
candidate_chars,candidate=selected(native.context_order(payload,goal))
before=len(relevant&set(baseline));after=len(relevant&set(candidate))
assert before==0,(before,baseline)
assert after==2,(after,candidate)
assert candidate_chars<=18000 and baseline_chars<=18000
print(f'local synthetic context proxy: relevant files retained {before}/{len(relevant)} -> {after}/{len(relevant)}; chars {baseline_chars} -> {candidate_chars}; caller tokens/cache/model savings: NOT MEASURED')
