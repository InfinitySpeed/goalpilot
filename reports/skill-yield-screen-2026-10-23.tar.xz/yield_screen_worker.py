"""Frozen paired contemporary skill comparison with historical controls retained."""
from pathlib import Path
import argparse,hashlib,importlib.util,json,os,shutil,subprocess,sys,time
ROOT=Path(__file__).resolve().parent;PRODUCT=Path('/workspace/goalpilot-public');HIST=Path('/workspace/goalpilot-research/thin-skill-002')
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def hashes(p):return {str(f.relative_to(p)):sha(f)for f in sorted(p.rglob('*'))if f.is_file()and'__pycache__'not in f.parts and f.suffix!='.pyc'}
def put(p,v):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
def register(name):
 d=ROOT/name;assert not d.exists();d.mkdir();(d/'harness').mkdir();(d/'source').mkdir()
 for folder in ('goalpilot','integrations','skills/goalpilot','skills/goalpilot-016','tests'):
  shutil.copytree(PRODUCT/folder,d/'source'/folder,ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
 shutil.copy2(PRODUCT/'install.py',d/'source/install.py')
 for f in ('cases.py','races.py','host_helpers.py','host_process.py','grading-amendment-subscriptions.json','grading-interpretation-annotations.json'):
  shutil.copy2(HIST/f,d/'harness'/f)
 for src,dst in ((HIST/'analysis-reviewed.json','historical-controls.json'),(PRODUCT/'reports/engine-promotion-2026-10-23.json','standalone-control.json'),(ROOT/'offline-tests-dedup.json','ci.json')):shutil.copy2(src,d/dst)
 cases=json.loads((HIST/'protocol.json').read_text())['cases']
 p={'registered_at':time.time(),'cases':cases,'order':[{'case':case,'arms':['old','new']if i%2==0 else['new','old']}for i,case in enumerate(cases)],
 'hook_setup':'Both arms use the identical zero-model launcher with process-only deduplication of exact verified pre-existing GoalPilot handlers; unrelated/managed hooks preserved. Effective configuration verified by hooks/list before inference. No global settings writes.','receipt_discovery':'Read the requested evidence directory, or its unique nested session-state receipt when the agent used a subdirectory. Never select among multiple receipts or by outcome. Goal bytes must match exactly.','model':'gpt-6.1-sol','effort':'low','sandbox':'danger-full-access','approval':'never','max_wall_seconds_per_caller':600,'max_session_verifications':5,'soft_raw_tokens_per_goal':700000,
 'campaign_raw_cap':5000000,'campaign_uncached_plus_output_cap':800000,'all_development_and_calibration_costs_count':True,'source_hashes':hashes(d/'source'),'harness_hashes':hashes(d/'harness'),'worker_sha256':sha(__file__),'historical_controls_sha256':sha(d/'historical-controls.json'),'standalone_control_sha256':sha(d/'standalone-control.json'),'ci_sha256':sha(d/'ci.json'),
 'planned_pairs':20,'planned_calls':40,'no_retries_or_replacements':True,'carry_development_outcomes':False,
 'arms':{'old':'Exact archived Codex Skill1.3.1 / engine0.12.1, original instructions and native Stop hooks','new':'Skill1.7.0 / exact frozen engine0.16.0, begin+deliver wrappers, mapped criteria and same native Stop-hook mode; portable explicit fallback tested offline'},
 'completion':'Normal provider closure, closed scope_passed, zero nested engine calls AND all10 independent reviewed judge groups. New skill additionally requires goal_complete:true; old scope predates that mapped requirement. Same preregistered historical amendments; strict scores also retained. No judge feedback.',
 'primary_gates':{'new_correct':20,'min_time_gain_vs_contemporary_old_percent':10,'min_raw_and_uncached_plus_output_gain_vs_contemporary_old_percent':15,'max_regression_tolerance_percent':3,'min_time_gain_vs_historical_native_percent':25,'min_raw_uncached_input_output_gain_vs_historical_native_percent':45},
 'rapid_screen':'After first2 fixed complete pairs (4 calls): all new outcomes correct, all meters complete; candidate time <= contemporary old*1.03, candidate raw and uncached+output <= old*.85. If passed retain these preregistered primary pairs and continue unchanged. If failed preserve all outcomes, stop remaining36calls and do not promote.',
 'historical_gate_disclosure':'The earlier two-case adapters did not pass the historical old time target. An unchanged-old contemporaneous accounting diagnostic measured152.968s vs60.620s archived,124022raw vs79010raw. Current serving/cache/load may differ; a fresh interleaved old control is therefore the primary product comparison. Historical old/native/standalone remain mandatory displayed comparisons, including regressions. This protocol is registered before any paired outcomes; it does not overwrite earlier gates or results.',
 'prior_cohort_exclusion':'paired-170-001 retained but ineligible for promotion: global and process GoalPilot hooks ran concurrently, causing old-control Stop lock/artifact conflicts. RC1–RC5 pilots and old calibration also retained as research, not pooled into clean primary. No previous result rerun or replaced within its cohort.',
 'scope':'Familiar synthetic Python service goals used during development, not a blind holdout. One outcome per case/arm, descriptive totals not general population claims. Current old is interleaved; native and standalone controls are historical. No cross-host performance or exact subscription quota conversion. Whole calling thread and independent judging timed; fixtures, evidence copying and research meta-conversation excluded. All failed attempts remain.'}
 shutil.copy2(__file__,d/'worker.py');put(d/'protocol.json',p);print('REGISTERED',name,flush=True)
def run(name,case,arm):
 d=ROOT/name;p=json.loads((d/'protocol.json').read_text());assert case in p['cases']and arm in ('old','new');assert hashes(d/'source')==p['source_hashes'];assert hashes(d/'harness')==p['harness_hashes'];assert sha(__file__)==p['worker_sha256'];assert sha(d/'candidate-SKILL.md')==p['candidate_sha256']
 rows=[json.loads(f.read_text())for f in (d/'trials').glob('*/result.json')]
 assert all(r['usage']['usage_complete']for r in rows),'Incomplete meter blocks more inference'
 assert sum(r['usage']['total_tokens']for r in rows)<p['campaign_raw_cap'],'Shared raw research cap'
 assert sum(r['usage']['uncached_tokens']for r in rows)<p['campaign_uncached_plus_output_cap'],'Shared uncached research cap'
 ident=case+'-'+arm;trial=d/'trials'/ident;assert not trial.exists(),'Never restart a started trial';trial.mkdir(parents=True)
 sys.path[:0]=[str(d/'source'),str(d/'harness')]
 from goalpilot.rpc import AppServerAdapter
 from goalpilot.engine import token_totals
 from host_process import run_process
 import cases
 work=ROOT/'work'/name/ident;work.mkdir(parents=True);repo=work/'repo';goal=cases.materialize(case,repo);subprocess.run(['git','init','-q',str(repo)],check=True)
 local=repo/'.agents/skills/goalpilot';run_dir=work/'session';source=d/'source/skills/goalpilot-016'
 class Skill(AppServerAdapter):
  def _request(self,method,params,deadline):
   if method=='thread/start':params={**params,'ephemeral':False,'sandbox':'danger-full-access','config':{'model_reasoning_effort':'low'}}
   if method=='turn/start':params={**params,'input':[*params['input'],{'type':'skill','name':'goalpilot','path':str(local/'SKILL.md')}]}
   return super()._request(method,params,deadline)
  def _start(self,repo,planning,log_dir,deadline):
   super()._start(repo,planning,log_dir,deadline)
   listed=self._request('skills/list',{'cwds':[str(repo)],'forceReload':True},deadline)
   assert any(s.get('enabled')and s.get('path')==str(local/'SKILL.md')for e in listed.get('data',[])for s in e.get('skills',[]))
 prompt=f'''$goalpilot
Repository: {repo}. Implement EVERY original public workflow in README.md, preserve original tests/data, choose reversible details autonomously. Python stdlib, no external dependencies/credentials/network required, actual localhost HTTP allowed.
Read ONLY this repository, original goal, selected skill and this goal's own evidence. Do not inspect external research harnesses, judges, other tasks/projects or previous runs. No delegated agents/models/nested Codex. Your meaningful tests may guide repairs; independent judging runs after final outcome, no feedback.
ORIGINAL USER GOAL (verbatim):
{goal}
Use ONLY the selected installed GoalPilot skill at {local/'SKILL.md'}. Evidence {run_dir}. Preserve the original goal verbatim as UTF8 within THIS session. Forward --wall-seconds 600 --max-verifications 5 --max-tokens 700000. No standalone controller. Finish concisely and factually.'''
 put(trial/'started.json',{'at':time.time(),'goal':goal,'arm':arm});started=time.monotonic()
 installed=subprocess.run([sys.executable,str(d/'source/install.py'),'--profile','candidate','--host','codex','--target',str(local)],capture_output=True,text=True)
 assert installed.returncode==0,installed.stderr
 installation=json.loads(installed.stdout)
 if arm=='new':
  original=(local/'SKILL.md').read_text(); start=original.index('## Installed runtime'); end=original.index('GP =',start)
  candidate=(d/'candidate-SKILL.md').read_text().replace('# GoalPilot\n','# GoalPilot\n\n'+original[start:end],1)
  (local/'SKILL.md').write_text(candidate)
  manifest=json.loads((local/'MANIFEST.json').read_text());manifest['files']['SKILL.md']=sha(local/'SKILL.md');put(local/'MANIFEST.json',manifest)
 put(trial/'installation.json',installation)
 shim=d/('codex-hooked-'+arm)
 if not shim.exists():
  launcher=d/'source/skills/goalpilot-016/scripts/codex_launch.py'
  shim.write_text('#!'+sys.executable+'\nimport os,sys\nos.execv(sys.executable,[sys.executable,'+repr(str(launcher))+',"--bundle",'+repr(str(source))+',"--codex-executable","/opt/codex/bin/codex","--receipt",os.environ["GOALPILOT_PAIRED_SETUP_RECEIPT"],"--",*sys.argv[1:]])\n');shim.chmod(0o700)
 os.environ['GOALPILOT_PAIRED_SETUP_RECEIPT']=str(trial/'hooks-setup.json')
 with Skill('gpt-6.1-sol',executable=str(shim),effort='low')as adapter:r=adapter.execute(prompt,repo,600,trial/'caller')
 seconds=time.monotonic()-started;put(trial/'caller-result.json',r.to_dict());usage=token_totals([{'result':r.to_dict()}]);requested_run_dir=run_dir
 if not(run_dir/'session-state.json').exists()and run_dir.exists():
  receipts=list(run_dir.rglob('session-state.json'))
  if len(receipts)==1:run_dir=receipts[0].parent
 state=json.loads((run_dir/'session-state.json').read_text())if(run_dir/'session-state.json').exists()else{}
 shutil.copytree(repo,trial/'delivered',ignore=shutil.ignore_patterns('.git','__pycache__','*.pyc','.agents'))
 strict=cases.judge(case,trial/'delivered',trial/'strict-judge');reviewed=strict;extra=0
 if case in ('subscriptions','annotations'):
  note=json.loads((d/'harness'/('grading-amendment-subscriptions.json'if case=='subscriptions'else'grading-interpretation-annotations.json')).read_text())
  program=cases.judge_program(case);assert hashlib.sha256(program.encode()).hexdigest()==note['original_program_sha256'];program=program.replace(note['original_condition'],note['corrected_condition'if case=='subscriptions'else'sensitivity_condition']);assert hashlib.sha256(program.encode()).hexdigest()==note['corrected_program_sha256'if case=='subscriptions'else'interpretation_program_sha256']
  dest=trial/'reviewed-judge';dest.mkdir();script=dest/'judge.py';script.write_text(program);j=run_process([sys.executable,'-B',str(script),str(trial/'delivered')],trial/'delivered',90,env={**os.environ,'PYTHONPATH':str(d/'harness'),'PYTHONOPTIMIZE':'0'},log_path=dest/'judge.log');groups=[x[5:]for x in j.output.splitlines()if x.startswith('PASS ')];reviewed={'correct':j.returncode==0 and len(groups)==10,'groups_passed':groups,'seconds':j.duration_seconds,'returncode':j.returncode};extra=j.duration_seconds;put(dest/'result.json',reviewed)
 assessment={}
 if(run_dir/'session.json').exists():
  status=subprocess.run([sys.executable,str(local/'scripts'/'host.py'),'session','status',str(run_dir)],cwd=repo,capture_output=True,text=True)
  if status.returncode==0:assessment=json.loads(status.stdout)
 preserved=(run_dir/'goal.bin').exists()and(run_dir/'goal.bin').read_bytes()==goal.encode('utf8')
 closed=bool(r.returncode==0 and state.get('closed')and state.get('status')=='scope_passed'and assessment.get('goal_complete'))
 row={'cohort':name,'case':case,'arm':arm,'success':closed and reviewed['correct']and preserved,'normal_closure':closed,'goal_complete':assessment.get('goal_complete'),'goal_verbatim_preserved':preserved,'strict_correct':strict['correct'],'reviewed_correct':reviewed['correct'],'caller_seconds':seconds,'judge_seconds':strict['seconds']+extra,'seconds':seconds+strict['seconds']+extra,'usage':usage,'status':state.get('status'),'model':r.telemetry.get('model'),'fatal':r.fatal,'message':r.message[-2500:],'calls':1,'engine_model_calls':state.get('engine_model_calls'),'completion_owner':state.get('completion_owner'),'source_unchanged':hashes(d/'source')==p['source_hashes'],'requested_evidence':str(requested_run_dir),'actual_evidence':str(run_dir),'hooks_setup':json.loads((trial/'hooks-setup.json').read_text()),'installed_skill_sha256':sha(local/'SKILL.md'),'installed_files':hashes(local),'strict_judge':strict,'reviewed_judge':reviewed}
 if run_dir.exists():shutil.copytree(run_dir,trial/'session',ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
 put(trial/'result.json',row);print(json.dumps(row,ensure_ascii=False),flush=True);return 0 if usage['usage_complete']else 3
if __name__=='__main__':
 if sys.argv[1]=='register':register(sys.argv[2])
 else:raise SystemExit(run(*sys.argv[2:]))
