import csv
import io
import re
from goalpilot_runtime import ReplayService, fields, text, integer, boolean, require, get_record


def banner():
    return 'Local Ops — café'


def columns(value):
    require(isinstance(value, list) and bool(value), 'Columns required')
    seen = set()
    for col in value:
        fields(col, {'name': text, 'type': text, 'required': boolean})
        require(col['type'] in ('text', 'integer', 'money'), 'Unknown column type')
        require(col['name'] not in seen, 'Duplicate column')
        seen.add(col['name'])


def header(raw, schema):
    text_value = isinstance(raw, str)
    require(text_value, 'CSV must be a string')
    reader = csv.reader(io.StringIO(raw, newline=''), strict=True)
    try:
        names = next(reader)
    except (StopIteration, csv.Error) as exc:
        raise ValueError('Invalid CSV header') from exc
    require(names == [c['name'] for c in schema['columns']], 'Header mismatch')
    return reader


def normalize(raw, schema):
    require(len(raw) == len(schema['columns']), 'Wrong cell count')
    row = {}
    for cell, col in zip(raw, schema['columns']):
        cell = cell.strip()
        require(cell != '' or not col['required'], 'Required value: ' + col['name'])
        if col['type'] == 'text':
            value = cell
        elif not cell:
            value = None
        elif col['type'] == 'integer':
            require(re.fullmatch(r'[+-]?[0-9]+', cell) is not None, 'Invalid integer: ' + col['name'])
            value = int(cell)
        else:
            require(re.fullmatch(r'[0-9]+(?:\.[0-9]{1,2})?', cell) is not None, 'Invalid money: ' + col['name'])
            whole, _, fraction = cell.partition('.')
            value = int(whole) * 100 + int((fraction + '00')[:2])
        row[col['name']] = value
    require(bool(row[schema['key']]), 'Empty primary key')
    return row


class Service(ReplayService):
    def initial(self):
        return {'schemas': {}, 'jobs': {}, 'datasets': {}, 'keys': {}}

    def job_view(self, job):
        return {k: v for k, v in job.items() if k != 'snapshot'}

    def create(self, state, data):
        fields(data, {'id': text, 'schema': text, 'csv': lambda x: require(isinstance(x, str))})
        require(data['id'] not in state['jobs'], 'Job exists')
        schema = get_record(state['schemas'], data['schema'])
        header(data['csv'], schema)
        job = dict(data, status='draft', revision=1, snapshot=schema,
                   schema_revision=schema['revision'])
        state['jobs'][data['id']] = job
        return self.job_view(job)

    def handle(self, state, op, data):
        if op == 'schema.put':
            fields(data, {'id': text, 'columns': columns, 'key': text})
            require(any(c['name'] == data['key'] and c['type'] == 'text' and c['required']
                        for c in data['columns']), 'Key must be required text')
            revision = state['schemas'].get(data['id'], {}).get('revision', 0) + 1
            schema = dict(data, revision=revision)
            state['schemas'][data['id']] = schema
            return schema
        if op == 'job.create':
            return self.create(state, data)
        if op == 'job.import':
            fields(data, {'jobs': lambda x: require(isinstance(x, list))})
            for item in data['jobs']:
                self.create(state, item)
            return {'imported': len(data['jobs'])}
        if op == 'dataset.get':
            fields(data, {'schema': text})
            return get_record(state['datasets'], data['schema'])
        if op == 'job.run':
            fields(data, {'id': text, 'key': text})
            if data['key'] in state['keys']:
                saved = state['keys'][data['key']]
                require(saved['request'] == data and saved['operation'] == op, 'Idempotency conflict')
                return saved['result']
            job = get_record(state['jobs'], data['id'])
            require(job['status'] == 'draft', 'Job must be draft')
            schema = job['snapshot']
            reader = header(job['csv'], schema)
            rows, rejects, seen = [], [], set()
            while True:
                try:
                    raw = next(reader)
                except StopIteration:
                    break
                except csv.Error as exc:
                    rejects.append({'row': reader.line_num, 'reason': str(exc) or 'Invalid CSV'})
                    break
                try:
                    row = normalize(raw, schema)
                    key = row[schema['key']]
                    require(key not in seen, 'Duplicate primary key')
                    seen.add(key)
                    rows.append(row)
                except ValueError as exc:
                    rejects.append({'row': reader.line_num, 'reason': str(exc) or 'Invalid row'})
            result = {'id': job['id'], 'status': 'processed', 'accepted': len(rows),
                      'rejected': len(rejects), 'rows': rows, 'rejects': rejects,
                      'schema_revision': schema['revision']}
            job.update(result)
            state['keys'][data['key']] = {'operation': op, 'request': data, 'result': result}
            return result
        if op == 'job.publish':
            fields(data, {'id': text, 'expected_revision': lambda x: integer(x, minimum=1)})
            job = get_record(state['jobs'], data['id'])
            require(job['status'] == 'processed' and job['revision'] == data['expected_revision'],
                    'Publication status/revision conflict')
            job.update(status='published', revision=2)
            state['datasets'][job['schema']] = {'job': job['id'], 'rows': job['rows'],
                                               'schema_revision': job['schema_revision']}
            return self.job_view(job)
        if op == 'job.retry':
            fields(data, {'id': text, 'csv': lambda x: require(isinstance(x, str))})
            job = get_record(state['jobs'], data['id'])
            require(job['status'] == 'processed', 'Job cannot be retried')
            header(data['csv'], job['snapshot'])
            for key in ('accepted', 'rejected', 'rows', 'rejects'):
                job.pop(key, None)
            job.update(csv=data['csv'], status='draft')
            return self.job_view(job)
        if op in ('job.get', 'job.export'):
            fields(data, {'id': text})
            job = get_record(state['jobs'], data['id'])
            if op == 'job.get':
                return self.job_view(job)
            require(job['status'] in ('processed', 'published'), 'Job is not processed')
            out = io.StringIO(newline='')
            names = [c['name'] for c in job['snapshot']['columns']]
            writer = csv.writer(out)
            writer.writerow(names)
            for row in job['rows']:
                writer.writerow(['' if row[n] is None else row[n] for n in names])
            return out.getvalue()
        raise ValueError('Unknown operation')


if __name__ == '__main__':
    Service.main()
