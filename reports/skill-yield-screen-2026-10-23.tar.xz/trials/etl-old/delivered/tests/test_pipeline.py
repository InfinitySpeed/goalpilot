import copy
import csv
import io
import unittest
from app import Service
from goalpilot_support import JourneyMixin, rejects


COLS = [{'name': 'id', 'type': 'text', 'required': True},
        {'name': 'n', 'type': 'integer', 'required': False},
        {'name': 'cost', 'type': 'money', 'required': True}]


class Pipeline(JourneyMixin, unittest.TestCase):
    def setUp(self):
        self.open_service(Service)

    def test_journey(self):
        def flow(c):
            schema = c('schema.put', id='café', columns=COLS, key='id')
            self.assertEqual(schema['revision'], 1)
            raw = 'id,n,cost\na,bad,1\na, +12 ,9007199254740993.01\na,2,1\n"é\nx",,0.02\nb,1,1.001\nc,1\nd,1,1,extra\n'
            created = c('job.create', id='j', schema='café', csv=raw)
            self.assertEqual(created['status'], 'draft')
            c('schema.put', id='café', columns=[COLS[0]], key='id')
            rejects(lambda: c('job.create', id='bad', schema='café', csv=raw))
            result = c('job.run', id='j', key='once')
            self.assertEqual(result['accepted'], 2)
            self.assertEqual(result['rejected'], 5)
            self.assertEqual([r['row'] for r in result['rejects']], [2, 4, 7, 8, 9])
            self.assertEqual(result['schema_revision'], 1)
            self.assertEqual(result['rows'], [{'id': 'a', 'n': 12, 'cost': 900719925474099301},
                                               {'id': 'é\nx', 'n': None, 'cost': 2}])
            self.assertEqual(c('job.run', id='j', key='once'), result)
            rejects(lambda: c('job.run', id='j', key='new'))
            exported = list(csv.reader(io.StringIO(c('job.export', id='j'))))
            self.assertEqual(exported[1], ['a', '12', '900719925474099301'])
            c('job.retry', id='j', csv='id,n,cost\nz,-0,2.5\n')
            self.assertEqual(c('job.run', id='j', key='once'), result)
            fresh = c('job.run', id='j', key='twice')
            self.assertEqual(fresh['rows'], [{'id': 'z', 'n': 0, 'cost': 250}])
            rejects(lambda: c('job.publish', id='j', expected_revision=True))
            rejects(lambda: c('job.publish', id='j', expected_revision=2))
            c('job.publish', id='j', expected_revision=1)
            self.assertEqual(c('dataset.get', schema='café'), {'job': 'j', 'rows': fresh['rows'], 'schema_revision': 1})
            rejects(lambda: c('job.retry', id='j', csv='id,n,cost\n'))
            rejects(lambda: c('job.publish', id='j', expected_revision=2))
            snap = c('backup')
            rejects(lambda: c('job.import', jobs=[{'id': 'other', 'schema': 'café', 'csv': 'id\nx\n'},
                                                 {'id': 'j', 'schema': 'café', 'csv': 'id\ny\n'}]))
            rejects(lambda: c('job.get', id='other'))
            c('job.import', jobs=[{'id': 'next', 'schema': 'café', 'csv': 'id\n new \n'}])
            c('job.run', id='next', key='third')
            c('job.publish', id='next', expected_revision=1)
            self.assertEqual(c('dataset.get', schema='café')['rows'], [{'id': 'new'}])
            c('restore', state=snap)
            self.assertEqual(c('dataset.get', schema='café')['job'], 'j')
            rejects(lambda: c('job.get', id='next'))
            c('job.create', id='continued', schema='café', csv='id\nok\n')
            self.assertEqual(c('job.get', id='j')['csv'], 'id,n,cost\nz,-0,2.5\n')
        self.assertJourney(flow)

    def test_atomic_validation_and_snapshots(self):
        self.c('schema.put', id='s', columns=COLS, key='id')
        for col in ([dict(COLS[0], required=1)], [dict(COLS[0], type='float')], [COLS[0], COLS[0]]):
            self.assertRejects('schema.put', id='s', columns=col, key='id')
        self.assertRejects('job.create', id='x', schema='s', csv='wrong\na\n')
        self.c('job.create', id='j', schema='s', csv='id,n,cost\nx,1.0,1\nx,1e2,1\nx,True,1\nx,1,-1\nx,1,NaN\nx,+2,0.01\n')
        r = self.c('job.run', id='j', key='k')
        self.assertEqual((r['accepted'], r['rejected']), (1, 5))
        r['rows'][0]['cost'] = -1
        self.assertEqual(self.c('job.get', id='j')['rows'][0]['cost'], 1)
        self.assertRejects('job.run', id='missing', key='k')
        self.restart()
        self.assertEqual(self.c('job.get', id='j')['accepted'], 1)
        snap = self.c('backup')
        broken = copy.deepcopy(snap)
        broken['state']['jobs']['j']['rows'][0]['cost'] = -1
        self.assertRejects('restore', state=broken)
        broken = copy.deepcopy(snap)
        broken['state']['schemas']['s']['revision'] = 99
        self.assertRejects('restore', state=broken)
        self.assertRejects('restore', state={})

    def test_concurrent_publication(self):
        self.c('schema.put', id='s', columns=[COLS[0]], key='id')
        self.c('job.create', id='j', schema='s', csv='id\na\n')
        self.c('job.run', id='j', key='run')
        results = self.race(*[('job.publish', {'id': 'j', 'expected_revision': 1})] * 2)
        self.assertEqual(sum(ok for ok, _ in results), 1)
        self.assertEqual(self.c('job.get', id='j')['revision'], 2)
        results = self.race(('schema.put', {'id': 's', 'columns': [COLS[0]], 'key': 'id'}),
                            ('schema.put', {'id': 's', 'columns': [COLS[0]], 'key': 'id'}))
        self.assertEqual(sorted(r['revision'] for ok, r in results if ok), [2, 3])
