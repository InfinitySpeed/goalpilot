"""Local, exact double-entry ledger. See README.md for the public contract."""
from goalpilot_runtime import (ReplayService, fields, text, integer, choice,
                              sequence, require, get_record, idempotent)


def banner():
    return 'Local Ops — café'


def line(value):
    fields(value, {'account': text, 'debit': integer, 'credit': integer})
    require((value['debit'] > 0) != (value['credit'] > 0),
            'Each line needs exactly one positive side')


def post_fields(value):
    fields(value, {'id': text, 'date': integer,
                   'lines': sequence(line, nonempty=True), 'key': text})
    require(len(value['lines']) >= 2, 'At least two lines required')
    debit = sum(row['debit'] for row in value['lines'])
    credit = sum(row['credit'] for row in value['lines'])
    require(debit == credit and debit > 0, 'Unbalanced entry')


class Service(ReplayService):
    def initial(self):
        return {'accounts': {}, 'periods': {}, 'entries': {},
                'reversal_of': {}, 'keys': {}}

    def open_period(self, state, date):
        matches = [p for p in state['periods'].values()
                   if p['start'] <= date < p['end']]
        require(len(matches) == 1 and matches[0]['status'] == 'open',
                'Date must belong to an open period')
        return matches[0]['id']

    def post(self, state, data):
        post_fields(data)
        def commit():
            require(data['id'] not in state['entries'], 'Entry already exists')
            for row in data['lines']:
                get_record(state['accounts'], row['account'])
            period = self.open_period(state, data['date'])
            entry = {'id': data['id'], 'date': data['date'], 'period': period,
                     'lines': data['lines'], 'status': 'posted', 'reversal': None}
            state['entries'][data['id']] = entry
            return entry
        return idempotent(state, data['key'], 'journal.post', data, commit)

    def balance(self, state, account):
        get_record(state['accounts'], account)
        rows = [row for entry in state['entries'].values()
                for row in entry['lines'] if row['account'] == account]
        debit = sum(row['debit'] for row in rows)
        credit = sum(row['credit'] for row in rows)
        return {'debit': debit, 'credit': credit, 'net': debit - credit}

    def handle(self, state, operation, data):
        accounts, periods, entries = (state[k] for k in ('accounts', 'periods', 'entries'))
        if operation == 'account.create':
            fields(data, {'id': text, 'name': text,
                          'kind': choice('asset', 'liability', 'income', 'expense')})
            require(data['id'] not in accounts, 'Account already exists')
            accounts[data['id']] = data
            return data
        if operation == 'period.create':
            fields(data, {'id': text, 'start': integer, 'end': integer})
            require(data['id'] not in periods, 'Period already exists')
            require(data['end'] > data['start'], 'Invalid period bounds')
            require(all(data['end'] <= p['start'] or data['start'] >= p['end']
                        for p in periods.values()), 'Overlapping periods')
            period = dict(data, status='open', revision=1)
            periods[data['id']] = period
            return period
        if operation in ('period.close', 'period.reopen'):
            fields(data, {'id': text, 'expected_revision': integer})
            period = get_record(periods, data['id'])
            require(period['revision'] == data['expected_revision'], 'Stale revision')
            closing = operation == 'period.close'
            require(period['status'] == ('open' if closing else 'closed'), 'Invalid period status')
            period['status'] = 'closed' if closing else 'open'
            period['revision'] += 1
            return period
        if operation == 'journal.post':
            return self.post(state, data)
        if operation == 'journal.import':
            fields(data, {'entries': sequence(post_fields)})
            for payload in data['entries']:
                self.post(state, payload)
            return {'imported': len(data['entries'])}
        if operation == 'journal.reverse':
            fields(data, {'id': text, 'reversal_id': text, 'date': integer, 'key': text})
            def commit():
                original = get_record(entries, data['id'])
                require(original['status'] == 'posted', 'Already reversed')
                require(data['id'] not in state['reversal_of'], 'Cannot reverse a reversal')
                require(data['reversal_id'] not in entries, 'Entry already exists')
                period = self.open_period(state, data['date'])
                reversal = {'id': data['reversal_id'], 'date': data['date'],
                            'period': period, 'lines': [
                                {'account': row['account'], 'debit': row['credit'],
                                 'credit': row['debit']} for row in original['lines']],
                            'status': 'posted', 'reversal': None}
                entries[reversal['id']] = reversal
                state['reversal_of'][reversal['id']] = original['id']
                original['status'] = 'reversed'
                original['reversal'] = reversal['id']
                return reversal
            return idempotent(state, data['key'], operation, data, commit)
        if operation == 'journal.get':
            fields(data, {'id': text})
            return get_record(entries, data['id'])
        if operation == 'journal.list':
            fields(data, {}, {'period': text, 'account': text})
            if 'period' in data:
                get_record(periods, data['period'])
            if 'account' in data:
                get_record(accounts, data['account'])
            return sorted((e for e in entries.values()
                           if ('period' not in data or e['period'] == data['period'])
                           and ('account' not in data or any(
                               row['account'] == data['account'] for row in e['lines']))),
                          key=lambda e: (e['date'], e['id']))
        if operation == 'account.balance':
            fields(data, {'id': text})
            return self.balance(state, data['id'])
        if operation == 'trial_balance':
            fields(data, {})
            return [dict(account=account, **self.balance(state, account))
                    for account in sorted(accounts)]
        raise ValueError('Unknown operation')


if __name__ == '__main__':
    Service.main()
