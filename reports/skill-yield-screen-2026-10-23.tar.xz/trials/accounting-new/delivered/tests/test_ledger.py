import copy
import unittest
from app import Service
from goalpilot_support import JourneyMixin, rejects


def posting(id='j', date=1, key='k', cents=123):
    return {'id': id, 'date': date, 'key': key, 'lines': [
        {'account': 'cash', 'debit': cents, 'credit': 0},
        {'account': 'sales', 'debit': 0, 'credit': cents}]}


class Ledger(JourneyMixin, unittest.TestCase):
    def setUp(self):
        self.open_service(Service)

    def seed(self):
        self.c('account.create', id='cash', name='Caisse café', kind='asset')
        self.c('account.create', id='sales', name='Ventes', kind='income')
        self.c('period.create', id='p', start=0, end=10)

    def test_journey(self):
        def flow(c):
            for id, kind in [('cash', 'asset'), ('sales', 'income'), ('zero', 'expense')]:
                self.assertEqual(c('account.create', id=id, name='café', kind=kind),
                                 {'id': id, 'name': 'café', 'kind': kind})
            self.assertEqual(c('period.create', id='p', start=0, end=10),
                             dict(id='p', start=0, end=10, status='open', revision=1))
            c('period.create', id='q', start=10, end=20)
            rejects(lambda: c('period.create', id='bad', start=9, end=11))
            payload = posting(cents=10**20 + 1)
            entry = c('journal.post', **payload)
            self.assertEqual(entry, dict(id='j', date=1, period='p',
                lines=payload['lines'], status='posted', reversal=None))
            self.assertEqual(c('journal.post', **payload), entry)
            rejects(lambda: c('journal.post', **posting(id='other')))
            rejects(lambda: c('journal.post', **posting(id='end', date=20, key='end')))
            c('period.close', id='p', expected_revision=1)
            rejects(lambda: c('journal.post', **posting(id='closed', key='closed')))
            rejects(lambda: c('period.reopen', id='p', expected_revision=1))
            rejects(lambda: c('journal.reverse', id='j', reversal_id='r', date=2, key='r'))
            reversal = c('journal.reverse', id='j', reversal_id='r', date=10, key='r')
            self.assertEqual(reversal['lines'], [dict(account=r['account'],
                debit=r['credit'], credit=r['debit']) for r in payload['lines']])
            self.assertEqual(c('journal.reverse', id='j', reversal_id='r', date=10, key='r'), reversal)
            self.assertEqual(c('journal.post', **payload), entry)
            rejects(lambda: c('journal.reverse', id='j', reversal_id='s', date=11, key='s'))
            rejects(lambda: c('journal.reverse', id='r', reversal_id='s', date=11, key='s'))
            self.assertEqual(c('journal.get', id='j')['status'], 'reversed')
            self.assertEqual([e['id'] for e in c('journal.list')], ['j', 'r'])
            self.assertEqual([e['id'] for e in c('journal.list', period='q', account='cash')], ['r'])
            self.assertEqual(c('account.balance', id='cash'),
                {'debit': 10**20+1, 'credit': 10**20+1, 'net': 0})
            trial = c('trial_balance')
            self.assertEqual([r['account'] for r in trial], ['cash', 'sales', 'zero'])
            self.assertTrue(all(r['net'] == 0 for r in trial))
            saved = c('backup')
            c('period.reopen', id='p', expected_revision=2)
            bad = posting(id='bad', key='bad'); bad['lines'][0]['debit'] += 1
            rejects(lambda: c('journal.import', entries=[posting(id='new', key='new'), bad]))
            self.assertEqual(c('journal.list'), saved['state']['entries'].values() if False else
                             [saved['state']['entries'][id] for id in ['j', 'r']])
            self.assertEqual(c('journal.import', entries=[posting(id='new', key='new')]), {'imported': 1})
            c('restore', state=saved)
            self.assertEqual(c('backup'), saved)
            c('period.reopen', id='p', expected_revision=2)
            c('journal.post', **posting(id='new', key='new'))
        self.assertJourney(flow)

    def test_rejections_and_atomic_batch(self):
        self.seed()
        for value in [True, 1.0, '1', -1]:
            payload = posting(); payload['lines'][0]['debit'] = value
            self.assertRejects('journal.post', **payload)
            self.assertRejects('period.create', id='bad', start=value, end=100)
        for change in [dict(account='missing'), dict(debit=0), dict(credit=1)]:
            payload = posting(); payload['lines'][0].update(change)
            self.assertRejects('journal.post', **payload)
        self.assertRejects('journal.post', **dict(posting(), lines=posting()['lines'][:1]))
        self.assertRejects('journal.import', entries=[posting(), posting(id='second')])
        self.assertEqual(self.c('journal.list'), [])
        self.c('journal.post', **posting())
        self.assertRejects('journal.reverse', id='j', reversal_id='j', date=1, key='rev')
        self.assertRejects('period.close', id='p', expected_revision=True)
        self.assertRejects('unknown')
        self.assertRejects('journal.get', id='missing')
        self.assertRejects('account.create', id='cash', name='duplicate', kind='asset')
        self.assertRejects('trial_balance', unexpected=1)
        self.restart()
        self.assertEqual(self.c('account.balance', id='cash')['net'], 123)

    def test_restore_and_detachment(self):
        self.seed()
        payload = posting()
        entry = self.c('journal.post', **payload)
        payload['lines'][0]['debit'] = 999
        entry['lines'].clear()
        self.assertEqual(self.c('journal.get', id='j')['lines'][0]['debit'], 123)
        self.assertCorruptions(
            lambda b: b['state']['accounts'].pop('cash'),
            lambda b: b['state']['entries']['j']['lines'][0].update(debit=124),
            lambda b: b['state']['periods']['p'].update(end=True),
            lambda b: b['state']['keys']['k']['result'].update(status='reversed'),
            lambda b: b['events'][3]['result'].update(date=9),
            lambda b: b.update(events=[]))
        self.c('journal.reverse', id='j', reversal_id='r', date=2, key='r')
        self.assertCorruptions(
            lambda b: b['state']['entries']['r']['lines'][0].update(credit=1),
            lambda b: b['state']['entries']['j'].update(reversal='unknown'))
        before = self.c('backup')
        before['state']['accounts'].clear()
        self.assertEqual(len(self.c('trial_balance')), 2)

    def test_concurrent_posts_and_revision(self):
        self.seed()
        results = self.race(*[('journal.post', posting(id=str(i), key=str(i))) for i in range(6)])
        self.assertTrue(all(ok for ok, _ in results))
        self.assertEqual(self.c('account.balance', id='cash')['net'], 6*123)
        self.assertEqual(len(self.c('journal.list')), 6)
        results = self.race(*[('period.close', {'id': 'p', 'expected_revision': 1}) for _ in range(3)])
        self.assertEqual(sum(ok for ok, _ in results), 1)
        self.restart()
        self.assertRejects('journal.post', **posting(id='late', key='late'))
