import csv
import io
import unittest
from copy import deepcopy
from app import Service
from goalpilot_support import JourneyMixin, rejects

COLS = [{'name': 'id', 'type': 'text', 'required': True},
        {'name': 'n', 'type': 'integer', 'required': False},
        {'name': 'price', 'type': 'money', 'required': False}]


class Pipeline(JourneyMixin, unittest.TestCase):
    def setUp(self):
        self.open_service(Service)

    def test_journey(self):
        def flow(c):
            s = c('schema.put', id='café', columns=COLS, key='id')
            self.assertEqual(s['revision'], 1)
            raw = 'id,n,price\r\na,bad,1.00\r\na,+02,0.29\r\na,3,1\r\n"é\nx",-3,123456789012345.67\r\nz,,\r\nx,1,1.234\r\nx,1,2,extra\r\n,1,2\r\n'
            c('job.create', id='j', schema='café', csv=raw)
            rejects(lambda: c('dataset.get', schema='café'))
            c('schema.put', id='café', columns=[COLS[0]], key='id')
            r = c('job.run', id='j', key='run')
            self.assertEqual((r['accepted'], r['rejected'], r['schema_revision']), (3, 5, 1))
            self.assertEqual(r['rows'], [{'id': 'a', 'n': 2, 'price': 29},
                                        {'id': 'é\nx', 'n': -3, 'price': 12345678901234567},
                                        {'id': 'z', 'n': None, 'price': None}])
            self.assertEqual([x['row'] for x in r['rejects']], [2, 4, 8, 9, 10])
            self.assertTrue(all(x['reason'] for x in r['rejects']))
            self.assertEqual(c('job.get', id='j')['csv'], raw)
            out = list(csv.reader(io.StringIO(c('job.export', id='j'))))
            self.assertEqual(out[1], ['a', '2', '29'])
            self.assertEqual(out[-1], ['z', '', ''])
            rejects(lambda: c('job.publish', id='j', expected_revision=True))
            rejects(lambda: c('job.publish', id='j', expected_revision=2))
            before = c('backup')
            c('job.publish', id='j', expected_revision=1)
            self.assertEqual(c('dataset.get', schema='café')['rows'], r['rows'])
            self.assertEqual(c('job.run', id='j', key='run'), r)
            rejects(lambda: c('job.retry', id='j', csv='id,n,price\nx,1,2'))
            rejects(lambda: c('job.publish', id='j', expected_revision=2))
            c('restore', state=before)
            self.assertEqual(c('job.get', id='j')['status'], 'processed')
            c('job.retry', id='j', csv='id,n,price\nx,1,2.01\n')
            self.assertEqual(c('job.run', id='j', key='run'), r)
            self.assertEqual(c('job.get', id='j')['status'], 'draft')
            fresh = c('job.run', id='j', key='second')
            self.assertEqual(fresh['rows'], [{'id': 'x', 'n': 1, 'price': 201}])
            c('job.publish', id='j', expected_revision=1)
            self.assertEqual(c('dataset.get', schema='café')['rows'], fresh['rows'])
            c('job.import', jobs=[{'id': 'b', 'schema': 'café', 'csv': 'id\ny\n'},
                                  {'id': 'c', 'schema': 'café', 'csv': 'id\nz\n'}])
            rejects(lambda: c('job.run', id='b', key='second'))
            c('job.run', id='b', key='third')
            c('job.publish', id='b', expected_revision=1)
            self.assertEqual(c('dataset.get', schema='café'),
                             {'job': 'b', 'rows': [{'id': 'y'}], 'schema_revision': 2})
        self.assertJourney(flow)

    def test_rejections_persistence_and_snapshots(self):
        self.c('schema.put', id='s', columns=COLS, key='id')
        for columns, key in [(COLS + [COLS[0]], 'id'), (COLS, 'n'),
                             ([dict(COLS[0], required=1)], 'id'),
                             ([dict(COLS[0], type='float')], 'id')]:
            self.assertRejects('schema.put', id='s', columns=columns, key=key)
        self.assertRejects('job.create', id='bad', schema='s', csv='n,id,price\n')
        self.assertRejects('job.import', jobs=[{'id': 'a', 'schema': 's', 'csv': 'id,n,price\n'},
                                            {'id': 'b', 'schema': 's', 'csv': 'wrong\n'}])
        self.assertRejects('job.get', id='a')
        raw = 'id,n,price\na,1e2,1\nb,1.0,1\nc,True,1\nd,1,-1\ne,1,1e2\nf,1,.2\ng,1,2.00\n'
        self.c('job.create', id='j', schema='s', csv=raw)
        self.assertRejects('job.export', id='j')
        result = self.c('job.run', id='j', key='k')
        self.assertEqual((result['accepted'], result['rejected']), (1, 6))
        result['rows'].clear()
        self.restart()
        self.assertEqual(len(self.c('job.get', id='j')['rows']), 1)
        self.assertRejects('job.run', id='j', key='new')
        self.assertRejects('job.retry', id='j', csv='wrong\n')
        backup = self.c('backup')
        self.assertRejects('restore', state={})
        damaged = deepcopy(backup)
        damaged['state']['jobs']['j']['accepted'] = 99
        self.assertRejects('restore', state=damaged)
        damaged = deepcopy(backup)
        damaged['state']['jobs']['j']['schema_snapshot']['columns'][0]['type'] = 'money'
        self.assertRejects('restore', state=damaged)
        self.c('restore', state=backup)
        self.assertEqual(self.c('job.get', id='j')['rows'][0]['price'], 200)
        self.assertRejects('missing')
        self.assertRejects('job.get', id=2)

    def test_concurrent_atomic_publication(self):
        self.c('schema.put', id='s', columns=[COLS[0]], key='id')
        self.c('job.create', id='j', schema='s', csv='id\na\n')
        results = self.race(*[('job.run', {'id': 'j', 'key': 'same'})] * 2)
        self.assertEqual(sum(ok for ok, _ in results), 2)
        results = self.race(*[('job.publish', {'id': 'j', 'expected_revision': 1})] * 2)
        self.assertEqual(sum(ok for ok, _ in results), 1)
        self.assertEqual(self.c('dataset.get', schema='s')['rows'], [{'id': 'a'}])
        results = self.race(*[('schema.put', {'id': 's', 'columns': [COLS[0]], 'key': 'id'})] * 2)
        self.assertTrue(all(ok for ok, _ in results))
        self.assertEqual(sorted(r['revision'] for _, r in results), [2, 3])
