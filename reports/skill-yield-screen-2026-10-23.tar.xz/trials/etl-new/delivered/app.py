import csv
import io
import re
from copy import deepcopy
from goalpilot_runtime import ReplayService, fields, text, integer, boolean, require, idempotent


def banner():
    return 'Local Ops — café'


def schema_columns(value):
    require(isinstance(value, list) and bool(value), 'Columns must be a nonempty list')
    names = []
    for col in value:
        fields(col, {'name': text, 'type': text, 'required': boolean})
        require(col['type'] in ('text', 'integer', 'money'), 'Unknown column type')
        names.append(col['name'])
    require(len(set(names)) == len(names), 'Duplicate columns')


def reader_for(raw, schema):
    reader = csv.reader(io.StringIO(raw, newline=''), strict=True)
    try:
        header = next(reader)
    except (StopIteration, csv.Error) as exc:
        raise ValueError('Missing or invalid CSV header') from exc
    require(header == [c['name'] for c in schema['columns']], 'CSV header mismatch')
    return reader


def normalize(cell, col):
    cell = cell.strip()
    if not cell:
        require(not col['required'], 'Required value: ' + col['name'])
        return '' if col['type'] == 'text' else None
    if col['type'] == 'text':
        return cell
    if col['type'] == 'integer':
        require(re.fullmatch(r'[+-]?[0-9]+', cell) is not None, 'Invalid integer: ' + col['name'])
        try:
            return int(cell)
        except ValueError as exc:
            raise ValueError('Integer too large') from exc
    require(re.fullmatch(r'[0-9]+(?:\.[0-9]{1,2})?', cell) is not None, 'Invalid money: ' + col['name'])
    parts = cell.split('.')
    try:
        return int(parts[0]) * 100 + int((parts[1] if len(parts) > 1 else '').ljust(2, '0'))
    except ValueError as exc:
        raise ValueError('Money too large') from exc


class Service(ReplayService):
    def initial(self):
        return {'schemas': {}, 'jobs': {}, 'datasets': {}, 'keys': {}}

    def handle(self, state, op, data):
        if op == 'schema.put':
            fields(data, {'id': text, 'columns': schema_columns, 'key': text})
            require(any(c['name'] == data['key'] and c['type'] == 'text' and c['required']
                        for c in data['columns']), 'Key must be required text')
            result = deepcopy(data)
            result['revision'] = state['schemas'].get(data['id'], {}).get('revision', 0) + 1
            state['schemas'][data['id']] = result
            return result
        if op == 'job.create':
            return self.create(state, data)
        if op == 'job.import':
            fields(data, {'jobs': lambda v: require(isinstance(v, list), 'Jobs must be a list')})
            # Runtime commits only if the whole request succeeds.
            for job in data['jobs']:
                self.create(state, job)
            return {'imported': len(data['jobs'])}
        if op == 'dataset.get':
            fields(data, {'schema': text})
            require(data['schema'] in state['datasets'], 'No published dataset')
            return state['datasets'][data['schema']]
        if op == 'job.run':
            fields(data, {'id': text, 'key': text})
            return idempotent(state, data['key'], op, data, lambda: self.run(state, data['id']))
        if op in ('job.get', 'job.export', 'job.retry', 'job.publish'):
            spec = {'id': text}
            if op == 'job.retry':
                spec['csv'] = lambda v: require(isinstance(v, str), 'CSV must be text')
            if op == 'job.publish':
                spec['expected_revision'] = lambda v: integer(v, minimum=1)
            fields(data, spec)
            require(data['id'] in state['jobs'], 'Unknown job')
            job = state['jobs'][data['id']]
            if op == 'job.get':
                return job
            if op == 'job.retry':
                require(job['status'] == 'processed', 'Only processed jobs can retry')
                reader_for(data['csv'], job['schema_snapshot'])
                for name in ('accepted', 'rejected', 'rows', 'rejects'):
                    job.pop(name, None)
                job.update(csv=data['csv'], status='draft')
                return job
            if op == 'job.publish':
                require(job['status'] == 'processed', 'Only processed jobs can publish')
                require(data['expected_revision'] == job['revision'], 'Revision conflict')
                job.update(status='published', revision=2)
                state['datasets'][job['schema']] = {'job': job['id'], 'rows': deepcopy(job['rows']),
                                                    'schema_revision': job['schema_revision']}
                return job
            require(job['status'] in ('processed', 'published'), 'Job has not run')
            output = io.StringIO(newline='')
            writer = csv.writer(output)
            columns = [c['name'] for c in job['schema_snapshot']['columns']]
            writer.writerow(columns)
            for row in job['rows']:
                writer.writerow(['' if row[c] is None else row[c] for c in columns])
            return output.getvalue()
        raise ValueError('Unknown operation')

    def create(self, state, data):
        fields(data, {'id': text, 'schema': text,
                      'csv': lambda v: require(isinstance(v, str), 'CSV must be text')})
        require(data['id'] not in state['jobs'], 'Duplicate job')
        require(data['schema'] in state['schemas'], 'Unknown schema')
        snapshot = deepcopy(state['schemas'][data['schema']])
        reader_for(data['csv'], snapshot)
        job = dict(data, schema_snapshot=snapshot, schema_revision=snapshot['revision'],
                   status='draft', revision=1)
        state['jobs'][data['id']] = job
        return job

    def run(self, state, ident):
        require(ident in state['jobs'], 'Unknown job')
        job = state['jobs'][ident]
        require(job['status'] == 'draft', 'Only draft jobs can run')
        schema = job['schema_snapshot']
        reader = reader_for(job['csv'], schema)
        rows, rejects, seen = [], [], set()
        while True:
            try:
                cells = next(reader)
            except StopIteration:
                break
            except csv.Error as exc:
                rejects.append({'row': reader.line_num, 'reason': 'Invalid CSV: ' + str(exc)})
                break
            try:
                require(len(cells) == len(schema['columns']), 'Wrong number of cells')
                row = {c['name']: normalize(v, c) for c, v in zip(schema['columns'], cells)}
                key = row[schema['key']]
                require(key not in seen, 'Duplicate primary key')
                seen.add(key)
                rows.append(row)
            except ValueError as exc:
                rejects.append({'row': reader.line_num, 'reason': str(exc)})
        result = {'id': ident, 'status': 'processed', 'accepted': len(rows), 'rejected': len(rejects),
                  'rows': rows, 'rejects': rejects, 'schema_revision': schema['revision']}
        job.update(result)
        return result


if __name__ == '__main__':
    Service.main()
