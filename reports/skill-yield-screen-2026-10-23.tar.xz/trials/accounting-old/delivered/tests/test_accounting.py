import copy
import unittest
from app import Service
from goalpilot_support import JourneyMixin, rejects


class Accounting(JourneyMixin, unittest.TestCase):
    def setUp(self):
        self.open_service(Service)

    @staticmethod
    def payload(id='e', key='k', date=1, amount=101):
        return dict(id=id, key=key, date=date, lines=[dict(account='cash', debit=amount, credit=0),
                                                   dict(account='sales', debit=0, credit=amount)])

    def seed(self, c):
        for id, kind in [('cash', 'asset'), ('sales', 'income'), ('zero', 'expense')]:
            self.assertEqual(c('account.create', id=id, name='café '+id, kind=kind), dict(id=id, name='café '+id, kind=kind))
        self.assertEqual(c('period.create', id='p', start=0, end=10), dict(id='p', start=0, end=10, status='open', revision=1))

    def test_journey(self):
        def flow(c):
            self.seed(c)
            p = self.payload(amount=10**30+1)
            original = c('journal.post', **p)
            self.assertEqual(original, dict(id='e', date=1, period='p', lines=p['lines'], status='posted', reversal=None))
            self.assertEqual(c('journal.post', **p), original)
            rejects(lambda: c('journal.post', **dict(p, date=2)))
            snap = c('backup')
            c('period.close', id='p', expected_revision=1)
            rejects(lambda: c('journal.post', **self.payload('b', 'b')))
            rejects(lambda: c('journal.reverse', id='e', reversal_id='r', date=2, key='r'))
            rejects(lambda: c('period.reopen', id='p', expected_revision=1))
            self.assertEqual(c('period.reopen', id='p', expected_revision=2)['revision'], 3)
            rev = c('journal.reverse', id='e', reversal_id='r', date=2, key='r')
            self.assertEqual(rev['lines'], [dict(account=x['account'], debit=x['credit'], credit=x['debit']) for x in p['lines']])
            self.assertEqual(c('journal.reverse', id='e', reversal_id='r', date=2, key='r'), rev)
            self.assertEqual(c('journal.post', **p), original)
            self.assertEqual(c('journal.get', id='e')['reversal'], 'r')
            rejects(lambda: c('journal.reverse', id='r', reversal_id='rr', date=3, key='rr'))
            rejects(lambda: c('journal.reverse', id='e', reversal_id='rr', date=3, key='rr'))
            self.assertEqual([x['id'] for x in c('journal.list', account='cash', period='p')], ['e', 'r'])
            self.assertEqual(c('account.balance', id='cash'), dict(debit=10**30+1, credit=10**30+1, net=0))
            self.assertEqual(c('trial_balance')[-1], dict(account='zero', debit=0, credit=0, net=0))
            c('restore', state=snap)
            self.assertEqual(c('journal.list'), [original])
            rejects(lambda: c('journal.import', entries=[self.payload('b', 'b'), self.payload('bad', 'bad', date=10)]))
            self.assertEqual(c('journal.import', entries=[self.payload('b', 'b'), self.payload('c', 'c', date=9)]), {'imported': 2})
            self.assertEqual(c('account.balance', id='cash')['net'], 10**30+203)
            c('period.create', id='next', start=10, end=20)
            c('journal.post', **self.payload('edge', 'edge', date=10))
        self.assertJourney(flow)

    def test_rejections_snapshots_and_restore(self):
        self.seed(self.c)
        for bad in [True, 1.5, '1', -1]:
            self.assertRejects('journal.post', **self.payload(date=bad))
            self.assertRejects('journal.post', **self.payload(amount=bad))
        for lines in [[], [dict(account='cash', debit=1, credit=0)],
                      [dict(account='cash', debit=1, credit=1), dict(account='sales', debit=0, credit=1)],
                      [dict(account='missing', debit=1, credit=0), dict(account='sales', debit=0, credit=1)],
                      [dict(account='cash', debit=2, credit=0), dict(account='sales', debit=0, credit=1)]]:
            self.assertRejects('journal.post', **dict(self.payload(), lines=lines))
        self.assertRejects('period.create', id='overlap', start=9, end=11)
        self.assertRejects('account.create', id='cash', name='duplicate', kind='asset')
        self.assertRejects('journal.get', id='missing')
        self.assertRejects('anything')
        self.assertRejects('account.balance', id='cash', extra=1)
        payload = self.payload()
        saved = copy.deepcopy(payload)
        result = self.c('journal.post', **payload)
        self.assertEqual(payload, saved)
        result['lines'][0]['debit'] = 99
        self.assertEqual(self.c('journal.get', id='e')['lines'], saved['lines'])
        self.restart()
        self.assertEqual(self.c('account.balance', id='cash')['net'], 101)
        self.assertCorruptions(
            lambda b: b['state']['entries']['e']['lines'][0].update(debit=102),
            lambda b: b['state']['accounts'].pop('cash'),
            lambda b: b['state']['periods']['p'].update(end=True),
            lambda b: b['state']['entries']['e'].update(reversal='missing'),
            lambda b: b['state']['keys'].clear())
        self.assertRejects('restore', state={})
        self.assertEqual(self.c('account.balance', id='cash')['net'], 101)

    def test_cumulative_batch_and_aggregation(self):
        self.seed(self.c)
        self.assertRejects('journal.import', entries=[self.payload('a', 'a'), self.payload('b', 'a')])
        self.assertEqual(self.c('journal.list'), [])
        p = self.payload('a', 'a')
        p['lines'] = [dict(account='cash', debit=50, credit=0), dict(account='cash', debit=51, credit=0), dict(account='sales', debit=0, credit=101)]
        self.c('journal.post', **p)
        self.assertEqual(self.c('journal.get', id='a')['lines'], p['lines'])
        self.assertEqual(self.c('account.balance', id='cash')['net'], 101)
        self.assertRejects('journal.import', entries=[self.payload('b', 'b'), self.payload('a', 'new')])
        self.c('journal.post', **self.payload('b', 'b'))
        self.assertEqual(self.c('account.balance', id='cash')['net'], 202)

    def test_concurrent_posts_and_revision(self):
        self.seed(self.c)
        results = self.race(*[('journal.post', self.payload(str(i), str(i))) for i in range(6)])
        self.assertEqual(sum(ok for ok, _ in results), 6)
        self.assertEqual(self.c('account.balance', id='cash')['net'], 606)
        results = self.race(*[('period.close', dict(id='p', expected_revision=1)) for _ in range(3)])
        self.assertEqual(sum(ok for ok, _ in results), 1)
        self.assertRejects('journal.post', **self.payload('late', 'late'))
