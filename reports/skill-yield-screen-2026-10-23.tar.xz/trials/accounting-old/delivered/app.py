from goalpilot_runtime import ReplayService, fields, text, integer, choice, sequence, require, get_record, idempotent, compare_revision


def banner():
    return 'Local Ops — café'


def line(value):
    fields(value, {'account': text, 'debit': integer, 'credit': integer})
    require((value['debit'] > 0) != (value['credit'] > 0), 'Exactly one positive side required')


def post(value):
    fields(value, {'id': text, 'date': integer, 'lines': sequence(line), 'key': text})
    require(len(value['lines']) >= 2, 'At least two lines required')
    debit = sum(x['debit'] for x in value['lines'])
    require(debit > 0 and debit == sum(x['credit'] for x in value['lines']), 'Unbalanced entry')


class Service(ReplayService):
    def initial(self):
        return {'accounts': {}, 'periods': {}, 'entries': {}, 'keys': {}}

    def period_at(self, state, date):
        matches = [p for p in state['periods'].values() if p['start'] <= date < p['end']]
        require(len(matches) == 1 and matches[0]['status'] == 'open', 'Date must be in an open period')
        return matches[0]['id']

    def post_entry(self, state, data):
        post(data)
        def commit():
            require(data['id'] not in state['entries'], 'Duplicate entry')
            for row in data['lines']:
                get_record(state['accounts'], row['account'])
            entry = dict(id=data['id'], date=data['date'], period=self.period_at(state, data['date']),
                         lines=data['lines'], status='posted', reversal=None)
            state['entries'][data['id']] = entry
            return entry
        return idempotent(state, data['key'], 'journal.post', data, commit)

    def handle(self, state, op, data):
        require(isinstance(data, dict), 'Expected object')
        accounts, periods, entries = state['accounts'], state['periods'], state['entries']
        if op == 'account.create':
            fields(data, {'id': text, 'name': text, 'kind': choice('asset', 'liability', 'income', 'expense')})
            require(data['id'] not in accounts, 'Duplicate account')
            accounts[data['id']] = dict(data)
            return accounts[data['id']]
        if op == 'period.create':
            fields(data, {'id': text, 'start': integer, 'end': integer})
            require(data['id'] not in periods and data['end'] > data['start'], 'Invalid period')
            require(all(data['end'] <= p['start'] or data['start'] >= p['end'] for p in periods.values()), 'Overlapping periods')
            periods[data['id']] = dict(data, status='open', revision=1)
            return periods[data['id']]
        if op in ('period.close', 'period.reopen'):
            fields(data, {'id': text, 'expected_revision': integer})
            period = get_record(periods, data['id'])
            compare_revision(period, data['expected_revision'])
            require(period['status'] == ('open' if op == 'period.close' else 'closed'), 'Wrong period status')
            period['status'] = 'closed' if op == 'period.close' else 'open'
            period['revision'] += 1
            return period
        if op == 'journal.post':
            return self.post_entry(state, data)
        if op == 'journal.import':
            fields(data, {'entries': sequence(post)})
            for entry in data['entries']:
                self.post_entry(state, entry)
            return {'imported': len(data['entries'])}
        if op == 'journal.reverse':
            fields(data, {'id': text, 'reversal_id': text, 'date': integer, 'key': text})
            def commit():
                original = get_record(entries, data['id'])
                require(original['status'] == 'posted', 'Already reversed')
                require(not any(e['reversal'] == data['id'] for e in entries.values()), 'Cannot reverse a reversal')
                require(data['reversal_id'] not in entries, 'Duplicate entry')
                reversal = dict(id=data['reversal_id'], date=data['date'], period=self.period_at(state, data['date']),
                                lines=[dict(account=x['account'], debit=x['credit'], credit=x['debit']) for x in original['lines']],
                                status='posted', reversal=None)
                entries[data['reversal_id']] = reversal
                original['status'], original['reversal'] = 'reversed', data['reversal_id']
                return reversal
            return idempotent(state, data['key'], op, data, commit)
        if op == 'journal.get':
            fields(data, {'id': text})
            return get_record(entries, data['id'])
        if op == 'journal.list':
            fields(data, {}, optional={'period': text, 'account': text})
            if 'period' in data:
                get_record(periods, data['period'])
            if 'account' in data:
                get_record(accounts, data['account'])
            return sorted((e for e in entries.values()
                           if ('period' not in data or e['period'] == data['period'])
                           and ('account' not in data or any(x['account'] == data['account'] for x in e['lines']))),
                          key=lambda e: (e['date'], e['id']))
        if op in ('account.balance', 'trial_balance'):
            fields(data, {'id': text} if op == 'account.balance' else {})
            if op == 'account.balance':
                get_record(accounts, data['id'])
            def balance(account):
                rows = [x for e in entries.values() for x in e['lines'] if x['account'] == account]
                debit, credit = sum(x['debit'] for x in rows), sum(x['credit'] for x in rows)
                return dict(debit=debit, credit=credit, net=debit-credit)
            if op == 'account.balance':
                return balance(data['id'])
            return [dict(account=a, **balance(a)) for a in sorted(accounts)]
        raise ValueError('Unknown operation')


if __name__ == '__main__':
    Service.main()
