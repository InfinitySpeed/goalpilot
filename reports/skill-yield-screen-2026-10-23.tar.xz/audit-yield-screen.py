from pathlib import Path
import json,hashlib,zipfile
root=Path('/workspace/goalpilot-public');r=json.loads((root/'reports/skill-yield-screen-2026-10-23.json').read_text());d=Path('/workspace/goalpilot-research/portable-016/yield-screen-001')
p=json.loads((d/'protocol.json').read_text());assert p==r['registered_protocol'];assert len(r['results'])==4
for row in r['results']:
 events=d/'trials'/(row['case']+'-'+row['arm'])/'caller/events.jsonl'; meters=[]
 for line in events.read_text().splitlines():
  e=json.loads(line).get('packet',{})
  if e.get('method')=='thread/tokenUsage/updated':meters.append(e['params']['tokenUsage'])
 assert meters
 total=meters[-1]['total'];u=row['usage'];assert total['totalTokens']==u['total_tokens'];assert total['inputTokens']+total['outputTokens']==u['total_tokens'];assert total['inputTokens']-total['cachedInputTokens']+total['outputTokens']==u['uncached_tokens']
 assert sum(m['last']['totalTokens']for m in meters)==u['total_tokens'];assert row['source_unchanged'];assert row['success']and row['goal_complete'];assert row['engine_model_calls']==0;assert len(row['reviewed_judge']['groups_passed'])==10
for name,arm in [('current','old'),('candidate','new')]:
 rs=[x for x in r['results']if x['arm']==arm];assert sum(x['usage']['total_tokens']for x in rs)==r['primary_fresh_totals'][name]['raw']
for key,v in r['candidate_gain_percent'].items():assert abs(v-100*(1-r['primary_fresh_totals']['candidate'][key]/r['primary_fresh_totals']['current'][key]))<1e-9
assert r['promoted']is False and r['full_benchmark_started']is False
assert hashlib.sha256((root/'reports'/r['archive']).read_bytes()).hexdigest()==r['archive_sha256']
with zipfile.ZipFile(root/'reports'/r['archive'])as z:assert z.testzip()is None
m=json.loads((root/'PORTABLE_SKILL.json').read_text());assert all(hashlib.sha256((root/m['bundle']/n).read_bytes()).hexdigest()==h for n,h in m['measured_files'].items())
print('PASS:4 complete provider meters,40 independent business groups, exact fresh aggregates, frozen49 files and archived evidence.')
