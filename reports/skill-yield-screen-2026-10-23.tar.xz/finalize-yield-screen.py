from pathlib import Path
import json,hashlib,zipfile,subprocess
b=Path('/workspace/goalpilot-research/portable-016');d=b/'yield-screen-001';root=Path('/workspace/goalpilot-public')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
rows=[json.loads(f.read_text())for f in sorted((d/'trials').glob('*/result.json'))]
p=json.loads((d/'protocol.json').read_text()); totals={}
for arm in ('old','new'):
 rs=[r for r in rows if r['arm']==arm];totals['current'if arm=='old'else'candidate']={'completed':sum(r['success']for r in rs),'calls':len(rs),'raw':sum(r['usage']['total_tokens']for r in rs),'uncached_plus_output':sum(r['usage']['uncached_tokens']for r in rs),'seconds':sum(r['seconds']for r in rs)}
a=totals['current'];c=totals['candidate'];gains={k:100*(1-c[k]/a[k])for k in ('raw','uncached_plus_output','seconds')}
checks={'all_four_calls_recorded':len(rows)==4,'both_candidate_goals_verified':c['completed']==2,'both_controls_verified':a['completed']==2,'complete_meters':all(r['usage']['usage_complete']for r in rows),'raw_saving_at_least_10pct':gains['raw']>=10,'uncached_plus_output_saving_at_least_10pct':gains['uncached_plus_output']>=10,'time_regression_at_most_3pct':gains['seconds']>=-3}
manifest=json.loads((root/'PORTABLE_SKILL.json').read_text());assert all(sha(root/manifest['bundle']/n)==h for n,h in manifest['measured_files'].items())
legacy=json.loads((b/'paired-170-clean-001/historical-controls.json').read_text()); historical={}
for arm in ('native','new'):
 rs=[r for r in legacy['rows']if r['case']in p['cases']and r['arm']==arm];historical['native_codex'if arm=='native'else'legacy_goalpilot_1.3.1']={'completed':sum(r['success']for r in rs),'calls':len(rs),'raw':sum(r['usage']['raw']for r in rs),'uncached_plus_output':sum(r['usage']['uncached_plus_output']for r in rs),'seconds':sum(r['seconds']for r in rs),'concurrent':False}
(d/'historical-controls.json').write_text(json.dumps(legacy,indent=2)+'\n')
# Include source, harness, provider event streams, independent graders and unchanged outcomes.
archive=root/'reports/skill-yield-screen-2026-10-23.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED)as z:
 for f in sorted(d.rglob('*')):
  if f.is_file()and '__pycache__'not in f.parts and f.suffix!='.pyc':z.write(f,str(f.relative_to(d)))
 z.write(b/'yield_screen_worker.py','yield_screen_worker.py');z.write(Path(__file__),'finalize-yield-screen.py')
report={'status':'eligible_for_full_benchmark'if all(checks.values())else'rejected_at_rapid_screen','promoted':False,'full_benchmark_started':False,'source_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'hypothesis':'Compress redundant instructions while retaining original-goal preservation, supplied-context reuse, coherent implementation/test/criteria delivery, frozen checks, repair semantics and honest completion. Engine unchanged.','candidate_words':len((d/'candidate-SKILL.md').read_text().split()),'current_words':len((root/manifest['bundle']/'SKILL.md').read_text().split()),'registered_protocol':p,'checks':checks,'primary_fresh_totals':totals,'candidate_gain_percent':gains,'historical_same_two_cases':historical,'results':rows,'research_usage':{'calls':len(rows),'raw':sum(r['usage']['total_tokens']for r in rows),'uncached_plus_output':sum(r['usage']['uncached_tokens']for r in rows),'meta_conversation_usage':'UNKNOWN'},'limitations':['Two familiar synthetic Python services; one observation per case/arm. Descriptive elimination screen, no statistical significance or generalization claim.','Current control interleaved; native and legacy comparisons historical with different serving/cache conditions. No exact subscription-quota claim.','All started trials retained; no retries/replacements. Product default and all49 promoted behavior files unchanged.','A smaller instruction file alone does not establish lower whole-caller usage.'],'archive':archive.name,'archive_sha256':sha(archive)}
out=root/'reports/skill-yield-screen-2026-10-23.json';out.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'status':report['status'],'totals':totals,'gains':gains,'checks':checks},indent=2))
