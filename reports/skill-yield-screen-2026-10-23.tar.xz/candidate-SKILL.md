---
name: goalpilot
description: Finish an explicitly requested coding goal in this session using reusable helpers and frozen behavioral checks.
---

# GoalPilot

GP = scripts/host.py beside this file. Work in this session; no nested agents/models.

1. FIRST command: python3 GP session begin --goal 'VERBATIM ORIGINAL GOAL' --repo REPO --run-dir RUN --helpers --context. RUN outside REPO; forward budgets. Do not create RUN first. Resume existing evidence; helper collision: omit --helpers.
2. Use supplied source/tests/helper API; read only missing/truncated/changed information. fields(value,schema) validates a value, not a validator factory; nested rows: lambda v: fields(v,{"id":text}); sequence(row).
3. Implement every requested workflow/guard/shape, preserve original tests/data, resolve reversible ambiguities. New unspecified pure formats: ReplayService initial()+handle(), opaque IDs and explicit request times. Existing formats: ServiceBase and full validator. Prefer one coherent multi-file implementation+test edit, direct dispatch, <=2500 code/test tokens where feasible. JourneyMixin.assertJourney(flow) exercises one business journey in-process, JSONL and HTTP with isolated fixtures. Keep meaningful rejection, persistence, time/actor, corruption and concurrency coverage.
4. In that SAME edit, write CRITERIA JSON covering ALL goal clauses with 1–8 observable criteria: {"criteria":[{"quote":"EXACT original goal phrase","checks":["builder-tests"]}]}. Use original-tests/builder-tests only for behavior actually exercised; unsupported criteria: checks:[] and blocker. Optional custom argv checks, statement, assumptions and limitations. Do not claim untested coverage.
   Immediately in that SAME command run: python3 GP session deliver RUN --criteria-file CRITERIA. Its frozen suites ARE the test run: no separate unittest beforehand, successful-file rereads or unchanged reruns. If completion_owner=codex_stop_hook, deliver freezes acceptance: END immediately with checks pending; Stop verifies locally. Otherwise deliver verifies now. Repair concrete failures against the SAME frozen acceptance/tests/budget, then session finish RUN.
5. End concisely with verified/missing/blocked evidence. Only goal_complete:true proves goal completion; scope_passed+closed proves frozen-check success.

Python3.11+, bounded unittest projects; service_race needs POSIX fork. Use RUNTIME.json interpreter. No Codex dependency for portable checks. Zero nested calls; caller usage UNKNOWN without external metering. No cross-host savings guarantee.
