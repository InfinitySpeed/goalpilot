from pathlib import Path
import shutil
import hashlib,json,subprocess,sys,time
ROOT=Path(__file__).resolve().parent
PRODUCT=Path('/workspace/goalpilot-public')
sys.path.insert(0,str(PRODUCT))
from goalpilot.rpc import AppServerAdapter
from goalpilot.engine import token_totals
from cases import CASES,materialize

def put(p,v):p.write_text(json.dumps(v,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')

def run(case,arm):
 trial=ROOT/'trials'/f'{case}-{arm}-r14';trial.mkdir(parents=True,exist_ok=False)
 repo=trial/'repo';goal=materialize(case,repo)
 for i in range(32):
  p=repo/'zz-reference'/f'background-{i:02d}.md';p.parent.mkdir(parents=True,exist_ok=True);p.write_text((f'Unrelated repository background note {i}.\n'+'context filler. '*75),encoding='utf-8')
 subprocess.run(['git','init','-q',str(repo)],check=True)
 evidence=trial/'session';local=repo/'.agents/skills/goalpilot'
 if arm!='native':
  r=subprocess.run([sys.executable,str(PRODUCT/'install.py'),'--profile','universal'if arm=='fast'else'stable','--host','codex','--target',str(local)],capture_output=True,text=True)
  assert r.returncode==0,r.stdout+r.stderr
  if arm in ('candidate','fast'):
   shutil.copy2('/tmp/goalpilot-work/integrations/native/routed-SKILL.md',local/'SKILL.md')
   shutil.copy2('/tmp/goalpilot-work/integrations/native/native.py',local/'scripts/native.py')
  put(trial/'installed-files.json',{str(p.relative_to(local)):hashlib.sha256(p.read_bytes()).hexdigest()for p in sorted(local.rglob('*'))if p.is_file()})
 class Adapter(AppServerAdapter):
  def _request(self,method,params,deadline):
   if method=='thread/start':params={**params,'ephemeral':False,'sandbox':'danger-full-access','config':{'model_reasoning_effort':'low'}}
   if method=='turn/start'and arm!='native':params={**params,'input':[*params['input'],{'type':'skill','name':'goalpilot','path':str(local/'SKILL.md')}]}
   return super()._request(method,params,deadline)
 prompt=f'''Implement the following original goal completely in the existing repository, preserving the stack, public contract, original tests and data. The complete API contract is in README.md. Choose reversible details autonomously. No network or dependencies to install; native tests are available. Read ONLY this repository, selected skill, and this trial's own evidence. Do not inspect external research files/judges/other trials. No nested agents/models. Independent behavioral judging happens after your final response without feedback.
ORIGINAL GOAL (verbatim):
{goal}
'''
 if arm=='fast':prompt='$goalpilot\n'+prompt+'Use the selected installed skill and choose its fast path if appropriate. Preserve the original goal, add focused tests, run the documented check and report verified clauses. Do not start a GoalPilot session for a simple bounded task.'
 elif arm!='native':prompt='$goalpilot\n'+prompt+f'Use the selected installed skill. Evidence directory {evidence}. Forward --wall-seconds 180 --max-verifications 3. Preserve only the ORIGINAL GOAL above verbatim. Finish factually.'
 put(trial/'started.json',{'at':time.time(),'arm':arm,'goal':goal});start=time.monotonic()
 with Adapter('gpt-6.1-sol',executable='/opt/codex/bin/codex',effort='low')as adapter:r=adapter.execute(prompt,repo,180,trial/'caller')
 seconds=time.monotonic()-start;put(trial/'caller-result.json',r.to_dict());usage=token_totals([{'result':r.to_dict()}]);data=CASES[case]
 script=repo/data['judge_file'];script.write_text(data['judge'],encoding='utf-8')
 try:
  judge=subprocess.run(data['judge_cmd'],cwd=repo,capture_output=True,text=True,timeout=40);correct=judge.returncode==0;log=judge.stdout+judge.stderr
 except subprocess.TimeoutExpired as exc:correct=False;log=str(exc)
 finally:script.unlink()
 (trial/'judge.log').write_text(log,encoding='utf-8')
 certified=None;preserved=None
 if arm in ('current','candidate'):
  engine=local/'scripts/native.py'if(evidence/'state.json').exists()else local/'scripts/host.py'
  argv=[sys.executable,str(engine)]+([]if engine.name=='native.py'else['session'])+['status',str(evidence)]
  s=subprocess.run(argv,capture_output=True,text=True);(trial/'status.json').write_text(s.stdout,encoding='utf-8')
  try:certified=json.loads(s.stdout).get('goal_complete',False)
  except ValueError:certified=False
  preserved=(evidence/'goal.bin').exists()and(evidence/'goal.bin').read_bytes()==goal.encode()
 row={'case':case,'arm':arm,'seconds':seconds,'usage':usage,'correct':correct,'certified':certified,'goal_preserved':preserved,'returncode':r.returncode,'message':r.message[-1500:]}
 put(trial/'result.json',row);print(json.dumps(row),flush=True)

if __name__=='__main__':run(*sys.argv[1:])
