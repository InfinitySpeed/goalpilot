---
name: goalpilot
description: Finish coding goals in the existing stack with frozen native verification.
---

# GoalPilot

Work HERE, without nested agents/models. FIRST command: python3 N begin --goal 'VERBATIM ORIGINAL GOAL' --repo REPO --run-dir RUN --context --context-chars B. N = scripts/native.py beside this skill; RUN outside REPO. Forward requested budgets; --goal-file accepts exact UTF-8. Resume existing evidence; never reset or start both engines. Set B=6000 only for one-file bug fixes or simple utilities with a direct API and obvious checks. Use B=18000 for features with interacting behaviors, concurrency/async, cross-file workflows, migrations, ambiguous product rules, or ambitious goals. Keep the full workflow in every case. Begin selects the frozen optimized service route only for compatible Python stubs; that route keeps its own 12,000-byte dossier limit. Native verification handles all other projects.

Follow the returned protocol. NEXT command: implement, add focused native regressions, save criteria and deliver together. Use the project’s documented check runner so it resolves tool paths; never assume a bare compiler command such as javac is installed. Before the first test run, check every new expected value against the written contract; for sequential operations derive expectations from intermediate state and keep rejection tests single-cause. If a pre-green authored test contradicts the contract, repair it and use the explicit finish --test-revision command; do not query CLI --help. Extra reads only for named missing/truncated details. Preserve stack/tests/data/API; cover ALL goal clauses/guards. Aim <=1600 implementation+test tokens with shared/table-driven logic, correctness first. No speculative abstractions, unrequested docs, narration or duplicate tests. goal_complete:true => END immediately. stop_blocked => report blocker without claiming completion or rerunning unchanged checks. Final factual and concise.
