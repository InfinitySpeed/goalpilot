import java.util.*;
import java.math.BigInteger;
import java.nio.file.*;
import java.net.*;
import javax.tools.ToolProvider;

class RegressionRanges {
 static Class<?> ranges;
 @SuppressWarnings("unchecked")
 static List<long[]> call(String method, List<long[]>... args) throws Exception {
  Class<?>[] types = new Class<?>[args.length]; Arrays.fill(types, List.class);
  return (List<long[]>) ranges.getMethod(method, types).invoke(null, (Object[]) args);
 }
 static void equal(List<long[]> actual, long[][] expected) {
  if (!Arrays.deepEquals(actual.toArray(), expected)) throw new AssertionError(Arrays.deepToString(actual.toArray()));
 }
 static void rejects(String method, List<long[]> a, List<long[]> b) throws Exception {
  try {
   if (method.equals("length")) ranges.getMethod(method,List.class).invoke(null,a);
   else if (method.equals("subtract")) call(method,a,b);
   else call(method,a);
  } catch (java.lang.reflect.InvocationTargetException e) {
   if (e.getCause() instanceof IllegalArgumentException) return;
   throw e;
  }
  throw new AssertionError("accepted invalid " + method);
 }
 public static void main(String[] args) throws Exception {
  Path dir = Files.createTempDirectory("ranges-regression");
  try {
   if (ToolProvider.getSystemJavaCompiler().run(null,null,null,"-d",dir.toString(),"Ranges.java") != 0) throw new AssertionError();
   try (var loader = new URLClassLoader(new URL[]{dir.toUri().toURL()})) {
    ranges = loader.loadClass("Ranges");
    long[] original = {5,9};
    List<long[]> input = List.of(original,new long[]{1,3},new long[]{3,6},new long[]{2,2},new long[]{12,14});
    var normalized = call("normalize",input);
    equal(normalized,new long[][]{{1,9},{12,14}});
    normalized.get(0)[0] = -100;
    if (!Arrays.equals(original,new long[]{5,9}) || input.get(1)[0] != 1) throw new AssertionError("mutated input");
    equal(call("subtract",input,List.of(new long[]{13,20},new long[]{4,7},new long[]{2,4})),new long[][]{{1,2},{7,9},{12,13}});
    equal(call("subtract",List.of(new long[]{0,2},new long[]{4,6}),List.of(new long[]{1,5})),new long[][]{{0,1},{5,6}});
    var copy = call("subtract",List.of(original),List.of()); copy.get(0)[1]=0;
    if (original[1]!=9) throw new AssertionError("aliased output");
    equal(call("normalize",List.of(new long[]{0,0})),new long[][]{});
    equal(call("subtract",input,List.of(new long[]{Long.MIN_VALUE,Long.MAX_VALUE})),new long[][]{});
    Object length = ranges.getMethod("length",List.class).invoke(null,List.of(new long[]{0,Long.MAX_VALUE},new long[]{Long.MIN_VALUE,0}));
    if (!length.equals(new BigInteger("18446744073709551615"))) throw new AssertionError(length);
    if (!ranges.getMethod("length",List.class).invoke(null,input).equals(BigInteger.TEN)) throw new AssertionError();
    List<List<long[]>> invalid = new ArrayList<>();
    invalid.add(null); invalid.add(Arrays.asList((long[])null));
    invalid.add(List.of(new long[]{})); invalid.add(List.of(new long[]{1}));
    invalid.add(List.of(new long[]{1,2,3})); invalid.add(List.of(new long[]{2,1}));
    for (var bad : invalid) {
     for (String method : List.of("normalize","length","subtract")) rejects(method,bad,List.of());
     rejects("subtract",List.of(),bad);
    }
   }
  } finally {
   try (var paths = Files.walk(dir)) { for (Path p : paths.sorted(Comparator.reverseOrder()).toList()) Files.delete(p); }
  }
 }
}
