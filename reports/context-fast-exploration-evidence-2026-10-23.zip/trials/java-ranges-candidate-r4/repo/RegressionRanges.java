import java.util.*;
import java.math.BigInteger;
import javax.tools.ToolProvider;
import java.net.*;
import java.nio.file.*;
import java.lang.reflect.*;

class RegressionRanges {
 static Class<?> type;
 static Object call(String name, List<long[]>... args) throws Exception {
  try {
   return type.getMethod(name, Collections.nCopies(args.length, List.class).toArray(Class<?>[]::new))
    .invoke(null, (Object[])args);
  } catch (InvocationTargetException e) {
   if (e.getCause() instanceof IllegalArgumentException) throw (IllegalArgumentException)e.getCause();
   throw e;
  }
 }
 static List<long[]> ranges(long... values) {
  List<long[]> a = new ArrayList<>();
  for (int i=0;i<values.length;i+=2) a.add(new long[]{values[i],values[i+1]});
  return a;
 }
 static void equal(Object actual, List<long[]> expected) {
  List<?> got = (List<?>)actual;
  if (got.size()!=expected.size()) throw new AssertionError("size");
  for(int i=0;i<got.size();i++) if(!Arrays.equals((long[])got.get(i),expected.get(i)))
   throw new AssertionError("endpoints");
 }
 static void run() throws Exception {
  List<long[]> a = ranges(8,10, 1,3, 3,6, 2,4, 9,9, 8,10);
  equal(call("normalize",a),ranges(1,6,8,10));
  equal(a,ranges(8,10,1,3,3,6,2,4,9,9,8,10));
  List<long[]> cuts = ranges(9,12, 4,5, 2,3, 3,4);
  equal(call("subtract",a,cuts),ranges(1,2,5,6,8,9));
  equal(cuts,ranges(9,12,4,5,2,3,3,4));
  equal(call("subtract",ranges(0,2,4,6,8,10),ranges(1,9)),ranges(0,1,9,10));
  equal(call("subtract",ranges(0,10),ranges(-1,11)),ranges());
  equal(call("subtract",ranges(0,2),ranges(2,4)),ranges(0,2));
  for(String op:List.of("normalize","subtract")) {
   List<long[]> fresh = (List<long[]>)(op.equals("normalize") ? call(op,a) : call(op,a,ranges()));
   fresh.get(0)[0]=-99;
   if(a.get(1)[0]!=1) throw new AssertionError("alias");
  }
  long lo=Long.MIN_VALUE, hi=Long.MAX_VALUE;
  if(!call("length",ranges(lo,hi,0,1)).equals(new BigInteger("18446744073709551615"))) throw new AssertionError("overflow");
  equal(call("subtract",ranges(lo,hi),ranges(-1,1)),ranges(lo,-1,1,hi));
  for(String op:List.of("normalize","subtract","length")) {
   List<List<long[]>> invalid = Arrays.asList(null, Collections.singletonList(null),
    Collections.singletonList(new long[0]), Collections.singletonList(new long[]{1}),
    Collections.singletonList(new long[]{1,2,3}),ranges(2,1));
   for(List<long[]> bad:invalid) {
    for(int side=0;side<(op.equals("subtract")?2:1);side++) {
     try {
      if(op.equals("subtract")) call(op,side==0?bad:ranges(),side==1?bad:ranges());
      else call(op,bad);
      throw new AssertionError("accepted invalid input");
     } catch(IllegalArgumentException expected) {}
    }
   }
   Object empty = op.equals("subtract")?call(op,ranges(1,1),ranges()):call(op,ranges(1,1));
   if(op.equals("length")) {if(!empty.equals(BigInteger.ZERO)) throw new AssertionError();}
   else equal(empty,ranges());
  }
 }
 public static void main(String[] args) throws Exception {
  Path dir=Files.createTempDirectory("ranges-regression");
  try {
   if(ToolProvider.getSystemJavaCompiler().run(null,null,null,"-d",dir.toString(),"Ranges.java")!=0) throw new AssertionError();
   try(var loader=new URLClassLoader(new URL[]{dir.toUri().toURL()})) {type=loader.loadClass("Ranges");run();}
  } finally {
   try(var paths=Files.walk(dir)) {for(Path p:paths.sorted(Comparator.reverseOrder()).toList()) Files.delete(p);}
  }
 }
}
