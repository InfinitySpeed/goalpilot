import java.util.*;
import java.math.BigInteger;
import java.nio.file.*;
import java.net.*;
import javax.tools.ToolProvider;

class RegressionRanges {
 static Class<?> ranges;
 @SuppressWarnings("unchecked")
 static <T> T call(String name, List<long[]>... args) throws Exception {
  Class<?>[] types = new Class<?>[args.length];
  Arrays.fill(types, List.class);
  try { return (T) ranges.getMethod(name, types).invoke(null, (Object[]) args); }
  catch (java.lang.reflect.InvocationTargetException e) {
   if (e.getCause() instanceof IllegalArgumentException) throw new IllegalArgumentException();
   throw e;
  }
 }
 static List<long[]> rs(long... endpoints) {
  List<long[]> a = new ArrayList<>();
  for (int i=0;i<endpoints.length;i+=2) a.add(new long[]{endpoints[i], endpoints[i+1]});
  return a;
 }
 static void eq(List<long[]> actual, long... expected) {
  if (!Arrays.deepEquals(actual.toArray(), rs(expected).toArray())) throw new AssertionError("Ranges differ");
 }
 static void check(boolean ok) { if (!ok) throw new AssertionError(); }
 static void invalid(String name, List<long[]>... args) throws Exception {
  try { call(name,args); } catch (IllegalArgumentException expected) { return; }
  throw new AssertionError("Accepted invalid input: " + name);
 }
 public static void main(String[] args) throws Exception {
  Path d = Files.createTempDirectory("ranges-regression");
  try {
   check(ToolProvider.getSystemJavaCompiler().run(null,null,null,"-d",d.toString(),"Ranges.java")==0);
   try (var loader = new URLClassLoader(new URL[]{d.toUri().toURL()})) {
    ranges = loader.loadClass("Ranges");
    List<long[]> a = rs(8,12,1,4,3,8,5,5,-4,-2);
    eq(call("normalize",a),-4,-2,1,12);
    eq(a,8,12,1,4,3,8,5,5,-4,-2);
    List<long[]> n = call("normalize",a);
    n.get(0)[0]=100;
    eq(a,8,12,1,4,3,8,5,5,-4,-2);
    List<long[]> b=rs(9,10,2,3,3,5,11,20);
    eq(call("subtract",a,b),-4,-2,1,2,5,9,10,11);
    eq(b,9,10,2,3,3,5,11,20);
    eq(call("subtract",rs(0,2,4,6,8,10),rs(1,9)),0,1,9,10);
    eq(call("subtract",rs(0,2),rs(-2,0,2,4)),0,2);
    eq(call("subtract",rs(0,2),rs(-1,3)));
    eq(call("subtract",rs(),rs(1,2)));
    List<long[]> original=rs(0,2);
    List<long[]> copy=call("subtract",original,rs());
    copy.get(0)[1]=1; eq(original,0,2);
    check(call("length",a).equals(BigInteger.valueOf(13)));
    check(call("length",rs(Long.MIN_VALUE,Long.MAX_VALUE)).equals(new BigInteger("18446744073709551615")));
    eq(call("normalize",rs(Long.MAX_VALUE,Long.MAX_VALUE,Long.MIN_VALUE,0,0,Long.MAX_VALUE)),Long.MIN_VALUE,Long.MAX_VALUE);
    check(call("length",rs(3,3)).equals(BigInteger.ZERO));
    List<List<long[]>> bad = new ArrayList<>();
    bad.add(null); bad.add(Collections.singletonList(null));
    bad.add(Collections.singletonList(new long[0]));
    bad.add(Collections.singletonList(new long[]{1}));
    bad.add(Collections.singletonList(new long[]{1,2,3})); bad.add(rs(2,1));
    for (List<long[]> x:bad) {
     invalid("normalize",x); invalid("length",x);
     invalid("subtract",x,rs()); invalid("subtract",rs(),x);
    }
   }
  } finally {
   try (var paths=Files.walk(d)) {
    for (Path p:paths.sorted(Comparator.reverseOrder()).toList()) Files.delete(p);
   }
  }
 }
}
