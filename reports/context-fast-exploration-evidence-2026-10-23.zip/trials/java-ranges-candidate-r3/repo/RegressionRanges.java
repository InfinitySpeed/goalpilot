import java.util.*;
import java.math.BigInteger;
import java.nio.file.*;
import java.net.*;
import javax.tools.ToolProvider;
import java.lang.reflect.*;

class RegressionRanges {
 static Class<?> ranges;
 static Object call(String name, Object... args) throws Exception {
  Class<?>[] types = new Class<?>[args.length]; Arrays.fill(types, List.class);
  try { return ranges.getMethod(name, types).invoke(null, args); }
  catch (InvocationTargetException e) {
   if (e.getCause() instanceof IllegalArgumentException) throw new IllegalArgumentException();
   throw e;
  }
 }
 static List<long[]> pairs(long... values) {
  List<long[]> out = new ArrayList<>();
  for(int i=0;i<values.length;i+=2) out.add(new long[]{values[i],values[i+1]});
  return out;
 }
 static void equal(Object actual, long... expected) {
  List<?> list=(List<?>)actual;
  if(list.size()*2!=expected.length) throw new AssertionError("size");
  for(int i=0;i<list.size();i++)
   if(!Arrays.equals((long[])list.get(i),new long[]{expected[2*i],expected[2*i+1]})) throw new AssertionError("range");
 }
 public static void main(String[] args) throws Exception {
  Path d=Files.createTempDirectory("ranges-regression");
  try {
   if(ToolProvider.getSystemJavaCompiler().run(null,null,null,"-d",d.toString(),"Ranges.java")!=0) throw new AssertionError();
   try(var loader=new URLClassLoader(new URL[]{d.toUri().toURL()})) {
    ranges=loader.loadClass("Ranges");
    List<long[]> a=pairs(8,10,1,4,4,8,2,3,9,9);
    equal(call("normalize",a),1,10);
    equal(a,8,10,1,4,4,8,2,3,9,9);
    List<long[]> b=pairs(7,9,2,4,3,5);
    equal(call("subtract",a,b),1,2,5,7,9,10);
    equal(b,7,9,2,4,3,5);
    equal(call("subtract",pairs(0,2,4,6,8,10),pairs(1,9)),0,1,9,10);
    equal(call("subtract",a,pairs(-1,20)));
    equal(call("subtract",pairs(1,3),pairs(-2,1,3,5)),1,3);
    equal(call("normalize",pairs(2,2)));
    equal(call("subtract",pairs(),pairs(0,1)));
    for(String op:List.of("normalize","subtract")) {
     List<long[]> out=(List<long[]>) (op.equals("normalize")?call(op,a):call(op,a,pairs()));
     out.get(0)[0]=99;
     equal(a,8,10,1,4,4,8,2,3,9,9);
    }
    if(!call("length",a).equals(BigInteger.valueOf(9))) throw new AssertionError();
    if(!call("length",pairs(Long.MIN_VALUE,Long.MAX_VALUE)).equals(new BigInteger("18446744073709551615"))) throw new AssertionError();
    equal(call("subtract",pairs(Long.MIN_VALUE,Long.MAX_VALUE),pairs(-1,1)),Long.MIN_VALUE,-1,1,Long.MAX_VALUE);
    if(!call("length",pairs()).equals(BigInteger.ZERO)) throw new AssertionError();
    List<List<long[]>> invalid=new ArrayList<>();
    invalid.add(null); invalid.add(Collections.singletonList(null));
    invalid.add(Collections.singletonList(new long[0]));
    invalid.add(Collections.singletonList(new long[]{1}));
    invalid.add(Collections.singletonList(new long[]{1,2,3}));
    invalid.add(pairs(3,2));
    for(List<long[]> bad:invalid) for(int mode=0;mode<4;mode++) {
     try {
      switch(mode) {
       case 0 -> call("normalize",bad);
       case 1 -> call("length",bad);
       case 2 -> call("subtract",bad,pairs());
       default -> call("subtract",pairs(),bad);
      }
      throw new AssertionError("accepted invalid input");
     } catch(IllegalArgumentException expected) {}
    }
   }
  } finally {
   try(var paths=Files.walk(d)) { paths.sorted(Comparator.reverseOrder()).forEach(p->{try{Files.delete(p);}catch(Exception e){throw new RuntimeException(e);}}); }
  }
 }
}
