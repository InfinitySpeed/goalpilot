import java.util.*;
import java.math.BigInteger;
import java.nio.file.*;
import java.net.*;
import javax.tools.ToolProvider;

class RegressionRanges {
 static Class<?> ranges;
 static Object call(String name, Object... args) throws Exception {
  Class<?>[] types = new Class<?>[args.length];
  Arrays.fill(types, List.class);
  try { return ranges.getMethod(name, types).invoke(null, args); }
  catch (java.lang.reflect.InvocationTargetException e) {
   if (e.getCause() instanceof IllegalArgumentException) throw (IllegalArgumentException)e.getCause();
   throw e;
  }
 }
 static List<long[]> list(long... pairs) {
  List<long[]> out = new ArrayList<>();
  for (int i=0;i<pairs.length;i+=2) out.add(new long[]{pairs[i],pairs[i+1]});
  return out;
 }
 static void eq(Object actual, List<long[]> expected) {
  List<?> got=(List<?>)actual;
  if(got.size()!=expected.size()) throw new AssertionError("size");
  for(int i=0;i<got.size();i++) if(!Arrays.equals((long[])got.get(i),expected.get(i))) throw new AssertionError("range");
 }
 static void invalid(String method, Object... args) throws Exception {
  try {call(method,args);} catch(IllegalArgumentException e){return;}
  throw new AssertionError("accepted invalid input");
 }
 public static void main(String[] args) throws Exception {
  Path dir=Files.createTempDirectory("ranges-regression");
  try {
   if(ToolProvider.getSystemJavaCompiler().run(null,null,null,"-d",dir.toString(),"Ranges.java")!=0) throw new AssertionError();
   try(var loader=new URLClassLoader(new URL[]{dir.toUri().toURL()})) {
    ranges=loader.loadClass("Ranges");
    List<long[]> a=list(8,10,2,5,5,8,3,4,0,0,-4,-2);
    eq(call("normalize",a),list(-4,-2,2,10));
    eq(a,list(8,10,2,5,5,8,3,4,0,0,-4,-2));
    List<long[]> cuts=list(7,9,1,3,3,4,20,30);
    eq(call("subtract",a,cuts),list(-4,-2,4,7,9,10));
    eq(cuts,list(7,9,1,3,3,4,20,30));
    eq(call("subtract",list(0,2,4,6),list(-1,5)),list(5,6));
    eq(call("subtract",list(0,5),list(0,5)),list());
    eq(call("subtract",list(0,5),list(-2,0,5,8)),list(0,5));
    eq(call("normalize",list()),list());
    eq(call("subtract",list(),list()),list());
    long lo=Long.MIN_VALUE, hi=Long.MAX_VALUE;
    eq(call("subtract",list(lo,hi),list(-1,1)),list(lo,-1,1,hi));
    if(!call("length",list(lo,0,0,hi,lo,hi)).equals(new BigInteger("18446744073709551615"))) throw new AssertionError("overflow");
    if(!call("length",list(0,0)).equals(BigInteger.ZERO)) throw new AssertionError();
    for(String method:List.of("normalize","subtract")) {
     List<long[]> input=list(1,4);
     Object result=method.equals("normalize")?call(method,input):call(method,input,list());
     ((long[])((List<?>)result).get(0))[0]=99;
     eq(input,list(1,4));
    }
    List<List<long[]>> bad=new ArrayList<>();
    bad.add(null); bad.add(Arrays.asList((long[])null));
    bad.add(Collections.singletonList(new long[0]));
    bad.add(Collections.singletonList(new long[]{1}));
    bad.add(Collections.singletonList(new long[]{1,2,3})); bad.add(list(2,1));
    for(List<long[]> b:bad) {
     invalid("normalize",b); invalid("length",b);
     invalid("subtract",b,list()); invalid("subtract",list(),b);
    }
   }
  } finally {
   try(var paths=Files.walk(dir)) { for(Path p:paths.sorted(Comparator.reverseOrder()).toList()) Files.delete(p); }
  }
 }
}
