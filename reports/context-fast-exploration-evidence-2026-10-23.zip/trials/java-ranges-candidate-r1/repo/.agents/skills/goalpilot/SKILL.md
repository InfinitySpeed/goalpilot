---
name: goalpilot
description: Finish coding goals in the existing stack with frozen native verification.
---

# GoalPilot

Work HERE, without nested agents/models. FIRST command: python3 N begin --goal 'VERBATIM ORIGINAL GOAL' --repo REPO --run-dir RUN --context --context-bytes B. N = scripts/native.py beside this skill; RUN outside REPO. Forward requested budgets; --goal-file accepts exact UTF-8. Resume existing evidence; never reset or start both engines. For one clear, bounded change with obvious checks, set B=6000; for vague, cross-file, multi-workflow or ambitious goals use B=18000 and retain the full workflow. Begin selects the frozen optimized service route only for compatible Python stubs, native verification otherwise.

Follow the returned protocol. NEXT command: implement, add focused native regressions, save criteria and deliver together. Use the project’s documented check runner so it resolves tool paths; never assume a bare compiler command such as javac is installed. Before the first test run, check every new expected value against the written contract; for sequential operations derive expectations from intermediate state and keep rejection tests single-cause. If a pre-green authored test contradicts the contract, repair it and use the explicit finish --test-revision command; do not query CLI --help. Extra reads only for named missing/truncated details. Preserve stack/tests/data/API; cover ALL goal clauses/guards. Aim <=1600 implementation+test tokens with shared/table-driven logic, correctness first. No speculative abstractions, unrequested docs, narration or duplicate tests. goal_complete:true => END immediately. stop_blocked => report blocker without claiming completion or rerunning unchanged checks. Final factual and concise.
