import java.util.*;
import java.math.BigInteger;
import java.nio.file.*;
import java.net.*;
import javax.tools.ToolProvider;

class RangeRegressions {
 static Class<?> ranges;
 @SuppressWarnings("unchecked")
 static List<long[]> call(String method, List<long[]> a, List<long[]> b) throws Exception {
  try {
   return (List<long[]>) (method.equals("normalize")
    ? ranges.getMethod(method,List.class).invoke(null,a)
    : ranges.getMethod(method,List.class,List.class).invoke(null,a,b));
  } catch (java.lang.reflect.InvocationTargetException e) {
   if (e.getCause() instanceof IllegalArgumentException x) throw x;
   throw e;
  }
 }
 static BigInteger length(List<long[]> a) throws Exception {
  try { return (BigInteger) ranges.getMethod("length",List.class).invoke(null,a); }
  catch (java.lang.reflect.InvocationTargetException e) {
   if (e.getCause() instanceof IllegalArgumentException x) throw x;
   throw e;
  }
 }
 static void check(boolean b) { if (!b) throw new AssertionError(); }
 static void same(List<long[]> actual, long[]... expected) {
  check(actual.size()==expected.length);
  for(int i=0;i<expected.length;i++) check(Arrays.equals(actual.get(i),expected[i]));
 }
 static boolean[] points(List<long[]> a) {
  boolean[] p=new boolean[20];
  for(long[] r:a) for(long i=r[0];i<r[1];i++) p[(int)i+10]=true;
  return p;
 }
 static List<long[]> random(Random random) {
  List<long[]> a=new ArrayList<>();
  for(int i=random.nextInt(12);i>0;i--) {
   int x=random.nextInt(21)-10,y=random.nextInt(21)-10;
   a.add(new long[]{Math.min(x,y),Math.max(x,y)});
  }
  return a;
 }
 static void canonical(List<long[]> a) {
  for(int i=0;i<a.size();i++) {
   check(a.get(i).length==2 && a.get(i)[0]<a.get(i)[1]);
   if(i>0) check(a.get(i-1)[1]<a.get(i)[0]);
  }
 }
 public static void main(String[] args) throws Exception {
  Path d=Files.createTempDirectory("range-regressions");
  try {
   check(ToolProvider.getSystemJavaCompiler().run(null,null,null,"-d",d.toString(),"Ranges.java")==0);
   try(var loader=new URLClassLoader(new URL[]{d.toUri().toURL()})) {
    ranges=loader.loadClass("Ranges");
    same(call("normalize",List.of(new long[]{5,8},new long[]{1,3},new long[]{3,5},new long[]{2,2}),null),new long[]{1,8});
    List<long[]> full=List.of(new long[]{Long.MIN_VALUE,Long.MAX_VALUE});
    check(length(full).equals(BigInteger.ONE.shiftLeft(64).subtract(BigInteger.ONE)));
    same(call("subtract",full,List.of(new long[]{-1,1})),new long[]{Long.MIN_VALUE,-1},new long[]{1,Long.MAX_VALUE});
    same(call("subtract",full,full));
    same(call("subtract",List.of(new long[]{0,2},new long[]{4,6}),List.of(new long[]{1,5})),new long[]{0,1},new long[]{5,6});
    for(String method:List.of("normalize","subtract")) {
     long[] source={1,4};
     List<long[]> out=call(method,List.of(source),List.of());
     check(out.get(0)!=source); out.get(0)[0]=2; check(source[0]==1);
     source[1]=3; check(out.get(0)[1]==4);
    }
    List<List<long[]>> invalid=new ArrayList<>();
    invalid.add(null); invalid.add(Arrays.asList((long[])null));
    invalid.add(List.of(new long[]{})); invalid.add(List.of(new long[]{1}));
    invalid.add(List.of(new long[]{0,1,2})); invalid.add(List.of(new long[]{2,1}));
    for(List<long[]> bad:invalid) for(int op=0;op<4;op++) {
     boolean rejected=false;
     try { if(op==0) call("normalize",bad,null); else if(op==1) length(bad);
      else call("subtract",op==2?bad:List.of(),op==3?bad:List.of());
     } catch(IllegalArgumentException expected) { rejected=true; }
     check(rejected);
    }
    Random random=new Random(193);
    for(int trial=0;trial<1000;trial++) {
     List<long[]> a=random(random),b=random(random);
     boolean[] pa=points(a),pb=points(b);
     List<long[]> n=call("normalize",a,null),s=call("subtract",a,b);
     canonical(n); canonical(s); check(Arrays.equals(points(n),pa));
     int count=0; for(int i=0;i<pa.length;i++) { if(pa[i]) count++; pa[i]&=!pb[i]; }
     check(length(a).equals(BigInteger.valueOf(count))); check(Arrays.equals(points(s),pa));
    }
   }
  } finally { try(var paths=Files.walk(d)) { for(Path p:paths.sorted(Comparator.reverseOrder()).toList()) Files.delete(p); } }
 }
}
