import pathlib
import subprocess
import tempfile

root = pathlib.Path(__file__).resolve().parent.parent
with tempfile.TemporaryDirectory() as output:
    subprocess.run(['javac', '-d', output, str(root / 'Ranges.java'),
                    str(root / 'tests/RangeRegression.java')], check=True)
    subprocess.run(['java', '-cp', output, 'RangeRegression'], check=True)
