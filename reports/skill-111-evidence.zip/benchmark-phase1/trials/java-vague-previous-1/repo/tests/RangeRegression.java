import java.util.*;
import java.math.BigInteger;

class RangeRegression {
 static List<long[]> ranges(long... values) {
  List<long[]> r = new ArrayList<>();
  for (int i=0;i<values.length;i+=2) r.add(new long[]{values[i],values[i+1]});
  return r;
 }
 static void equal(List<long[]> actual, long... expected) {
  if (actual.size()*2 != expected.length) throw new AssertionError("Wrong count");
  for(int i=0;i<actual.size();i++)
   if (!Arrays.equals(actual.get(i), new long[]{expected[2*i],expected[2*i+1]}))
    throw new AssertionError("Wrong range");
 }
 static void require(boolean b) { if(!b) throw new AssertionError(); }
 static void invalid(Runnable r) {
  try { r.run(); } catch(IllegalArgumentException e) { return; }
  throw new AssertionError("Missing IllegalArgumentException");
 }
 static boolean contains(List<long[]> a,int x) {
  for(long[] r:a) if(r[0]<=x && x<r[1]) return true;
  return false;
 }
 static void canonical(List<long[]> a) {
  for(int i=0;i<a.size();i++) {
   require(a.get(i).length==2 && a.get(i)[0]<a.get(i)[1]);
   if(i>0) require(a.get(i-1)[1]<a.get(i)[0]);
  }
 }
 public static void main(String[] args) {
  equal(Ranges.normalize(ranges(5,8,1,3,3,5,2,4,9,9)),1,8);
  equal(Ranges.normalize(ranges()));
  equal(Ranges.subtract(ranges(10,20,0,10),ranges(7,12,3,8,16,30)),0,3,12,16);
  equal(Ranges.subtract(ranges(0,1,2,3,4,5),ranges(-1,6)));
  equal(Ranges.subtract(ranges(0,10),ranges(-3,0,10,12)),0,10);
  equal(Ranges.subtract(ranges(0,10),ranges(2,3,5,6)),0,2,3,5,6,10);
  long lo=Long.MIN_VALUE, hi=Long.MAX_VALUE;
  equal(Ranges.normalize(ranges(hi-1,hi,lo,lo+1)),lo,lo+1,hi-1,hi);
  equal(Ranges.subtract(ranges(lo,hi),ranges(-1,1)),lo,-1,1,hi);
  require(Ranges.length(ranges(lo,hi)).equals(BigInteger.ONE.shiftLeft(64).subtract(BigInteger.ONE)));
  require(Ranges.length(ranges(0,10,5,15,2,2)).equals(BigInteger.valueOf(15)));
  require(Ranges.length(ranges()).equals(BigInteger.ZERO));
  List<List<long[]>> bad = new ArrayList<>();
  bad.add(null); bad.add(Arrays.asList((long[])null));
  bad.add(List.of(new long[0])); bad.add(List.of(new long[1]));
  bad.add(List.of(new long[3])); bad.add(ranges(2,1));
  for(List<long[]> a:bad) {
   invalid(()->Ranges.normalize(a)); invalid(()->Ranges.length(a));
   invalid(()->Ranges.subtract(a,ranges())); invalid(()->Ranges.subtract(ranges(),a));
  }
  long[] original={1,5}; List<long[]> input=Collections.singletonList(original);
  List<long[]> n=Ranges.normalize(input), s=Ranges.subtract(input,ranges(2,3));
  require(original[0]==1 && original[1]==5);
  n.get(0)[0]=99; s.get(0)[0]=98;
  require(original[0]==1 && s.get(1)[0]==3);
  original[1]=100; require(n.get(0)[1]==5 && s.get(1)[1]==5);
  Random random=new Random(715);
  for(int t=0;t<1000;t++) {
   List<long[]> a=new ArrayList<>(), b=new ArrayList<>();
   for(List<long[]> list:List.of(a,b)) for(int i=0;i<10;i++) {
    int x=random.nextInt(21)-10,y=random.nextInt(21)-10;
    list.add(new long[]{Math.min(x,y),Math.max(x,y)});
   }
   List<long[]> norm=Ranges.normalize(a), diff=Ranges.subtract(a,b);
   canonical(norm); canonical(diff); int count=0;
   for(int x=-10;x<10;x++) {
    require(contains(norm,x)==contains(a,x));
    boolean wanted=contains(a,x)&&!contains(b,x);
    require(contains(diff,x)==wanted); if(wanted)count++;
   }
   require(Ranges.length(diff).equals(BigInteger.valueOf(count)));
  }
 }
}
