import subprocess

subprocess.run(['java', 'tests/RunRegression.java'], check=True)
