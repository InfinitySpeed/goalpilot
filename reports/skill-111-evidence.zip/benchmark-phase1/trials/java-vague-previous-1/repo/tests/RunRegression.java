import javax.tools.ToolProvider;
import java.net.*;
import java.nio.file.*;
import java.util.Comparator;

class RunRegression {
 public static void main(String[] args) throws Exception {
  Path output=Files.createTempDirectory("range-regression");
  try {
   if(ToolProvider.getSystemJavaCompiler().run(null,null,null,"-d",output.toString(),
      "Ranges.java","tests/RangeRegression.java")!=0) throw new AssertionError("Compilation failed");
   try(var loader=new URLClassLoader(new URL[]{output.toUri().toURL()})) {
    var main=loader.loadClass("RangeRegression").getDeclaredMethod("main",String[].class);
    main.setAccessible(true);
    main.invoke(null,(Object)new String[0]);
   }
  } finally {
   try(var paths=Files.walk(output)) {
    for(Path path:paths.sorted(Comparator.reverseOrder()).toList()) Files.delete(path);
   }
  }
 }
}
