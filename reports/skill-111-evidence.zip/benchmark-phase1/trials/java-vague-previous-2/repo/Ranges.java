import java.util.*;
import java.math.BigInteger;

public class Ranges {
 public static List<long[]> normalize(List<long[]> a) {
  if (a == null) throw new IllegalArgumentException("null ranges");
  List<long[]> sorted = new ArrayList<>();
  for (long[] r : a) {
   if (r == null || r.length != 2 || r[0] > r[1])
    throw new IllegalArgumentException("expected [start,end) with start <= end");
   if (r[0] < r[1]) sorted.add(new long[]{r[0], r[1]});
  }
  sorted.sort(Comparator.comparingLong(r -> r[0]));
  List<long[]> result = new ArrayList<>();
  for (long[] r : sorted) {
   if (result.isEmpty() || result.get(result.size()-1)[1] < r[0]) result.add(r);
   else {
    long[] last = result.get(result.size()-1);
    last[1] = Math.max(last[1], r[1]);
   }
  }
  return result;
 }
 public static List<long[]> subtract(List<long[]> a, List<long[]> b) {
  List<long[]> left = normalize(a), right = normalize(b), result = new ArrayList<>();
  int j = 0;
  for (long[] r : left) {
   long start = r[0], end = r[1];
   while (j < right.size() && right.get(j)[1] <= start) j++;
   int k = j;
   while (k < right.size() && right.get(k)[0] < end) {
    long[] cut = right.get(k);
    if (cut[0] > start) result.add(new long[]{start, cut[0]});
    start = Math.max(start, cut[1]);
    if (start >= end) break;
    k++;
   }
   if (start < end) result.add(new long[]{start, end});
   j = k;
  }
  return result;
 }
 public static BigInteger length(List<long[]> a) {
  BigInteger total = BigInteger.ZERO;
  for (long[] r : normalize(a))
   total = total.add(BigInteger.valueOf(r[1]).subtract(BigInteger.valueOf(r[0])));
  return total;
 }
}
