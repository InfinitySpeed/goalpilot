import subprocess
subprocess.run(['java', 'RegressionRunner.java'], check=True)
