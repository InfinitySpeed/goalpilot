import javax.tools.ToolProvider;
import java.net.*;
import java.nio.file.*;
import java.util.Comparator;
class RegressionRunner {
 public static void main(String[] args) throws Exception {
  Path dir=Files.createTempDirectory("ranges-regressions");
  try {
   if(ToolProvider.getSystemJavaCompiler().run(null,null,null,"-d",dir.toString(),"Ranges.java","RegressionRanges.java")!=0) throw new AssertionError("compilation");
   try(var loader=new URLClassLoader(new URL[]{dir.toUri().toURL()})) {
    loader.loadClass("RegressionRanges").getMethod("main",String[].class).invoke(null,(Object)new String[0]);
   }
  } finally {
   try(var paths=Files.walk(dir)) {
    for(Path p:paths.sorted(Comparator.reverseOrder()).toList()) Files.delete(p);
   }
  }
 }
}
