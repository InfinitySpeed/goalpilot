import java.util.*;
import java.math.BigInteger;

public class RegressionRanges {
 static List<long[]> ranges(long... x) {
  List<long[]> a = new ArrayList<>();
  for (int i=0;i<x.length;i+=2) a.add(new long[]{x[i],x[i+1]});
  return a;
 }
 static void eq(List<long[]> a, long... expected) {
  List<long[]> b = ranges(expected);
  if (a.size()!=b.size()) throw new AssertionError("size " + a.size());
  for(int i=0;i<a.size();i++) if(!Arrays.equals(a.get(i),b.get(i))) throw new AssertionError(Arrays.toString(a.get(i)));
 }
 static void invalid(Runnable f) {
  try { f.run(); } catch(IllegalArgumentException e) { return; }
  throw new AssertionError("invalid input accepted");
 }
 static boolean contains(List<long[]> a, long x) {
  for(long[] r:a) if(r[0]<=x && x<r[1]) return true;
  return false;
 }
 static void canonical(List<long[]> a) {
  for(int i=0;i<a.size();i++) {
   if(a.get(i).length!=2 || a.get(i)[0]>=a.get(i)[1] || (i>0 && a.get(i-1)[1]>=a.get(i)[0])) throw new AssertionError("noncanonical");
  }
 }
 public static void main(String[] args) {
  eq(Ranges.normalize(ranges(5,9,1,3,3,5,2,4,10,10)),1,9);
  eq(Ranges.subtract(ranges(8,12,0,5,3,9),ranges(10,11,2,4,3,6)),0,2,6,10,11,12);
  eq(Ranges.subtract(ranges(0,2,4,6,8,10),ranges(1,9)),0,1,9,10);
  eq(Ranges.subtract(ranges(0,2),ranges(-1,3)));
  eq(Ranges.subtract(ranges(0,2),ranges(-2,0,2,4)),0,2);
  eq(Ranges.normalize(ranges()));
  eq(Ranges.subtract(ranges(),ranges(0,1)));
  long lo=Long.MIN_VALUE, hi=Long.MAX_VALUE;
  eq(Ranges.normalize(ranges(0,hi,lo,0)),lo,hi);
  eq(Ranges.subtract(ranges(lo,hi),ranges(-1,1)),lo,-1,1,hi);
  if(!Ranges.length(ranges(lo,hi,lo,0)).equals(BigInteger.ONE.shiftLeft(64).subtract(BigInteger.ONE))) throw new AssertionError("overflow");
  if(!Ranges.length(ranges()).equals(BigInteger.ZERO)) throw new AssertionError();
  List<List<long[]>> bad = new ArrayList<>();
  bad.add(null); bad.add(Arrays.asList((long[])null));
  bad.add(List.of(new long[0])); bad.add(List.of(new long[]{1}));
  bad.add(List.of(new long[]{0,1,2})); bad.add(ranges(2,1));
  for(List<long[]> a:bad) {
   invalid(()->Ranges.normalize(a)); invalid(()->Ranges.length(a));
   invalid(()->Ranges.subtract(a,ranges())); invalid(()->Ranges.subtract(ranges(),a));
  }
  List<long[]> input=ranges(4,8,0,2), copy=ranges(4,8,0,2);
  List<long[]> n=Ranges.normalize(input), s=Ranges.subtract(input,ranges());
  eq(input,4,8,0,2);
  n.get(0)[0]=-9; s.get(1)[1]=99;
  eq(input,4,8,0,2); eq(Ranges.normalize(copy),0,2,4,8);
  List<long[]> cuts=ranges(1,3);
  List<long[]> diff=Ranges.subtract(ranges(0,4),cuts);
  diff.get(0)[1]=99; eq(cuts,1,3); eq(diff.subList(1,2),3,4);
  Random random=new Random(193);
  for(int t=0;t<500;t++) {
   List<long[]> a=ranges(),b=ranges();
   for(List<long[]> set:List.of(a,b)) for(int i=0;i<8;i++) {
    int x=random.nextInt(21)-10,y=random.nextInt(21)-10;
    set.add(new long[]{Math.min(x,y),Math.max(x,y)});
   }
   List<long[]> norm=Ranges.normalize(a), sub=Ranges.subtract(a,b);
   canonical(norm); canonical(sub);
   int count=0;
   for(int x=-10;x<10;x++) {
    boolean in=contains(a,x);
    if(in) count++;
    if(contains(norm,x)!=in || contains(sub,x)!=(in&&!contains(b,x))) throw new AssertionError("membership");
   }
   if(!Ranges.length(a).equals(BigInteger.valueOf(count))) throw new AssertionError("length");
  }
 }
}
