import pathlib
import subprocess
import tempfile

root = pathlib.Path(__file__).resolve().parents[1]
with tempfile.TemporaryDirectory() as output:
    subprocess.run(['javac', '-d', output, str(root / 'Ranges.java'), str(root / 'RegressionRanges.java')], check=True)
    subprocess.run(['java', '-cp', output, 'RegressionRanges'], check=True)
