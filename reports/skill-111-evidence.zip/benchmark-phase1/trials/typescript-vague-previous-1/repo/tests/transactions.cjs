const assert = require('node:assert/strict');
const {Store} = require(process.env.STORE_MODULE);
const put = (key,value,expectedVersion) => expectedVersion === undefined ? {type:'put',key,value} : {type:'put',key,value,expectedVersion};
const del = (key,expectedVersion) => ({type:'delete',key,expectedVersion});
const s = new Store();
assert.deepEqual(s.apply([]), {revision:0,changed:[]});
const input = {nested:[{x:1}], ...JSON.parse('{"__proto__":{"safe":true}}')};
assert.deepEqual(s.apply([put('__proto__',input,0),put('b',null)]),{revision:1,changed:['__proto__','b']});
input.nested[0].x=9;
const output=s.get('__proto__'); output.value.nested[0].x=8; output.version=99;
assert.equal(s.get('__proto__').value.nested[0].x,1);
assert.equal(s.get('__proto__').version,1);
assert.equal(Object.hasOwn(s.get('__proto__').value,'__proto__'),true);
const keys=s.keys();keys.reverse();assert.deepEqual(s.keys(),['__proto__','b']);
const cycle={};cycle.self=cycle;
for (const bad of [undefined,()=>{},1n,NaN,Infinity,new Date(),cycle,{x:undefined},[undefined],Array(1)]) {
  const before=s.keys().map(k=>[k,s.get(k)]);
  assert.throws(()=>s.apply([del('__proto__',1),put('new',3),put('bad',bad)]));
  assert.equal(s.revision,1);assert.deepEqual(s.keys().map(k=>[k,s.get(k)]),before);
}
for (const bad of [null,{},[null],[{type:'other',key:'a'}],[put('',1)],[put('b',2,-1)],[put('b',2,1.5)],[put('b',2,0)]]) {
  assert.throws(()=>s.apply(bad));assert.equal(s.revision,1);
}
assert.throws(()=>s.apply([del('__proto__',1),put('b',2,0)]));
assert.deepEqual(s.keys(),['__proto__','b']);
assert.deepEqual(s.apply([put('x',1,0),put('x',2,2),del('x',2),del('missing',0),put('__proto__',false,1)]),{revision:2,changed:['x','missing','__proto__']});
assert.equal(s.get('x'),undefined);assert.deepEqual(s.get('__proto__'),{value:false,version:2});
const shared={a:1};s.apply([put('shared',[shared,shared]),del('b',1),put('b','last',0)]);
assert.deepEqual(s.keys(),['__proto__','shared','b']);
assert.deepEqual(s.get('shared').value,[{a:1},{a:1}]);
