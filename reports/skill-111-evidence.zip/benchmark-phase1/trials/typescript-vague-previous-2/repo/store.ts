type Entry = {value: unknown, version: number};
function copy(value: unknown, ancestors = new Set<object>()): unknown {
  if (value === null || typeof value === 'string' || typeof value === 'boolean') return value;
  if (typeof value === 'number' && Number.isFinite(value)) return value;
  if (typeof value !== 'object' || value === null) throw Error('Invalid JSON value');
  const proto = Object.getPrototypeOf(value);
  if (!Array.isArray(value) && proto !== Object.prototype && proto !== null) throw Error('Invalid JSON object');
  if (ancestors.has(value)) throw Error('Cyclic JSON value');
  ancestors.add(value);
  try {
    if (Array.isArray(value)) {
      const result: unknown[] = [];
      for (let i = 0; i < value.length; i++) result.push(copy(value[i], ancestors));
      return result;
    }
    const result: Record<string, unknown> = {};
    for (const key of Object.keys(value)) {
      Object.defineProperty(result, key, {value: copy((value as Record<string, unknown>)[key], ancestors), enumerable: true, writable: true, configurable: true});
    }
    return result;
  } finally { ancestors.delete(value); }
}
export class Store {
  revision = 0;
  private entries = new Map<string, Entry>();
  get(key: string): Entry | undefined {
    const entry = this.entries.get(key);
    return entry && {value: copy(entry.value), version: entry.version};
  }
  keys(): string[] { return [...this.entries.keys()]; }
  apply(ops: unknown): {revision: number, changed: string[]} {
    if (!Array.isArray(ops)) throw Error('Expected an operation array');
    const pending = new Map(this.entries);
    const changed = new Set<string>();
    const revision = this.revision + (ops.length ? 1 : 0);
    for (const raw of ops) {
      if (typeof raw !== 'object' || raw === null || Array.isArray(raw)) throw Error('Invalid operation');
      const op = raw as Record<string, unknown>;
      const {type, key} = op;
      if ((type !== 'put' && type !== 'delete') || typeof key !== 'string' || !key.length) throw Error('Invalid operation');
      if ('expectedVersion' in op) {
        const expected = op.expectedVersion;
        if (typeof expected !== 'number' || !Number.isSafeInteger(expected) || expected < 0) throw Error('Invalid version');
        if (expected !== (pending.get(key)?.version ?? 0)) throw Error('Version conflict');
      }
      if (type === 'put') pending.set(key, {value: copy(op.value), version: revision});
      else pending.delete(key);
      changed.add(key);
    }
    this.entries = pending;
    this.revision = revision;
    return {revision, changed: [...changed]};
  }
}
