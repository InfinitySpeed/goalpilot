const assert = require('node:assert/strict');
const {Store} = require(process.env.STORE_MODULE);
const s = new Store();
const put = (key,value,expectedVersion) => expectedVersion === undefined ? {type:'put',key,value} : {type:'put',key,value,expectedVersion};
assert.deepEqual(s.apply([]),{revision:0,changed:[]});
const input = {nested:[{n:1}]};
s.apply([put('a',input),put('b',2)]);
input.nested[0].n = 9;
const output = s.get('a'); output.value.nested[0].n = 8; output.version = 90;
assert.deepEqual(s.get('a'),{value:{nested:[{n:1}]},version:1});
const cycle = {}; cycle.self = cycle;
for (const bad of [undefined,NaN,Infinity,()=>{},1n,new Date(),cycle,{x:undefined},[undefined]]) {
  assert.throws(()=>s.apply([{type:'delete',key:'a'},put('c',bad)]));
  assert.deepEqual(s.keys(),['a','b']); assert.equal(s.revision,1);
  assert.equal(s.get('a').version,1); assert.equal(s.get('c'),undefined);
}
for (const bad of [null,{},[null],[{type:'other',key:'a'}],[put('',1)],[put('c',1,-1)],[put('c',1,0.5)],[put('a',1,0)]]) {
  assert.throws(()=>s.apply(bad)); assert.equal(s.revision,1); assert.deepEqual(s.keys(),['a','b']);
}
assert.throws(()=>s.apply([put('a',3,1),put('a',4,1)]));
assert.equal(s.get('a').value.nested[0].n,1);
assert.deepEqual(s.apply([put('a',3,1),{type:'delete',key:'a',expectedVersion:2},put('a',4,0),{type:'delete',key:'missing',expectedVersion:0}]),{revision:2,changed:['a','missing']});
assert.deepEqual(s.keys(),['b','a']); assert.deepEqual(s.get('a'),{value:4,version:2});
const special = JSON.parse('{"__proto__":{"ok":true}}');
s.apply([put('__proto__',special),put('constructor',[null,true,'x',-2]),put('shared',{a:input,b:input})]);
assert.deepEqual(s.get('__proto__').value,special);
assert.equal(Object.getPrototypeOf(s.get('__proto__').value),Object.prototype);
const keys=s.keys(); keys.length=0; assert.equal(s.keys().length,5);
assert.deepEqual(s.apply([put('temp',1),{type:'delete',key:'temp'}]),{revision:4,changed:['temp']});
assert.equal(s.get('temp'),undefined);
