type Entry = { value: unknown; version: number };
type Operation = {
  type: "put" | "delete";
  key: string;
  value?: unknown;
  expectedVersion?: number;
};

// Track ancestors, rather than every visited object: shared subtrees are valid
// JSON data, but a reference back to an ancestor is a cycle.
function copyJSON(value: unknown, ancestors = new Set<object>()): unknown {
  if (value === null || typeof value === "string" || typeof value === "boolean") {
    return value;
  }
  if (typeof value === "number" && Number.isFinite(value)) return value;
  if (typeof value !== "object" || value === null) throw new Error("Invalid JSON value");
  const array = Array.isArray(value);
  const prototype = Object.getPrototypeOf(value);
  if (!array && prototype !== Object.prototype && prototype !== null) {
    throw new Error("Invalid JSON object");
  }
  if (ancestors.has(value)) throw new Error("Cyclic JSON value");
  ancestors.add(value);
  try {
    if (array) {
      const result: unknown[] = [];
      for (let i = 0; i < value.length; i++) {
        if (!Object.prototype.hasOwnProperty.call(value, i)) throw new Error("Sparse JSON array");
        result.push(copyJSON(value[i], ancestors));
      }
      return result;
    }
    const result: Record<string, unknown> = {};
    for (const key of Object.keys(value)) {
      Object.defineProperty(result, key, {
        value: copyJSON((value as Record<string, unknown>)[key], ancestors),
        enumerable: true,
        configurable: true,
        writable: true,
      });
    }
    return result;
  } finally {
    ancestors.delete(value);
  }
}

export class Store {
  private currentRevision = 0;
  private entries = new Map<string, Entry>();

  get revision(): number { return this.currentRevision; }

  get(key: string): Entry | undefined {
    const entry = this.entries.get(key);
    return entry === undefined ? undefined : { value: copyJSON(entry.value), version: entry.version };
  }

  keys(): string[] { return [...this.entries.keys()]; }

  apply(ops: unknown): { revision: number; changed: string[] } {
    if (!Array.isArray(ops)) throw new Error("Operations must be an array");
    // Read and copy all caller-owned data before touching transaction state.
    const operations: Operation[] = [];
    for (const input of ops) {
      if (typeof input !== "object" || input === null) throw new Error("Invalid operation");
      const { type, key, expectedVersion } = input as Record<string, unknown>;
      if (type !== "put" && type !== "delete") throw new Error("Invalid operation type");
      if (typeof key !== "string" || key.length === 0) throw new Error("Invalid key");
      if (expectedVersion !== undefined &&
          (typeof expectedVersion !== "number" || !Number.isInteger(expectedVersion) || expectedVersion < 0)) {
        throw new Error("Invalid expected version");
      }
      operations.push({ type, key, expectedVersion,
        ...(type === "put" ? { value: copyJSON((input as Record<string, unknown>).value) } : {}),
      });
    }
    if (operations.length === 0) return { revision: this.currentRevision, changed: [] };
    const revision = this.currentRevision + 1;
    const staged = new Map(this.entries);
    const changed = new Set<string>();
    for (const op of operations) {
      const version = staged.get(op.key)?.version ?? 0;
      if (op.expectedVersion !== undefined && op.expectedVersion !== version) {
        throw new Error("Version conflict");
      }
      if (op.type === "put") staged.set(op.key, { value: op.value, version: revision });
      else staged.delete(op.key);
      changed.add(op.key);
    }
    this.entries = staged;
    this.currentRevision = revision;
    return { revision, changed: [...changed] };
  }
}
