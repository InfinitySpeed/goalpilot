const assert = require('node:assert/strict');
const { Store } = require(process.env.STORE_MODULE);
const put = (key, value, expectedVersion) => ({ type: 'put', key, value, expectedVersion });
const del = (key, expectedVersion) => ({ type: 'delete', key, expectedVersion });

const store = new Store();
assert.deepEqual(store.apply([]), { revision: 0, changed: [] });
assert.deepEqual(store.apply([put('a', { nested: [1] }), put('b', 2)]),
  { revision: 1, changed: ['a', 'b'] });
const snapshot = () => ({ revision: store.revision, entries: store.keys().map(k => [k, store.get(k)]) });
const before = snapshot();
for (const ops of [
  [del('a'), put('c', 3), put('b', 4, 0)],
  [put('a', 10), put('bad', undefined)],
  [del('a'), { type: 'unknown', key: 'b' }],
  [del('a'), put('', 1)],
  [del('a'), put('c', 1, -1)],
]) {
  assert.throws(() => store.apply(ops));
  assert.deepEqual(snapshot(), before);
}
assert.deepEqual(store.apply([put('a', 3, 1), put('a', 4, 2), del('a', 2), put('a', 5, 0)]),
  { revision: 2, changed: ['a'] });
assert.deepEqual(store.keys(), ['b', 'a']);
assert.deepEqual(store.get('a'), { value: 5, version: 2 });
assert.deepEqual(store.apply([put('temporary', true), del('temporary', 3), del('missing', 0)]),
  { revision: 3, changed: ['temporary', 'missing'] });
assert.equal(store.get('temporary'), undefined);
assert.equal(store.get('missing'), undefined);
assert.deepEqual(store.apply([]), { revision: 3, changed: [] });

const special = JSON.parse('{"__proto__":{"polluted":true},"constructor":[1]}');
store.apply([put('__proto__', special), put('constructor', null), put('toString', false)]);
assert.deepEqual(store.get('__proto__').value, special);
assert.equal(Object.getPrototypeOf(store.get('__proto__').value), Object.prototype);
assert.equal({}.polluted, undefined);
assert.equal(store.get('constructor').value, null);
assert.equal(store.get('toString').value, false);

const shared = { values: [1, { flag: true }] };
const input = { left: shared, right: shared };
store.apply([put('copy', input)]);
input.left.values[1].flag = false;
input.right.values.push(2);
const read = store.get('copy');
assert.deepEqual(read.value, { left: { values: [1, { flag: true }] }, right: { values: [1, { flag: true }] } });
read.value.left.values[1].flag = false;
read.version = 999;
const keys = store.keys();
keys.length = 0;
assert.equal(store.get('copy').value.left.values[1].flag, true);
assert.equal(store.get('copy').version, 5);
assert.ok(store.keys().includes('copy'));

const cycle = {}; cycle.self = cycle;
const arrayCycle = []; arrayCycle.push(arrayCycle);
for (const value of [undefined, NaN, Infinity, -Infinity, () => {}, 1n, Symbol(),
  new Date(), new Map(), new Set(), /x/, new Number(1), cycle, arrayCycle,
  { nested: undefined }, [undefined], Array(1), Object.create({ inherited: 1 })]) {
  const previous = snapshot();
  assert.throws(() => store.apply([del('b'), put('invalid', value)]));
  assert.deepEqual(snapshot(), previous);
}
for (const ops of [null, {}, 'x', [null], [1], Array(1),
  [put('x', 1, NaN)], [put('x', 1, 1.5)], [put('x', 1, '0')]]) {
  const previous = snapshot();
  assert.throws(() => store.apply(ops));
  assert.deepEqual(snapshot(), previous);
}
const plain = Object.create(null); plain.a = [null, true, 'text', -1.5];
store.apply([put('plain', plain)]);
assert.deepEqual(store.get('plain').value, { a: [null, true, 'text', -1.5] });

// A later conflict must also roll back a delete-and-reinsert's order changes.
const previous = snapshot();
assert.throws(() => store.apply([del('b'), put('b', 9), del('a', 999)]));
assert.deepEqual(snapshot(), previous);
