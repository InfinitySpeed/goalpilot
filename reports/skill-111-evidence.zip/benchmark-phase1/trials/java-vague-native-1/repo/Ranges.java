import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/** Operations on unions of half-open ranges with signed long endpoints. */
public class Ranges {
    /** Returns a sorted, disjoint union, merging adjacent ranges as well. */
    public static List<long[]> normalize(List<long[]> ranges) {
        if (ranges == null) {
            throw new IllegalArgumentException("Range list must not be null");
        }
        List<long[]> sorted = new ArrayList<>();
        for (long[] range : ranges) {
            if (range == null || range.length != 2) {
                throw new IllegalArgumentException("Each range must have two endpoints");
            }
            if (range[0] > range[1]) {
                throw new IllegalArgumentException("Range start must not exceed end");
            }
            if (range[0] < range[1]) {
                sorted.add(new long[] {range[0], range[1]});
            }
        }
        sorted.sort(Comparator.comparingLong(range -> range[0]));
        List<long[]> result = new ArrayList<>();
        for (long[] range : sorted) {
            if (result.isEmpty() || result.get(result.size() - 1)[1] < range[0]) {
                result.add(range);
            } else {
                long[] previous = result.get(result.size() - 1);
                previous[1] = Math.max(previous[1], range[1]);
            }
        }
        return result;
    }

    /** Returns the portion of the first union outside the second union. */
    public static List<long[]> subtract(List<long[]> a, List<long[]> b) {
        List<long[]> sources = normalize(a);
        List<long[]> removals = normalize(b);
        List<long[]> result = new ArrayList<>();
        int removalIndex = 0;
        for (long[] source : sources) {
            long cursor = source[0];
            while (removalIndex < removals.size()
                    && removals.get(removalIndex)[1] <= cursor) {
                removalIndex++;
            }
            while (removalIndex < removals.size()) {
                long[] removal = removals.get(removalIndex);
                if (removal[0] >= source[1]) {
                    break;
                }
                if (removal[0] > cursor) {
                    result.add(new long[] {cursor, removal[0]});
                }
                cursor = Math.max(cursor, removal[1]);
                if (cursor >= source[1]) {
                    break;
                }
                removalIndex++;
            }
            if (cursor < source[1]) {
                result.add(new long[] {cursor, source[1]});
            }
        }
        return result;
    }

    /** Returns the exact length of the union, without endpoint overflow. */
    public static BigInteger length(List<long[]> ranges) {
        BigInteger total = BigInteger.ZERO;
        for (long[] range : normalize(ranges)) {
            total = total.add(BigInteger.valueOf(range[1])
                    .subtract(BigInteger.valueOf(range[0])));
        }
        return total;
    }
}
