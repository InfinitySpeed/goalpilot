"""Run behavioral tests through Java's compiler API; no javac binary required."""
from pathlib import Path
import subprocess

root = Path(__file__).resolve().parent.parent
subprocess.run(["java", "tests/RunRangesBehavior.java"], cwd=root, check=True)
