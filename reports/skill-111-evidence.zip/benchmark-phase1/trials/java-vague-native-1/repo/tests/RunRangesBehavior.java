import java.net.URL;
import java.net.URLClassLoader;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Comparator;
import javax.tools.ToolProvider;

class RunRangesBehavior {
    public static void main(String[] args) throws Exception {
        Path directory = Files.createTempDirectory("ranges-behavior-");
        try {
            int status = ToolProvider.getSystemJavaCompiler().run(null, null, null,
                    "-d", directory.toString(), "Ranges.java", "TestRangesBehavior.java");
            if (status != 0) throw new AssertionError("Compilation failed");
            try (var loader = new URLClassLoader(new URL[] {directory.toUri().toURL()})) {
                loader.loadClass("TestRangesBehavior").getMethod("main", String[].class)
                        .invoke(null, (Object) new String[0]);
            }
        } finally {
            try (var paths = Files.walk(directory)) {
                for (Path path : paths.sorted(Comparator.reverseOrder()).toList()) {
                    Files.delete(path);
                }
            }
        }
    }
}
