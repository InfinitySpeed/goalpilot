import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;

public class TestRangesBehavior {
    private static List<long[]> ranges(long... endpoints) {
        List<long[]> result = new ArrayList<>();
        for (int i = 0; i < endpoints.length; i += 2) {
            result.add(new long[] {endpoints[i], endpoints[i + 1]});
        }
        return result;
    }

    private static void equal(List<long[]> actual, long... expected) {
        if (!Arrays.deepEquals(actual.toArray(), ranges(expected).toArray())) {
            throw new AssertionError("Unexpected ranges: " + Arrays.deepToString(actual.toArray()));
        }
    }

    private static void check(boolean condition) {
        if (!condition) throw new AssertionError();
    }

    private static void invalid(Runnable operation) {
        try {
            operation.run();
        } catch (IllegalArgumentException expected) {
            return;
        }
        throw new AssertionError("Expected IllegalArgumentException");
    }

    private static boolean covers(List<long[]> input, int point) {
        for (long[] range : input) {
            if (range[0] <= point && point < range[1]) return true;
        }
        return false;
    }

    private static void canonical(List<long[]> input) {
        for (int i = 0; i < input.size(); i++) {
            check(input.get(i).length == 2 && input.get(i)[0] < input.get(i)[1]);
            if (i > 0) check(input.get(i - 1)[1] < input.get(i)[0]);
            for (int j = 0; j < i; j++) check(input.get(j) != input.get(i));
        }
    }

    public static void main(String[] args) {
        equal(Ranges.normalize(ranges()));
        equal(Ranges.normalize(ranges(4, 4, 0, 0)));
        equal(Ranges.normalize(ranges(8, 10, 1, 3, 2, 5, 5, 8, 1, 3)), 1, 10);
        equal(Ranges.normalize(ranges(-5, -2, -10, -8)), -10, -8, -5, -2);
        equal(Ranges.subtract(ranges(0, 10), ranges(2, 4, 6, 8)), 0, 2, 4, 6, 8, 10);
        equal(Ranges.subtract(ranges(8, 12, 0, 6, 4, 10), ranges(9, 11, 2, 4, 3, 5)),
                0, 2, 5, 9, 11, 12);
        equal(Ranges.subtract(ranges(0, 2, 4, 6, 8, 10), ranges(1, 9)), 0, 1, 9, 10);
        equal(Ranges.subtract(ranges(0, 2), ranges(-2, 0, 2, 4)), 0, 2);
        equal(Ranges.subtract(ranges(0, 2), ranges(-1, 3)));
        equal(Ranges.subtract(ranges(), ranges(1, 2)));
        equal(Ranges.subtract(ranges(1, 2), ranges()), 1, 2);

        long lo = Long.MIN_VALUE, hi = Long.MAX_VALUE;
        equal(Ranges.normalize(ranges(hi - 1, hi, lo, lo + 1)), lo, lo + 1, hi - 1, hi);
        equal(Ranges.subtract(ranges(lo, hi), ranges(lo + 1, hi - 1)),
                lo, lo + 1, hi - 1, hi);
        check(Ranges.length(ranges(lo, hi)).equals(BigInteger.ONE.shiftLeft(64).subtract(BigInteger.ONE)));
        check(Ranges.length(ranges(0, 10, 2, 8, 10, 12)).equals(BigInteger.valueOf(12)));
        check(Ranges.length(ranges()).equals(BigInteger.ZERO));

        List<List<long[]>> badInputs = new ArrayList<>();
        badInputs.add(null);
        badInputs.add(Arrays.asList((long[]) null));
        badInputs.add(Arrays.asList(new long[0]));
        badInputs.add(Arrays.asList(new long[] {1}));
        badInputs.add(Arrays.asList(new long[] {1, 2, 3}));
        badInputs.add(ranges(2, 1));
        badInputs.add(ranges(0, 0, 2, 1));
        for (List<long[]> bad : badInputs) {
            invalid(() -> Ranges.normalize(bad));
            invalid(() -> Ranges.length(bad));
            invalid(() -> Ranges.subtract(bad, ranges()));
            invalid(() -> Ranges.subtract(ranges(), bad));
        }

        long[] first = {5, 10}, second = {0, 2};
        List<long[]> input = List.of(first, second);
        List<long[]> normalized = Ranges.normalize(input);
        List<long[]> difference = Ranges.subtract(input, ranges(6, 8));
        check(input.get(0) == first && first[0] == 5 && first[1] == 10);
        for (long[] output : normalized) check(output != first && output != second);
        for (long[] output : difference) check(output != first && output != second);
        normalized.get(0)[0] = -100;
        difference.get(0)[1] = 100;
        check(second[0] == 0 && second[1] == 2);
        List<long[]> copy = Ranges.subtract(input, ranges());
        first[0] = 7;
        equal(copy, 0, 2, 5, 10);
        List<long[]> repeated = Ranges.normalize(ranges(0, 2));
        check(repeated.get(0) != Ranges.normalize(repeated).get(0));

        Random random = new Random(20261023);
        for (int trial = 0; trial < 5000; trial++) {
            List<long[]> a = new ArrayList<>(), b = new ArrayList<>();
            for (List<long[]> set : List.of(a, b)) {
                for (int i = random.nextInt(12); i > 0; i--) {
                    int x = random.nextInt(41) - 20, y = random.nextInt(41) - 20;
                    set.add(new long[] {Math.min(x, y), Math.max(x, y)});
                }
            }
            List<long[]> union = Ranges.normalize(a), differenceSet = Ranges.subtract(a, b);
            canonical(union);
            canonical(differenceSet);
            int unionLength = 0, differenceLength = 0;
            for (int point = -21; point <= 21; point++) {
                boolean inA = covers(a, point), inB = covers(b, point);
                check(covers(union, point) == inA);
                check(covers(differenceSet, point) == (inA && !inB));
                if (inA) unionLength++;
                if (inA && !inB) differenceLength++;
            }
            check(Ranges.length(a).equals(BigInteger.valueOf(unionLength)));
            check(Ranges.length(differenceSet).equals(BigInteger.valueOf(differenceLength)));
            check(Arrays.deepEquals(union.toArray(), Ranges.normalize(union).toArray()));
        }
        System.out.println("Range behavior tests passed (5000 randomized cases).");
    }
}
