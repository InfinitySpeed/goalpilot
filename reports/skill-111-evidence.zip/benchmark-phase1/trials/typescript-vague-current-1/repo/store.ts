function copyJSON(value: unknown, active = new Set<object>()): unknown {
  if (value === null || typeof value === 'string' || typeof value === 'boolean') return value;
  if (typeof value === 'number' && Number.isFinite(value)) return value;
  if (typeof value !== 'object' || value === null) throw Error('Invalid JSON value');
  const array = Array.isArray(value);
  if (!array && Object.getPrototypeOf(value) !== Object.prototype && Object.getPrototypeOf(value) !== null) throw Error('Invalid JSON object');
  if (active.has(value)) throw Error('Cyclic JSON value');
  active.add(value);
  try {
    if (array) {
      const result: unknown[] = [];
      for (let i = 0; i < value.length; i++) result.push(copyJSON(value[i], active));
      return result;
    }
    const result: Record<string, unknown> = {};
    for (const key of Object.keys(value)) {
      Object.defineProperty(result, key, {value: copyJSON((value as Record<string, unknown>)[key], active), enumerable: true, writable: true, configurable: true});
    }
    return result;
  } finally { active.delete(value); }
}

type Entry = {value: unknown, version: number};
export class Store {
  revision = 0;
  private entries = new Map<string, Entry>();
  get(key: string): Entry | undefined {
    const entry = this.entries.get(key);
    return entry === undefined ? undefined : {value: copyJSON(entry.value), version: entry.version};
  }
  keys(): string[] { return [...this.entries.keys()]; }
  apply(ops: unknown): {revision: number, changed: string[]} {
    if (!Array.isArray(ops)) throw Error('Expected operations array');
    const staged = new Map(this.entries);
    const changed = new Set<string>();
    const revision = this.revision + (ops.length ? 1 : 0);
    for (const raw of ops) {
      if (typeof raw !== 'object' || raw === null) throw Error('Invalid operation');
      const op = raw as Record<string, unknown>;
      const {type, key, expectedVersion} = op;
      if ((type !== 'put' && type !== 'delete') || typeof key !== 'string' || !key.length) throw Error('Invalid operation');
      if (expectedVersion !== undefined && (typeof expectedVersion !== 'number' || !Number.isInteger(expectedVersion) || expectedVersion < 0)) throw Error('Invalid version');
      if (expectedVersion !== undefined && expectedVersion !== (staged.get(key)?.version ?? 0)) throw Error('Version conflict');
      if (type === 'put') staged.set(key, {value: copyJSON(op.value), version: revision});
      else staged.delete(key);
      changed.add(key);
    }
    this.entries = staged;
    this.revision = revision;
    return {revision, changed: [...changed]};
  }
}
