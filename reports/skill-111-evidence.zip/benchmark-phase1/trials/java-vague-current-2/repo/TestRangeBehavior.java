import javax.tools.ToolProvider;
import java.net.*;
import java.nio.file.*;
import java.util.*;
import java.math.BigInteger;
import java.lang.reflect.*;

class TestRangeBehavior {
 static Class<?> ranges;
 @SuppressWarnings("unchecked")
 static <T> T call(String name, Object... args) throws Exception {
  Class<?>[] types = new Class<?>[args.length]; Arrays.fill(types, List.class);
  try { return (T) ranges.getMethod(name, types).invoke(null,args); }
  catch (InvocationTargetException e) {
   if (e.getCause() instanceof IllegalArgumentException) throw (IllegalArgumentException)e.getCause();
   throw e;
  }
 }
 static List<long[]> rs(long... values) {
  List<long[]> r = new ArrayList<>();
  for(int i=0;i<values.length;i+=2) r.add(new long[]{values[i],values[i+1]});
  return r;
 }
 static void eq(Object actual,Object expected) {
  if(!actual.equals(expected)) throw new AssertionError(actual+" != "+expected);
 }
 static void same(List<long[]> actual,List<long[]> expected) {
  eq(actual.size(),expected.size());
  for(int i=0;i<actual.size();i++) if(!Arrays.equals(actual.get(i),expected.get(i))) throw new AssertionError("range mismatch");
 }
 static boolean[] points(List<long[]> a) {
  boolean[] out=new boolean[21];
  for(long[] r:a) for(int p=-10;p<11;p++) if(r[0]<=p && p<r[1]) out[p+10]=true;
  return out;
 }
 static void check() throws Exception {
  same(call("normalize",rs(5,8,1,3,3,5,2,4,9,9)),rs(1,8));
  same(call("subtract",rs(8,10,0,6,5,9),rs(7,8,2,4,3,5)),rs(0,2,5,7,8,10));
  same(call("subtract",rs(0,2,4,6),rs(-1,7)),rs());
  same(call("subtract",rs(0,2),rs(2,4,-2,0)),rs(0,2));
  same(call("normalize",rs()),rs());
  same(call("subtract",rs(),rs(1,2)),rs());
  long lo=Long.MIN_VALUE, hi=Long.MAX_VALUE;
  eq(call("length",rs(lo,hi)),BigInteger.ONE.shiftLeft(64).subtract(BigInteger.ONE));
  same(call("subtract",rs(lo,hi),rs(lo,lo+1,hi-1,hi)),rs(lo+1,hi-1));
  same(call("normalize",rs(hi-1,hi,lo,lo+1)),rs(lo,lo+1,hi-1,hi));
  eq(call("length",rs(1,5,3,8,8,8)),BigInteger.valueOf(7));
  List<long[]> input=rs(4,5,1,3); long[] original=input.get(0);
  List<long[]> normalized=call("normalize",input), difference=call("subtract",input,rs());
  normalized.get(1)[0]=99; difference.get(1)[1]=99;
  same(input,rs(4,5,1,3)); eq(input.get(0)==original,true);
  same(call("normalize",input),rs(1,3,4,5));
  List<List<long[]>> bad=new ArrayList<>(); bad.add(null);
  bad.add(Arrays.asList((long[])null)); bad.add(List.of(new long[0]));
  bad.add(List.of(new long[1])); bad.add(List.of(new long[3])); bad.add(rs(2,1));
  for(List<long[]> invalid:bad) for(String method:List.of("normalize","length","subtract")) {
   try { if(method.equals("subtract")) call(method,rs(),invalid); else call(method,invalid);
    throw new AssertionError("accepted invalid "+method);
   } catch(IllegalArgumentException expected) {}
   if(method.equals("subtract")) try { call(method,invalid,rs()); throw new AssertionError(); }
   catch(IllegalArgumentException expected) {}
  }
  Random random=new Random(419);
  for(int t=0;t<500;t++) {
   List<long[]> a=rs(),b=rs();
   for(List<long[]> set:List.of(a,b)) for(int i=0;i<12;i++) {
    long x=random.nextInt(21)-10,y=random.nextInt(21)-10;
    set.add(new long[]{Math.min(x,y),Math.max(x,y)});
   }
   boolean[] ap=points(a),bp=points(b);
   List<long[]> n=call("normalize",a),d=call("subtract",a,b);
   eq(Arrays.toString(points(n)),Arrays.toString(ap));
   int count=0;
   for(int i=0;i<21;i++) { if(ap[i]) count++; ap[i]=ap[i]&&!bp[i]; }
   eq(call("length",a),BigInteger.valueOf(count));
   eq(Arrays.toString(points(d)),Arrays.toString(ap));
   for(List<long[]> set:List.of(n,d)) for(int i=0;i<set.size();i++) {
    long[] r=set.get(i); if(r.length!=2 || r[0]>=r[1] || (i>0 && set.get(i-1)[1]>=r[0])) throw new AssertionError("noncanonical");
    for(long[] source:a) if(r==source) throw new AssertionError("alias");
    for(long[] source:b) if(r==source) throw new AssertionError("alias");
   }
  }
 }
 public static void main(String[] args) throws Exception {
  Path dir=Files.createTempDirectory("range-behavior");
  try {
   if(ToolProvider.getSystemJavaCompiler().run(null,null,null,"-d",dir.toString(),"Ranges.java")!=0) throw new AssertionError();
   try(var loader=new URLClassLoader(new URL[]{dir.toUri().toURL()})) { ranges=loader.loadClass("Ranges"); check(); }
  } finally { try(var files=Files.walk(dir)) { for(Path p:files.sorted(Comparator.reverseOrder()).toList()) Files.delete(p); } }
 }
}
