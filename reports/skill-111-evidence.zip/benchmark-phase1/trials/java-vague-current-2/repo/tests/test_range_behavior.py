import subprocess
subprocess.run(["java", "TestRangeBehavior.java"], check=True)
