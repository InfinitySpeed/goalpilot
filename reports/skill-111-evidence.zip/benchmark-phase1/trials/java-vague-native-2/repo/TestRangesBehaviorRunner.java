import javax.tools.ToolProvider;
import java.net.URL;
import java.net.URLClassLoader;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Comparator;

class TestRangesBehaviorRunner {
    public static void main(String[] args) throws Exception {
        Path output = Files.createTempDirectory("ranges-behavior-");
        try {
            int status = ToolProvider.getSystemJavaCompiler().run(null, null, null,
                    "-d", output.toString(), "Ranges.java", "TestRangesBehavior.java");
            if (status != 0) throw new AssertionError("Compilation failed");
            try (var loader = new URLClassLoader(new URL[] {output.toUri().toURL()})) {
                loader.loadClass("TestRangesBehavior").getMethod("main", String[].class)
                        .invoke(null, (Object) new String[0]);
            }
        } finally {
            try (var paths = Files.walk(output)) {
                for (Path path : paths.sorted(Comparator.reverseOrder()).toList()) {
                    Files.delete(path);
                }
            }
        }
    }
}
