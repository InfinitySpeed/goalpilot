import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/** Set operations on half-open intervals with signed long endpoints. */
public class Ranges {
    /** Returns the sorted union, merging overlapping and touching intervals. */
    public static List<long[]> normalize(List<long[]> ranges) {
        if (ranges == null) {
            throw new IllegalArgumentException("Range list must not be null");
        }
        List<long[]> sorted = new ArrayList<>();
        for (long[] range : ranges) {
            if (range == null || range.length != 2) {
                throw new IllegalArgumentException("Each range must have two endpoints");
            }
            if (range[0] > range[1]) {
                throw new IllegalArgumentException("Range start must not exceed end");
            }
            if (range[0] < range[1]) {
                sorted.add(new long[] {range[0], range[1]});
            }
        }
        sorted.sort(Comparator.comparingLong(range -> range[0]));
        List<long[]> result = new ArrayList<>();
        for (long[] range : sorted) {
            if (result.isEmpty() || result.get(result.size() - 1)[1] < range[0]) {
                result.add(range);
            } else {
                long[] previous = result.get(result.size() - 1);
                previous[1] = Math.max(previous[1], range[1]);
            }
        }
        return result;
    }

    /** Returns the points in the union of a that are outside the union of b. */
    public static List<long[]> subtract(List<long[]> a, List<long[]> b) {
        List<long[]> sources = normalize(a);
        List<long[]> cuts = normalize(b);
        List<long[]> result = new ArrayList<>();
        int cutIndex = 0;
        for (long[] source : sources) {
            long cursor = source[0];
            long end = source[1];
            while (cutIndex < cuts.size() && cuts.get(cutIndex)[1] <= cursor) {
                cutIndex++;
            }
            while (cutIndex < cuts.size() && cuts.get(cutIndex)[0] < end) {
                long[] cut = cuts.get(cutIndex);
                if (cut[0] > cursor) {
                    result.add(new long[] {cursor, cut[0]});
                }
                if (cut[1] >= end) {
                    cursor = end;
                    break; // Keep this cut: it may also cover the next source.
                }
                cursor = Math.max(cursor, cut[1]);
                cutIndex++;
            }
            if (cursor < end) {
                result.add(new long[] {cursor, end});
            }
        }
        return result;
    }

    /** Returns the length of the union, without overflowing long arithmetic. */
    public static BigInteger length(List<long[]> ranges) {
        BigInteger total = BigInteger.ZERO;
        for (long[] range : normalize(ranges)) {
            total = total.add(BigInteger.valueOf(range[1])
                    .subtract(BigInteger.valueOf(range[0])));
        }
        return total;
    }
}
