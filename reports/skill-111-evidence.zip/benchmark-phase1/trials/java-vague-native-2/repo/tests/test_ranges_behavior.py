"""Run the additional suite using the available Java compiler API."""
from pathlib import Path
import subprocess

subprocess.run(
    ["java", "TestRangesBehaviorRunner.java"],
    cwd=Path(__file__).resolve().parent.parent,
    check=True,
)
