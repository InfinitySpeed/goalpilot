import java.math.BigInteger;
import java.util.*;

/** Additional behavioral tests; run with python3 tests/test_ranges_behavior.py. */
public class TestRangesBehavior {
    private static List<long[]> ranges(long... endpoints) {
        List<long[]> result = new ArrayList<>();
        for (int i = 0; i < endpoints.length; i += 2) {
            result.add(new long[] {endpoints[i], endpoints[i + 1]});
        }
        return result;
    }

    private static void equal(List<long[]> actual, long... expected) {
        if (!Arrays.deepEquals(actual.toArray(), ranges(expected).toArray())) {
            throw new AssertionError("Unexpected ranges: " + Arrays.deepToString(actual.toArray()));
        }
    }

    private static void invalid(Runnable action) {
        try {
            action.run();
        } catch (IllegalArgumentException expected) {
            return;
        }
        throw new AssertionError("Expected IllegalArgumentException");
    }

    public static void main(String[] args) {
        equal(Ranges.normalize(ranges(5, 9, 1, 3, 3, 5, 2, 4, 7, 7)), 1, 9);
        equal(Ranges.normalize(ranges()));
        equal(Ranges.normalize(ranges(0, 0, Long.MIN_VALUE, Long.MIN_VALUE)));
        equal(Ranges.subtract(ranges(8, 12, 0, 5, 4, 10), ranges(9, 11, 2, 3, 3, 6)),
                0, 2, 6, 9, 11, 12);
        equal(Ranges.subtract(ranges(0, 2, 4, 6, 8, 10), ranges(1, 9)), 0, 1, 9, 10);
        equal(Ranges.subtract(ranges(0, 2), ranges(-2, 0, 2, 4)), 0, 2);
        equal(Ranges.subtract(ranges(0, 2), ranges(-1, 3)));
        equal(Ranges.subtract(ranges(), ranges(1, 2)));
        equal(Ranges.subtract(ranges(Long.MIN_VALUE, Long.MAX_VALUE), ranges(-1, 1)),
                Long.MIN_VALUE, -1, 1, Long.MAX_VALUE);
        BigInteger full = BigInteger.ONE.shiftLeft(64).subtract(BigInteger.ONE);
        if (!Ranges.length(ranges(Long.MIN_VALUE, Long.MAX_VALUE)).equals(full)
                || !Ranges.length(ranges(1, 5, 2, 6, 8, 8)).equals(BigInteger.valueOf(5))
                || !Ranges.length(ranges()).equals(BigInteger.ZERO)) {
            throw new AssertionError("Incorrect union length");
        }
        List<List<long[]>> bad = new ArrayList<>();
        bad.add(null);
        bad.add(Collections.singletonList(null));
        bad.add(Collections.singletonList(new long[0]));
        bad.add(Collections.singletonList(new long[] {1}));
        bad.add(Collections.singletonList(new long[] {1, 2, 3}));
        bad.add(ranges(2, 1));
        for (List<long[]> input : bad) {
            invalid(() -> Ranges.normalize(input));
            invalid(() -> Ranges.length(input));
            invalid(() -> Ranges.subtract(input, ranges()));
            invalid(() -> Ranges.subtract(ranges(), input));
        }
        long[] original = {1, 5};
        List<long[]> input = List.of(original, new long[] {2, 3});
        List<long[]> normalized = Ranges.normalize(input);
        List<long[]> difference = Ranges.subtract(input, ranges(2, 4));
        equal(input, 1, 5, 2, 3);
        normalized.get(0)[0] = -10;
        difference.get(0)[1] = -5;
        equal(input, 1, 5, 2, 3);
        original[0] = 0;
        equal(difference, 1, -5, 4, 5);
        randomized();
        System.out.println("Range behavioral tests passed (10,000 randomized cases).");
    }

    private static void randomized() {
        Random random = new Random(1023);
        for (int trial = 0; trial < 10000; trial++) {
            List<long[]> a = randomRanges(random);
            List<long[]> b = randomRanges(random);
            boolean[] aa = points(a), bb = points(b);
            List<long[]> union = Ranges.normalize(a);
            List<long[]> difference = Ranges.subtract(a, b);
            boolean[] expected = aa.clone();
            int length = 0;
            for (int i = 0; i < aa.length; i++) {
                if (aa[i]) length++;
                expected[i] &= !bb[i];
            }
            if (!Arrays.equals(aa, points(union))
                    || !Arrays.equals(expected, points(difference))
                    || !Ranges.length(a).equals(BigInteger.valueOf(length))) {
                throw new AssertionError("Randomized set operation failed");
            }
            canonical(union);
            canonical(difference);
        }
    }

    private static List<long[]> randomRanges(Random random) {
        List<long[]> result = new ArrayList<>();
        for (int i = random.nextInt(15); i > 0; i--) {
            int x = random.nextInt(41) - 20, y = random.nextInt(41) - 20;
            result.add(new long[] {Math.min(x, y), Math.max(x, y)});
        }
        return result;
    }

    private static boolean[] points(List<long[]> ranges) {
        boolean[] result = new boolean[40];
        for (long[] range : ranges) {
            for (long x = range[0]; x < range[1]; x++) result[(int) x + 20] = true;
        }
        return result;
    }

    private static void canonical(List<long[]> ranges) {
        for (int i = 0; i < ranges.size(); i++) {
            long[] range = ranges.get(i);
            if (range.length != 2 || range[0] >= range[1]
                    || (i > 0 && ranges.get(i - 1)[1] >= range[0])) {
                throw new AssertionError("Noncanonical result");
            }
        }
    }
}
