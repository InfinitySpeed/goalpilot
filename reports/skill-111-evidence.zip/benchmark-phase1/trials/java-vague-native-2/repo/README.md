Make this range utility dependable for real input: fix the correctness gaps, preserve the public contract and existing data, handle awkward edge cases, and show me it is solid with tests. Work it through without asking me follow-up questions.

Ranges.normalize(List<long[]>), subtract(List<long[]>, List<long[]>), and length(List<long[]>) are public static methods. Each pair is [start,end) with signed long endpoints. normalize/subtract return independent fresh two-element arrays sorted by start. length returns java.math.BigInteger. subtract must normalize both sets before subtraction. Throw IllegalArgumentException for invalid inputs. Only the Java 21 standard library. Run python3 tests/test_ranges.py; it launches source-file Java tests through java TestRanges.java using the compiler API to load Ranges.java. Keep original tests unchanged.

Range semantics: null lists, null pairs, pairs with a length other than two,
and reversed endpoints are invalid and throw IllegalArgumentException. Empty
ranges contribute no points and are omitted. Normalization merges overlapping
and touching ranges. length measures the union (so overlapping points count
once), using BigInteger even when the distance exceeds Long.MAX_VALUE. All
operations leave input lists and arrays unchanged; result arrays are independent
of the inputs and of one another.

Additional behavioral coverage: run `python3 tests/test_ranges_behavior.py`.
This includes signed-long extremes, malformed inputs, subtraction boundaries,
input/output independence, and 10,000 reproducible randomized comparisons against
a small integer-set reference. Both test runners use only the native Java tools
and Python standard library, and clean up their temporary compiled classes.
