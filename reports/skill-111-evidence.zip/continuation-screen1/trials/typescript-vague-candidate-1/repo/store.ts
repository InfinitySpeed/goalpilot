type Entry = { value: unknown; version: number };

function copyJSON(value: unknown, ancestors = new Set<object>()): unknown {
  if (value === null || typeof value === 'string' || typeof value === 'boolean') return value;
  if (typeof value === 'number' && Number.isFinite(value)) return value;
  if (typeof value !== 'object' || value === null) throw Error('Invalid JSON value');
  const array = Array.isArray(value);
  const proto = Object.getPrototypeOf(value);
  if (!array && proto !== Object.prototype && proto !== null) throw Error('Invalid JSON object');
  if (ancestors.has(value)) throw Error('Cyclic JSON value');
  ancestors.add(value);
  try {
    if (array) {
      const result: unknown[] = [];
      for (let i = 0; i < value.length; i++) result.push(copyJSON(value[i], ancestors));
      return result;
    }
    const result: Record<string, unknown> = {};
    for (const key of Object.keys(value)) {
      Object.defineProperty(result, key, {
        value: copyJSON((value as Record<string, unknown>)[key], ancestors),
        enumerable: true, writable: true, configurable: true
      });
    }
    return result;
  } finally { ancestors.delete(value); }
}

export class Store {
  revision = 0;
  private entries = new Map<string, Entry>();
  get(key: string): Entry | undefined {
    const entry = this.entries.get(key);
    return entry && { value: copyJSON(entry.value), version: entry.version };
  }
  keys(): string[] { return [...this.entries.keys()]; }
  apply(ops: unknown): { revision: number; changed: string[] } {
    if (!Array.isArray(ops)) throw Error('Expected operations array');
    const pending = new Map(this.entries);
    const changed = new Set<string>();
    const revision = this.revision + (ops.length ? 1 : 0);
    for (const op of ops) {
      if (op === null || typeof op !== 'object' || Array.isArray(op)) throw Error('Invalid operation');
      const { type, key, expectedVersion } = op;
      if ((type !== 'put' && type !== 'delete') || typeof key !== 'string' || !key.length) throw Error('Invalid operation');
      if ('expectedVersion' in op) {
        if (!Number.isInteger(expectedVersion) || expectedVersion < 0) throw Error('Invalid expected version');
        if (expectedVersion !== (pending.get(key)?.version ?? 0)) throw Error('Version conflict');
      }
      if (type === 'put') pending.set(key, { value: copyJSON(op.value), version: revision });
      else pending.delete(key);
      changed.add(key);
    }
    this.entries = pending;
    this.revision = revision;
    return { revision, changed: [...changed] };
  }
}
