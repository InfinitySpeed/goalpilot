"""Frozen prospective extension cases. Judges are never shown to callers."""
import json
from pathlib import Path

CASES = {
'java-ranges': {
 'goal': 'Finish the existing Java interval library. Normalize unsorted half-open integer ranges by merging overlaps and adjacent ranges, subtract a second set, and calculate their total covered length without integer overflow. Reject null lists, null entries, malformed range pairs and reversed endpoints; ignore empty ranges. Preserve all caller inputs. Keep the existing public API and source-file test command, with meaningful native regression tests.',
 'contract': 'Ranges.normalize(List<long[]>), subtract(List<long[]>, List<long[]>), and length(List<long[]>) are public static methods. Each pair is [start,end) with signed long endpoints. normalize/subtract return independent fresh two-element arrays sorted by start. length returns java.math.BigInteger. subtract must normalize both sets before subtraction. Throw IllegalArgumentException for invalid inputs. Only the Java 21 standard library. Run python3 tests/test_ranges.py; it launches source-file Java tests through java TestRanges.java using the compiler API to load Ranges.java. Keep original tests unchanged.',
 'files': {
 'Ranges.java': 'import java.util.*;import java.math.BigInteger;\npublic class Ranges {\n public static List<long[]> normalize(List<long[]> a){throw new UnsupportedOperationException();}\n public static List<long[]> subtract(List<long[]> a,List<long[]> b){throw new UnsupportedOperationException();}\n public static BigInteger length(List<long[]> a){throw new UnsupportedOperationException();}\n}\n',
 'TestRanges.java': '''import javax.tools.ToolProvider;import java.net.*;import java.nio.file.*;
class TestRanges {public static void main(String[] args)throws Exception{Path d=Files.createTempDirectory("ranges-test");try{if(ToolProvider.getSystemJavaCompiler().run(null,null,null,"-d",d.toString(),"Ranges.java")!=0)throw new AssertionError();try(var loader=new URLClassLoader(new URL[]{d.toUri().toURL()})){Class<?> c=loader.loadClass("Ranges");if(c.getMethod("normalize",java.util.List.class)==null)throw new AssertionError();}}finally{try(var paths=Files.walk(d)){paths.sorted(java.util.Comparator.reverseOrder()).forEach(p->{try{Files.delete(p);}catch(Exception e){throw new RuntimeException(e);}});}}}}
''',
 'tests/test_ranges.py': 'import subprocess\nsubprocess.run(["java","TestRanges.java"],check=True)\n',
 },
 'judge': '''import javax.tools.ToolProvider;import java.net.*;import java.nio.file.*;import java.lang.reflect.*;import java.util.*;import java.math.*;
class Judge {public static void main(String[] args)throws Exception{Path d=Files.createTempDirectory("judge");try{if(ToolProvider.getSystemJavaCompiler().run(null,null,null,"-d",d.toString(),"Ranges.java")!=0)throw new AssertionError();try(var loader=new URLClassLoader(new URL[]{d.toUri().toURL()})){Class<?> c=loader.loadClass("Ranges");Method n=c.getMethod("normalize",List.class),s=c.getMethod("subtract",List.class,List.class),len=c.getMethod("length",List.class);List<long[]> in=new ArrayList<>(List.of(new long[]{8,10},new long[]{1,4},new long[]{4,8},new long[]{5,5}));List<long[]> out=(List<long[]>)n.invoke(null,in);if(out.size()!=1||!Arrays.equals(out.get(0),new long[]{1,10})||in.get(0)[0]!=8)throw new AssertionError("normalize");out.get(0)[0]=100;if(in.get(1)[0]!=1)throw new AssertionError("alias");out=(List<long[]>)s.invoke(null,List.of(new long[]{0,10}),List.of(new long[]{7,20},new long[]{2,4}));if(out.size()!=2||!Arrays.equals(out.get(0),new long[]{0,2})||!Arrays.equals(out.get(1),new long[]{4,7}))throw new AssertionError("subtract");if(!len.invoke(null,List.of(new long[]{Long.MIN_VALUE,Long.MAX_VALUE})).equals(new BigInteger("18446744073709551615")))throw new AssertionError("overflow");for(Object bad:new Object[]{null,Arrays.asList((long[])null),List.of(new long[]{2,1}),List.of(new long[]{1})}){try{n.invoke(null,bad);throw new AssertionError("invalid accepted");}catch(InvocationTargetException e){if(!(e.getCause() instanceof IllegalArgumentException))throw e;}}if(!((List<?>)n.invoke(null,List.of())).isEmpty())throw new AssertionError();}System.out.println("PASS independent Java ranges");}finally{try(var paths=Files.walk(d)){paths.sorted(Comparator.reverseOrder()).forEach(p->{try{Files.delete(p);}catch(Exception e){throw new RuntimeException(e);}});}}}}
''', 'judge_file':'Judge.java', 'judge_cmd':['java','Judge.java'],
},
'node-pool': {
 'goal': 'Implement the existing asynchronous JavaScript worker pool. Run lazy task functions with a positive integer concurrency limit, preserve result ordering, and never exceed the limit. Stop scheduling new tasks after the first task failure or external abort; wait for all already-started tasks to settle before rejecting with the first observed error. Never invoke any task when already aborted. Support synchronous task throws and promises without unhandled rejections, validate all arguments before starting, preserve the API, and add deterministic behavioral tests without timing-dependent sleeps.',
 'contract': 'Export async function runPool(tasks, {concurrency=2, signal}={}) from pool.mjs. tasks must be an array of functions. Invalid tasks or nonpositive/noninteger concurrency reject TypeError before any invocation. signal is an optional standard AbortSignal. For abort reject signal.reason (standard AbortController supplies an Error); for task failure preserve error identity, even if undefined/null/false is thrown. Empty valid input resolves []. All started tasks must settle before final resolution/rejection; subsequent errors must be handled. Already-aborted signal rejects even for empty input. Only Node standard library; npm test uses node --test. Preserve original tests.',
 'files': {'package.json':json.dumps({'type':'module','scripts':{'test':'node --test'}}), 'pool.mjs':'export async function runPool(tasks,{concurrency=2,signal}={}) { throw Error("unfinished"); }\n', 'test/pool.test.mjs': 'import {test} from "node:test";import assert from "node:assert/strict";import {runPool} from "../pool.mjs";test("API",()=>assert.equal(typeof runPool,"function"));\n'},
 'judge': '''import {runPool} from './pool.mjs';import assert from 'node:assert/strict';
function deferred(){let resolve,reject;let promise=new Promise((a,b)=>{resolve=a;reject=b});return {promise,resolve,reject}}
const tick=()=>new Promise(r=>setImmediate(r));
let ds=[deferred(),deferred(),deferred()],started=[],done=false;
let p=runPool(ds.map((d,i)=>()=>{started.push(i);return d.promise}),{concurrency:2});p.then(()=>done=true,()=>done=true);await tick();assert.deepEqual(started,[0,1]);ds[1].resolve('b');await tick();assert.deepEqual(started,[0,1,2]);ds[2].resolve('c');await tick();assert.equal(done,false);ds[0].resolve('a');assert.deepEqual(await p,['a','b','c']);
let error=Error('first'),slow=deferred(),calls=[];p=runPool([()=>{calls.push(0);return Promise.reject(error)},()=>{calls.push(1);return slow.promise},()=>{calls.push(2)}],{concurrency:2});let observed=false;p.catch(()=>observed=true);await tick();assert.deepEqual(calls,[0,1]);assert.equal(observed,false);slow.reject(Error('later'));await assert.rejects(p,e=>e===error);
let ac=new AbortController(),reason=Error('stop');ac.abort(reason);let invoked=false;await assert.rejects(runPool([()=>invoked=true],{signal:ac.signal}),e=>e===reason);assert.equal(invoked,false);await assert.rejects(runPool([],{signal:ac.signal}),e=>e===reason);
ac=new AbortController();slow=deferred();calls=[];p=runPool([()=>{calls.push(0);return slow.promise},()=>calls.push(1)],{concurrency:1,signal:ac.signal});await tick();ac.abort(reason);slow.resolve(1);await assert.rejects(p,e=>e===reason);assert.deepEqual(calls,[0]);
for(let bad of [0,-1,1.2,NaN]){invoked=false;await assert.rejects(runPool([()=>invoked=true],{concurrency:bad}),TypeError);assert.equal(invoked,false)}
invoked=false;await assert.rejects(runPool([()=>invoked=true,7]),TypeError);assert.equal(invoked,false);assert.deepEqual(await runPool([]),[]);
for(let e of [undefined,null,false]){let failed=false;try{await runPool([()=>{throw e}])}catch(actual){failed=true;assert.equal(actual,e)}assert.equal(failed,true)}console.log('PASS independent pool');
''', 'judge_file':'judge.mjs', 'judge_cmd':['node','judge.mjs'],
},
'python-repair': {
 'goal': 'Repair the existing Python dependency planner while preserving its public API. Return a deterministic topological order using lexicographically smallest ready nodes, include dependencies that appear only as values, handle duplicate edges, and never mutate the input. For cyclic graphs raise ValueError listing only nodes actually belonging to cycles, not downstream dependents. Reject malformed graph keys or dependency values before producing output, support empty graphs, and add focused regressions using the existing unittest command.',
 'contract': 'plan(graph: dict[str,list[str]]) -> list[str]. Each key depends on its value nodes, so dependencies come first. All node names are nonempty strings; values must be lists of such strings; no other iterables accepted. Any malformed input raises ValueError. Cycle message must be exactly "cycle: " + ",".join(sorted(cyclic_nodes)), including self-loop nodes, excluding acyclic downstream nodes. Only Python stdlib. Run python3 -m unittest discover -s tests. Preserve the existing tests.',
 'files': {'planner.py':'def plan(graph):\n return sorted(graph)\n', 'tests/test_planner.py':'import unittest\nfrom planner import plan\nclass Existing(unittest.TestCase):\n def test_empty(self):self.assertEqual(plan({}),[])\n def test_single(self):self.assertEqual(plan({"a":[]}),["a"])\n'},
 'judge': '''from planner import plan
import copy
g={'c':['a','b','a'],'b':['z'],'a':[]};before=copy.deepcopy(g);assert plan(g)==['a','z','b','c'];assert g==before
assert plan({'b':['x'],'a':[]})==['a','x','b'];assert plan({})==[]
for g,expected in [({'a':['b'],'b':['a'],'c':['b'],'d':[]},'cycle: a,b'),({'a':['a'],'b':['a'],'c':['d'],'d':['c']},'cycle: a,c,d')]:
 try:plan(g)
 except ValueError as e:assert str(e)==expected,str(e)
 else:raise AssertionError('accepted cycle')
for g in [[],{'':[]},{1:[]},{'a':'b'},{'a':[1]},{'a':['']},{'a':None}]:
 try:plan(g)
 except ValueError:pass
 else:raise AssertionError(('accepted invalid',g))
print('PASS independent planner')
''', 'judge_file':'judge.py', 'judge_cmd':['python3','judge.py'],
},
'c-codec': {
 'goal': 'Implement the existing C byte-run codec without changing its ABI. Encode arbitrary bytes as (count,byte) pairs with counts 1 to 255, splitting longer runs. Decode strictly, rejecting odd-length input, zero counts and insufficient output capacity. Both operations must reject invalid pointers, guard arithmetic overflow, report produced length, and leave destination bytes and reported length unchanged on every failure. Empty input succeeds and reports zero. Preserve original tests and add native behavioral regressions.',
 'contract': 'codec_encode(const unsigned char *src,size_t n,unsigned char *dst,size_t capacity,size_t *written) and codec_decode with the same signature return 0 success, -1 failure. written must never be NULL. For nonzero input src must be nonnull, and dst must be nonnull if output would be nonempty. Empty input accepts NULL src/dst. Non-overlapping input/output buffers only; overlapping buffers are outside the contract. No dynamic allocation, C11 stdlib only. Header codec.h stays unchanged. make test compiles -Wall -Wextra -Werror. On insufficient capacity never partially write dst or written.',
 'files': {'codec.h':'#ifndef CODEC_H\n#define CODEC_H\n#include <stddef.h>\nint codec_encode(const unsigned char*,size_t,unsigned char*,size_t,size_t*);\nint codec_decode(const unsigned char*,size_t,unsigned char*,size_t,size_t*);\n#endif\n', 'codec.c':'#include "codec.h"\nint codec_encode(const unsigned char*s,size_t n,unsigned char*d,size_t c,size_t*w){(void)s;(void)n;(void)d;(void)c;(void)w;return -1;}\nint codec_decode(const unsigned char*s,size_t n,unsigned char*d,size_t c,size_t*w){(void)s;(void)n;(void)d;(void)c;(void)w;return -1;}\n', 'tests/test_codec.c':'#include "codec.h"\nint main(void){return 0;}\n', 'Makefile':'CC=cc\n.PHONY: test\ntest:\n\t@dir=$$(mktemp -d); $(CC) -std=c11 -Wall -Wextra -Werror -I. codec.c tests/test_codec.c -o $$dir/check && $$dir/check; status=$$?; rm -rf $$dir; exit $$status\n'},
 'judge': '''import ctypes as c,pathlib,tempfile,subprocess
with tempfile.TemporaryDirectory() as d:
 p=pathlib.Path(d)/'x.so';subprocess.run(['cc','-shared','-fPIC','-std=c11','-Wall','-Wextra','-Werror','codec.c','-o',str(p)],check=True);lib=c.CDLL(str(p));U=c.c_ubyte;S=c.c_size_t
 for name in ['codec_encode','codec_decode']:
  f=getattr(lib,name);f.argtypes=[c.POINTER(U),S,c.POINTER(U),S,c.POINTER(S)];f.restype=c.c_int
 def invoke(name,data,capacity):
  src=(U*len(data))(*data);dst=(U*1024)(*([99]*1024));w=S(777);rc=getattr(lib,name)(src,len(data),dst,capacity,c.byref(w));return rc,bytes(dst),w.value
 raw=bytes([0]*256+[255]*2+[1,2]);r,out,n=invoke('codec_encode',raw,1024);assert r==0;assert out[:n]==bytes([255,0,1,0,2,255,1,1,1,2]);r,decoded,m=invoke('codec_decode',out[:n],1024);assert r==0 and decoded[:m]==raw
 for name,data,cap in [('codec_encode',raw,1),('codec_decode',bytes([0,7]),1024),('codec_decode',bytes([1]),1024),('codec_decode',bytes([3,7]),2)]:
  r,out,w=invoke(name,data,cap);assert r==-1 and w==777 and out==bytes([99]*1024),(name,r,w)
 for name in ['codec_encode','codec_decode']:
  f=getattr(lib,name);w=S(777);assert f(None,0,None,0,c.byref(w))==0 and w.value==0;w.value=777;assert f(None,1,None,0,c.byref(w))==-1 and w.value==777;assert f(None,0,None,0,None)==-1
print('PASS independent codec')
''', 'judge_file':'judge.py', 'judge_cmd':['python3','judge.py'],
},
}

def materialize(name, repo):
    case=CASES[name];repo.mkdir(parents=True)
    for name,text in case['files'].items():
        p=repo/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(text,encoding='utf-8')
    (repo/'README.md').write_text(case['goal']+'\n\n'+case['contract']+'\n',encoding='utf-8')
    return case['goal']
