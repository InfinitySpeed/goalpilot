Finish the existing Java interval library. Normalize unsorted half-open integer ranges by merging overlaps and adjacent ranges, subtract a second set, and calculate their total covered length without integer overflow. Reject null lists, null entries, malformed range pairs and reversed endpoints; ignore empty ranges. Preserve all caller inputs. Keep the existing public API and source-file test command, with meaningful native regression tests.

Ranges.normalize(List<long[]>), subtract(List<long[]>, List<long[]>), and length(List<long[]>) are public static methods. Each pair is [start,end) with signed long endpoints. normalize/subtract return independent fresh two-element arrays sorted by start. length returns java.math.BigInteger. subtract must normalize both sets before subtraction. Throw IllegalArgumentException for invalid inputs. Only the Java 21 standard library. Run python3 tests/test_ranges.py; it launches source-file Java tests through java TestRanges.java using the compiler API to load Ranges.java. Keep original tests unchanged.

Additional native regression coverage: run `java RegressionRanges.java`.
This checks validation, input preservation, independent output arrays, boundary
endpoints, exact large lengths, and randomized subtraction against a coverage oracle.
