import java.math.BigInteger;
import java.net.URL;
import java.net.URLClassLoader;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;
import javax.tools.ToolProvider;

/** Additional native regressions; run with java RegressionRanges.java. */
class RegressionRanges {
    static Class<?> ranges;

    @SuppressWarnings("unchecked")
    static List<long[]> normalize(List<long[]> input) throws Exception {
        return (List<long[]>) call("normalize", new Class<?>[] {List.class}, input);
    }

    @SuppressWarnings("unchecked")
    static List<long[]> subtract(List<long[]> a, List<long[]> b) throws Exception {
        return (List<long[]>) call("subtract", new Class<?>[] {List.class, List.class}, a, b);
    }

    static Object call(String name, Class<?>[] types, Object... args) throws Exception {
        try {
            return ranges.getMethod(name, types).invoke(null, args);
        } catch (java.lang.reflect.InvocationTargetException e) {
            if (e.getCause() instanceof IllegalArgumentException cause) throw cause;
            throw e;
        }
    }

    static BigInteger length(List<long[]> input) throws Exception {
        return (BigInteger) call("length", new Class<?>[] {List.class}, input);
    }

    static List<long[]> pairs(long... endpoints) {
        List<long[]> result = new ArrayList<>();
        for (int i = 0; i < endpoints.length; i += 2)
            result.add(new long[] {endpoints[i], endpoints[i + 1]});
        return result;
    }

    static void equal(List<long[]> actual, List<long[]> expected) {
        if (actual.size() != expected.size()) throw new AssertionError("Range count");
        for (int i = 0; i < actual.size(); i++)
            if (!Arrays.equals(actual.get(i), expected.get(i)))
                throw new AssertionError("Range " + i + ": " + Arrays.toString(actual.get(i)));
    }

    interface Checked { void run() throws Exception; }
    static void invalid(Checked action) throws Exception {
        try { action.run(); } catch (IllegalArgumentException expected) { return; }
        throw new AssertionError("Expected IllegalArgumentException");
    }

    static void test() throws Exception {
        List<long[]> input = pairs(8, 10, 1, 3, 3, 7, 2, 4, 6, 8, 20, 20);
        List<long[]> snapshot = pairs(8, 10, 1, 3, 3, 7, 2, 4, 6, 8, 20, 20);
        List<long[]> normalized = normalize(Collections.unmodifiableList(input));
        equal(normalized, pairs(1, 10));
        equal(input, snapshot);
        normalized.get(0)[0] = -99;
        equal(input, snapshot);
        equal(normalize(pairs()), pairs());
        equal(normalize(pairs(5, 5)), pairs());
        equal(subtract(pairs(10, 20, 0, 8, 7, 10), pairs(12, 14, 3, 5, 4, 7)),
                pairs(0, 3, 7, 12, 14, 20));
        equal(subtract(pairs(0, 2, 4, 6, 8, 10), pairs(1, 9)), pairs(0, 1, 9, 10));
        equal(subtract(pairs(0, 10), pairs(-1, 11)), pairs());
        equal(subtract(pairs(0, 10), pairs(-1, 0, 10, 11)), pairs(0, 10));
        List<long[]> a = pairs(0, 10), b = pairs(3, 7);
        List<long[]> difference = subtract(a, b);
        equal(a, pairs(0, 10)); equal(b, pairs(3, 7));
        difference.get(0)[0] = 99;
        equal(a, pairs(0, 10)); equal(b, pairs(3, 7));
        List<long[]> copy = subtract(a, pairs());
        copy.get(0)[0] = -1;
        equal(a, pairs(0, 10));
        long lo = Long.MIN_VALUE, hi = Long.MAX_VALUE;
        equal(normalize(pairs(0, hi, lo, 0)), pairs(lo, hi));
        equal(subtract(pairs(lo, hi), pairs(-1, 1)), pairs(lo, -1, 1, hi));
        if (!length(pairs(lo, hi)).equals(BigInteger.ONE.shiftLeft(64).subtract(BigInteger.ONE)))
            throw new AssertionError("Overflow");
        if (!length(pairs(1, 4, 2, 6, 6, 8)).equals(BigInteger.valueOf(7)))
            throw new AssertionError("Union length");
        if (!length(pairs()).equals(BigInteger.ZERO)) throw new AssertionError("Empty length");
        List<List<long[]>> badInputs = new ArrayList<>();
        badInputs.add(null);
        badInputs.add(Arrays.asList((long[]) null));
        badInputs.add(List.of(new long[0]));
        badInputs.add(List.of(new long[] {1}));
        badInputs.add(List.of(new long[] {1, 2, 3}));
        badInputs.add(pairs(3, 2));
        for (List<long[]> bad : badInputs) {
            invalid(() -> normalize(bad)); invalid(() -> length(bad));
            invalid(() -> subtract(bad, pairs())); invalid(() -> subtract(pairs(), bad));
        }
        // Compare against an independent small integer coverage oracle.
        Random random = new Random(12345);
        for (int iteration = 0; iteration < 1000; iteration++) {
            List<long[]> left = new ArrayList<>(), right = new ArrayList<>();
            boolean[] l = new boolean[20], r = new boolean[20];
            for (int side = 0; side < 2; side++) {
                for (int n = 0; n < 10; n++) {
                    int x = random.nextInt(21), y = random.nextInt(21);
                    int start = Math.min(x, y), end = Math.max(x, y);
                    (side == 0 ? left : right).add(new long[] {start - 10, end - 10});
                    Arrays.fill(side == 0 ? l : r, start, end, true);
                }
            }
            List<long[]> expected = new ArrayList<>();
            int count = 0;
            for (int i = 0; i < 20;) {
                if (!l[i] || r[i]) { i++; continue; }
                int start = i;
                while (i < 20 && l[i] && !r[i]) { i++; count++; }
                expected.add(new long[] {start - 10, i - 10});
            }
            List<long[]> actual = subtract(left, right);
            equal(actual, expected);
            if (!length(actual).equals(BigInteger.valueOf(count))) throw new AssertionError("Length");
        }
    }

    public static void main(String[] args) throws Exception {
        Path dir = Files.createTempDirectory("ranges-regression");
        try {
            if (ToolProvider.getSystemJavaCompiler().run(null, null, null, "-d", dir.toString(), "Ranges.java") != 0)
                throw new AssertionError("Compilation failed");
            try (var loader = new URLClassLoader(new URL[] {dir.toUri().toURL()})) {
                ranges = loader.loadClass("Ranges");
                test();
            }
        } finally {
            try (var paths = Files.walk(dir)) {
                for (Path path : paths.sorted(Comparator.reverseOrder()).toList()) Files.delete(path);
            }
        }
        System.out.println("Range regressions passed");
    }
}
