import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class Ranges {
    public static List<long[]> normalize(List<long[]> a) {
        if (a == null) {
            throw new IllegalArgumentException("Range list must not be null");
        }
        List<long[]> sorted = new ArrayList<>();
        for (long[] range : a) {
            if (range == null || range.length != 2) {
                throw new IllegalArgumentException("Each range must contain two endpoints");
            }
            if (range[0] > range[1]) {
                throw new IllegalArgumentException("Range endpoints are reversed");
            }
            if (range[0] != range[1]) {
                sorted.add(new long[] {range[0], range[1]});
            }
        }
        sorted.sort(Comparator.comparingLong(range -> range[0]));
        List<long[]> result = new ArrayList<>();
        for (long[] range : sorted) {
            if (result.isEmpty() || result.get(result.size() - 1)[1] < range[0]) {
                result.add(range);
            } else {
                long[] previous = result.get(result.size() - 1);
                previous[1] = Math.max(previous[1], range[1]);
            }
        }
        return result;
    }

    public static List<long[]> subtract(List<long[]> a, List<long[]> b) {
        List<long[]> sources = normalize(a);
        List<long[]> exclusions = normalize(b);
        List<long[]> result = new ArrayList<>();
        int j = 0;
        for (long[] source : sources) {
            long cursor = source[0];
            while (j < exclusions.size() && exclusions.get(j)[1] <= cursor) {
                j++;
            }
            while (j < exclusions.size() && exclusions.get(j)[0] < source[1]) {
                long[] exclusion = exclusions.get(j);
                if (exclusion[0] > cursor) {
                    result.add(new long[] {cursor, exclusion[0]});
                }
                cursor = Math.max(cursor, exclusion[1]);
                // Retain an exclusion that may also cover the next source.
                if (cursor >= source[1]) {
                    break;
                }
                j++;
            }
            if (cursor < source[1]) {
                result.add(new long[] {cursor, source[1]});
            }
        }
        return result;
    }

    public static BigInteger length(List<long[]> a) {
        BigInteger total = BigInteger.ZERO;
        for (long[] range : normalize(a)) {
            total = total.add(BigInteger.valueOf(range[1]).subtract(BigInteger.valueOf(range[0])));
        }
        return total;
    }
}
