export async function runPool(tasks, {concurrency = 2, signal} = {}) {
  if (!Array.isArray(tasks) || tasks.some(task => typeof task !== 'function') ||
      !Number.isInteger(concurrency) || concurrency <= 0 ||
      (signal !== undefined && !(signal instanceof AbortSignal))) {
    throw new TypeError('Invalid pool arguments');
  }
  // Array iteration includes holes, unlike Array.prototype.some.
  for (const task of tasks) if (typeof task !== 'function') throw new TypeError('Invalid task');
  return new Promise((resolve, reject) => {
    const results = new Array(tasks.length);
    let next = 0, active = 0, stopped = false, error, finished = false;
    const stop = reason => {
      if (!stopped) { stopped = true; error = reason; }
    };
    const abort = () => { stop(signal.reason); pump(); };
    const pump = () => {
      if (finished) return;
      while (!stopped && active < concurrency && next < tasks.length) {
        const index = next++;
        active++;
        let value;
        try { value = tasks[index](); }
        catch (reason) { active--; stop(reason); break; }
        Promise.resolve(value).then(
          result => { results[index] = result; active--; pump(); },
          reason => { active--; stop(reason); pump(); }
        );
      }
      if (active === 0 && (stopped || next === tasks.length)) {
        finished = true;
        signal?.removeEventListener('abort', abort);
        if (stopped) reject(error); else resolve(results);
      }
    };
    signal?.addEventListener('abort', abort, {once: true});
    if (signal?.aborted) stop(signal.reason);
    pump();
  });
}
