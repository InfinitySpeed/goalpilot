import {test} from "node:test";import assert from "node:assert/strict";import {runPool} from "../pool.mjs";test("API",()=>assert.equal(typeof runPool,"function"));
