import {test} from 'node:test';
import assert from 'node:assert/strict';
import {runPool} from '../pool.mjs';
const deferred = () => { let resolve, reject; const promise = new Promise((a,b) => {resolve=a; reject=b;}); return {promise,resolve,reject}; };
const turn = async () => { for (let i=0;i<8;i++) await Promise.resolve(); };
const outcome = p => p.then(value => ({value}), error => ({error}));
test('lazy bounded workers preserve order and drain', async () => {
  const gates = Array.from({length:5}, deferred);
  const started = []; let active=0, peak=0;
  const p = runPool(gates.map((gate,i) => () => {
    started.push(i); peak=Math.max(peak,++active);
    return gate.promise.finally(() => active--);
  }), {concurrency:2});
  assert.deepEqual(started,[0,1]);
  gates[1].resolve('b'); await turn(); assert.deepEqual(started,[0,1,2]);
  gates[2].resolve('c'); await turn(); assert.deepEqual(started,[0,1,2,3]);
  gates[0].resolve('a'); await turn(); assert.deepEqual(started,[0,1,2,3,4]);
  gates[4].resolve('e'); gates[3].resolve('d');
  assert.deepEqual(await p,['a','b','c','d','e']); assert.equal(peak,2); assert.equal(active,0);
  assert.deepEqual(await runPool([()=>1,()=>Promise.resolve(2)]),[1,2]);
  assert.deepEqual(await runPool([]),[]);
});
test('validate all arguments before invoking', async () => {
  let calls=0; const task=()=>calls++;
  for (const tasks of [null, {}, [task,1], [task,,]])
    await assert.rejects(runPool(tasks),TypeError);
  for (const concurrency of [0,-1,1.2,NaN,Infinity,'2',null])
    await assert.rejects(runPool([task],{concurrency}),TypeError);
  await assert.rejects(runPool([task],{signal:{}}),TypeError);
  assert.equal(calls,0);
});
test('failure identities, synchronous throws, and drain of later rejection', async () => {
  for (const error of [undefined,null,false,new Error('first')]) {
    const gate=deferred(); let calls=0, settled=false;
    const p=outcome(runPool([()=>gate.promise,()=>{throw error;},()=>calls++],{concurrency:2}));
    p.then(()=>settled=true); await turn(); assert.equal(settled,false); assert.equal(calls,0);
    gate.reject(new Error('later')); assert.equal((await p).error,error);
  }
  const a=deferred(), b=deferred(); let calls=0;
  const p=outcome(runPool([()=>a.promise,()=>b.promise,()=>calls++],{concurrency:2}));
  const first=new Error('async first'); a.reject(first); await turn();
  assert.equal(calls,0); b.reject(new Error('second')); assert.equal((await p).error,first);
});
test('abort stops scheduling, drains, and preserves first observed cause', async () => {
  for (const empty of [false,true]) {
    const c=new AbortController(); c.abort(); let calls=0;
    const result=await outcome(runPool(empty?[]:[()=>calls++],{signal:c.signal}));
    assert.equal(result.error,c.signal.reason); assert.equal(calls,0);
  }
  for (const failureFirst of [false,true]) {
    const c=new AbortController(), a=deferred(), b=deferred(); let calls=0, settled=false;
    const p=outcome(runPool([()=>a.promise,()=>b.promise,()=>calls++],{signal:c.signal}));
    p.then(()=>settled=true); const error=new Error('task');
    if (failureFirst) { a.reject(error); await turn(); }
    c.abort(); await turn(); assert.equal(settled,false); assert.equal(calls,0);
    if (!failureFirst) a.reject(error);
    b.resolve(); assert.equal((await p).error,failureFirst?error:c.signal.reason);
  }
  const c=new AbortController(); let calls=0;
  const p=outcome(runPool([()=>{c.abort(); return 1;},()=>calls++],{signal:c.signal}));
  assert.equal((await p).error,c.signal.reason); assert.equal(calls,0);
});
