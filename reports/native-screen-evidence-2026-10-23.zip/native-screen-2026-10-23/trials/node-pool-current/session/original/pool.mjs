export async function runPool(tasks,{concurrency=2,signal}={}) { throw Error("unfinished"); }
