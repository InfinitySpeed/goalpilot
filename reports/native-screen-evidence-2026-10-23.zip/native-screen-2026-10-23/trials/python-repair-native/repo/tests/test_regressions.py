import copy
import unittest

from planner import plan


class PlannerRegressions(unittest.TestCase):
    def test_dependencies_and_newly_ready_nodes(self):
        self.assertEqual(plan({"z": [], "b": ["a"], "c": []}),
                         ["a", "b", "c", "z"])

    def test_duplicate_edges_and_value_only_nodes(self):
        graph = {"c": ["b", "a", "b"], "b": ["a", "a"]}
        original = copy.deepcopy(graph)
        self.assertEqual(plan(graph), ["a", "b", "c"])
        self.assertEqual(graph, original)

    def test_insertion_order_does_not_matter(self):
        self.assertEqual(plan({"c": ["b", "a"], "d": []}),
                         plan({"d": [], "c": ["a", "b"]}))

    def test_only_cycle_members_are_reported(self):
        graph = {"a": ["b"], "b": ["a"], "c": ["b"],
                 "d": ["c"], "s": ["s"], "x": ["y"],
                 "y": ["x"], "free": []}
        original = copy.deepcopy(graph)
        with self.assertRaises(ValueError) as error:
            plan(graph)
        self.assertEqual(str(error.exception), "cycle: a,b,s,x,y")
        self.assertEqual(graph, original)

    def test_malformed_inputs(self):
        invalid = [None, [], "graph", {1: []}, {"": []},
                   {"a": None}, {"a": "b"}, {"a": ("b",)},
                   {"a": {"b"}}, {"a": [""]}, {"a": [1]},
                   {"a": [["b"]]}, {"a": [None]},
                   {"a": ["a"], "z": [False]}]
        for graph in invalid:
            with self.subTest(graph=graph):
                with self.assertRaises(ValueError):
                    plan(graph)

    def test_long_chains_and_cycles_do_not_require_recursion(self):
        names = [str(i).zfill(4) for i in range(1500)]
        graph = {names[i]: [names[i - 1]] for i in range(1, len(names))}
        self.assertEqual(plan(graph), names)
        graph[names[0]] = [names[-1]]
        graph["downstream"] = [names[-1]]
        with self.assertRaises(ValueError) as error:
            plan(graph)
        self.assertEqual(str(error.exception), "cycle: " + ",".join(names))
