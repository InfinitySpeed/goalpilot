import heapq


def plan(graph):
    """Return dependencies first, choosing the smallest available node."""
    if not isinstance(graph, dict):
        raise ValueError("graph must be a dictionary")
    for node, dependencies in graph.items():
        if not isinstance(node, str) or not node:
            raise ValueError("node names must be nonempty strings")
        if not isinstance(dependencies, list):
            raise ValueError("dependencies must be lists")
        if any(not isinstance(dep, str) or not dep for dep in dependencies):
            raise ValueError("node names must be nonempty strings")

    # Copy and deduplicate edges without changing the caller's lists.
    dependencies = {node: set(deps) for node, deps in graph.items()}
    nodes = set(dependencies)
    for deps in dependencies.values():
        nodes.update(deps)
    for node in nodes:
        dependencies.setdefault(node, set())
    dependents = {node: set() for node in nodes}
    for node, deps in dependencies.items():
        for dep in deps:
            dependents[dep].add(node)

    remaining = {node: len(deps) for node, deps in dependencies.items()}
    ready = [node for node in nodes if remaining[node] == 0]
    heapq.heapify(ready)
    result = []
    while ready:
        node = heapq.heappop(ready)
        result.append(node)
        for dependent in dependents[node]:
            remaining[dependent] -= 1
            if remaining[dependent] == 0:
                heapq.heappush(ready, dependent)
    if len(result) == len(nodes):
        return result

    # A blocked node need not be cyclic. Find strongly connected components
    # among blocked nodes with iterative DFS, avoiding recursion depth limits.
    blocked = {node for node in nodes if remaining[node] > 0}
    visited = set()
    finished = []
    for start in blocked:
        if start in visited:
            continue
        visited.add(start)
        stack = [(start, iter(dependencies[start]))]
        while stack:
            node, edges = stack[-1]
            neighbor = next(edges, None)
            if neighbor is None:
                finished.append(node)
                stack.pop()
            elif neighbor in blocked and neighbor not in visited:
                visited.add(neighbor)
                stack.append((neighbor, iter(dependencies[neighbor])))

    visited.clear()
    cyclic = set()
    for start in reversed(finished):
        if start in visited:
            continue
        component = set()
        pending = [start]
        visited.add(start)
        while pending:
            node = pending.pop()
            component.add(node)
            for neighbor in dependents[node]:
                if neighbor in blocked and neighbor not in visited:
                    visited.add(neighbor)
                    pending.append(neighbor)
        if len(component) > 1 or start in dependencies[start]:
            cyclic.update(component)
    raise ValueError("cycle: " + ",".join(sorted(cyclic)))
