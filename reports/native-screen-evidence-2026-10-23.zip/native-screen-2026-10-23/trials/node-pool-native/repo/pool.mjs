export async function runPool(tasks, { concurrency = 2, signal } = {}) {
  if (!Array.isArray(tasks)) throw new TypeError('tasks must be an array');
  if (!Number.isInteger(concurrency) || concurrency <= 0) {
    throw new TypeError('concurrency must be a positive integer');
  }
  const queue = Array.from(tasks);
  if (queue.some(task => typeof task !== 'function')) {
    throw new TypeError('tasks must contain only functions');
  }
  if (signal !== undefined && !(signal instanceof AbortSignal)) {
    throw new TypeError('signal must be an AbortSignal');
  }
  if (signal?.aborted) throw signal.reason;

  return new Promise((resolve, reject) => {
    const results = new Array(queue.length);
    let next = 0;
    let active = 0;
    let stopped = false;
    let firstError;

    function stop(error) {
      if (!stopped) {
        stopped = true;
        firstError = error;
      }
    }

    function finish() {
      if (active === 0 && (stopped || next === queue.length)) {
        signal?.removeEventListener('abort', onAbort);
        if (stopped) reject(firstError);
        else resolve(results);
      }
    }

    function onAbort() {
      stop(signal.reason);
      finish();
    }

    function schedule() {
      while (!stopped && active < concurrency && next < queue.length) {
        const index = next++;
        let value;
        active++;
        try {
          // Invoke directly so a synchronous throw stops this scheduling pass.
          value = queue[index]();
        } catch (error) {
          active--;
          stop(error);
          break;
        }
        Promise.resolve(value).then(
          result => {
            results[index] = result;
            active--;
            schedule();
          },
          error => {
            active--;
            stop(error);
            finish();
          },
        );
      }
      finish();
    }

    signal?.addEventListener('abort', onAbort, { once: true });
    schedule();
  });
}
