import { test } from 'node:test';
import assert from 'node:assert/strict';
import { runPool } from '../pool.mjs';

function deferred() {
  let resolve, reject;
  const promise = new Promise((yes, no) => { resolve = yes; reject = no; });
  return { promise, resolve, reject };
}

// Drain promise reactions without depending on timers or machine speed.
async function flush() {
  for (let i = 0; i < 10; i++) await Promise.resolve();
}

function observe(promise) {
  const state = { settled: false };
  state.done = promise.then(
    value => { state.settled = true; state.value = value; },
    error => { state.settled = true; state.error = error; state.failed = true; },
  );
  return state;
}

test('lazy scheduling respects capacity and preserves input order', async () => {
  const gates = Array.from({ length: 5 }, deferred);
  const started = [];
  let active = 0, peak = 0;
  const result = runPool(gates.map((gate, i) => () => {
    started.push(i);
    peak = Math.max(peak, ++active);
    return gate.promise.then(value => { active--; return value; });
  }), { concurrency: 2 });
  assert.deepEqual(started, [0, 1]);
  gates[1].resolve('b');
  await flush();
  assert.deepEqual(started, [0, 1, 2]);
  gates[2].resolve('c');
  await flush();
  gates[3].resolve('d');
  await flush();
  gates[4].resolve('e');
  await flush();
  gates[0].resolve('a');
  assert.deepEqual(await result, ['a', 'b', 'c', 'd', 'e']);
  assert.equal(peak, 2);
});

test('first rejection stops scheduling, drains work and handles later errors', async () => {
  const gates = [deferred(), deferred(), deferred()];
  let started = 0;
  const state = observe(runPool([...gates.map(g => () => { started++; return g.promise; }),
    () => { started++; }], { concurrency: 3 }));
  const first = new Error('first');
  gates[1].reject(first);
  await flush();
  assert.equal(started, 3);
  assert.equal(state.settled, false);
  gates[0].reject(new Error('later'));
  await flush();
  assert.equal(state.settled, false);
  gates[2].resolve();
  await state.done;
  assert.equal(state.error, first);
});

test('synchronous throws stop immediately and preserve falsy reasons', async () => {
  for (const reason of [undefined, null, false, 0, '']) {
    const gate = deferred();
    let called = false;
    const state = observe(runPool([
      () => gate.promise,
      () => { throw reason; },
      () => { called = true; },
    ], { concurrency: 3 }));
    await flush();
    assert.equal(called, false);
    assert.equal(state.settled, false);
    gate.resolve();
    await state.done;
    assert.equal(state.failed, true);
    assert.equal(state.error, reason);
  }
});

test('abort stops scheduling and waits for every started task', async () => {
  const controller = new AbortController();
  const gate = deferred();
  const reason = new Error('abort');
  let called = false;
  const state = observe(runPool([
    () => { controller.abort(reason); return gate.promise; },
    () => { called = true; },
  ], { signal: controller.signal }));
  await flush();
  assert.equal(called, false);
  assert.equal(state.settled, false);
  gate.reject(new Error('later'));
  await state.done;
  assert.equal(state.error, reason);
});

test('first observed failure wins over a subsequent abort', async () => {
  const controller = new AbortController();
  const gate = deferred();
  const reason = new Error('task');
  const state = observe(runPool([
    () => Promise.reject(reason), () => gate.promise, () => assert.fail('scheduled'),
  ], { signal: controller.signal }));
  await flush();
  controller.abort();
  gate.resolve();
  await state.done;
  assert.equal(state.error, reason);
});

test('already aborted input rejects even when empty and never invokes tasks', async () => {
  const controller = new AbortController();
  controller.abort();
  for (const tasks of [[], [() => assert.fail('invoked')]]) {
    await assert.rejects(runPool(tasks, { signal: controller.signal }),
      error => error === controller.signal.reason);
  }
});

test('validates all arguments before invoking any task', async () => {
  const task = () => assert.fail('invoked');
  for (const tasks of [null, {}, 'tasks', [task, null], [task, , task]]) {
    await assert.rejects(runPool(tasks), TypeError);
  }
  for (const concurrency of [0, -1, 1.5, NaN, Infinity, '2', null]) {
    await assert.rejects(runPool([task], { concurrency }), TypeError);
  }
  for (const signal of [null, {}, false]) {
    await assert.rejects(runPool([task], { signal }), TypeError);
  }
});

test('empty input, default concurrency, values and thenables', async () => {
  assert.deepEqual(await runPool([]), []);
  assert.deepEqual(await runPool([() => 1, () => Promise.resolve(2),
    () => ({ then(resolve) { resolve(3); } })]), [1, 2, 3]);
  const reason = new Error('then getter');
  await assert.rejects(runPool([() => ({ get then() { throw reason; } })]),
    error => error === reason);
});

test('external abort drains multiple running tasks and keeps its reason', async () => {
  const controller = new AbortController();
  const gates = [deferred(), deferred()];
  let started = 0;
  const state = observe(runPool([
    ...gates.map(gate => () => { started++; return gate.promise; }),
    () => { started++; },
  ], { concurrency: 2, signal: controller.signal }));
  const reason = new Error('external');
  controller.abort(reason);
  gates[0].resolve();
  await flush();
  assert.equal(started, 2);
  assert.equal(state.settled, false);
  gates[1].reject(new Error('secondary'));
  await state.done;
  assert.equal(state.error, reason);
});
