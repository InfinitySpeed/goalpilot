import copy
import unittest

from planner import plan


class PlannerRegressions(unittest.TestCase):
    def test_order_and_input_preservation(self):
        graph = {"z": ["b", "b"], "b": ["a"], "c": [], "d": ["c"]}
        before = copy.deepcopy(graph)
        # a unlocks b, which must precede the already-ready c.
        self.assertEqual(plan(graph), ["a", "b", "c", "d", "z"])
        self.assertEqual(graph, before)
        self.assertEqual(plan(dict(reversed(list(graph.items())))),
                         ["a", "b", "c", "d", "z"])

    def test_cycles_only(self):
        graphs = [
            ({"a": ["b"], "b": ["a"], "tail": ["a"]}, "a,b"),
            ({"a": ["a"], "tail": ["a"]}, "a"),
            ({"a": ["b"], "b": ["a"], "c": ["d"], "d": ["c"],
              "s": ["s"], "tail": ["b", "d"], "free": []}, "a,b,c,d,s"),
        ]
        for graph, names in graphs:
            with self.subTest(graph=graph):
                before = copy.deepcopy(graph)
                with self.assertRaises(ValueError) as caught:
                    plan(graph)
                self.assertEqual(str(caught.exception), "cycle: " + names)
                self.assertEqual(graph, before)

    def test_malformed_inputs(self):
        cases = [None, [], "graph", {1: []}, {"": []},
                 {"a": "b"}, {"a": ("b",)}, {"a": {"b"}},
                 {"a": None}, {"a": [1]}, {"a": [""]},
                 {"a": [["b"]]}, {"ready": [], "bad": [None]},
                 {"cycle": ["cycle"], "bad": [None]}]
        for graph in cases:
            with self.subTest(graph=graph):
                with self.assertRaises(ValueError):
                    plan(graph)

    def test_deep_graph(self):
        graph = {str(i): [str(i + 1)] for i in range(1500)}
        self.assertEqual(plan(graph), [str(i) for i in range(1500, -1, -1)])
        graph["1500"] = ["1499"]
        with self.assertRaises(ValueError) as caught:
            plan(graph)
        self.assertEqual(str(caught.exception), "cycle: 1499,1500")
