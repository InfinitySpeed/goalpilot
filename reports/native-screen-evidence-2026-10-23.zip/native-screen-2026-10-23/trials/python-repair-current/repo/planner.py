"""Deterministic dependency planning."""
import heapq


def plan(graph):
    if not isinstance(graph, dict):
        raise ValueError("graph must be a dict")
    for node, dependencies in graph.items():
        if not isinstance(node, str) or not node:
            raise ValueError("invalid node")
        if not isinstance(dependencies, list):
            raise ValueError("dependencies must be lists")
        if any(not isinstance(dep, str) or not dep for dep in dependencies):
            raise ValueError("invalid dependency")

    edges = {node: set(deps) for node, deps in graph.items()}
    for deps in graph.values():
        for dep in deps:
            edges.setdefault(dep, set())
    followers = {node: set() for node in edges}
    for node, deps in edges.items():
        for dep in deps:
            followers[dep].add(node)
    remaining = {node: len(deps) for node, deps in edges.items()}
    ready = [node for node, count in remaining.items() if count == 0]
    heapq.heapify(ready)
    result = []
    while ready:
        node = heapq.heappop(ready)
        result.append(node)
        for follower in followers[node]:
            remaining[follower] -= 1
            if remaining[follower] == 0:
                heapq.heappush(ready, follower)
    if len(result) == len(edges):
        return result

    # Iterative Kosaraju traversal keeps deep dependency graphs safe as well.
    seen = set()
    finished = []
    for node in edges:
        if node in seen:
            continue
        seen.add(node)
        stack = [(node, iter(edges[node]))]
        while stack:
            current, neighbors = stack[-1]
            neighbor = next(neighbors, None)
            if neighbor is None:
                finished.append(current)
                stack.pop()
            elif neighbor not in seen:
                seen.add(neighbor)
                stack.append((neighbor, iter(edges[neighbor])))
    seen.clear()
    cyclic = set()
    for node in reversed(finished):
        if node in seen:
            continue
        component = set()
        stack = [node]
        seen.add(node)
        while stack:
            current = stack.pop()
            component.add(current)
            for neighbor in followers[current]:
                if neighbor not in seen:
                    seen.add(neighbor)
                    stack.append(neighbor)
        if len(component) > 1 or node in edges[node]:
            cyclic.update(component)
    raise ValueError("cycle: " + ",".join(sorted(cyclic)))
