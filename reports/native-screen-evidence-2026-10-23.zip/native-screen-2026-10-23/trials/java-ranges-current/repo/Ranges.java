import java.util.*;
import java.math.BigInteger;

public class Ranges {
 public static List<long[]> normalize(List<long[]> a) {
  if (a == null) throw new IllegalArgumentException("null ranges");
  List<long[]> sorted = new ArrayList<>();
  for (long[] r : a) {
   if (r == null || r.length != 2 || r[0] > r[1])
    throw new IllegalArgumentException("invalid range");
   if (r[0] != r[1]) sorted.add(r.clone());
  }
  sorted.sort(Comparator.comparingLong(r -> r[0]));
  List<long[]> out = new ArrayList<>();
  for (long[] r : sorted) {
   if (out.isEmpty() || r[0] > out.get(out.size()-1)[1]) out.add(r);
   else {
    long[] last = out.get(out.size()-1);
    last[1] = Math.max(last[1], r[1]);
   }
  }
  return out;
 }
 public static List<long[]> subtract(List<long[]> a, List<long[]> b) {
  List<long[]> left = normalize(a), right = normalize(b), out = new ArrayList<>();
  int j = 0;
  for (long[] r : left) {
   long cursor = r[0];
   while (j < right.size() && right.get(j)[1] <= cursor) j++;
   int k = j;
   while (k < right.size() && right.get(k)[0] < r[1]) {
    long[] cut = right.get(k);
    if (cut[0] > cursor) out.add(new long[]{cursor, cut[0]});
    cursor = Math.max(cursor, cut[1]);
    if (cursor >= r[1]) break;
    k++;
   }
   if (cursor < r[1]) out.add(new long[]{cursor, r[1]});
   j = k;
  }
  return out;
 }
 public static BigInteger length(List<long[]> a) {
  BigInteger total = BigInteger.ZERO;
  for (long[] r : normalize(a))
   total = total.add(BigInteger.valueOf(r[1]).subtract(BigInteger.valueOf(r[0])));
  return total;
 }
}
