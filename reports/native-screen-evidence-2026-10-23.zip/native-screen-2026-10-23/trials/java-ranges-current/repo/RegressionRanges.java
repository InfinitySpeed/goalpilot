import java.util.*;
import java.math.BigInteger;
import javax.tools.ToolProvider;
import java.net.*;
import java.nio.file.*;

class RegressionRanges {
 static Class<?> ranges;
 @SuppressWarnings("unchecked")
 static Object call(String name, List<long[]>... args) throws Exception {
  try {
   return args.length == 2
    ? ranges.getMethod(name,List.class,List.class).invoke(null,args[0],args[1])
    : ranges.getMethod(name,List.class).invoke(null,args[0]);
  } catch (java.lang.reflect.InvocationTargetException e) {
   if(e.getCause() instanceof IllegalArgumentException) throw (IllegalArgumentException)e.getCause();
   throw e;
  }
 }
 static List<long[]> list(long[]... a) { return Arrays.asList(a); }
 static void equal(Object actual, long[]... expected) {
  if (!Arrays.deepEquals(((List<?>)actual).toArray(), expected)) throw new AssertionError("ranges");
 }
 static void invalid(String name, List<long[]> a, List<long[]> b) throws Exception {
  try { if(name.equals("subtract")) call(name,a,b); else call(name,a); }
  catch(IllegalArgumentException ok) { return; }
  throw new AssertionError("accepted invalid " + name);
 }
 public static void main(String[] args) throws Exception {
  Path d=Files.createTempDirectory("ranges-regression");
  try {
   if(ToolProvider.getSystemJavaCompiler().run(null,null,null,"-d",d.toString(),"Ranges.java")!=0) throw new AssertionError();
   try(var loader=new URLClassLoader(new URL[]{d.toUri().toURL()})) {
    ranges=loader.loadClass("Ranges");
    long[] first={5,9};
    List<long[]> input=List.of(first,new long[]{1,3},new long[]{3,5},new long[]{2,4},new long[]{8,8},new long[]{12,14});
    equal(call("normalize",input),new long[]{1,9},new long[]{12,14});
    equal(call("subtract",input,list(new long[]{7,13},new long[]{2,4},new long[]{4,6})),new long[]{1,2},new long[]{6,7},new long[]{13,14});
    equal(call("subtract",list(new long[]{10,12},new long[]{0,2}),list(new long[]{1,11})),new long[]{0,1},new long[]{11,12});
    equal(call("subtract",input,input));
    equal(call("normalize",list(new long[]{4,4})));
    equal(call("subtract",list(),list()));
    List<long[]> full=list(new long[]{Long.MIN_VALUE,0},new long[]{0,Long.MAX_VALUE});
    if(!call("length",full).equals(BigInteger.ONE.shiftLeft(64).subtract(BigInteger.ONE))) throw new AssertionError("overflow");
    if(!call("length",input).equals(BigInteger.TEN)) throw new AssertionError("union length");
    if(!call("length",list()).equals(BigInteger.ZERO)) throw new AssertionError();
    equal(call("subtract",full,list(new long[]{Long.MIN_VALUE,Long.MAX_VALUE})));
    for(String name:List.of("normalize","subtract","length")) {
     for(List<long[]> bad:Arrays.<List<long[]>>asList(null,list((long[])null),list(new long[]{}),list(new long[]{1}),list(new long[]{1,2,3}),list(new long[]{2,1}))) {
      invalid(name,bad,list());
      if(name.equals("subtract")) invalid(name,list(),bad);
     }
    }
    @SuppressWarnings("unchecked") List<long[]> fresh=(List<long[]>)call("normalize",input);
    fresh.get(0)[0]=99;
    @SuppressWarnings("unchecked") List<long[]> sub=(List<long[]>)call("subtract",input,list());
    sub.get(0)[1]=99;
    equal(input,new long[]{5,9},new long[]{1,3},new long[]{3,5},new long[]{2,4},new long[]{8,8},new long[]{12,14});
   }
  } finally {
   try(var paths=Files.walk(d)) { paths.sorted(Comparator.reverseOrder()).forEach(p->{try{Files.delete(p);}catch(Exception e){throw new RuntimeException(e);}}); }
  }
 }
}
