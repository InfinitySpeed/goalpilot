from pathlib import Path
import json,subprocess,sys,time
root=Path(__file__).resolve().parent
p=json.loads((root/'protocol.json').read_text())
raw=0
for case,arm in p['fresh_run_order']:
    ident=f'{case}-{arm}'
    trial=root/'trials'/ident
    if trial.exists():
        raise RuntimeError(f'evidence already exists; refusing overwrite: {trial}')
    print('START',ident,time.time(),flush=True)
    proc=subprocess.run([sys.executable,str(root/'worker.py'),case,arm],capture_output=True,text=True,timeout=240)
    (root/f'{ident}.worker.log').write_text(proc.stdout+proc.stderr)
    print(proc.stdout,flush=True)
    if proc.returncode:
        print('STOP worker failure',proc.returncode,proc.stderr[-1000:],flush=True)
        break
    row=json.loads((trial/'result.json').read_text())
    usage=row['usage']
    raw+=usage.get('total_tokens',0)
    print('CUMULATIVE_RAW',raw,flush=True)
    if not usage.get('usage_complete'):
        print('STOP incomplete usage; no retry',flush=True)
        break
    if raw>=600000:
        print('STOP raw-token cap reached at trial boundary',flush=True)
        break
else:
    print('SCREEN_COMPLETE',len(p['fresh_run_order']),flush=True)
