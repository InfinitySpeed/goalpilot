"""Reference controls validate judges; never shared with model callers."""
from pathlib import Path
import json,subprocess,tempfile
from cases import CASES,materialize

REFERENCES={
'java-ranges': {'Ranges.java': '''import java.util.*;import java.math.BigInteger;
public class Ranges {
 public static List<long[]> normalize(List<long[]> a){
  if(a==null)throw new IllegalArgumentException();List<long[]> r=new ArrayList<>();
  for(long[] p:a){if(p==null||p.length!=2||p[0]>p[1])throw new IllegalArgumentException();if(p[0]<p[1])r.add(p.clone());}
  r.sort(Comparator.comparingLong(p->p[0]));List<long[]> out=new ArrayList<>();
  for(long[] p:r){if(out.isEmpty()||out.get(out.size()-1)[1]<p[0])out.add(p);else{long[] last=out.get(out.size()-1);last[1]=Math.max(last[1],p[1]);}}
  return out;
 }
 public static List<long[]> subtract(List<long[]> a,List<long[]> b){List<long[]> aa=normalize(a),bb=normalize(b),out=new ArrayList<>();
  for(long[] p:aa){long at=p[0];for(long[] q:bb){if(q[1]<=at)continue;if(q[0]>=p[1])break;if(q[0]>at)out.add(new long[]{at,q[0]});at=Math.max(at,q[1]);if(at>=p[1])break;}if(at<p[1])out.add(new long[]{at,p[1]});}return out;
 }
 public static BigInteger length(List<long[]> a){BigInteger n=BigInteger.ZERO;for(long[] p:normalize(a))n=n.add(BigInteger.valueOf(p[1]).subtract(BigInteger.valueOf(p[0])));return n;}
}
'''},
'node-pool': {'pool.mjs': '''export async function runPool(tasks,{concurrency=2,signal}={}) {
 if(!Array.isArray(tasks)||tasks.some(x=>typeof x!=='function')||!Number.isInteger(concurrency)||concurrency<=0)throw new TypeError();
 let stopped=false,error,at=0;const out=[];function stop(e){if(!stopped){stopped=true;error=e;}}
 const abort=()=>stop(signal.reason);if(signal?.aborted)throw signal.reason;signal?.addEventListener('abort',abort,{once:true});
 async function worker(){while(!stopped&&at<tasks.length){const i=at++;try{out[i]=await tasks[i]();}catch(e){stop(e);}}}
 try{await Promise.all(Array.from({length:Math.min(concurrency,tasks.length)},worker));if(stopped)throw error;return out;}finally{signal?.removeEventListener('abort',abort);}
}
'''},
'python-repair': {'planner.py': '''import heapq
def plan(graph):
 if not isinstance(graph,dict) or any(not isinstance(k,str)or not k or not isinstance(v,list)or any(not isinstance(x,str)or not x for x in v)for k,v in graph.items()):raise ValueError('invalid')
 deps={k:set(v)for k,v in graph.items()}
 for v in list(deps.values()):
  for x in v:deps.setdefault(x,set())
 out=[];ready=[k for k,v in deps.items()if not v];heapq.heapify(ready);followers={k:set()for k in deps}
 for k,vs in deps.items():
  for v in vs:followers[v].add(k)
 while ready:
  x=heapq.heappop(ready);out.append(x)
  for k in followers[x]:
   deps[k].remove(x)
   if not deps[k]:heapq.heappush(ready,k)
 if len(out)!=len(deps):
  cyclic=[]
  for start in deps:
   seen=set();todo=list(deps[start])
   while todo:
    x=todo.pop()
    if x==start:cyclic.append(start);break
    if x not in seen:seen.add(x);todo.extend(deps[x])
  raise ValueError('cycle: '+','.join(sorted(cyclic)))
 return out
'''},
'c-codec': {'codec.c': '''#include "codec.h"
#include <stdint.h>
int codec_encode(const unsigned char*s,size_t n,unsigned char*d,size_t c,size_t*w){
 if(!w||(n&&!s))return -1;
 size_t need=0,i=0;
 while(i<n){size_t len=1;while(len<255&&len<n-i&&s[i+len]==s[i])len++;if(need>SIZE_MAX-2)return -1;need+=2;i+=len;}
 if(need>c||(need&&!d))return -1;
 size_t o=0;i=0;while(i<n){size_t len=1;while(len<255&&len<n-i&&s[i+len]==s[i])len++;d[o++]=(unsigned char)len;d[o++]=s[i];i+=len;}*w=need;return 0;
}
int codec_decode(const unsigned char*s,size_t n,unsigned char*d,size_t c,size_t*w){
 if(!w||(n&&!s)||n%2)return -1;
 size_t need=0;for(size_t i=0;i<n;i+=2){if(!s[i]||need>SIZE_MAX-s[i])return -1;need+=s[i];}
 if(need>c||(need&&!d))return -1;
 size_t o=0;for(size_t i=0;i<n;i+=2){for(unsigned int j=0;j<s[i];j++)d[o++]=s[i+1];}*w=need;return 0;
}
'''},
}
results={}
for name,files in REFERENCES.items():
 case=CASES[name]
 with tempfile.TemporaryDirectory()as tmp:
  repo=Path(tmp)/'repo';materialize(name,repo)
  for path,body in files.items():(repo/path).write_text(body)
  (repo/case['judge_file']).write_text(case['judge'])
  r=subprocess.run(case['judge_cmd'],cwd=repo,capture_output=True,text=True,timeout=35)
  results[name]={'reference_accepted':r.returncode==0,'log':r.stdout+r.stderr}
Path(__file__).with_name('judge-positive-controls.json').write_text(json.dumps(results,indent=2)+'\n')
print({k:v['reference_accepted']for k,v in results.items()})
assert all(v['reference_accepted']for v in results.values())
