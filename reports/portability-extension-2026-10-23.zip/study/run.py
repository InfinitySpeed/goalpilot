import json,subprocess,sys,time
from pathlib import Path
ROOT=Path(__file__).resolve().parent
protocol=json.loads((ROOT/'protocol.json').read_text())
raw=0
for case,arm in protocol['order']:
 if raw>=protocol['stop_before_next_call_if_raw_tokens_ge']:
  print('STOP research token cap',raw,flush=True);break
 trial=ROOT/'trials'/f'{case}-{arm}'
 if trial.exists():raise RuntimeError('Existing evidence must not be overwritten: '+str(trial))
 print('START',case,arm,time.time(),flush=True)
 p=subprocess.run([sys.executable,str(ROOT/'worker.py'),case,arm],capture_output=True,text=True,timeout=240)
 print(p.stdout,flush=True)
 (ROOT/f'{case}-{arm}.worker.log').write_text(p.stdout+p.stderr)
 if p.returncode:
  print('STOP worker failed; no automatic retry',p.returncode,p.stderr[-500:],flush=True);break
 row=json.loads((trial/'result.json').read_text());raw+=row['usage'].get('total_tokens',0)
 if not row['usage'].get('usage_complete'):
  print('STOP incomplete provider metering',flush=True);break
 print('RESEARCH RAW',raw,flush=True)
