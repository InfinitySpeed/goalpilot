export async function runPool(tasks, {concurrency = 2, signal} = {}) {
  if (!Array.isArray(tasks) || !Number.isInteger(concurrency) || concurrency <= 0) {
    throw new TypeError('Expected tasks array and positive integer concurrency');
  }
  const queue = Array.from(tasks);
  if (queue.some(task => typeof task !== 'function')) throw new TypeError('Expected task functions');
  if (signal !== undefined && !(signal instanceof AbortSignal)) throw new TypeError('Expected AbortSignal');
  return new Promise((resolve, reject) => {
    const results = new Array(queue.length);
    let next = 0, active = 0, stopped = false, error;
    const stop = reason => {
      if (!stopped) { stopped = true; error = reason; }
    };
    const finish = () => {
      if (active === 0 && (stopped || next === queue.length)) {
        signal?.removeEventListener('abort', abort);
        if (stopped) reject(error); else resolve(results);
      }
    };
    const abort = () => { stop(signal.reason); finish(); };
    const pump = () => {
      while (!stopped && active < concurrency && next < queue.length) {
        const index = next++;
        active++;
        let value;
        try { value = queue[index](); }
        catch (reason) { active--; stop(reason); break; }
        Promise.resolve(value).then(
          result => { results[index] = result; active--; pump(); },
          reason => { active--; stop(reason); finish(); }
        );
      }
      finish();
    };
    signal?.addEventListener('abort', abort, {once: true});
    if (signal?.aborted) stop(signal.reason);
    pump();
  });
}
