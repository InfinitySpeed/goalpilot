import {test} from 'node:test';
import assert from 'node:assert/strict';
import {runPool} from '../pool.mjs';
const deferred = () => { let resolve, reject; const promise = new Promise((a,b) => {resolve=a;reject=b;}); return {promise,resolve,reject}; };
const ticks = async () => { for (let i=0;i<8;i++) await Promise.resolve(); };
const observe = p => p.then(value=>({ok:true,value}),error=>({ok:false,error}));

test('lazy bounded scheduling and ordered results', async () => {
  const gates = Array.from({length:5},deferred);
  const started=[]; let active=0, peak=0;
  const result=runPool(gates.map((gate,i)=>()=>{
    started.push(i); peak=Math.max(peak,++active);
    return gate.promise.then(v=>{active--;return v;});
  }),{concurrency:2});
  assert.deepEqual(started,[0,1]);
  gates[1].resolve('b'); await ticks(); assert.deepEqual(started,[0,1,2]);
  gates[2].resolve('c'); await ticks(); assert.deepEqual(started,[0,1,2,3]);
  gates[0].resolve('a'); await ticks(); assert.deepEqual(started,[0,1,2,3,4]);
  gates[4].resolve('e'); gates[3].resolve('d');
  assert.deepEqual(await result,['a','b','c','d','e']); assert.equal(peak,2);
  assert.deepEqual(await runPool([()=>1,()=>Promise.resolve(2),()=>3]),[1,2,3]);
  assert.deepEqual(await runPool([]),[]);
});

test('all validation precedes invocation', async () => {
  let calls=0; const task=()=>++calls;
  for (const tasks of [null,{},[task,null],[task,1],Array(2)]) {
    await assert.rejects(runPool(tasks),TypeError);
  }
  for (const concurrency of [0,-1,1.5,NaN,Infinity,'2',null]) {
    await assert.rejects(runPool([task],{concurrency}),TypeError);
  }
  for (const signal of [null,{},true]) await assert.rejects(runPool([task],{signal}),TypeError);
  assert.equal(calls,0);
});

test('sync failures preserve falsy reasons and stop immediately', async () => {
  for (const reason of [undefined,null,false,new Error('sync')]) {
    let calls=0;
    const result=await observe(runPool([()=>{throw reason;},()=>calls++],{concurrency:2}));
    assert.equal(result.ok,false); assert.equal(result.error,reason); assert.equal(calls,0);
  }
});

test('first failure drains started work, handles later failures and beats abort', async () => {
  const a=deferred(), b=deferred(), controller=new AbortController(); let calls=0, settled=false;
  const result=observe(runPool([()=>a.promise,()=>b.promise,()=>calls++],{signal:controller.signal}));
  result.then(()=>{settled=true;});
  a.reject(undefined); await ticks(); controller.abort(new Error('later abort'));
  assert.equal(settled,false); assert.equal(calls,0);
  b.reject(new Error('later rejection'));
  const outcome=await result; assert.equal(outcome.ok,false); assert.equal(outcome.error,undefined);
  assert.equal(calls,0);
});

test('synchronous throw also drains earlier started work', async () => {
  const gate=deferred(); const error=new Error('sync'); let settled=false,calls=0;
  const result=observe(runPool([()=>gate.promise,()=>{throw error;},()=>calls++],{concurrency:3}));
  result.then(()=>{settled=true;}); await ticks(); assert.equal(settled,false);
  gate.resolve(); assert.equal((await result).error,error); assert.equal(calls,0);
});

test('abort drains tasks and wins over subsequent task failure', async () => {
  const controller=new AbortController(), a=deferred(), b=deferred();
  const reason=new Error('abort'); let calls=0,settled=false;
  const result=observe(runPool([()=>a.promise,()=>b.promise,()=>calls++],{signal:controller.signal}));
  result.then(()=>{settled=true;}); controller.abort(reason);
  a.reject(new Error('later')); await ticks(); assert.equal(settled,false);
  b.resolve(); assert.equal((await result).error,reason); assert.equal(calls,0);
});

test('already aborted input including empty input invokes nothing', async () => {
  const controller=new AbortController(); controller.abort(); let calls=0;
  for (const tasks of [[],[()=>calls++]]) {
    const outcome=await observe(runPool(tasks,{signal:controller.signal}));
    assert.equal(outcome.ok,false); assert.equal(outcome.error,controller.signal.reason);
  }
  assert.equal(calls,0);
});

test('abort inside a task prevents the next invocation', async () => {
  const controller=new AbortController(); const gate=deferred(); let calls=0;
  const result=observe(runPool([()=>{controller.abort();return gate.promise;},()=>calls++],{signal:controller.signal}));
  gate.resolve(); assert.equal((await result).error,controller.signal.reason); assert.equal(calls,0);
});
