#include "codec.h"
#include <stdint.h>
#include <string.h>

int codec_encode(const unsigned char *s, size_t n, unsigned char *d,
                 size_t c, size_t *w)
{
    size_t i = 0, needed = 0;
    if (!w || (n && (!s || !d))) return -1;
    while (i < n) {
        size_t run = 1;
        while (run < 255 && run < n - i && s[i + run] == s[i]) ++run;
        if (needed > SIZE_MAX - 2 || c - needed < 2) return -1;
        needed += 2;
        i += run;
    }
    i = 0;
    size_t out = 0;
    while (i < n) {
        size_t run = 1;
        while (run < 255 && run < n - i && s[i + run] == s[i]) ++run;
        d[out++] = (unsigned char)run;
        d[out++] = s[i];
        i += run;
    }
    *w = needed;
    return 0;
}

int codec_decode(const unsigned char *s, size_t n, unsigned char *d,
                 size_t c, size_t *w)
{
    size_t needed = 0;
    if (!w || (n & 1) || (n && (!s || !d))) return -1;
    for (size_t i = 0; i < n; i += 2) {
        size_t count = s[i];
        if (!count || needed > SIZE_MAX - count || count > c - needed)
            return -1;
        needed += count;
    }
    size_t out = 0;
    for (size_t i = 0; i < n; i += 2) {
        memset(d + out, s[i + 1], s[i]);
        out += s[i];
    }
    *w = needed;
    return 0;
}
