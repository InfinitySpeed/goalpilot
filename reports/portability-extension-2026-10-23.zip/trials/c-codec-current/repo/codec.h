#ifndef CODEC_H
#define CODEC_H
#include <stddef.h>
int codec_encode(const unsigned char*,size_t,unsigned char*,size_t,size_t*);
int codec_decode(const unsigned char*,size_t,unsigned char*,size_t,size_t*);
#endif
