#include "codec.h"
#include <assert.h>
#include <stdint.h>
#include <string.h>

typedef int (*codec_fn)(const unsigned char *, size_t, unsigned char *, size_t, size_t *);
static void fails(codec_fn fn, const unsigned char *s, size_t n,
                  size_t capacity, int null_dst, int null_written)
{
    unsigned char dst[2048], before[2048];
    size_t written = 937;
    memset(dst, 0xa7, sizeof dst);
    memcpy(before, dst, sizeof dst);
    assert(fn(s, n, null_dst ? NULL : dst, capacity,
              null_written ? NULL : &written) == -1);
    assert(written == 937);
    assert(memcmp(dst, before, sizeof dst) == 0);
}
int main(void)
{
    unsigned char src[1024], encoded[2048], decoded[1024];
    size_t e, d;
    codec_fn functions[] = {codec_encode, codec_decode};
    for (size_t f = 0; f < 2; ++f) {
        size_t w = 99;
        assert(functions[f](NULL, 0, NULL, 0, &w) == 0 && w == 0);
        w = 99;
        memset(decoded, 0xa7, sizeof decoded);
        assert(functions[f](NULL, 0, decoded, SIZE_MAX, &w) == 0 && w == 0);
        assert(decoded[0] == 0xa7);
        fails(functions[f], NULL, 2, 2048, 0, 0);
        fails(functions[f], NULL, 0, 0, 1, 1);
    }
    for (size_t n = 0; n <= 1024; ++n) {
        for (size_t pattern = 0; pattern < 3; ++pattern) {
            for (size_t i = 0; i < n; ++i)
                src[i] = pattern == 0 ? 0 : pattern == 1 ? 255 : (unsigned char)i;
            memset(encoded, 0xa7, sizeof encoded);
            assert(codec_encode(src, n, encoded, sizeof encoded, &e) == 0);
            size_t expected = pattern < 2 ? 2 * ((n + 254) / 255) : 2 * n;
            assert(e == expected);
            if (e < sizeof encoded) assert(encoded[e] == 0xa7);
            for (size_t j = 0, pos = 0; j < e; j += 2) {
                size_t run = pattern < 2 ? (n - pos > 255 ? 255 : n - pos) : 1;
                assert(encoded[j] == run && encoded[j + 1] == src[pos]);
                pos += run;
            }
            memset(decoded, 0xa7, sizeof decoded);
            assert(codec_decode(encoded, e, decoded, n, &d) == 0);
            assert(d == n && memcmp(src, decoded, n) == 0);
            if (n < sizeof decoded) assert(decoded[n] == 0xa7);
            if (n) {
                fails(codec_encode, src, n, e - 1, 0, 0);
                fails(codec_decode, encoded, e, n - 1, 0, 0);
            }
        }
    }
    const unsigned char valid[] = {1, 0, 255, 255};
    const unsigned char zero[] = {1, 42, 0, 7};
    fails(codec_decode, valid, 3, SIZE_MAX, 0, 0);
    fails(codec_decode, valid, SIZE_MAX, SIZE_MAX, 0, 0);
    fails(codec_decode, zero, sizeof zero, SIZE_MAX, 0, 0);
    fails(codec_decode, valid, sizeof valid, 255, 0, 0);
    for (size_t f = 0; f < 2; ++f) {
        fails(functions[f], valid, sizeof valid, SIZE_MAX, 1, 0);
        fails(functions[f], valid, sizeof valid, SIZE_MAX, 0, 1);
    }
    assert(codec_decode(valid, sizeof valid, decoded, SIZE_MAX, &d) == 0 && d == 256);
    assert(decoded[0] == 0 && decoded[255] == 255);
    assert(codec_encode(valid, sizeof valid, encoded, SIZE_MAX, &e) == 0 && e == 6);
    return 0;
}
