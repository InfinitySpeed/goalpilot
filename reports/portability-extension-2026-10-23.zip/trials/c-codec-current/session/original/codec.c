#include "codec.h"
int codec_encode(const unsigned char*s,size_t n,unsigned char*d,size_t c,size_t*w){(void)s;(void)n;(void)d;(void)c;(void)w;return -1;}
int codec_decode(const unsigned char*s,size_t n,unsigned char*d,size_t c,size_t*w){(void)s;(void)n;(void)d;(void)c;(void)w;return -1;}
