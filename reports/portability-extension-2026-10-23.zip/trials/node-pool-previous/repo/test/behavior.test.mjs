import {test} from 'node:test';
import assert from 'node:assert/strict';
import {runPool} from '../pool.mjs';
const deferred = () => {
  let resolve, reject;
  const promise = new Promise((a, b) => { resolve = a; reject = b; });
  return {promise, resolve, reject};
};
const tick = () => new Promise(resolve => queueMicrotask(resolve));

test('lazy bounded scheduling preserves order through a complete journey', async () => {
  const gates = Array.from({length: 5}, deferred), started = [];
  let active = 0, peak = 0;
  const result = runPool(gates.map((gate, i) => () => {
    started.push(i); peak = Math.max(peak, ++active);
    return gate.promise.finally(() => active--);
  }), {concurrency: 2});
  assert.deepEqual(started, [0, 1]);
  gates[1].resolve('b');
  await tick(); await tick();
  assert.deepEqual(started, [0, 1, 2]);
  gates[2].resolve('c'); gates[0].resolve('a');
  await tick(); await tick();
  assert.deepEqual(started, [0, 1, 2, 3, 4]);
  gates[4].resolve('e'); gates[3].resolve('d');
  assert.deepEqual(await result, ['a', 'b', 'c', 'd', 'e']);
  assert.equal(peak, 2);
  assert.deepEqual(await runPool([() => 1, () => Promise.resolve(2)]), [1, 2]);
  assert.deepEqual(await runPool([]), []);
});

test('failure identity, draining, and suppression of subsequent failures', async () => {
  for (const reason of [undefined, null, false, new Error('first')]) {
    const a = deferred(), b = deferred(); let called = 0, settled = false;
    const result = runPool([() => a.promise, () => b.promise, () => called++]);
    const observed = result.then(() => assert.fail('must reject'), error => {
      settled = true; assert.equal(error, reason);
    });
    a.reject(reason); await tick();
    assert.equal(settled, false); assert.equal(called, 0);
    b.reject(new Error('later')); await observed;
    assert.equal(called, 0);
    await runPool([() => { throw reason; }, () => called++]).then(
      () => assert.fail('must reject'), error => assert.equal(error, reason));
    assert.equal(called, 0);
  }
});

test('abort stops scheduling and drains; first observed error wins', async () => {
  for (const failureFirst of [false, true]) {
    const controller = new AbortController(), a = deferred(), b = deferred();
    const failure = new Error('task'), abort = new Error('abort');
    let called = 0, settled = false;
    const observed = runPool([() => a.promise, () => b.promise, () => called++],
      {signal: controller.signal}).catch(error => {
        settled = true; assert.equal(error, failureFirst ? failure : abort);
      });
    if (failureFirst) { a.reject(failure); await tick(); }
    controller.abort(abort); await tick(); assert.equal(settled, false);
    if (!failureFirst) a.reject(failure);
    b.resolve(); await observed; assert.equal(called, 0);
  }
  const controller = new AbortController(); controller.abort();
  for (const tasks of [[], [() => assert.fail('already aborted')]])
    await assert.rejects(runPool(tasks, {signal: controller.signal}),
      error => error === controller.signal.reason);
  const synchronous = new AbortController(); let called = false;
  await assert.rejects(runPool([() => { synchronous.abort(); return 1; },
    () => { called = true; }], {signal: synchronous.signal}));
  assert.equal(called, false);
});

test('all validation precedes any invocation', async () => {
  let calls = 0; const task = () => calls++;
  for (const tasks of [null, {}, 'tasks', [task, null], [task, ,]])
    await assert.rejects(runPool(tasks), TypeError);
  for (const concurrency of [0, -1, 1.5, NaN, Infinity, '2', null])
    await assert.rejects(runPool([task], {concurrency}), TypeError);
  for (const signal of [null, {}, {aborted: false}])
    await assert.rejects(runPool([task], {signal}), TypeError);
  await assert.rejects(runPool([task], null), TypeError);
  assert.equal(calls, 0);
});
