export async function runPool(tasks, {concurrency = 2, signal} = {}) {
  if (!Array.isArray(tasks) || !Number.isInteger(concurrency) || concurrency <= 0)
    throw new TypeError('Expected tasks and a positive integer concurrency');
  for (const task of tasks)
    if (typeof task !== 'function') throw new TypeError('Tasks must be functions');
  if (signal !== undefined && !(signal instanceof AbortSignal))
    throw new TypeError('Expected an AbortSignal');
  return new Promise((resolve, reject) => {
    const results = new Array(tasks.length);
    let next = 0, active = 0, stopped = false, firstError;
    const stop = error => {
      if (!stopped) { stopped = true; firstError = error; }
    };
    const onAbort = () => { stop(signal.reason); pump(); };
    const finish = () => {
      signal?.removeEventListener('abort', onAbort);
      if (stopped) reject(firstError);
      else resolve(results);
    };
    const settle = () => { active--; pump(); };
    function pump() {
      while (!stopped && active < concurrency && next < tasks.length) {
        const index = next++;
        active++;
        let value;
        try { value = tasks[index](); }
        catch (error) { stop(error); active--; break; }
        Promise.resolve(value).then(
          result => { results[index] = result; settle(); },
          error => { stop(error); settle(); }
        );
      }
      if (active === 0 && (stopped || next === tasks.length)) finish();
    }
    if (signal?.aborted) stop(signal.reason);
    else signal?.addEventListener('abort', onAbort, {once: true});
    pump();
  });
}
