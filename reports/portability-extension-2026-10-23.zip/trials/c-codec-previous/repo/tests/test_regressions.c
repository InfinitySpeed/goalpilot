#include "codec.h"
#include <assert.h>
#include <stdint.h>
#include <string.h>

typedef int (*codec)(const unsigned char *, size_t, unsigned char *, size_t, size_t *);
static void failure(codec f, const unsigned char *s, size_t n, size_t cap,
                    int null_dst, int null_written)
{
    unsigned char dst[2048], before[2048];
    size_t written = 12345;
    memset(dst, 0xa5, sizeof dst);
    memcpy(before, dst, sizeof dst);
    assert(f(s, n, null_dst ? NULL : dst, cap,
             null_written ? NULL : &written) == -1);
    assert(written == 12345);
    assert(memcmp(dst, before, sizeof dst) == 0);
}
int main(void)
{
    unsigned char src[1024], encoded[2048], decoded[1024];
    size_t e, d;
    /* Arbitrary byte values, exact capacities, long runs, and repeated reuse. */
    for (size_t pattern = 0; pattern < 3; ++pattern) {
        for (size_t i = 0; i < sizeof src; ++i)
            src[i] = pattern == 0 ? (unsigned char)i :
                     pattern == 1 ? 0xff : (unsigned char)(i / 256);
        assert(codec_encode(src, sizeof src, encoded, sizeof encoded, &e) == 0);
        assert(e <= sizeof encoded && e % 2 == 0);
        for (size_t i = 0; i < e; i += 2) assert(encoded[i] != 0);
        assert(codec_decode(encoded, e, decoded, sizeof decoded, &d) == 0);
        assert(d == sizeof src && memcmp(src, decoded, d) == 0);
        failure(codec_encode, src, sizeof src, e - 1, 0, 0);
        failure(codec_decode, encoded, e, d - 1, 0, 0);
    }
    memset(src, 7, sizeof src);
    const size_t lengths[] = {1, 254, 255, 256, 510, 511};
    for (size_t k = 0; k < sizeof lengths / sizeof *lengths; ++k) {
        size_t n = lengths[k];
        assert(codec_encode(src, n, encoded, 2 * ((n + 254) / 255), &e) == 0);
        assert(e == 2 * ((n + 254) / 255));
        for (size_t i = 0; i < e; i += 2) {
            assert(encoded[i] == (n > 255 ? 255 : n));
            assert(encoded[i + 1] == 7);
            n -= encoded[i];
        }
    }
    const unsigned char bad[] = {1, 8, 0, 9};
    failure(codec_decode, bad, sizeof bad, sizeof decoded, 0, 0);
    failure(codec_decode, bad, 3, sizeof decoded, 0, 0);
    failure(codec_decode, bad, SIZE_MAX, sizeof decoded, 0, 0);
    for (size_t k = 0; k < 2; ++k) {
        codec f = k ? codec_decode : codec_encode;
        const unsigned char valid[] = {1, 8};
        failure(f, NULL, 2, sizeof decoded, 0, 0);
        failure(f, valid, 2, sizeof decoded, 1, 0);
        failure(f, valid, 2, sizeof decoded, 0, 1);
        failure(f, NULL, 0, 0, 1, 1);
        d = 42;
        assert(f(NULL, 0, NULL, 0, &d) == 0 && d == 0);
        memset(decoded, 0xa5, sizeof decoded);
        d = 42;
        assert(f(NULL, 0, decoded, SIZE_MAX, &d) == 0 && d == 0);
        for (size_t i = 0; i < sizeof decoded; ++i) assert(decoded[i] == 0xa5);
    }
    return 0;
}
