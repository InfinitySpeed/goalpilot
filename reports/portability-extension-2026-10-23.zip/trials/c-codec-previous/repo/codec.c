#include "codec.h"
#include <stdint.h>

int codec_encode(const unsigned char *s, size_t n, unsigned char *d,
                 size_t c, size_t *w)
{
    size_t i = 0, required = 0, out = 0;
    if (!w || (n && !s)) return -1;
    while (i < n) {
        size_t run = 1;
        while (run < 255 && run < n - i && s[i + run] == s[i]) ++run;
        if (required > SIZE_MAX - 2) return -1;
        required += 2;
        i += run;
    }
    if (required > c || (required && !d)) return -1;
    i = 0;
    while (i < n) {
        size_t run = 1;
        while (run < 255 && run < n - i && s[i + run] == s[i]) ++run;
        d[out++] = (unsigned char)run;
        d[out++] = s[i];
        i += run;
    }
    *w = required;
    return 0;
}

int codec_decode(const unsigned char *s, size_t n, unsigned char *d,
                 size_t c, size_t *w)
{
    size_t required = 0, out = 0;
    if (!w || (n && !s) || n % 2) return -1;
    for (size_t i = 0; i < n; i += 2) {
        size_t count = s[i];
        if (!count || required > SIZE_MAX - count) return -1;
        required += count;
    }
    if (required > c || (required && !d)) return -1;
    for (size_t i = 0; i < n; i += 2)
        for (size_t j = 0; j < s[i]; ++j) d[out++] = s[i + 1];
    *w = required;
    return 0;
}
