import javax.tools.ToolProvider;
import java.net.*;
import java.nio.file.*;
import java.util.*;
import java.math.BigInteger;
import java.lang.reflect.*;

class TestRangesRegression {
 static Class<?> ranges;
 @SuppressWarnings("unchecked")
 static <T> T call(String name, Object... args) throws Exception {
  Class<?>[] types = new Class<?>[args.length];
  Arrays.fill(types, List.class);
  try { return (T) ranges.getMethod(name, types).invoke(null, args); }
  catch (InvocationTargetException e) {
   if (e.getCause() instanceof IllegalArgumentException) throw (IllegalArgumentException)e.getCause();
   throw e;
  }
 }
 static List<long[]> list(long... v) {
  List<long[]> out = new ArrayList<>();
  for (int i=0;i<v.length;i+=2) out.add(new long[]{v[i],v[i+1]});
  return out;
 }
 static void equal(List<long[]> got, long... expected) {
  if (!Arrays.deepEquals(got.toArray(), list(expected).toArray())) throw new AssertionError(Arrays.deepToString(got.toArray()));
 }
 static void bad(String name, Object... args) throws Exception {
  try { call(name,args); } catch (IllegalArgumentException expected) { return; }
  throw new AssertionError("accepted invalid " + name);
 }
 static void check(boolean ok) { if (!ok) throw new AssertionError(); }
 static void run() throws Exception {
  List<long[]> a = list(8,12, 1,4, 3,6, 6,8, 20,20, -5,-2);
  List<long[]> b = list(9,11, 2,3, 3,5, -9,-3);
  long[][] beforeA = a.stream().map(long[]::clone).toArray(long[][]::new);
  long[][] beforeB = b.stream().map(long[]::clone).toArray(long[][]::new);
  List<long[]> normalized = call("normalize",a);
  equal(normalized,-5,-2,1,12);
  List<long[]> difference = call("subtract",a,b);
  equal(difference,-3,-2,1,2,5,9,11,12);
  check(call("length",difference).equals(BigInteger.valueOf(7)));
  check(Arrays.deepEquals(a.toArray(),beforeA) && Arrays.deepEquals(b.toArray(),beforeB));
  normalized.get(0)[0]=99; difference.get(0)[0]=99;
  check(Arrays.deepEquals(a.toArray(),beforeA) && Arrays.deepEquals(b.toArray(),beforeB));
  equal(call("normalize",a),-5,-2,1,12);
  equal(call("subtract",list(0,2,4,6,8,10),list(1,9)),0,1,9,10);
  equal(call("subtract",list(0,10),list(-1,11)));
  equal(call("subtract",list(0,10),list(-1,0,10,11)),0,10);
  equal(call("subtract",list(),list(0,1)));
  equal(call("subtract",list(0,1),list()),0,1);
  equal(call("normalize",list(1,1)));
  check(call("length",list()).equals(BigInteger.ZERO));
  check(call("length",list(Long.MIN_VALUE,0,0,Long.MAX_VALUE)).equals(new BigInteger("18446744073709551615")));
  equal(call("subtract",list(Long.MIN_VALUE,Long.MAX_VALUE),list(-1,1)),Long.MIN_VALUE,-1,1,Long.MAX_VALUE);
  List<List<long[]>> invalid = new ArrayList<>();
  invalid.add(null);
  invalid.add(Arrays.asList((long[])null));
  invalid.add(Collections.singletonList(new long[]{}));
  invalid.add(Collections.singletonList(new long[]{1}));
  invalid.add(Collections.singletonList(new long[]{1,2,3}));
  invalid.add(list(2,1));
  for (List<long[]> x : invalid) {
   bad("normalize",x); bad("length",x);
   bad("subtract",x,list()); bad("subtract",list(),x);
  }
  List<long[]> immutable = Collections.unmodifiableList(list(4,5,0,4));
  equal(call("normalize",immutable),0,5);
  // Exhaustive small-domain coverage checks union and difference against membership.
  for (int mask=0;mask<256;mask++) {
   List<long[]> x=list(), y=list();
   for(int i=0;i<4;i++) {
    if((mask & (1<<i))!=0) x.add(new long[]{i-2,i-1});
    if((mask & (16<<i))!=0) y.add(new long[]{i-2,i-1});
   }
   Collections.reverse(x);
   List<long[]> d=call("subtract",x,y);
   int count=0;
   for(int i=0;i<4;i++) {
    boolean expected=(mask&(1<<i))!=0 && (mask&(16<<i))==0;
    boolean actual=false;
    for(long[] r:d) if(r[0]<=i-2 && i-2<r[1]) actual=true;
    check(expected==actual); if(expected) count++;
   }
   check(call("length",d).equals(BigInteger.valueOf(count)));
  }
 }
 public static void main(String[] args) throws Exception {
  Path d=Files.createTempDirectory("ranges-regression");
  try {
   if(ToolProvider.getSystemJavaCompiler().run(null,null,null,"-d",d.toString(),"Ranges.java")!=0) throw new AssertionError();
   try(var loader=new URLClassLoader(new URL[]{d.toUri().toURL()})) { ranges=loader.loadClass("Ranges"); run(); }
  } finally {
   try(var paths=Files.walk(d)) { paths.sorted(Comparator.reverseOrder()).forEach(p->{try { Files.delete(p); } catch(Exception e) { throw new RuntimeException(e); }}); }
  }
 }
}
