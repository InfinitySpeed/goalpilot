import {test} from 'node:test';
import assert from 'node:assert/strict';
import {runPool} from '../pool.mjs';

function deferred() {
  let resolve, reject;
  const promise = new Promise((res, rej) => { resolve = res; reject = rej; });
  return {promise, resolve, reject};
}

// Flush promise reactions deterministically, without wall-clock delays.
async function flush() {
  for (let i = 0; i < 8; i++) await Promise.resolve();
}

test('limits lazy execution and preserves input ordering', async () => {
  const gates = Array.from({length: 5}, deferred);
  const started = [];
  let active = 0;
  let maximum = 0;
  const result = runPool(gates.map((gate, i) => () => {
    started.push(i);
    maximum = Math.max(maximum, ++active);
    return gate.promise.finally(() => { active--; });
  }), {concurrency: 2});
  assert.deepEqual(started, [0, 1]);
  gates[1].resolve('b');
  await flush();
  assert.deepEqual(started, [0, 1, 2]);
  gates[2].resolve('c');
  await flush();
  assert.deepEqual(started, [0, 1, 2, 3]);
  gates[0].resolve('a');
  await flush();
  assert.deepEqual(started, [0, 1, 2, 3, 4]);
  gates[4].resolve('e');
  gates[3].resolve('d');
  assert.deepEqual(await result, ['a', 'b', 'c', 'd', 'e']);
  assert.equal(maximum, 2);
});

test('defaults to two workers and accepts plain values and thenables', async () => {
  const gate = deferred();
  const started = [];
  const result = runPool([
    () => { started.push(0); return gate.promise; },
    () => { started.push(1); return 2; },
    () => { started.push(2); return {then(resolve) { resolve(3); }}; },
  ]);
  assert.deepEqual(started, [0, 1]);
  gate.resolve(1);
  assert.deepEqual(await result, [1, 2, 3]);
  assert.deepEqual(await runPool([]), []);
});

test('validates the entire input before invoking any task', async () => {
  let calls = 0;
  const task = () => { calls++; };
  for (const tasks of [null, {}, 'tasks', [task, 4], [task, , task]]) {
    await assert.rejects(runPool(tasks), TypeError);
  }
  for (const concurrency of [0, -1, 1.5, NaN, Infinity, '2', null, false]) {
    await assert.rejects(runPool([task], {concurrency}), TypeError);
  }
  for (const signal of [null, {}, true]) {
    await assert.rejects(runPool([task], {signal}), TypeError);
  }
  await assert.rejects(runPool([task], null), TypeError);
  assert.equal(calls, 0);
});

test('first rejection stops scheduling and waits for every started task', async () => {
  const gates = Array.from({length: 3}, deferred);
  const error = new Error('first');
  let calls = 0;
  let settled = false;
  const result = runPool([...gates.map(gate => () => { calls++; return gate.promise; }),
    () => { calls++; }], {concurrency: 3});
  const observed = result.then(() => { settled = true; }, reason => {
    settled = true;
    assert.equal(reason, error);
  });
  gates[1].reject(error);
  await flush();
  assert.equal(settled, false);
  assert.equal(calls, 3);
  gates[0].reject(new Error('later'));
  await flush();
  assert.equal(settled, false);
  gates[2].resolve();
  await observed;
  assert.equal(calls, 3);
});

for (const reason of [undefined, null, false, 0, new Error('sync')]) {
  test(`preserves synchronous failure identity: ${String(reason)}`, async () => {
    const gate = deferred();
    let calls = 0;
    let settled = false;
    const result = runPool([
      () => gate.promise,
      () => { throw reason; },
      () => { calls++; },
    ], {concurrency: 3});
    const observed = result.then(() => assert.fail('expected rejection'), error => {
      settled = true;
      assert.equal(error, reason);
    });
    await flush();
    assert.equal(settled, false);
    assert.equal(calls, 0);
    gate.reject(new Error('secondary failure'));
    await observed;
  });
}

test('already aborted signals prevent all work, including empty input', async () => {
  const controller = new AbortController();
  const error = new Error('aborted');
  controller.abort(error);
  let calls = 0;
  for (const tasks of [[], [() => { calls++; }]]) {
    await assert.rejects(runPool(tasks, {signal: controller.signal}), reason => reason === error);
  }
  assert.equal(calls, 0);
});

test('abort waits for started tasks and wins over later failures', async () => {
  const controller = new AbortController();
  const gates = [deferred(), deferred()];
  const reason = new Error('abort');
  let calls = 0;
  let settled = false;
  const result = runPool([...gates.map(gate => () => gate.promise), () => { calls++; }],
    {signal: controller.signal});
  const observed = result.catch(error => { settled = true; assert.equal(error, reason); });
  controller.abort(reason);
  gates[0].reject(new Error('later'));
  await flush();
  assert.equal(settled, false);
  assert.equal(calls, 0);
  gates[1].resolve();
  await observed;
});

test('a task failure wins over a subsequent abort', async () => {
  const controller = new AbortController();
  const gate = deferred();
  const error = new Error('task');
  const result = runPool([() => Promise.reject(error), () => gate.promise], {signal: controller.signal});
  const observed = assert.rejects(result, reason => reason === error);
  await flush();
  controller.abort(new Error('later abort'));
  gate.resolve();
  await observed;
});

test('abort inside a task stops further invocations and handles its returned rejection', async () => {
  const controller = new AbortController();
  const gate = deferred();
  const reason = new Error('abort in task');
  let calls = 0;
  const result = runPool([
    () => { controller.abort(reason); return gate.promise; },
    () => { calls++; },
  ], {signal: controller.signal});
  const observed = assert.rejects(result, error => error === reason);
  gate.reject(new Error('task failure'));
  await observed;
  assert.equal(calls, 0);
});

test('a concurrency limit of one runs tasks serially', async () => {
  const gates = [deferred(), deferred(), deferred()];
  const started = [];
  const result = runPool(gates.map((gate, i) => () => {
    started.push(i);
    return gate.promise;
  }), {concurrency: 1});
  assert.deepEqual(started, [0]);
  gates[0].resolve(0);
  await flush();
  assert.deepEqual(started, [0, 1]);
  gates[1].resolve(1);
  await flush();
  assert.deepEqual(started, [0, 1, 2]);
  gates[2].resolve(2);
  assert.deepEqual(await result, [0, 1, 2]);
});

test('preserves falsy promise rejection reasons and stops scheduling', async () => {
  for (const reason of [undefined, null, false, 0]) {
    let calls = 0;
    await runPool([
      () => Promise.reject(reason),
      () => { calls++; },
    ], {concurrency: 1}).then(
      () => assert.fail('expected rejection'),
      error => assert.equal(error, reason),
    );
    assert.equal(calls, 0);
  }
});
