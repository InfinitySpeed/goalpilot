export async function runPool(tasks, {concurrency = 2, signal} = {}) {
  if (!Array.isArray(tasks)) throw new TypeError('tasks must be an array of functions');
  const queue = Array.from(tasks);
  if (queue.some(task => typeof task !== 'function')) {
    throw new TypeError('tasks must be an array of functions');
  }
  if (!Number.isInteger(concurrency) || concurrency <= 0) {
    throw new TypeError('concurrency must be a positive integer');
  }
  if (signal !== undefined && !(signal instanceof AbortSignal)) {
    throw new TypeError('signal must be an AbortSignal');
  }

  return new Promise((resolve, reject) => {
    const results = new Array(queue.length);
    let next = 0;
    let active = 0;
    let stopped = false;
    let firstError;

    function stop(error) {
      if (!stopped) {
        stopped = true;
        firstError = error;
      }
    }

    function finish() {
      if (active !== 0 || (!stopped && next !== queue.length)) return;
      signal?.removeEventListener('abort', onAbort);
      if (stopped) reject(firstError);
      else resolve(results);
    }

    function onAbort() {
      stop(signal.reason);
      finish();
    }

    function schedule() {
      while (!stopped && active < concurrency && next < queue.length) {
        const index = next++;
        active++;
        let value;
        try {
          const task = queue[index];
          value = task();
        } catch (error) {
          stop(error);
          active--;
          break;
        }
        // Attach both handlers immediately, including after an abort inside a task.
        Promise.resolve(value).then(
          result => {
            results[index] = result;
            active--;
            schedule();
          },
          error => {
            stop(error);
            active--;
            finish();
          },
        );
      }
      finish();
    }

    signal?.addEventListener('abort', onAbort, {once: true});
    if (signal?.aborted) onAbort();
    else schedule();
  });
}
