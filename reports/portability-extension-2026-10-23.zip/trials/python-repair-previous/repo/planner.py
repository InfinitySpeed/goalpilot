"""Deterministic dependency planning."""
import heapq


def plan(graph):
    if not isinstance(graph, dict):
        raise ValueError("invalid graph")
    for node, dependencies in graph.items():
        if (not isinstance(node, str) or not node
                or not isinstance(dependencies, list)
                or any(not isinstance(dep, str) or not dep for dep in dependencies)):
            raise ValueError("invalid graph")

    deps = {node: set(values) for node, values in graph.items()}
    nodes = set(deps)
    for values in deps.values():
        nodes.update(values)
    for node in nodes:
        deps.setdefault(node, set())
    dependents = {node: set() for node in nodes}
    for node, values in deps.items():
        for dep in values:
            dependents[dep].add(node)
    counts = {node: len(values) for node, values in deps.items()}
    ready = [node for node in nodes if not counts[node]]
    heapq.heapify(ready)
    result = []
    while ready:
        node = heapq.heappop(ready)
        result.append(node)
        for dependent in dependents[node]:
            counts[dependent] -= 1
            if not counts[dependent]:
                heapq.heappush(ready, dependent)
    if len(result) == len(nodes):
        return result

    # Iterative Kosaraju finds actual cyclic components, even in deep graphs.
    seen, finished = set(), []
    for root in nodes:
        if root in seen:
            continue
        seen.add(root)
        stack = [(root, iter(deps[root]))]
        while stack:
            node, children = stack[-1]
            child = next(children, None)
            if child is None:
                finished.append(node)
                stack.pop()
            elif child not in seen:
                seen.add(child)
                stack.append((child, iter(deps[child])))
    seen, cyclic = set(), set()
    for root in reversed(finished):
        if root in seen:
            continue
        seen.add(root)
        component, stack = set(), [root]
        while stack:
            node = stack.pop()
            component.add(node)
            for child in dependents[node]:
                if child not in seen:
                    seen.add(child)
                    stack.append(child)
        if len(component) > 1 or root in deps[root]:
            cyclic.update(component)
    raise ValueError("cycle: " + ",".join(sorted(cyclic)))
