import copy
import unittest
from planner import plan


class PlannerRegressions(unittest.TestCase):
    def test_planning_journey(self):
        graph = {"z": ["b", "a", "a"], "b": ["c"], "d": []}
        before = copy.deepcopy(graph)
        self.assertEqual(plan(graph), ["a", "c", "b", "d", "z"])
        self.assertEqual(graph, before)
        self.assertEqual(plan(dict(reversed(list(graph.items())))), plan(graph))
        self.assertEqual(plan({"a": ["z"], "b": []}), ["b", "z", "a"])
        self.assertEqual(plan({}), [])

    def test_cycles_only_and_no_mutation(self):
        graphs = [
            ({"a": ["b"], "b": ["a"], "c": ["a"], "free": []}, "a,b"),
            ({"self": ["self", "self"], "tail": ["self"]}, "self"),
            ({"a": ["b"], "b": ["a"], "x": ["y"], "y": ["x"],
              "tail": ["a", "x"], "upstream": [], "z": ["z", "upstream"]}, "a,b,x,y,z"),
        ]
        for graph, names in graphs:
            with self.subTest(graph=graph):
                before = copy.deepcopy(graph)
                with self.assertRaises(ValueError) as error:
                    plan(graph)
                self.assertEqual(str(error.exception), "cycle: " + names)
                self.assertEqual(graph, before)

    def test_malformed_inputs(self):
        invalid = [None, [], (), "graph", 1, {1: []}, {"": []},
                   {"a": None}, {"a": "b"}, {"a": ("b",)},
                   {"a": {"b"}}, {"a": {"b": []}},
                   {"a": [""]}, {"a": [None]}, {"a": [1]},
                   {"a": [["b"]]}, {"a": [True]},
                   {"a": ["a"], "z": [None]}]
        for graph in invalid:
            with self.subTest(graph=graph):
                before = copy.deepcopy(graph)
                with self.assertRaises(ValueError):
                    plan(graph)
                self.assertEqual(graph, before)

    def test_deep_cycle_with_tail(self):
        graph = {str(i): [str(i + 1)] for i in range(1500)}
        graph["1500"] = ["1499"]
        with self.assertRaises(ValueError) as error:
            plan(graph)
        self.assertEqual(str(error.exception), "cycle: 1499,1500")
