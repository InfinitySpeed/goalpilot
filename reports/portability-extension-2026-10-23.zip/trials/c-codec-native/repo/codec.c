#include "codec.h"
#include <stdint.h>

int codec_encode(const unsigned char *src, size_t n, unsigned char *dst,
                 size_t capacity, size_t *written)
{
    size_t i = 0, needed = 0, out = 0;

    if (written == NULL || (n != 0 && (src == NULL || dst == NULL)))
        return -1;

    /* Validate the entire operation before touching either output. */
    while (i < n) {
        size_t run = 1;
        while (run < 255 && run < n - i && src[i + run] == src[i])
            ++run;
        if (needed > SIZE_MAX - 2)
            return -1;
        needed += 2;
        if (needed > capacity)
            return -1;
        i += run;
    }

    i = 0;
    while (i < n) {
        size_t run = 1;
        while (run < 255 && run < n - i && src[i + run] == src[i])
            ++run;
        dst[out++] = (unsigned char)run;
        dst[out++] = src[i];
        i += run;
    }
    *written = needed;
    return 0;
}

int codec_decode(const unsigned char *src, size_t n, unsigned char *dst,
                 size_t capacity, size_t *written)
{
    size_t i, needed = 0, out = 0;

    if (written == NULL || (n != 0 && (src == NULL || dst == NULL)) || n % 2 != 0)
        return -1;

    for (i = 0; i < n; i += 2) {
        size_t count = src[i];
        if (count == 0 || needed > SIZE_MAX - count)
            return -1;
        needed += count;
        if (needed > capacity)
            return -1;
    }

    for (i = 0; i < n; i += 2) {
        size_t count = src[i];
        while (count-- != 0)
            dst[out++] = src[i + 1];
    }
    *written = needed;
    return 0;
}
