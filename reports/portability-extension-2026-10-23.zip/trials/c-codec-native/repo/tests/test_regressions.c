#include "codec.h"
#include <assert.h>
#include <stdint.h>
#include <string.h>

typedef int (*codec_fn)(const unsigned char *, size_t, unsigned char *,
                        size_t, size_t *);

static void failure(codec_fn fn, const unsigned char *src, size_t n,
                    size_t capacity)
{
    unsigned char dst[1024], before[1024];
    size_t written = 123;
    memset(dst, 0xa5, sizeof dst);
    memcpy(before, dst, sizeof dst);
    assert(fn(src, n, dst, capacity, &written) == -1);
    assert(written == 123);
    assert(memcmp(dst, before, sizeof dst) == 0);
}

static void pointers_and_empty(codec_fn fn)
{
    unsigned char src[] = {1, 42}, dst[] = {9, 8};
    size_t written = 123;
    assert(fn(NULL, 0, NULL, 0, &written) == 0 && written == 0);
    written = 123;
    assert(fn(src, 0, dst, SIZE_MAX, &written) == 0 && written == 0);
    assert(dst[0] == 9 && dst[1] == 8);
    failure(fn, NULL, 2, sizeof dst);
    written = 123;
    assert(fn(src, 2, NULL, SIZE_MAX, &written) == -1);
    assert(written == 123);
    assert(fn(src, 2, dst, sizeof dst, NULL) == -1);
    assert(dst[0] == 9 && dst[1] == 8);
    assert(fn(NULL, 0, NULL, 0, NULL) == -1);
}

int main(void)
{
    unsigned char src[1024], encoded[2049], decoded[1025];
    const unsigned char expected[] = {255, 0, 255, 0, 1, 0, 1, 255};
    const unsigned char malformed[] = {2, 7, 0, 8};
    const unsigned char pairs[] = {255, 0, 255, 255};
    size_t n, i, used, restored;

    pointers_and_empty(codec_encode);
    pointers_and_empty(codec_decode);

    memset(src, 0, 511);
    src[511] = 255;
    assert(codec_encode(src, 512, encoded, 8, &used) == 0);
    assert(used == sizeof expected && memcmp(encoded, expected, used) == 0);
    failure(codec_encode, src, 512, 7);
    failure(codec_decode, malformed, sizeof malformed, sizeof decoded);
    failure(codec_decode, pairs, 3, sizeof decoded);
    failure(codec_decode, pairs, sizeof pairs, 509);
    assert(codec_decode(pairs, sizeof pairs, decoded, 510, &used) == 0);
    assert(used == 510);
    for (i = 0; i < used; ++i)
        assert(decoded[i] == (i < 255 ? 0 : 255));

    /* Exercise every byte, run boundaries, exact capacity, and output tails. */
    for (n = 0; n <= sizeof src; ++n) {
        for (i = 0; i < n; ++i)
            src[i] = (unsigned char)(i / (n % 257 + 1));
        memset(encoded, 0xa5, sizeof encoded);
        assert(codec_encode(src, n, encoded, 2 * n, &used) == 0);
        assert(encoded[used] == 0xa5);
        memset(decoded, 0xa5, sizeof decoded);
        assert(codec_decode(encoded, used, decoded, n, &restored) == 0);
        assert(restored == n && memcmp(src, decoded, n) == 0);
        assert(decoded[n] == 0xa5);
        if (n != 0) {
            failure(codec_encode, src, n, used - 1);
            failure(codec_decode, encoded, used, n - 1);
        }
    }
    for (i = 0; i < 256; ++i)
        src[i] = (unsigned char)i;
    assert(codec_encode(src, 256, encoded, 512, &used) == 0 && used == 512);
    for (i = 0; i < 256; ++i) {
        assert(encoded[2 * i] == 1);
        assert(encoded[2 * i + 1] == (unsigned char)i);
    }
    return 0;
}
