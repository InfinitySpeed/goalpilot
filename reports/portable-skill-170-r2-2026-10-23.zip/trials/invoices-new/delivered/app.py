from goalpilot_runtime import ReplayService, fields, text, integer, sequence, require, get_record, compare_revision, idempotent

def banner():return 'Local Ops — café'

positive=lambda x:integer(x,1)
line=lambda x:fields(x,{'description':text,'quantity':positive,'unit_cents':integer})
payment=lambda x:fields(x,{'id':text,'amount':positive,'key':text})

class Service(ReplayService):
 def initial(self):return {'customers':{},'invoices':{},'keys':{}}
 def handle(self,s,op,d):
  schemas={
   'customer.put':{'id':text,'name':text},'customer.list':{},
   'invoice.create':{'id':text,'customer':text,'lines':sequence(line,nonempty=True),'tax_bps':lambda x:integer(x,0,10000)},
   'invoice.issue':{'id':text,'expected_revision':positive},'invoice.void':{'id':text,'expected_revision':positive},
   'invoice.pay':{'id':text,'amount':positive,'key':text},'invoice.credit':{'id':text,'amount':positive,'key':text},
   'invoice.get':{'id':text},'invoice.list':{},'payment.import':{'payments':sequence(payment)},'statement':{'customer':text}}
  require(op in schemas,'Unknown operation')
  fields(d,schemas[op],optional={'customer':text,'status':text} if op=='invoice.list' else None)
  customers,invoices=s['customers'],s['invoices']
  if op=='customer.put':
   customers[d['id']]=dict(d);return customers[d['id']]
  if op=='customer.list':return [customers[k] for k in sorted(customers)]
  if op=='invoice.create':
   require(d['id'] not in invoices,'Duplicate invoice');get_record(customers,d['customer'])
   subtotal=sum(l['quantity']*l['unit_cents'] for l in d['lines']);tax=(subtotal*d['tax_bps']+5000)//10000
   r={**d,'status':'draft','subtotal':subtotal,'tax':tax,'total':subtotal+tax,'paid':0,'credited':0,'balance':subtotal+tax,'revision':1}
   invoices[d['id']]=r;return r
  if op=='invoice.list':
   if 'customer' in d:get_record(customers,d['customer'])
   if 'status' in d:require(d['status'] in ('draft','issued','partial','paid','credited','void'))
   return [invoices[k] for k in sorted(invoices) if all(invoices[k][f]==v for f,v in d.items())]
  if op=='statement':
   get_record(customers,d['customer']);rows=[r for r in invoices.values() if r['customer']==d['customer']]
   return {'invoiced':sum(r['total'] for r in rows if r['status']!='void'),'paid':sum(r['paid'] for r in rows),'credited':sum(r['credited'] for r in rows),'due':sum(r['balance'] for r in rows)}
  if op=='payment.import':
   for p in d['payments']:self.handle(s,'invoice.pay',p)
   return {'imported':len(d['payments'])}
  r=get_record(invoices,d['id'])
  if op=='invoice.get':return r
  if op in ('invoice.issue','invoice.void'):
   compare_revision(r,d['expected_revision'])
   if op=='invoice.issue':require(r['status']=='draft');r['status']='issued'
   else:
    require(r['status'] in ('draft','issued') and r['paid']==r['credited']==0);r['status']='void';r['balance']=0
   r['revision']+=1;return r
  def apply():
   credit=op=='invoice.credit'
   require(r['status'] in (('issued','partial','paid') if credit else ('issued','partial')))
   require(d['amount']<=r['balance'],'Amount exceeds balance')
   r['credited' if credit else 'paid']+=d['amount'];r['balance']=r['total']-r['paid']-r['credited']
   r['status']=('credited' if r['paid']==0 else 'paid') if r['balance']==0 else 'partial'
   r['revision']+=1;return r
  return idempotent(s,d['key'],op,d,apply)

if __name__=='__main__':Service.main()
