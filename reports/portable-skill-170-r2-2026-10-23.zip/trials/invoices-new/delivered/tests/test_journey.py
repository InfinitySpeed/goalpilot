import unittest
from app import Service
from goalpilot_support import JourneyMixin,rejects

class Business(JourneyMixin,unittest.TestCase):
 def setUp(self):self.open_service(Service)
 def test_journey(self):
  def flow(c):
   c('customer.put',id='c',name='Café');c('customer.put',id='other',name='Autre')
   self.assertEqual([x['id'] for x in c('customer.list')],['c','other'])
   draft=c('invoice.create',id='i',customer='c',lines=[{'description':'été','quantity':3,'unit_cents':101}],tax_bps=5000)
   self.assertEqual((draft['subtotal'],draft['tax'],draft['total']),(303,152,455))
   rejects(lambda:c('invoice.pay',id='i',amount=1,key='draft'))
   rejects(lambda:c('invoice.issue',id='i',expected_revision=2))
   c('invoice.issue',id='i',expected_revision=1)
   first=c('invoice.pay',id='i',amount=100,key='p')
   c('invoice.credit',id='i',amount=55,key='cr')
   self.assertEqual(c('invoice.pay',id='i',amount=100,key='p'),first)
   rejects(lambda:c('invoice.credit',id='i',amount=100,key='p'))
   rejects(lambda:c('payment.import',payments=[{'id':'i','amount':200,'key':'batch'},{'id':'i','amount':101,'key':'bad'}]))
   self.assertEqual(c('invoice.get',id='i')['balance'],300)
   self.assertEqual(c('payment.import',payments=[{'id':'i','amount':200,'key':'batch'},{'id':'i','amount':100,'key':'end'}]),{'imported':2})
   self.assertEqual(c('invoice.get',id='i')['status'],'paid')
   self.assertEqual(c('statement',customer='c'),{'invoiced':455,'paid':400,'credited':55,'due':0})
   snap=c('backup');c('customer.put',id='temp',name='Temp');c('restore',state=snap)
   self.assertEqual(len(c('customer.list')),2)
   for ident in ('v','cr'):
    c('invoice.create',id=ident,customer='c',lines=[{'description':'x','quantity':1,'unit_cents':50}],tax_bps=0)
    c('invoice.issue',id=ident,expected_revision=1)
   c('invoice.void',id='v',expected_revision=2)
   self.assertEqual(c('invoice.credit',id='cr',amount=50,key='full')['status'],'credited')
   for ident in ('v','cr'):rejects(lambda:c('invoice.pay',id=ident,amount=1,key=ident))
   self.assertEqual([r['id'] for r in c('invoice.list',customer='c',status='paid')],['i'])
  self.assertJourney(flow)
 def test_guards_and_restore(self):
  self.c('customer.put',id='c',name='é')
  for value in (True,1.5,'1',-1):
   self.assertRejects('invoice.create',id='bad',customer='c',lines=[{'description':'x','quantity':value,'unit_cents':1}],tax_bps=0)
  self.c('invoice.create',id='i',customer='c',lines=[{'description':'x','quantity':1,'unit_cents':100}],tax_bps=0)
  self.c('invoice.issue',id='i',expected_revision=1)
  self.assertRejects('invoice.pay',id='i',amount=101,key='x')
  snapshot=self.c('backup');snapshot['state']['invoices']['i']['total']=2
  self.assertRejects('restore',state=snapshot)
  self.restart();self.assertEqual(self.c('invoice.get',id='i')['total'],100)
  r=self.c('invoice.get',id='i');r['lines'][0]['quantity']=999
  self.assertEqual(self.c('invoice.get',id='i')['lines'][0]['quantity'],1)
  outcomes=self.race(*[('invoice.pay',{'id':'i','amount':60,'key':k}) for k in ('a','b')])
  self.assertEqual(sum(ok for ok,_ in outcomes),1)
  self.restart();self.assertEqual(self.c('invoice.get',id='i')['balance'],40)
