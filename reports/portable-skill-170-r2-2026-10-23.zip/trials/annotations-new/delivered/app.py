from goalpilot_runtime import ReplayService, fields, text, integer, boolean, identifiers, require, get_record
import json

def banner():return 'Local Ops — café'
def positive(x):return integer(x,1)
def payload(x):
 def check(v):
  require(v is None or type(v) in (str,bool,int,float,list,dict))
  if isinstance(v,list):
   for a in v:check(a)
  if isinstance(v,dict):
   for k,a in v.items():require(isinstance(k,str));check(a)
 check(x)
 try:json.dumps(x,allow_nan=False)
 except (ValueError,TypeError):raise ValueError('Invalid JSON')
 return x

class Service(ReplayService):
 def initial(self):return {'datasets':{},'annotators':{}}
 def handle(self,s,op,d):
  schemas={
   'dataset.create':{'id':text,'labels':lambda x:identifiers(x,nonempty=True),'reviews':positive},
   'annotator.put':{'id':text,'active':boolean},
   'item.add':{'dataset':text,'id':text,'payload':payload},
   'item.import':{'dataset':text,'items':lambda x: self.import_rows(x)},
   'claim':{'dataset':text,'annotator':text,'now':integer,'lease':positive},
   'submit':{'dataset':text,'item':text,'annotator':text,'receipt':text,'now':integer,'label':text},
   'item.reopen':{'dataset':text,'id':text,'expected_revision':positive},
   'item.get':{'dataset':text,'id':text},'item.list':{'dataset':text},
   'history':{'dataset':text,'id':text},'report':{'dataset':text}}
  require(op in schemas,'Unknown operation')
  fields(d,schemas[op],optional={'status':lambda x:require(x in ('pending','reviewing','complete'))} if op=='item.list' else None)
  if op=='dataset.create':
   require(d['id'] not in s['datasets'],'Dataset exists')
   s['datasets'][d['id']]={'labels':identifiers(d['labels'],nonempty=True),'reviews':d['reviews'],'items':{}}
   return s['datasets'][d['id']]
  if op=='annotator.put':
   s['annotators'][d['id']]={'id':d['id'],'active':d['active']};return s['annotators'][d['id']]
  ds=get_record(s['datasets'],d['dataset']);items=ds['items']
  if op in ('item.add','item.import'):
   rows=[{'id':d['id'],'payload':d['payload']}] if op=='item.add' else d['items']
   require(len({r['id'] for r in rows})==len(rows),'Duplicate IDs')
   require(all(r['id'] not in items for r in rows),'Item exists')
   for r in rows:
    items[r['id']]={'view':{'id':r['id'],'dataset':d['dataset'],'payload':r['payload'],'status':'pending','votes':[],'revision':1,'consensus':None},'claims':{},'history':[]}
   return items[d['id']]['view'] if op=='item.add' else {'imported':len(rows)}
  if op=='item.list':return [items[k]['view'] for k in sorted(items) if 'status' not in d or items[k]['view']['status']==d['status']]
  if op=='report':
   out=dict.fromkeys(('pending','reviewing','complete','disputed'),0)
   for r in items.values():
    v=r['view'];out[v['status']]+=1
    if v['status']=='complete' and v['consensus'] is None:out['disputed']+=1
   return out
  if op in ('claim','submit'):
   actor=get_record(s['annotators'],d['annotator']);require(actor['active'],'Inactive annotator')
  if op=='claim':
   for k in sorted(items):
    r=items[k];v=r['view'];live={a:c for a,c in r['claims'].items() if c['expires']>d['now']}
    if v['status']=='complete' or any(t['annotator']==d['annotator'] for t in v['votes']) or d['annotator'] in live or len(v['votes'])+len(live)>=ds['reviews']:continue
    c={'receipt':self.opaque(),'expires':d['now']+d['lease']};live[d['annotator']]=c;r['claims']=live
    return {'item':v,'receipt':c['receipt'],'expires':c['expires']}
   return None
  r=get_record(items,d['item'] if op=='submit' else d['id']);v=r['view']
  if op=='item.get':return v
  if op=='history':return r['history']
  if op=='item.reopen':
   require(v['status']=='complete' and v['revision']==d['expected_revision'],'Revision or status conflict')
   r['history'].append({'votes':v['votes'],'consensus':v['consensus']});r['claims']={}
   v.update(votes=[],consensus=None,status='pending',revision=v['revision']+1);return v
  require(d['label'] in ds['labels'],'Unknown label')
  c=r['claims'].get(d['annotator']);require(c is not None and c['receipt']==d['receipt'] and d['now']<c['expires'],'Invalid lease')
  require(v['status']!='complete' and len(v['votes'])<ds['reviews'] and all(t['annotator']!=d['annotator'] for t in v['votes']),'Already voted')
  v['votes'].append({'annotator':d['annotator'],'label':d['label']});v['revision']+=1;del r['claims'][d['annotator']]
  v['status']='complete' if len(v['votes'])==ds['reviews'] else 'reviewing'
  if v['status']=='complete':v['consensus']=v['votes'][0]['label'] if len({t['label'] for t in v['votes']})==1 else None
  return v
 def import_rows(self,x):
  require(isinstance(x,list))
  for r in x:fields(r,{'id':text,'payload':payload})
  return x

if __name__=='__main__':Service.main()
