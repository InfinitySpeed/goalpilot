import unittest
from app import Service
from goalpilot_support import JourneyMixin, rejects

class Annotation(JourneyMixin,unittest.TestCase):
 def setUp(self):self.open_service(Service)
 def test_journey(self):
  def flow(c):
   c('dataset.create',id='café',labels=['yes','no','yes'],reviews=2)
   for a in ['a','b','c']:c('annotator.put',id=a,active=True)
   original={'nested':['é']}
   v=c('item.add',dataset='café',id='x',payload=original)
   self.assertEqual(v,dict(id='x',dataset='café',payload=original,status='pending',votes=[],revision=1,consensus=None))
   rejects(lambda:c('item.import',dataset='café',items=[{'id':'y','payload':0},{'id':'x','payload':1}]))
   self.assertEqual(len(c('item.list',dataset='café')),1)
   a=c('claim',dataset='café',annotator='a',now=0,lease=2)
   b=c('claim',dataset='café',annotator='b',now=0,lease=10)
   self.assertIsNone(c('claim',dataset='café',annotator='c',now=1,lease=3))
   fresh=c('claim',dataset='café',annotator='a',now=2,lease=10)
   self.assertNotEqual(a['receipt'],fresh['receipt'])
   args=dict(dataset='café',item='x',annotator='a',now=3,label='yes')
   rejects(lambda:c('submit',receipt=a['receipt'],**args))
   c('annotator.put',id='a',active=False)
   rejects(lambda:c('submit',receipt=fresh['receipt'],**args))
   c('annotator.put',id='a',active=True)
   self.assertEqual(c('submit',receipt=fresh['receipt'],**args)['status'],'reviewing')
   done=c('submit',dataset='café',item='x',annotator='b',receipt=b['receipt'],now=3,label='no')
   self.assertEqual(done['revision'],3);self.assertIsNone(done['consensus'])
   self.assertEqual(c('report',dataset='café'),dict(pending=0,reviewing=0,complete=1,disputed=1))
   backup=c('backup')
   rejects(lambda:c('item.reopen',dataset='café',id='x',expected_revision=2))
   c('item.reopen',dataset='café',id='x',expected_revision=3)
   self.assertEqual(c('history',dataset='café',id='x'),[{'votes':done['votes'],'consensus':None}])
   for who in ['a','b']:
    claim=c('claim',dataset='café',annotator=who,now=20,lease=10)
    done2=c('submit',dataset='café',item='x',annotator=who,receipt=claim['receipt'],now=21,label='yes')
   self.assertEqual(done2['consensus'],'yes')
   c('restore',state=backup)
   self.assertEqual(c('item.get',dataset='café',id='x'),done)
   self.assertEqual(c('history',dataset='café',id='x'),[])
   self.assertEqual(c('item.import',dataset='café',items=[{'id':'z','payload':None},{'id':'a','payload':True}]),{'imported':2})
   self.assertEqual([i['id'] for i in c('item.list',dataset='café',status='pending')],['a','z'])
  self.assertJourney(flow)
 def test_guards_persistence_and_race(self):
  for bad in [True,1.5,'2',0]:self.assertRejects('dataset.create',id='d',labels=['x'],reviews=bad)
  self.c('dataset.create',id='d',labels=['x'],reviews=1)
  for a in ['a','b']:self.c('annotator.put',id=a,active=True)
  self.c('item.add',dataset='d',id='i',payload={})
  results=self.race(*[('claim',dict(dataset='d',annotator=a,now=0,lease=10)) for a in ['a','b']])
  self.assertEqual(sum(ok and value is not None for ok,value in results),1)
  self.restart()
  snap=self.c('backup');snap['state']['datasets']['d']['reviews']=10
  self.assertRejects('restore',state=snap)
  self.assertRejects('item.add',dataset='d',id='i',payload=2)
  view=self.c('item.get',dataset='d',id='i');view['payload']['oops']=1
  self.assertEqual(self.c('item.get',dataset='d',id='i')['payload'],{})
  self.c('annotator.put',id='a',active=False);self.restart()
  self.assertRejects('claim',dataset='d',annotator='a',now=11,lease=1)
