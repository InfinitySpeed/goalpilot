import unittest
from app import Service
from goalpilot_support import JourneyMixin, rejects


class Journeys(JourneyMixin, unittest.TestCase):
    def setUp(self): self.open_service(Service)

    def test_journey(self):
        def flow(c):
            for sid in ('z', 'a', 'm', 'x'):
                c('student.put', id=sid, name='Élève ' + sid)
            c('course.put', id='base', prerequisites=[], capacity=1, price=120)
            c('course.put', id='next', prerequisites=['base', 'base'], capacity=1, price=200)
            rejects(lambda: c('enroll', student='z', course='next', key='blocked'))
            a = c('enroll', student='z', course='base', key='z')
            b = c('enroll', student='a', course='base', key='a')
            m = c('enroll', student='m', course='base', key='m')
            self.assertEqual((a['status'], b['status']), ('enrolled', 'waiting'))
            self.assertEqual(c('course.report', id='base')['waitlist'], ['a', 'm'])
            rejects(lambda: c('complete', id=b['id'], score=90))
            rejects(lambda: c('enroll', student='z', course='base', key='different'))
            rejects(lambda: c('enroll', student='a', course='base', key='z'))
            rejects(lambda: c('course.put', id='base', prerequisites=['next'], capacity=1, price=5))
            rejects(lambda: c('course.put', id='base', prerequisites=[], capacity=0, price=5))
            for bad in (True, 1.5, '2', -1):
                rejects(lambda: c('course.put', id='bad', prerequisites=[], capacity=bad, price=0))
            c('course.put', id='base', prerequisites=[], capacity=1, price=999)
            for bad in (True, -1, 101, '60'):
                rejects(lambda: c('complete', id=a['id'], score=bad))
            c('complete', id=a['id'], score=60)
            self.assertEqual(c('enrollment.get', id=b['id'])['status'], 'enrolled')
            self.assertEqual(c('enroll', student='z', course='base', key='z'), a)
            n = c('enroll', student='z', course='next', key='next')
            self.assertEqual(c('cancel', id=n['id'])['refund'], 200)
            self.assertEqual(c('cancel', id=n['id'])['refund'], 200)
            c('enroll', student='z', course='next', key='next2')
            c('complete', id=b['id'], score=59)
            rejects(lambda: c('enroll', student='a', course='next', key='fail'))
            self.assertEqual(c('enrollment.get', id=m['id'])['price'], 120)
            w = c('enroll', student='x', course='base', key='x')
            self.assertEqual(c('cancel', id=w['id'])['refund'], 0)
            self.assertEqual(c('cancel', id=m['id'])['refund'], 120)
            report = c('course.report', id='base')
            self.assertEqual(report, dict(enrolled=0, waiting=0, completed=2, cancelled=2, revenue=240, waitlist=[]))
            before = c('backup')
            rejects(lambda: c('enroll.import', requests=[dict(student='m', course='base', key='fresh'), dict(student='missing', course='base', key='oops')]))
            self.assertEqual(c('backup'), before)
            self.assertEqual(c('enroll.import', requests=[dict(student='m', course='base', key='fresh'), dict(student='x', course='base', key='fresh2')]), {'imported': 2})
            self.assertEqual([e['student'] for e in c('enrollment.list', course='base')][-2:], ['m', 'x'])
            c('restore', state=before)
            self.assertEqual(c('backup'), before)
            self.assertEqual(c('enrollment.list', student='x'), [c('enrollment.get', id=w['id'])])
            rejects(lambda: c('cancel', id=a['id']))
            rejects(lambda: c('complete', id=m['id'], score=70))
            c('enroll', student='m', course='base', key='after-restore')
        self.assertJourney(flow)

    def test_atomic_restore_and_snapshots(self):
        self.c('student.put', id='s', name='Original')
        d = dict(id='c', prerequisites=[], capacity=1, price=10)
        self.c('course.put', **d)
        self.assertEqual(d['prerequisites'], [])
        self.c('enroll', student='s', course='c', key='k')
        backup = self.c('backup')
        self.assertCorruptions(lambda b: b['state']['courses']['c'].update(capacity=0),
                               lambda b: b['state']['enrollments'].clear(),
                               lambda b: b['state']['keys'].clear(),
                               lambda b: b['state']['courses']['c'].update(prerequisites=['c']))
        self.assertRejects('restore', state={})
        backup['state']['students']['s']['name'] = 'Changed'
        self.assertEqual(self.c('backup')['state']['students']['s']['name'], 'Original')
        self.restart()
        self.assertEqual(self.c('course.report', id='c')['enrolled'], 1)

    def test_concurrency(self):
        self.c('course.put', id='c', prerequisites=[], capacity=1, price=10)
        for sid in ('a', 'b', 'c'): self.c('student.put', id=sid, name=sid)
        outcomes = self.race(*[('enroll', dict(student=sid, course='c', key=sid)) for sid in ('a', 'b', 'c')])
        self.assertTrue(all(ok for ok, result in outcomes))
        self.assertEqual(self.c('course.report', id='c'), dict(enrolled=1, waiting=2, completed=0, cancelled=0, revenue=10, waitlist=[e['student'] for e in self.c('enrollment.list') if e['status'] == 'waiting']))
