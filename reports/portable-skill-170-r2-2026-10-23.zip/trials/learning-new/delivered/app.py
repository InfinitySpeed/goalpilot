from goalpilot_runtime import ReplayService, fields, text, integer, identifiers, get_record, dag, require, idempotent


def banner(): return 'Local Ops — café'


class Service(ReplayService):
    def initial(self):
        return {'students': {}, 'courses': {}, 'enrollments': {}, 'keys': {}}

    def handle(self, s, op, d):
        students, courses, rows = s['students'], s['courses'], s['enrollments']
        def record(table, key): return get_record(table, key)
        def passed(student):
            return {e['course'] for e in rows.values() if e['student'] == student and e['status'] == 'completed' and e['score'] >= 60}
        def eligible(student, course): return set(courses[course]['prerequisites']) <= passed(student)
        def count(course): return sum(e['course'] == course and e['status'] == 'enrolled' for e in rows.values())
        def promote(course):
            for e in rows.values():
                if count(course) >= courses[course]['capacity']: break
                if e['course'] == course and e['status'] == 'waiting' and eligible(e['student'], course): e['status'] = 'enrolled'
        if op == 'student.put':
            fields(d, {'id': text, 'name': text})
            students[d['id']] = dict(d)
            return students[d['id']]
        if op == 'course.put':
            fields(d, {'id': text, 'prerequisites': identifiers, 'capacity': integer, 'price': integer})
            deps = identifiers(d['prerequisites'])
            for dep in deps: record(courses, dep)
            graph = {k: v['prerequisites'] for k, v in courses.items()}
            graph[d['id']] = deps
            dag(graph)
            require(d['capacity'] >= count(d['id']), 'Capacity below enrollment')
            courses[d['id']] = dict(d, prerequisites=deps)
            promote(d['id'])
            return courses[d['id']]
        if op == 'enroll':
            fields(d, {'student': text, 'course': text, 'key': text})
            def create():
                record(students, d['student']); course = record(courses, d['course'])
                require(eligible(d['student'], d['course']), 'Prerequisites incomplete')
                require(not any(e['student'] == d['student'] and e['course'] == d['course'] and e['status'] != 'cancelled' for e in rows.values()), 'Already registered')
                e = dict(id=self.opaque(), student=d['student'], course=d['course'], status='enrolled' if count(d['course']) < course['capacity'] else 'waiting', price=course['price'], score=None)
                rows[e['id']] = e
                return e
            return idempotent(s, d['key'], op, dict(d), create)
        if op == 'enroll.import':
            fields(d, {'requests': lambda x: require(isinstance(x, list), 'Expected requests list')})
            for request in d['requests']: self.handle(s, 'enroll', request)
            return {'imported': len(d['requests'])}
        if op == 'enrollment.get':
            fields(d, {'id': text})
            return record(rows, d['id'])
        if op == 'enrollment.list':
            fields(d, {}, {'course': text, 'student': text})
            if 'course' in d: record(courses, d['course'])
            if 'student' in d: record(students, d['student'])
            return [e for e in rows.values() if all(e[k] == v for k, v in d.items())]
        if op == 'complete':
            fields(d, {'id': text, 'score': lambda x: integer(x, 0, 100)})
            e = record(rows, d['id'])
            require(e['status'] == 'enrolled', 'Must be enrolled')
            e.update(status='completed', score=d['score'])
            promote(e['course'])
            return e
        if op == 'cancel':
            fields(d, {'id': text})
            e = record(rows, d['id'])
            if e['status'] == 'cancelled': return {'id': e['id'], 'status': 'cancelled', 'refund': e['refund']}
            require(e['status'] in ('waiting', 'enrolled'), 'Cannot cancel completed enrollment')
            refund = e['price'] if e['status'] == 'enrolled' else 0
            e.update(status='cancelled', refund=refund)
            promote(e['course'])
            return {'id': e['id'], 'status': 'cancelled', 'refund': refund}
        if op == 'course.report':
            fields(d, {'id': text}); record(courses, d['id'])
            selected = [e for e in rows.values() if e['course'] == d['id']]
            result = {status: sum(e['status'] == status for e in selected) for status in ('enrolled', 'waiting', 'completed', 'cancelled')}
            result.update(revenue=sum(e['price'] for e in selected if e['status'] in ('enrolled', 'completed')), waitlist=[e['student'] for e in selected if e['status'] == 'waiting'])
            return result
        raise ValueError('Unknown operation')


if __name__ == '__main__': Service.main()
