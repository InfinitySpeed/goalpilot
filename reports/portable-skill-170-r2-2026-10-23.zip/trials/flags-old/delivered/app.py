import hashlib
from goalpilot_runtime import ReplayService, fields, text, boolean, integer, identifiers, sequence, nullable, require, get_record


def banner():
    return 'Local Ops — café'


def rule(value):
    return fields(value, {'segment': nullable(text), 'percent': lambda x: integer(x, 0, 100), 'value': boolean})


def imported(value):
    return fields(value, {'id': text, 'default': boolean})


class Service(ReplayService):
    def initial(self):
        return {'environments': {}}

    def handle(self, state, op, data):
        schemas = {
            'environment.create': {'id': text},
            'segment.put': {'environment': text, 'id': text, 'members': identifiers},
            'segment.delete': {'environment': text, 'id': text},
            'flag.create': {'environment': text, 'id': text, 'default': boolean},
            'flag.import': {'environment': text, 'flags': sequence(imported)},
            'flag.update': {'environment': text, 'id': text, 'expected_revision': lambda x: integer(x, 1), 'enabled': boolean, 'rules': sequence(rule)},
            'flag.publish': {'environment': text, 'id': text, 'expected_revision': lambda x: integer(x, 1)},
            'flag.rollback': {'environment': text, 'id': text, 'revision': lambda x: integer(x, 1), 'expected_revision': lambda x: integer(x, 1)},
            'flag.evaluate': {'environment': text, 'id': text, 'user': text},
            'flag.get': {'environment': text, 'id': text},
            'flag.list': {'environment': text},
            'audit.list': {'environment': text},
        }
        require(op in schemas, 'Unknown operation')
        fields(data, schemas[op])
        envs = state['environments']
        if op == 'environment.create':
            require(data['id'] not in envs, 'Environment exists')
            envs[data['id']] = {'segments': {}, 'flags': {}, 'audit': []}
            return {'id': data['id']}
        env = get_record(envs, data['environment'])
        flags, segments = env['flags'], env['segments']

        def event(kind, flag):
            env['audit'].append({'sequence': len(env['audit']) + 1, 'kind': kind,
                                 'flag': flag['id'], 'revision': flag['revision']})

        def create(item):
            require(item['id'] not in flags, 'Flag exists')
            draft = {'id': item['id'], 'environment': data['environment'], 'revision': 1,
                     'published': 0, 'enabled': False, 'default': item['default'], 'rules': []}
            flags[item['id']] = {'draft': draft, 'history': {}}
            event('flag.created', draft)
            return draft

        if op == 'segment.put':
            members = identifiers(data['members'])
            segments[data['id']] = members
            return {'environment': data['environment'], 'id': data['id'], 'members': members}
        if op == 'segment.delete':
            get_record(segments, data['id'])
            for entry in flags.values():
                for snapshot in [entry['draft'], *entry['history'].values()]:
                    require(all(r['segment'] != data['id'] for r in snapshot['rules']), 'Segment referenced')
            del segments[data['id']]
            return {'deleted': data['id']}
        if op == 'flag.create':
            return create(data)
        if op == 'flag.import':
            ids = [item['id'] for item in data['flags']]
            require(len(set(ids)) == len(ids) and not any(i in flags for i in ids), 'Duplicate flag')
            for item in data['flags']:
                create(item)
            return {'imported': len(ids)}
        if op == 'flag.list':
            return sorted(flags)
        if op == 'audit.list':
            return env['audit']
        entry = get_record(flags, data['id'])
        draft, history = entry['draft'], entry['history']
        if op == 'flag.get':
            return draft
        if op == 'flag.evaluate':
            bucket = int.from_bytes(hashlib.sha256((data['environment'] + '|' + data['id'] + '|' + data['user']).encode('utf-8')).digest()[:8], 'big') % 100
            live = history.get(str(draft['published']))
            value = draft['default'] if live is None else live['default']
            if live is not None and live['enabled']:
                for r in live['rules']:
                    if (r['segment'] is None or data['user'] in segments[r['segment']]) and bucket < r['percent']:
                        value = r['value']
                        break
            return {'value': value, 'revision': draft['published'], 'bucket': bucket}
        require(data['expected_revision'] == draft['revision'], 'Stale revision')
        if op == 'flag.update':
            for r in data['rules']:
                if r['segment'] is not None:
                    get_record(segments, r['segment'])
            draft.update(enabled=data['enabled'], rules=data['rules'], revision=draft['revision'] + 1)
            event('flag.updated', draft)
        elif op == 'flag.publish':
            if draft['published'] != draft['revision']:
                draft['published'] = draft['revision']
                history[str(draft['revision'])] = dict(draft)
                event('flag.published', draft)
        elif op == 'flag.rollback':
            old = get_record(history, str(data['revision']))
            revision = draft['revision'] + 1
            draft = dict(old, revision=revision, published=revision)
            entry['draft'] = draft
            history[str(revision)] = dict(draft)
            event('flag.rolled_back', draft)
        return draft


if __name__ == '__main__':
    Service.main()
