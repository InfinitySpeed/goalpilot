import hashlib
import unittest
from app import Service
from goalpilot_support import JourneyMixin, rejects


class Flags(JourneyMixin, unittest.TestCase):
    def setUp(self):
        self.open_service(Service)

    def test_journey(self):
        def flow(c):
            for environment in ['prod', 'café']:
                c('environment.create', id=environment)
            def call(op, **data):
                return c(op, environment='prod', **data)
            call('segment.put', id='team', members=['zoé', 'zoé', 'alice'])
            f = call('flag.create', id='feature', default=False)
            self.assertEqual(f, dict(id='feature', environment='prod', revision=1, published=0, enabled=False, default=False, rules=[]))
            c('flag.create', environment='café', id='feature', default=True)
            self.assertTrue(c('flag.evaluate', environment='café', id='feature', user='zoé')['value'])
            rules = [dict(segment='team', percent=100, value=True), dict(segment=None, percent=100, value=False)]
            call('flag.update', id='feature', expected_revision=1, enabled=True, rules=rules)
            self.assertEqual(call('flag.evaluate', id='feature', user='zoé')['revision'], 0)
            call('flag.publish', id='feature', expected_revision=2)
            self.assertTrue(call('flag.evaluate', id='feature', user='zoé')['value'])
            self.assertFalse(call('flag.evaluate', id='feature', user='bob')['value'])
            call('flag.publish', id='feature', expected_revision=2)
            self.assertEqual(len(call('audit.list')), 3)
            call('flag.update', id='feature', expected_revision=2, enabled=False, rules=[])
            self.assertTrue(call('flag.evaluate', id='feature', user='zoé')['value'])
            call('segment.put', id='team', members=[])
            self.assertFalse(call('flag.evaluate', id='feature', user='zoé')['value'])
            call('segment.put', id='team', members=['zoé'])
            call('flag.publish', id='feature', expected_revision=3)
            self.assertFalse(call('flag.evaluate', id='feature', user='zoé')['value'])
            restored = call('flag.rollback', id='feature', revision=2, expected_revision=3)
            self.assertEqual((restored['revision'], restored['published']), (4, 4))
            self.assertTrue(call('flag.evaluate', id='feature', user='zoé')['value'])
            rejects(lambda: call('segment.delete', id='team'))
            rejects(lambda: call('flag.rollback', id='feature', revision=1, expected_revision=4))
            rejects(lambda: call('flag.update', id='feature', expected_revision=3, enabled=True, rules=[]))
            rejects(lambda: call('flag.update', id='feature', expected_revision=4, enabled=True, rules=[dict(segment='missing', percent=50, value=True)]))
            rejects(lambda: call('flag.import', flags=[dict(id='new', default=True), dict(id='feature', default=False)]))
            self.assertEqual(call('flag.list'), ['feature'])
            self.assertEqual(call('flag.import', flags=[dict(id='z', default=True), dict(id='a', default=False)]), {'imported': 2})
            self.assertEqual(call('flag.list'), ['a', 'feature', 'z'])
            call('segment.put', id='unused', members=[])
            call('segment.delete', id='unused')
            snapshot = c('backup')
            call('flag.update', id='feature', expected_revision=4, enabled=True, rules=[dict(segment=None, percent=37, value=True)])
            call('flag.publish', id='feature', expected_revision=5)
            for user in ['zoé', 'alice', 'bob', 'user|42']:
                bucket = int.from_bytes(hashlib.sha256(('prod|feature|' + user).encode()).digest()[:8], 'big') % 100
                self.assertEqual(call('flag.evaluate', id='feature', user=user), dict(value=bucket < 37, revision=5, bucket=bucket))
            c('restore', state=snapshot)
            self.assertEqual(call('flag.get', id='feature')['revision'], 4)
            self.assertEqual(c('flag.get', environment='café', id='feature')['default'], True)
            events = call('audit.list')
            self.assertEqual([e['sequence'] for e in events], list(range(1, len(events) + 1)))
            self.assertEqual([e['kind'] for e in events[:6]], ['flag.created', 'flag.updated', 'flag.published', 'flag.updated', 'flag.published', 'flag.rolled_back'])
        self.assertJourney(flow)

    def test_rejections_detachment_and_corruption(self):
        self.c('environment.create', id='prod')
        self.c('environment.create', id='dev')
        self.c('segment.put', environment='dev', id='private', members=['u'])
        self.c('flag.create', environment='prod', id='f', default=False)
        for percent in [True, 1.5, '50', -1, 101]:
            self.assertRejects('flag.update', environment='prod', id='f', expected_revision=1, enabled=True, rules=[dict(segment=None, percent=percent, value=True)])
        self.assertRejects('flag.update', environment='prod', id='f', expected_revision=True, enabled=True, rules=[])
        self.assertRejects('flag.update', environment='prod', id='f', expected_revision=1, enabled=True, rules=[dict(segment='private', percent=100, value=True)])
        self.assertRejects('flag.create', environment='prod', id='x', default=1)
        self.assertRejects('flag.get', environment='missing', id='f')
        self.assertRejects('unknown')
        request = dict(environment='prod', id='f', expected_revision=1, enabled=True, rules=[dict(segment=None, percent=100, value=True)])
        result = self.service.call('flag.update', request)
        result['rules'][0]['value'] = False
        self.assertTrue(request['rules'][0]['value'])
        request['rules'].clear()
        self.c('flag.publish', environment='prod', id='f', expected_revision=2)
        self.restart()
        self.assertTrue(self.c('flag.evaluate', environment='prod', id='f', user='u')['value'])
        self.assertCorruptions(lambda b: b['state']['environments']['prod']['flags']['f']['draft'].__setitem__('revision', 90),
                               lambda b: b['state']['environments']['prod']['audit'][0].__setitem__('sequence', 9),
                               lambda b: b['state']['environments']['prod']['flags']['f']['history']['2']['rules'][0].__setitem__('segment', 'private'))

    def test_concurrent_cas_and_creation(self):
        self.c('environment.create', id='e')
        self.c('flag.create', environment='e', id='f', default=False)
        update = ('flag.update', dict(environment='e', id='f', expected_revision=1, enabled=True, rules=[]))
        results = self.race(update, update)
        self.assertEqual(sum(ok for ok, _ in results), 1)
        results = self.race(*[('flag.create', dict(environment='e', id=str(i), default=True)) for i in range(4)])
        self.assertTrue(all(ok for ok, _ in results))
        self.assertEqual(self.c('flag.list', environment='e'), ['0', '1', '2', '3', 'f'])
        self.assertEqual(len(self.c('audit.list', environment='e')), 6)
