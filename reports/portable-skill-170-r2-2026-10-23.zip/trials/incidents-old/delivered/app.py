from goalpilot_runtime import ReplayService, fields, text, integer, identifiers, require, get_record, compare_revision
import copy


def banner():return 'Local Ops — café'

N = integer
P = lambda x: integer(x, minimum=1)
OPEN = {'id':text,'team':text,'policy':text,'now':N,'title':text,'key':text}
PUBLIC = ('id','team','title','status','owner','revision','level','acknowledged','resolved','paused')

class Service(ReplayService):
 def initial(self):return {'teams':{},'policies':{},'incidents':{},'keys':{}}
 def public(self,r):return {k:copy.deepcopy(r[k]) for k in PUBLIC}
 def elapsed(self,r,now):
  end = r['resolved'] if r['status']=='resolved' else now
  return end-r['start']-r['pause_total']-(end-r['pause_start'] if r['paused'] else 0)
 def inspect(self,r,now):
  e=self.elapsed(r,now)
  active=r['status']!='resolved'
  return dict(self.public(r),elapsed=e,response_breached=active and r['acknowledged'] is None and e>=r['sla']['response'],resolve_breached=active and e>=r['sla']['resolve'])
 def open(self,s,d):
  fields(d,OPEN)
  if d['key'] in s['keys']:
   old=s['keys'][d['key']]
   require(old['request']==d,'Conflicting key')
   return copy.deepcopy(old['result'])
  require(d['id'] not in s['incidents'],'Duplicate incident')
  get_record(s['teams'],d['team']); policy=get_record(s['policies'],d['policy'])
  r=dict(id=d['id'],team=d['team'],title=d['title'],status='open',owner=None,revision=1,level=0,acknowledged=None,resolved=None,paused=False,start=d['now'],last=d['now'],pause_total=0,pause_start=None,sla=copy.deepcopy(policy),escalations=[])
  s['incidents'][d['id']]=r
  result=self.public(r)
  s['keys'][d['key']]={'request':copy.deepcopy(d),'result':copy.deepcopy(result)}
  return result
 def handle(self,s,op,d):
  if op=='team.put':
   fields(d,{'id':text,'members':lambda v:identifiers(v,nonempty=True)})
   members=identifiers(d['members'],nonempty=True)
   require(all(r['owner'] is None or r['owner'] in members for r in s['incidents'].values() if r['team']==d['id'] and r['status']!='resolved'),'Assigned owner would be removed')
   s['teams'][d['id']]={'id':d['id'],'members':members}; return s['teams'][d['id']]
  if op=='policy.put':
   fields(d,{'id':text,'response':P,'resolve':P}); require(d['resolve']>=d['response'])
   s['policies'][d['id']]=copy.deepcopy(d); return d
  if op=='incident.open':return self.open(s,d)
  if op=='incident.import':
   fields(d,{'incidents':lambda v: require(isinstance(v,list))})
   for row in d['incidents']: self.open(s,row)
   return {'imported':len(d['incidents'])}
  if op=='incident.list':
   fields(d,{},optional={'team':text,'status':text})
   if 'status' in d:require(d['status'] in ('open','acknowledged','resolved'))
   return [self.public(r) for _,r in sorted(s['incidents'].items()) if all(r[k]==v for k,v in d.items())]
  if op=='incident.inspect':
   fields(d,{'id':text,'now':N}); r=get_record(s['incidents'],d['id']); require(d['now']>=r['last'],'Time moved backwards')
   return self.inspect(r,d['now'])
  allowed=('incident.assign','incident.ack','incident.pause','incident.resume','incident.resolve','incident.reopen','escalate')
  require(op in allowed,'Unknown operation')
  schema={'id':text,'expected_revision':P,'now':N}
  if op=='incident.assign':schema['owner']=text
  fields(d,schema);r=get_record(s['incidents'],d['id']);compare_revision(r,d['expected_revision']);now=d['now'];require(now>=r['last'],'Time moved backwards')
  if op=='incident.reopen':
   require(r['status']=='resolved');require(r['owner'] is None or r['owner'] in s['teams'][r['team']]['members'],'Owner no longer a member')
   r.update(status='open',acknowledged=None,resolved=None,paused=False,start=now,pause_total=0,pause_start=None,level=0,escalations=[])
  else:
   require(r['status']!='resolved','Incident resolved')
   if op=='incident.assign':
    require(d['owner'] in s['teams'][r['team']]['members'],'Unknown member');r['owner']=d['owner']
   elif op=='incident.ack':
    require(r['status']=='open' and r['acknowledged'] is None);r.update(acknowledged=now,status='acknowledged')
   elif op=='incident.pause':
    require(not r['paused']);r.update(paused=True,pause_start=now)
   elif op=='incident.resume':
    require(r['paused']);r['pause_total']+=now-r['pause_start'];r.update(paused=False,pause_start=None)
   elif op=='incident.resolve':
    require(not r['paused']);r.update(status='resolved',resolved=now)
   elif op=='escalate':
    view=self.inspect(r,now);e=view['elapsed'];require(view['response_breached'] or view['resolve_breached'],'SLA not breached');require(e not in r['escalations'],'Already escalated at this elapsed time');r['escalations'].append(e);r['level']+=1
  r['last']=now;r['revision']+=1
  return self.public(r)

if __name__=='__main__':Service.main()
