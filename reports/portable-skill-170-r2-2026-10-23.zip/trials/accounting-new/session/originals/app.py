def banner():return 'Local Ops — café'

class Service:
 def __init__(self,path):self.path=path
 def call(self,operation,data):raise ValueError('Not implemented')
