import unittest
from app import Service
from goalpilot_support import JourneyMixin, rejects

class Accounting(JourneyMixin,unittest.TestCase):
 def setUp(self):self.open_service(Service)
 def test_journey(self):
  def flow(c):
   for a,k in [('cash','asset'),('sales','income'),('zero','expense')]:c('account.create',id=a,name='café '+a,kind=k)
   self.assertEqual(c('period.create',id='p',start=0,end=10),dict(id='p',start=0,end=10,status='open',revision=1))
   rejects(lambda:c('period.create',id='overlap',start=9,end=20))
   payload=dict(id='j',date=0,key='k',lines=[dict(account='cash',debit=101,credit=0),dict(account='sales',debit=0,credit=101)])
   first=c('journal.post',**payload)
   self.assertEqual(c('journal.post',**payload),first)
   rejects(lambda:c('journal.post',**dict(payload,id='other')))
   rejects(lambda:c('journal.post',**dict(payload,id='bad',key='bad',date=10)))
   rejects(lambda:c('journal.post',**dict(payload,id='bad',key='bad',lines=[dict(account='cash',debit=True,credit=0)])))
   self.assertEqual(c('account.balance',id='cash'),dict(debit=101,credit=0,net=101))
   snap=c('backup')
   c('period.close',id='p',expected_revision=1)
   rejects(lambda:c('journal.reverse',id='j',reversal_id='r',date=1,key='r'))
   rejects(lambda:c('period.reopen',id='p',expected_revision=1))
   c('period.reopen',id='p',expected_revision=2)
   rev=dict(id='j',reversal_id='r',date=1,key='r')
   r=c('journal.reverse',**rev)
   self.assertEqual(c('journal.reverse',**rev),r)
   self.assertEqual(c('journal.post',**payload),first)
   self.assertEqual(c('journal.get',id='j')['status'],'reversed')
   rejects(lambda:c('journal.reverse',id='r',reversal_id='x',date=2,key='x'))
   rejects(lambda:c('journal.reverse',**dict(rev,key='again',reversal_id='x')))
   self.assertEqual([e['id'] for e in c('journal.list',period='p',account='cash')],['j','r'])
   self.assertEqual(c('trial_balance'),[dict(account=a,debit=101 if a!='zero' else 0,credit=101 if a!='zero' else 0,net=0) for a in ['cash','sales','zero']])
   batch=[dict(payload,id='b',key='b'),dict(payload,id='j',key='collision')]
   rejects(lambda:c('journal.import',entries=batch))
   self.assertEqual(c('account.balance',id='cash')['net'],0)
   self.assertEqual(c('journal.import',entries=[batch[0]]),{'imported':1})
   c('restore',state=snap)
   self.assertEqual(c('journal.list'),[first])
   c('journal.reverse',**rev)
  self.assertJourney(flow)
 def test_integrity_and_concurrency(self):
  for a in ['a','b']:self.c('account.create',id=a,name=a,kind='asset')
  self.c('period.create',id='p',start=0,end=100)
  def payload(i):return dict(id=str(i),date=1,key=str(i),lines=[dict(account='a',debit=10**20+1,credit=0),dict(account='b',debit=0,credit=10**20+1)])
  self.assertRejects('journal.post',**dict(payload(0),lines=[dict(account='a',debit=1,credit=0),dict(account='b',debit=0,credit=2)]))
  results=self.race(*[('journal.post',payload(i)) for i in range(4)])
  self.assertTrue(all(ok for ok,_ in results)); self.restart()
  self.assertEqual(self.c('account.balance',id='a')['net'],4*(10**20+1))
  snapshot=self.c('backup'); snapshot['state']['accounts']['a']['name']='tampered'
  self.assertRejects('restore',state=snapshot)
  snapshot=self.c('backup'); snapshot['state']['entries']['0']['lines'][0]['debit']=1
  self.assertRejects('restore',state=snapshot)
  rows=self.c('journal.list'); rows[0]['lines'].clear()
  self.assertEqual(len(self.c('journal.get',id='0')['lines']),2)
