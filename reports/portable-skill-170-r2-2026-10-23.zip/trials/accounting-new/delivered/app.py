from copy import deepcopy
from goalpilot_runtime import ReplayService, fields, text, integer, choice, sequence, require, get_record


def banner():return 'Local Ops — café'
def date(value):
 require(type(value) is int); return value
line = lambda v: fields(v, {'account':text,'debit':integer,'credit':integer})
post = lambda v: fields(v, {'id':text,'date':date,'lines':sequence(line),'key':text})

class Service(ReplayService):
 def initial(self):return {'accounts':{},'periods':{},'entries':{},'keys':{},'origins':{}}
 def handle(self,s,op,d):
  schemas={
   'account.create':{'id':text,'name':text,'kind':choice('asset','liability','income','expense')},
   'period.create':{'id':text,'start':integer,'end':integer},
   'period.close':{'id':text,'expected_revision':integer},
   'period.reopen':{'id':text,'expected_revision':integer},
   'journal.reverse':{'id':text,'reversal_id':text,'date':date,'key':text},
   'journal.get':{'id':text},'account.balance':{'id':text},'trial_balance':{},
   'journal.import':{'entries':sequence(post)}}
  if op=='journal.list':fields(d,{},optional={'period':text,'account':text})
  elif op=='journal.post':post(d)
  else:
   require(op in schemas,'Unknown operation'); fields(d,schemas[op])
  if op in ('journal.post','journal.reverse'):
   key=d['key']
   if key in s['keys']:
    saved=s['keys'][key]; require(saved['operation']==op and saved['data']==d,'Conflicting key')
    return deepcopy(saved['result'])
   result=self.entry(s,op,d)
   s['keys'][key]={'operation':op,'data':deepcopy(d),'result':deepcopy(result)}
   return result
  if op=='account.create':
   require(d['id'] not in s['accounts'],'Duplicate account'); s['accounts'][d['id']]=deepcopy(d); return d
  if op=='period.create':
   require(d['id'] not in s['periods']); require(d['end']>d['start'])
   require(all(d['end']<=p['start'] or d['start']>=p['end'] for p in s['periods'].values()),'Overlapping period')
   result=dict(d,status='open',revision=1); s['periods'][d['id']]=result; return result
  if op in ('period.close','period.reopen'):
   p=get_record(s['periods'],d['id']); require(p['revision']==d['expected_revision'],'Stale revision')
   require(p['status']==('open' if op=='period.close' else 'closed'))
   p['status']='closed' if op=='period.close' else 'open'; p['revision']+=1; return p
  if op=='journal.get':return get_record(s['entries'],d['id'])
  if op=='journal.list':
   if 'period' in d:get_record(s['periods'],d['period'])
   if 'account' in d:get_record(s['accounts'],d['account'])
   return sorted((e for e in s['entries'].values() if ('period' not in d or e['period']==d['period']) and ('account' not in d or any(l['account']==d['account'] for l in e['lines']))),key=lambda e:(e['date'],e['id']))
  if op=='journal.import':
   for entry in d['entries']:self.handle(s,'journal.post',entry)
   return {'imported':len(d['entries'])}
  def balance(a):
   rows=[l for e in s['entries'].values() for l in e['lines'] if l['account']==a]
   debit=sum(l['debit'] for l in rows); credit=sum(l['credit'] for l in rows)
   return {'debit':debit,'credit':credit,'net':debit-credit}
  if op=='account.balance':get_record(s['accounts'],d['id']); return balance(d['id'])
  return [dict(account=a,**balance(a)) for a in sorted(s['accounts'])]
 def entry(self,s,op,d):
  original=None
  if op=='journal.reverse':
   original=get_record(s['entries'],d['id']); require(original['status']=='posted','Already reversed')
   require(d['id'] not in s['origins'],'Cannot reverse a reversal')
   ident=d['reversal_id']; lines=[{'account':l['account'],'debit':l['credit'],'credit':l['debit']} for l in original['lines']]
  else:ident=d['id']; lines=deepcopy(d['lines'])
  require(ident not in s['entries'],'Duplicate entry'); require(len(lines)>=2)
  for l in lines:
   get_record(s['accounts'],l['account']); require((l['debit']>0) != (l['credit']>0),'One positive side required')
  require(sum(l['debit'] for l in lines)==sum(l['credit'] for l in lines)>0,'Unbalanced entry')
  periods=[p for p in s['periods'].values() if p['start']<=d['date']<p['end']]
  require(len(periods)==1 and periods[0]['status']=='open','No open period')
  result={'id':ident,'date':d['date'],'period':periods[0]['id'],'lines':lines,'status':'posted','reversal':None}
  s['entries'][ident]=result
  if original is not None:
   original['status']='reversed'; original['reversal']=ident; s['origins'][ident]=original['id']
  return result

if __name__=='__main__':Service.main()
