import hashlib
from goalpilot_runtime import ReplayService, fields, text, boolean, integer, identifiers, require, get_record, sequence, nullable

def banner():return 'Local Ops — café'

def positive(v):return integer(v,1)
def percent(v):return integer(v,0,100)
def rule(v):return fields(v,{'segment':nullable(text),'percent':percent,'value':boolean})
def definition(v):return fields(v,{'id':text,'default':boolean})

class Service(ReplayService):
 def initial(self):return {'environments':{}}
 def handle(self,state,op,data):
  schemas={
   'environment.create':{'id':text},
   'segment.put':{'environment':text,'id':text,'members':identifiers},
   'segment.delete':{'environment':text,'id':text},
   'flag.create':{'environment':text,'id':text,'default':boolean},
   'flag.import':{'environment':text,'flags':sequence(definition)},
   'flag.update':{'environment':text,'id':text,'expected_revision':positive,'enabled':boolean,'rules':sequence(rule)},
   'flag.publish':{'environment':text,'id':text,'expected_revision':positive},
   'flag.rollback':{'environment':text,'id':text,'revision':positive,'expected_revision':positive},
   'flag.evaluate':{'environment':text,'id':text,'user':text},
   'flag.get':{'environment':text,'id':text},
   'flag.list':{'environment':text},'audit.list':{'environment':text}}
  require(op in schemas,'Unknown operation');fields(data,schemas[op])
  envs=state['environments']
  if op=='environment.create':
   require(data['id'] not in envs,'Environment exists');envs[data['id']]={'segments':{},'flags':{},'audit':[]};return {'id':data['id']}
  env=get_record(envs,data['environment']);flags=env['flags'];segments=env['segments']
  def event(kind,f):env['audit'].append({'sequence':len(env['audit'])+1,'kind':'flag.'+kind,'flag':f['id'],'revision':f['revision']})
  def create(d):
   f={'id':d['id'],'environment':data['environment'],'revision':1,'published':0,'enabled':False,'default':d['default'],'rules':[]}
   flags[d['id']]={'draft':f,'history':{}};event('created',f);return f
  def snapshot(f):return {k:f[k] for k in ('enabled','default','rules')}
  if op=='audit.list':return env['audit']
  if op=='flag.list':return [flags[k]['draft'] for k in sorted(flags)]
  if op=='segment.put':segments[data['id']]=identifiers(data['members']);return {'id':data['id'],'environment':data['environment'],'members':segments[data['id']]}
  if op=='segment.delete':
   get_record(segments,data['id'])
   for record in flags.values():
    for f in [record['draft'],*record['history'].values()]:require(all(r['segment']!=data['id'] for r in f['rules']),'Segment referenced')
   del segments[data['id']];return {'deleted':data['id']}
  if op=='flag.import':
   rows=data['flags'];ids=[d['id'] for d in rows];require(len(ids)==len(set(ids)) and all(i not in flags for i in ids),'Duplicate flag')
   for d in rows:create(d)
   return {'imported':len(rows)}
  if op=='flag.create':require(data['id'] not in flags,'Flag exists');return create(data)
  record=get_record(flags,data['id']);f=record['draft'];history=record['history']
  if op=='flag.get':return f
  if op=='flag.evaluate':
   bucket=int.from_bytes(hashlib.sha256((data['environment']+'|'+data['id']+'|'+data['user']).encode('utf8')).digest()[:8],'big')%100
   live=history.get(str(f['published']));value=f['default'] if live is None else live['default']
   if live and live['enabled']:
    for r in live['rules']:
     if (r['segment'] is None or data['user'] in segments[r['segment']]) and bucket<r['percent']:value=r['value'];break
   return {'value':value,'revision':f['published'],'bucket':bucket}
  require(data['expected_revision']==f['revision'],'Stale revision')
  if op=='flag.update':
   for r in data['rules']:
    if r['segment'] is not None:get_record(segments,r['segment'])
   f.update(enabled=data['enabled'],rules=data['rules'],revision=f['revision']+1);event('updated',f)
  elif op=='flag.publish':
   if f['published']!=f['revision']:
    history[str(f['revision'])]=snapshot(f);f['published']=f['revision'];event('published',f)
  elif op=='flag.rollback':
   old=get_record(history,str(data['revision']));f.update(old);f['revision']+=1;f['published']=f['revision'];history[str(f['revision'])]=snapshot(f);event('rolled_back',f)
  return f

if __name__=='__main__':Service.main()
