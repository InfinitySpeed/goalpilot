import hashlib
import unittest
from app import Service
from goalpilot_support import JourneyMixin, rejects

class Workflows(JourneyMixin,unittest.TestCase):
 def setUp(self):self.open_service(Service)
 def test_journey(self):
  def flow(c):
   for e in ['prod','dev']:c('environment.create',id=e)
   p={'environment':'prod','id':'café'}
   c('segment.put',environment='prod',id='team',members=['é','é','a'])
   f=c('flag.create',**p,default=False);self.assertEqual(f,dict(p,revision=1,published=0,enabled=False,default=False,rules=[]))
   c('flag.create',environment='dev',id='café',default=True)
   r=[{'segment':'team','percent':100,'value':True},{'segment':None,'percent':0,'value':True}]
   c('flag.update',**p,expected_revision=1,enabled=True,rules=r)
   self.assertFalse(c('flag.evaluate',**p,user='é')['value'])
   c('flag.publish',**p,expected_revision=2);c('flag.publish',**p,expected_revision=2)
   self.assertTrue(c('flag.evaluate',**p,user='é')['value'])
   self.assertFalse(c('flag.evaluate',**p,user='outside')['value'])
   c('segment.put',environment='prod',id='team',members=[])
   self.assertFalse(c('flag.evaluate',**p,user='é')['value'])
   c('flag.update',**p,expected_revision=2,enabled=True,rules=[{'segment':None,'percent':47,'value':True}])
   self.assertEqual(c('flag.evaluate',**p,user='u')['revision'],2)
   c('flag.publish',**p,expected_revision=3)
   for user in ['u','v','é','long']:
    bucket=int.from_bytes(hashlib.sha256(('prod|café|'+user).encode()).digest()[:8],'big')%100
    self.assertEqual(c('flag.evaluate',**p,user=user),{'bucket':bucket,'revision':3,'value':bucket<47})
   c('flag.rollback',**p,expected_revision=3,revision=2)
   self.assertEqual(c('flag.get',**p)['revision'],4)
   c('flag.update',**p,expected_revision=4,enabled=False,rules=[]);c('flag.publish',**p,expected_revision=5)
   self.assertFalse(c('flag.evaluate',**p,user='u')['value'])
   rejects(lambda:c('segment.delete',environment='prod',id='team'))
   rejects(lambda:c('flag.rollback',**p,expected_revision=5,revision=99))
   rejects(lambda:c('flag.update',**p,expected_revision=4,enabled=True,rules=[]))
   for bad in [True,1.2,'1',-1,101]:
    rejects(lambda:c('flag.update',**p,expected_revision=5,enabled=True,rules=[{'segment':None,'percent':bad,'value':True}]))
   rejects(lambda:c('flag.update',environment='dev',id='café',expected_revision=1,enabled=True,rules=r))
   self.assertTrue(c('flag.evaluate',environment='dev',id='café',user='u')['value'])
   self.assertEqual(len(c('audit.list',environment='dev')),1)
   a=c('audit.list',environment='prod');self.assertEqual([x['sequence'] for x in a],list(range(1,len(a)+1)))
   self.assertEqual([x['kind'] for x in a],['flag.created','flag.updated','flag.published','flag.updated','flag.published','flag.rolled_back','flag.updated','flag.published'])
   saved=c('backup')
   c('flag.import',environment='prod',flags=[{'id':'z','default':True},{'id':'a','default':False}])
   rejects(lambda:c('flag.import',environment='prod',flags=[{'id':'new','default':True},{'id':'z','default':True}]))
   self.assertEqual([f['id'] for f in c('flag.list',environment='prod')],['a','café','z'])
   c('restore',state=saved);self.assertEqual([f['id'] for f in c('flag.list',environment='prod')],['café'])
   c('segment.put',environment='dev',id='unused',members=[]);c('segment.delete',environment='dev',id='unused')
  self.assertJourney(flow)
 def test_atomic_and_concurrent(self):
  self.c('environment.create',id='e');self.c('flag.create',environment='e',id='f',default=False)
  self.assertRejects('flag.update',environment='e',id='f',expected_revision=True,enabled=True,rules=[])
  self.assertRejects('flag.import',environment='e',flags=[{'id':'x','default':True},{'id':'x','default':False}])
  result=self.race(*[('flag.update',{'environment':'e','id':'f','expected_revision':1,'enabled':True,'rules':[]}) for _ in range(2)])
  self.assertEqual(sum(ok for ok,_ in result),1)
  self.restart();self.assertEqual(self.c('flag.get',environment='e',id='f')['revision'],2)
  snapshot=self.c('backup');snapshot.clear();self.assertEqual(self.c('flag.get',environment='e',id='f')['revision'],2)
  self.assertCorruptions(lambda b:b.clear(),lambda b:b['state'].clear())
