from goalpilot_runtime import ReplayService, fields, text, integer, boolean, identifiers, sequence, require


def banner():
    return 'Local Ops — café'


class Service(ReplayService):
    def initial(self):
        return {'practitioners': {}, 'patients': {}, 'appointments': {}, 'keys': {}, 'wait': {}}

    def handle(self, s, op, d):
        def schema(required, optional=None):
            fields(d, required, optional=optional)
        def record(table, key):
            text(key)
            require(key in s[table], 'Missing record')
            return s[table][key]
        def interval(start, end):
            integer(start); integer(end)
            require(end > start, 'Invalid interval')
        def available(a, ignore=None):
            for other in s['appointments'].values():
                if other['id'] == ignore or other['status'] == 'cancelled':
                    continue
                require(not ((other['patient'] == a['patient'] or other['practitioner'] == a['practitioner']) and a['start'] < other['end'] and other['start'] < a['end']), 'Overlapping appointment')
        def create(payload):
            fields(payload, {k: text for k in ('id', 'patient', 'practitioner', 'skill', 'key')} | {k: integer for k in ('start', 'end', 'fee')})
            interval(payload['start'], payload['end'])
            key = payload['key']
            if key in s['keys']:
                previous = s['keys'][key]
                require(previous['request'] == payload, 'Conflicting create key')
                return previous['result']
            require(payload['id'] not in s['appointments'], 'Duplicate appointment')
            p = record('patients', payload['patient'])
            pr = record('practitioners', payload['practitioner'])
            require(p['consent'], 'Consent required')
            require(payload['skill'] in pr['skills'], 'Missing skill')
            a = {k: v for k, v in payload.items() if k != 'key'}
            a.update(status='confirmed', revision=1, charged=0)
            available(a)
            s['appointments'][a['id']] = dict(a)
            s['keys'][key] = {'request': dict(payload), 'result': dict(a)}
            return a

        if op == 'practitioner.put':
            schema({'id': text, 'skills': identifiers})
            skills = identifiers(d['skills'])
            require(all(a['skill'] in skills for a in s['appointments'].values() if a['practitioner'] == d['id'] and a['status'] != 'cancelled'), 'Skill in use')
            row = {'id': d['id'], 'skills': skills}
            s['practitioners'][d['id']] = row
            return row
        if op == 'patient.put':
            schema({'id': text, 'consent': boolean})
            s['patients'][d['id']] = dict(d)
            return d
        if op == 'appointment.create':
            return create(d)
        if op == 'appointment.import':
            schema({'appointments': sequence(lambda x: fields(x, {k: text for k in ('id','patient','practitioner','skill','key')} | {k: integer for k in ('start','end','fee')}))})
            for payload in d['appointments']:
                create(payload)
            return {'imported': len(d['appointments'])}
        if op in ('appointment.move', 'appointment.cancel', 'appointment.finish'):
            extra = {'start': integer, 'end': integer} if op.endswith('move') else ({'attended': boolean} if op.endswith('finish') else {})
            schema({'id': text, 'expected_revision': integer} | extra)
            a = record('appointments', d['id'])
            require(a['status'] == 'confirmed', 'Appointment not confirmed')
            require(a['revision'] == d['expected_revision'], 'Revision conflict')
            if op.endswith('move'):
                interval(d['start'], d['end'])
                candidate = dict(a, start=d['start'], end=d['end'])
                available(candidate, a['id'])
                a.update(start=d['start'], end=d['end'])
            elif op.endswith('cancel'):
                a['status'] = 'cancelled'
            else:
                a['status'] = 'attended' if d['attended'] else 'missed'
                a['charged'] = a['fee'] if d['attended'] else a['fee'] // 2
            a['revision'] += 1
            return a
        if op == 'appointment.get':
            schema({'id': text})
            return record('appointments', d['id'])
        if op == 'appointment.list':
            schema({}, {'patient': text, 'practitioner': text, 'status': lambda v: require(v in ('confirmed', 'cancelled', 'attended', 'missed'), 'Invalid status')})
            return sorted((a for a in s['appointments'].values() if all(a[k] == v for k, v in d.items())), key=lambda a: (a['start'], a['id']))
        if op == 'invoice':
            schema({'patient': text})
            record('patients', d['patient'])
            rows = [a for a in s['appointments'].values() if a['patient'] == d['patient']]
            return {'charged': sum(a['charged'] for a in rows), 'attended': sum(a['status'] == 'attended' for a in rows), 'missed': sum(a['status'] == 'missed' for a in rows)}
        if op == 'wait.add':
            schema({'id': text, 'patient': text, 'skill': text})
            require(record('patients', d['patient'])['consent'], 'Consent required')
            require(d['id'] not in s['wait'], 'Duplicate wait ID')
            require(all((w['patient'], w['skill']) != (d['patient'], d['skill']) for w in s['wait'].values()), 'Duplicate wait request')
            s['wait'][d['id']] = dict(d)
            return d
        if op == 'wait.list':
            schema({'skill': text})
            return [w for w in s['wait'].values() if w['skill'] == d['skill']]
        if op == 'wait.remove':
            schema({'id': text})
            row = record('wait', d['id'])
            del s['wait'][d['id']]
            return row
        raise ValueError('Unknown operation')


if __name__ == '__main__':
    Service.main()
