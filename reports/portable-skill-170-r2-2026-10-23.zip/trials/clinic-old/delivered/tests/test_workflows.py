import unittest
from app import Service
from goalpilot_support import JourneyMixin, rejects


class Workflows(JourneyMixin, unittest.TestCase):
    def setUp(self):
        self.open_service(Service)

    def test_business_transports(self):
        def flow(c):
            c('practitioner.put', id='médecin', skills=['s', 's'])
            c('practitioner.put', id='other', skills=['s'])
            for p in ('p', 'q'):
                c('patient.put', id=p, consent=True)
            def payload(i, **overrides):
                return dict(id=i, patient='p', practitioner='médecin', start=10, end=20, skill='s', fee=101, key=i) | overrides
            original = c('appointment.create', **payload('a'))
            self.assertEqual(original, dict(id='a', patient='p', practitioner='médecin', start=10, end=20, skill='s', fee=101, status='confirmed', revision=1, charged=0))
            for changes in ({'practitioner':'other'}, {'patient':'q'}, {'fee':True}, {'start':1.2}, {'end':10}, {'skill':'absent'}):
                rejects(lambda: c('appointment.create', **payload('bad', **changes)))
            rejects(lambda: c('appointment.create', **payload('a', fee=102)))
            rejects(lambda: c('practitioner.put', id='médecin', skills=[]))
            c('patient.put', id='p', consent=False)
            rejects(lambda: c('appointment.create', **payload('denied', start=30, end=40)))
            c('patient.put', id='p', consent=True)
            self.assertEqual(c('appointment.move', id='a', start=20, end=30, expected_revision=1)['revision'], 2)
            rejects(lambda: c('appointment.cancel', id='a', expected_revision=1))
            self.assertEqual(c('appointment.create', **payload('a')), original)
            c('appointment.create', **payload('b'))
            rejects(lambda: c('appointment.move', id='b', start=25, end=35, expected_revision=1))
            self.assertEqual(c('appointment.finish', id='a', expected_revision=2, attended=False)['charged'], 50)
            rejects(lambda: c('appointment.create', **payload('occupied', start=20, end=21)))
            c('appointment.finish', id='b', expected_revision=1, attended=True)
            self.assertEqual(c('invoice', patient='p'), {'charged':151, 'attended':1, 'missed':1})
            c('appointment.create', **payload('cancel', start=30, end=40))
            c('appointment.cancel', id='cancel', expected_revision=1)
            c('appointment.create', **payload('free', start=30, end=40))
            self.assertEqual([a['id'] for a in c('appointment.list', patient='p', practitioner='médecin', status='confirmed')], ['free'])
            for wid, p in (('z','p'), ('a','q')):
                c('wait.add', id=wid, patient=p, skill='s')
            self.assertEqual([w['id'] for w in c('wait.list', skill='s')], ['z','a'])
            rejects(lambda: c('wait.add', id='dup', patient='p', skill='s'))
            c('wait.remove', id='z')
            rejects(lambda: c('wait.remove', id='z'))
            snapshot = c('backup')
            rejects(lambda: c('appointment.import', appointments=[payload('x', start=40, end=50), payload('y', start=45, end=55)]))
            self.assertEqual(c('backup'), snapshot)
            self.assertEqual(c('appointment.import', appointments=[payload('x', start=40, end=50), payload('y', start=50, end=60)]), {'imported':2})
            c('restore', state=snapshot)
            self.assertEqual(c('backup'), snapshot)
            rejects(lambda: c('appointment.get', id='x'))
            c('appointment.create', **payload('after', start=40, end=50))
            rejects(lambda: c('unknown'))
        self.assertJourney(flow)

    def seed(self):
        self.c('practitioner.put', id='d', skills=['s'])
        self.c('patient.put', id='p', consent=True)
        return dict(patient='p', practitioner='d', start=0, end=10, skill='s', fee=20)

    def test_atomic_detached_and_corruption(self):
        base = self.seed()
        data = dict(base, id='a', key='a')
        result = self.service.call('appointment.create', data)
        result['start'] = 999
        self.assertEqual(data, dict(base, id='a', key='a'))
        self.restart()
        self.assertEqual(self.c('appointment.get', id='a')['start'], 0)
        self.assertRejects('appointment.create', **dict(base, id='b', key='b'))
        self.assertRejects('patient.put', id='p', consent=1)
        self.assertRejects('restore', state={})
        self.assertCorruptions(lambda b: b['state']['appointments']['a'].__setitem__('charged', 999), lambda b: b['state']['patients']['p'].__setitem__('consent', 'yes'), lambda b: b['state']['keys'].clear(), lambda b: b['state']['appointments']['a'].__setitem__('revision', 99))

    def test_concurrent_booking_and_revision(self):
        base = self.seed()
        outcomes = self.race(*[('appointment.create', dict(base, id=i, key=i)) for i in ('a','b')])
        self.assertEqual(sum(ok for ok, _ in outcomes), 1)
        row = self.c('appointment.list')[0]
        outcomes = self.race(*[('appointment.move', dict(id=row['id'], start=t, end=t+10, expected_revision=1)) for t in (20,40)])
        self.assertEqual(sum(ok for ok, _ in outcomes), 1)
        self.assertEqual(self.c('appointment.get', id=row['id'])['revision'], 2)
