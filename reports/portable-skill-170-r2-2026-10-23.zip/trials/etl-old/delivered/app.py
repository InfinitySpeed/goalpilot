import copy
import csv
import io
import re
from goalpilot_runtime import ReplayService, fields, text, integer, boolean, require


def banner():
    return 'Local Ops — café'


def schema_columns(value):
    require(isinstance(value, list) and bool(value), 'Columns required')
    names = set()
    for col in value:
        fields(col, {'name': text, 'type': text, 'required': boolean})
        require(col['type'] in ('text', 'integer', 'money'), 'Invalid column type')
        require(col['name'] not in names, 'Duplicate column')
        names.add(col['name'])


def reader(raw):
    return csv.reader(io.StringIO(raw, newline=''), strict=True)


def header(raw, schema):
    require(isinstance(raw, str), 'CSV must be a string')
    try:
        require(next(reader(raw), None) == [c['name'] for c in schema['columns']], 'Invalid CSV header')
    except csv.Error as exc:
        raise ValueError('Invalid CSV header') from exc


def normalize(raw, schema):
    stream = reader(raw)
    next(stream)
    rows, rejects, seen = [], [], set()
    while True:
        try:
            cells = next(stream)
        except StopIteration:
            break
        except csv.Error as exc:
            rejects.append({'row': stream.line_num, 'reason': str(exc) or 'Malformed CSV'})
            break
        line = stream.line_num
        try:
            require(len(cells) == len(schema['columns']), 'Wrong cell count')
            row = {}
            for col, cell in zip(schema['columns'], cells):
                value = cell.strip()
                kind = col['type']
                require(value != '' or not col['required'], 'Required value: ' + col['name'])
                if kind == 'text':
                    result = value
                elif value == '':
                    result = None
                elif kind == 'integer':
                    require(re.fullmatch(r'[+-]?[0-9]+', value) is not None, 'Invalid integer: ' + col['name'])
                    result = int(value)
                else:
                    require(re.fullmatch(r'[0-9]+(?:\.[0-9]{1,2})?', value) is not None, 'Invalid money: ' + col['name'])
                    whole, _, fraction = value.partition('.')
                    result = int(whole) * 100 + int((fraction + '00')[:2])
                row[col['name']] = result
            key = row[schema['key']]
            require(key != '', 'Empty primary key')
            require(key not in seen, 'Duplicate primary key')
            seen.add(key)
            rows.append(row)
        except ValueError as exc:
            rejects.append({'row': line, 'reason': str(exc)})
    return rows, rejects


class Service(ReplayService):
    def initial(self):
        return {'schemas': {}, 'jobs': {}, 'datasets': {}, 'keys': {}}

    def handle(self, state, operation, data):
        schemas, jobs = state['schemas'], state['jobs']
        if operation == 'schema.put':
            fields(data, {'id': text, 'columns': schema_columns, 'key': text})
            require(any(c['name'] == data['key'] and c['type'] == 'text' and c['required'] for c in data['columns']), 'Key must be required text')
            item = copy.deepcopy(data)
            item['revision'] = schemas.get(data['id'], {}).get('revision', 0) + 1
            schemas[data['id']] = item
            return item
        if operation in ('job.create', 'job.import'):
            if operation == 'job.import':
                fields(data, {'jobs': lambda x: require(isinstance(x, list), 'Jobs must be a list')})
                incoming = data['jobs']
            else:
                incoming = [data]
            prepared = []
            ids = set(jobs)
            for item in incoming:
                fields(item, {'id': text, 'schema': text, 'csv': lambda x: require(isinstance(x, str), 'CSV must be a string')})
                require(item['id'] not in ids, 'Job already exists')
                require(item['schema'] in schemas, 'Unknown schema')
                snapshot = copy.deepcopy(schemas[item['schema']])
                header(item['csv'], snapshot)
                job = dict(copy.deepcopy(item), status='draft', revision=1, schema_revision=snapshot['revision'], snapshot=snapshot)
                prepared.append(job)
                ids.add(item['id'])
            for job in prepared:
                jobs[job['id']] = job
            return {'imported': len(prepared)} if operation == 'job.import' else self.public(prepared[0])
        if operation == 'dataset.get':
            fields(data, {'schema': text})
            require(data['schema'] in state['datasets'], 'No published dataset')
            return state['datasets'][data['schema']]
        if operation not in ('job.get', 'job.run', 'job.publish', 'job.export', 'job.retry'):
            raise ValueError('Unknown operation')
        validators = {'id': text}
        if operation == 'job.run':
            validators['key'] = text
        elif operation == 'job.publish':
            validators['expected_revision'] = integer
        elif operation == 'job.retry':
            validators['csv'] = lambda x: require(isinstance(x, str), 'CSV must be a string')
        fields(data, validators)
        if operation == 'job.run' and data['key'] in state['keys']:
            previous = state['keys'][data['key']]
            require(previous['operation'] == operation and previous['data'] == data, 'Idempotency conflict')
            return previous['result']
        require(data['id'] in jobs, 'Unknown job')
        job = jobs[data['id']]
        if operation == 'job.get':
            return self.public(job)
        if operation == 'job.run':
            require(job['status'] == 'draft', 'Job must be draft')
            rows, rejects = normalize(job['csv'], job['snapshot'])
            result = {'id': job['id'], 'status': 'processed', 'accepted': len(rows), 'rejected': len(rejects), 'rows': rows, 'rejects': rejects, 'schema_revision': job['snapshot']['revision']}
            job.update(copy.deepcopy(result))
            state['keys'][data['key']] = {'operation': operation, 'data': copy.deepcopy(data), 'result': copy.deepcopy(result)}
            return result
        if operation == 'job.publish':
            require(job['status'] == 'processed' and data['expected_revision'] == job['revision'], 'Publication conflict')
            job.update(status='published', revision=2)
            state['datasets'][job['schema']] = {'job': job['id'], 'rows': copy.deepcopy(job['rows']), 'schema_revision': job['schema_revision']}
            return self.public(job)
        if operation == 'job.retry':
            require(job['status'] == 'processed', 'Only processed jobs can retry')
            header(data['csv'], job['snapshot'])
            for key in ('accepted', 'rejected', 'rows', 'rejects'):
                job.pop(key, None)
            job.update(csv=data['csv'], status='draft')
            return self.public(job)
        require(job['status'] in ('processed', 'published'), 'Job not processed')
        output = io.StringIO(newline='')
        writer = csv.writer(output)
        columns = [c['name'] for c in job['snapshot']['columns']]
        writer.writerow(columns)
        for row in job['rows']:
            writer.writerow(['' if row[name] is None else row[name] for name in columns])
        return output.getvalue()

    @staticmethod
    def public(job):
        return {k: copy.deepcopy(v) for k, v in job.items() if k != 'snapshot'}


if __name__ == '__main__':
    Service.main()
