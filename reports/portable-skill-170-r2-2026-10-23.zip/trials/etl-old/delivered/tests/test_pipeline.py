import copy
import csv
import io
import unittest
from app import Service
from goalpilot_support import JourneyMixin, rejects

COLUMNS = [{'name': 'id', 'type': 'text', 'required': True},
           {'name': 'qty', 'type': 'integer', 'required': False},
           {'name': 'cost', 'type': 'money', 'required': True}]


class Pipeline(JourneyMixin, unittest.TestCase):
    def setUp(self):
        self.open_service(Service)

    def test_business_journey_all_transports(self):
        def flow(c):
            schema = c('schema.put', id='café', columns=COLUMNS, key='id')
            self.assertEqual(schema['revision'], 1)
            rejects(lambda: c('schema.put', id='bad', columns=COLUMNS, key='qty'))
            rejects(lambda: c('job.create', id='bad', schema='café', csv='qty,id,cost\n'))
            raw = 'id,qty,cost\n a ,1e2,1.00\n a ,+002,0.29\na,3,2\n"é\nx",-7,9007199254740993.01\nb,,1.2\nc,1,-1\nd,1,1.234\ne,1\nf,1,2,3\n'
            c('job.create', id='j', schema='café', csv=raw)
            changed = copy.deepcopy(COLUMNS)
            changed[1]['type'] = 'text'
            self.assertEqual(c('schema.put', id='café', columns=changed, key='id')['revision'], 2)
            result = c('job.run', id='j', key='run1')
            self.assertEqual(result['schema_revision'], 1)
            self.assertEqual(result['rows'], [{'id': 'a', 'qty': 2, 'cost': 29}, {'id': 'é\nx', 'qty': -7, 'cost': 900719925474099301}, {'id': 'b', 'qty': None, 'cost': 120}])
            self.assertEqual((result['accepted'], result['rejected']), (3, 6))
            self.assertEqual([r['row'] for r in result['rejects']], [2, 4, 8, 9, 10, 11])
            self.assertTrue(all(r['reason'] for r in result['rejects']))
            self.assertEqual(c('job.run', id='j', key='run1'), result)
            rejects(lambda: c('job.run', id='j', key='new'))
            rejects(lambda: c('job.publish', id='j', expected_revision=True))
            rejects(lambda: c('job.publish', id='j', expected_revision=2))
            exported = list(csv.reader(io.StringIO(c('job.export', id='j'))))
            self.assertEqual(exported[1:], [['a', '2', '29'], ['é\nx', '-7', '900719925474099301'], ['b', '', '120']])
            before = c('backup')
            self.assertEqual(c('job.publish', id='j', expected_revision=1)['revision'], 2)
            self.assertEqual(c('dataset.get', schema='café'), {'job': 'j', 'rows': result['rows'], 'schema_revision': 1})
            self.assertEqual(c('job.get', id='j')['csv'], raw)
            rejects(lambda: c('job.publish', id='j', expected_revision=1))
            rejects(lambda: c('job.retry', id='j', csv='id,qty,cost\nx,2,3\n'))
            c('restore', state=before)
            rejects(lambda: c('dataset.get', schema='café'))
            rejects(lambda: c('job.retry', id='j', csv='wrong\n'))
            self.assertEqual(c('job.retry', id='j', csv='id,qty,cost\nx,2,3\n')['status'], 'draft')
            self.assertEqual(c('job.run', id='j', key='run1'), result)
            self.assertEqual(c('job.get', id='j')['status'], 'draft')
            self.assertEqual(c('job.run', id='j', key='run2')['rows'], [{'id': 'x', 'qty': 2, 'cost': 300}])
            rejects(lambda: c('job.import', jobs=[{'id': 'one', 'schema': 'café', 'csv': 'id,qty,cost\n'}, {'id': 'two', 'schema': 'missing', 'csv': ''}]))
            rejects(lambda: c('job.get', id='one'))
            self.assertEqual(c('job.import', jobs=[{'id': 'one', 'schema': 'café', 'csv': 'id,qty,cost\nz,abc,0\n'}]), {'imported': 1})
            rejects(lambda: c('job.run', id='one', key='run1'))
            self.assertEqual(c('job.run', id='one', key='run3')['rows'][0]['qty'], 'abc')
            c('job.publish', id='one', expected_revision=1)
            self.assertEqual(c('dataset.get', schema='café')['schema_revision'], 2)
        self.assertJourney(flow)

    def test_atomic_restore_detachment_and_concurrency(self):
        columns = copy.deepcopy(COLUMNS)
        self.c('schema.put', id='s', columns=columns, key='id')
        columns.clear()
        self.c('job.create', id='j', schema='s', csv='id,qty,cost\na,1,2\n')
        result = self.c('job.run', id='j', key='k')
        result['rows'].clear()
        self.restart()
        self.assertEqual(len(self.c('job.get', id='j')['rows']), 1)
        self.assertRejects('schema.put', id='s', columns=COLUMNS + [COLUMNS[0]], key='id')
        self.assertRejects('job.get', id='missing')
        self.assertRejects('nonsense')
        self.assertCorruptions(lambda b: b.clear(), lambda b: b['state']['jobs']['j']['rows'][0].update(cost=True), lambda b: b['state']['schemas']['s'].update(revision=999), lambda b: b['state']['jobs']['j'].update(accepted=99))
        outcomes = self.race(*[('job.publish', {'id': 'j', 'expected_revision': 1}) for _ in range(3)])
        self.assertEqual(sum(ok for ok, _ in outcomes), 1)
        self.assertEqual(self.c('dataset.get', schema='s')['rows'], [{'id': 'a', 'qty': 1, 'cost': 200}])
        outcomes = self.race(*[('job.create', {'id': str(i), 'schema': 's', 'csv': 'id,qty,cost\n'}) for i in range(3)])
        self.assertEqual(sum(ok for ok, _ in outcomes), 3)
        for i in range(3):
            self.assertEqual(self.c('job.get', id=str(i))['status'], 'draft')
