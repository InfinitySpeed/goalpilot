import copy
from goalpilot_runtime import ReplayService, fields, text, integer, sequence, require, get_record, compare_revision, choice


def banner():
    return 'Local Ops — café'


positive = lambda v: integer(v, 1)
line = lambda v: fields(v, {'description': text, 'quantity': positive, 'unit_cents': integer})
payment = lambda v: fields(v, {'id': text, 'amount': positive, 'key': text})
statuses = choice('draft', 'issued', 'partial', 'paid', 'credited', 'void')


class Service(ReplayService):
    def initial(self):
        return {'customers': {}, 'invoices': {}, 'keys': {}}

    def money(self, state, op, data):
        payment(data)
        prior = state['keys'].get(data['key'])
        if prior is not None:
            require(prior['operation'] == op and prior['request'] == data, 'Idempotency key conflict')
            return copy.deepcopy(prior['result'])
        inv = get_record(state['invoices'], data['id'])
        allowed = ('issued', 'partial') if op == 'invoice.pay' else ('issued', 'partial', 'paid')
        require(inv['status'] in allowed, 'Invoice cannot accept money')
        require(data['amount'] <= inv['balance'], 'Amount exceeds balance')
        field = 'paid' if op == 'invoice.pay' else 'credited'
        inv[field] += data['amount']
        inv['balance'] = inv['total'] - inv['paid'] - inv['credited']
        inv['status'] = ('credited' if inv['paid'] == 0 else 'paid') if inv['balance'] == 0 else 'partial'
        inv['revision'] += 1
        result = copy.deepcopy(inv)
        state['keys'][data['key']] = {'operation': op, 'request': copy.deepcopy(data), 'result': result}
        return copy.deepcopy(result)

    def handle(self, state, op, data):
        customers, invoices = state['customers'], state['invoices']
        if op == 'customer.put':
            fields(data, {'id': text, 'name': text})
            customers[data['id']] = copy.deepcopy(data)
            return customers[data['id']]
        if op == 'customer.list':
            fields(data, {})
            return [customers[k] for k in sorted(customers)]
        if op == 'invoice.create':
            fields(data, {'id': text, 'customer': text, 'lines': sequence(line, nonempty=True),
                          'tax_bps': lambda v: integer(v, 0, 10000)})
            require(data['id'] not in invoices, 'Invoice already exists')
            get_record(customers, data['customer'])
            subtotal = sum(row['quantity'] * row['unit_cents'] for row in data['lines'])
            tax = (subtotal * data['tax_bps'] + 5000) // 10000
            total = subtotal + tax
            result = dict(id=data['id'], customer=data['customer'], status='draft',
                          lines=copy.deepcopy(data['lines']), subtotal=subtotal, tax=tax,
                          total=total, paid=0, credited=0, balance=total, revision=1)
            invoices[data['id']] = result
            return result
        if op == 'invoice.get':
            fields(data, {'id': text})
            return get_record(invoices, data['id'])
        if op == 'invoice.list':
            fields(data, {}, {'customer': text, 'status': statuses})
            if 'customer' in data:
                get_record(customers, data['customer'])
            return [invoices[k] for k in sorted(invoices)
                    if all(invoices[k][f] == v for f, v in data.items())]
        if op in ('invoice.issue', 'invoice.void'):
            fields(data, {'id': text, 'expected_revision': positive})
            inv = get_record(invoices, data['id'])
            compare_revision(inv, data['expected_revision'])
            if op == 'invoice.issue':
                require(inv['status'] == 'draft', 'Only drafts can be issued')
                inv['status'] = 'issued'
            else:
                require(inv['status'] in ('draft', 'issued') and not inv['paid'] and not inv['credited'],
                        'Invoice cannot be voided')
                inv['status'], inv['balance'] = 'void', 0
            inv['revision'] += 1
            return inv
        if op in ('invoice.pay', 'invoice.credit'):
            return self.money(state, op, data)
        if op == 'payment.import':
            fields(data, {'payments': sequence(payment)})
            for row in data['payments']:
                self.money(state, 'invoice.pay', row)
            return {'imported': len(data['payments'])}
        if op == 'statement':
            fields(data, {'customer': text})
            get_record(customers, data['customer'])
            rows = [v for v in invoices.values() if v['customer'] == data['customer'] and v['status'] != 'void']
            return {out: sum(v[src] for v in rows) for out, src in
                    [('invoiced', 'total'), ('paid', 'paid'), ('credited', 'credited'), ('due', 'balance')]}
        raise ValueError('Unknown operation')


if __name__ == '__main__':
    Service.main()
