import copy
import unittest
from app import Service
from goalpilot_support import JourneyMixin, rejects


class Workflows(JourneyMixin, unittest.TestCase):
    def setUp(self):
        self.open_service(Service)

    def test_complete_journey(self):
        def flow(c):
            self.assertEqual(c('customer.put', id='c', name='Café'), {'id': 'c', 'name': 'Café'})
            c('customer.put', id='other', name='Autre')
            self.assertEqual(c('customer.list'), [{'id': 'c', 'name': 'Café'}, {'id': 'other', 'name': 'Autre'}])
            lines = [{'description': 'Écriture', 'quantity': 3, 'unit_cents': 101},
                     {'description': 'Arrondi', 'quantity': 1, 'unit_cents': 2}]
            draft = c('invoice.create', id='i', customer='c', lines=lines, tax_bps=1000)
            self.assertEqual(draft, dict(id='i', customer='c', status='draft', lines=lines,
                                        subtotal=305, tax=31, total=336, paid=0, credited=0, balance=336, revision=1))
            rejects(lambda: c('invoice.pay', id='i', amount=1, key='draft'))
            rejects(lambda: c('invoice.issue', id='i', expected_revision=2))
            issued = c('invoice.issue', id='i', expected_revision=1)
            self.assertEqual((issued['status'], issued['revision']), ('issued', 2))
            p = c('invoice.pay', id='i', amount=100, key='p')
            self.assertEqual((p['paid'], p['balance'], p['status'], p['revision']), (100, 236, 'partial', 3))
            credit = c('invoice.credit', id='i', amount=36, key='cr')
            self.assertEqual((credit['credited'], credit['balance'], credit['revision']), (36, 200, 4))
            self.assertEqual(c('invoice.pay', id='i', amount=100, key='p'), p)
            rejects(lambda: c('invoice.credit', id='i', amount=100, key='p'))
            rejects(lambda: c('invoice.pay', id='i', amount=101, key='p'))
            rejects(lambda: c('payment.import', payments=[{'id': 'i', 'amount': 150, 'key': 'batch'},
                                                         {'id': 'i', 'amount': 51, 'key': 'over'}]))
            self.assertEqual(c('invoice.get', id='i'), credit)
            self.assertEqual(c('payment.import', payments=[{'id': 'i', 'amount': 150, 'key': 'batch'},
                                                          {'id': 'i', 'amount': 50, 'key': 'end'}]), {'imported': 2})
            self.assertEqual(c('payment.import', payments=[{'id': 'i', 'amount': 150, 'key': 'batch'}]), {'imported': 1})
            paid = c('invoice.get', id='i')
            self.assertEqual((paid['paid'], paid['credited'], paid['balance'], paid['status'], paid['revision']),
                             (300, 36, 0, 'paid', 6))
            rejects(lambda: c('invoice.credit', id='i', amount=1, key='overcredit'))
            rejects(lambda: c('invoice.void', id='i', expected_revision=6))
            for ident in ('v', 'z'):
                c('invoice.create', id=ident, customer='c', lines=[{'description': 'A', 'quantity': 1, 'unit_cents': 100}], tax_bps=0)
            c('invoice.issue', id='v', expected_revision=1)
            void = c('invoice.void', id='v', expected_revision=2)
            self.assertEqual((void['status'], void['balance'], void['revision']), ('void', 0, 3))
            rejects(lambda: c('invoice.pay', id='v', amount=1, key='void'))
            c('invoice.issue', id='z', expected_revision=1)
            z = c('invoice.credit', id='z', amount=100, key='allcredit')
            self.assertEqual((z['status'], z['balance'], z['credited']), ('credited', 0, 100))
            rejects(lambda: c('invoice.pay', id='z', amount=1, key='credited'))
            self.assertEqual([r['id'] for r in c('invoice.list', customer='c')], ['i', 'v', 'z'])
            self.assertEqual([r['id'] for r in c('invoice.list', status='paid')], ['i'])
            self.assertEqual(c('statement', customer='c'), {'invoiced': 436, 'paid': 300, 'credited': 136, 'due': 0})
            self.assertEqual(c('statement', customer='other'), {'invoiced': 0, 'paid': 0, 'credited': 0, 'due': 0})
            snapshot = c('backup')
            c('customer.put', id='c', name='Changed')
            c('restore', state=snapshot)
            self.assertEqual(c('backup'), snapshot)
            self.assertEqual(c('invoice.pay', id='i', amount=100, key='p'), p)
            c('customer.put', id='c', name='Après reprise')
            self.assertEqual(len(c('customer.list')), 2)
        self.assertJourney(flow)

    def seed(self, amount=100):
        self.c('customer.put', id='c', name='Café')
        self.c('invoice.create', id='i', customer='c', lines=[{'description': 'x', 'quantity': 1, 'unit_cents': amount}], tax_bps=0)
        self.c('invoice.issue', id='i', expected_revision=1)

    def test_rejections_detachment_and_restore(self):
        self.seed()
        for value in (True, 1.0, '1', 0, -1):
            self.assertRejects('invoice.pay', id='i', amount=value, key='bad')
        for value in (True, 1.0, '1', -1, 10001):
            self.assertRejects('invoice.create', id='bad', customer='c', lines=[{'description': 'x', 'quantity': 1, 'unit_cents': 1}], tax_bps=value)
        for data in ({'id': 'x', 'customer': 'missing', 'lines': [{'description': 'x', 'quantity': 1, 'unit_cents': 1}], 'tax_bps': 0},
                     {'id': 'x', 'customer': 'c', 'lines': [], 'tax_bps': 0}):
            self.assertRejects('invoice.create', **data)
        self.assertRejects('unknown')
        self.assertRejects('invoice.get', id='missing')
        self.assertRejects('invoice.get', id='i', extra=1)
        self.assertRejects('invoice.issue', id='i', expected_revision=True)
        request = {'id': 'i', 'amount': 10, 'key': 'one'}
        saved = copy.deepcopy(request)
        result = self.service.call('invoice.pay', request)
        self.assertEqual(request, saved)
        result['lines'][0]['description'] = 'mutated'
        result['paid'] = 999
        self.assertEqual(self.c('invoice.get', id='i')['paid'], 10)
        backup = self.c('backup')
        self.assertCorruptions(
            lambda b: b['state']['customers'].clear(),
            lambda b: b['state']['invoices']['i'].__setitem__('total', 101),
            lambda b: b['state']['invoices']['i'].__setitem__('revision', 0),
            lambda b: b['state']['invoices']['i'].__setitem__('status', 'paid'),
            lambda b: b['state']['keys']['one']['result'].__setitem__('paid', 999),
            lambda b: b['events'][0]['data'].__setitem__('name', 'tampered'),
            lambda b: b['events'].clear())
        self.assertRejects('restore', state={})
        self.restart()
        self.assertEqual(self.c('backup'), backup)
        self.c('invoice.credit', id='i', amount=90, key='restored')
        self.assertEqual(self.c('invoice.get', id='i')['status'], 'paid')
        self.c('restore', state=backup)
        self.assertEqual(self.c('invoice.get', id='i')['balance'], 90)
        self.assertEqual(self.c('invoice.pay', **request)['paid'], 10)
        self.c('invoice.pay', id='i', amount=90, key='finish')

    def test_concurrent_limits_and_revisions(self):
        self.seed()
        outcomes = self.race(*[('invoice.pay', {'id': 'i', 'amount': 60, 'key': str(n)}) for n in range(4)])
        self.assertEqual(sum(ok for ok, _ in outcomes), 1)
        self.assertEqual(self.c('invoice.get', id='i')['balance'], 40)
        self.c('invoice.create', id='draft', customer='c', lines=[{'description': 'x', 'quantity': 1, 'unit_cents': 0}], tax_bps=0)
        outcomes = self.race(('invoice.issue', {'id': 'draft', 'expected_revision': 1}),
                             ('invoice.void', {'id': 'draft', 'expected_revision': 1}))
        self.assertEqual(sum(ok for ok, _ in outcomes), 1)
        self.assertEqual(self.c('invoice.get', id='draft')['revision'], 2)

    def test_zero_and_large_integer_money(self):
        self.c('customer.put', id='c', name='C')
        for ident, cents, tax in [('zero', 0, 10000), ('large', 10**25+5, 1000)]:
            r = self.c('invoice.create', id=ident, customer='c', lines=[{'description': 'x', 'quantity': 3, 'unit_cents': cents}], tax_bps=tax)
            self.assertEqual(r['tax'], (3*cents*tax+5000)//10000)
        self.c('invoice.void', id='zero', expected_revision=1)
        self.assertEqual(self.c('invoice.get', id='zero')['balance'], 0)
