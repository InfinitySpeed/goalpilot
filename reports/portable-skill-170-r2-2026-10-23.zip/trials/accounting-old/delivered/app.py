from goalpilot_runtime import ReplayService, fields, text, integer, sequence, choice, require, get_record, compare_revision, idempotent


def banner():
    return 'Local Ops — café'


def line(value):
    fields(value, {'account': text, 'debit': integer, 'credit': integer})
    require((value['debit'] > 0) != (value['credit'] > 0), 'One positive side required')


def post(value):
    fields(value, {'id': text, 'date': integer, 'lines': sequence(line, nonempty=True), 'key': text})
    require(len(value['lines']) >= 2, 'At least two lines required')
    require(sum(x['debit'] for x in value['lines']) == sum(x['credit'] for x in value['lines']), 'Unbalanced entry')


class Service(ReplayService):
    def initial(self):
        return {'accounts': {}, 'periods': {}, 'entries': {}, 'keys': {}}

    def period_for(self, state, date):
        periods = [p for p in state['periods'].values() if p['start'] <= date < p['end']]
        require(len(periods) == 1 and periods[0]['status'] == 'open', 'Date must belong to an open period')
        return periods[0]['id']

    def add_entry(self, state, data):
        require(data['id'] not in state['entries'], 'Entry already exists')
        for row in data['lines']:
            get_record(state['accounts'], row['account'])
        entry = dict(id=data['id'], date=data['date'], period=self.period_for(state, data['date']),
                     lines=[dict(row) for row in data['lines']], status='posted', reversal=None)
        state['entries'][entry['id']] = entry
        return entry

    def balance(self, state, account):
        rows = [row for entry in state['entries'].values() for row in entry['lines'] if row['account'] == account]
        debit = sum(row['debit'] for row in rows)
        credit = sum(row['credit'] for row in rows)
        return {'debit': debit, 'credit': credit, 'net': debit-credit}

    def handle(self, state, op, data):
        if op == 'account.create':
            fields(data, {'id': text, 'name': text, 'kind': choice('asset', 'liability', 'income', 'expense')})
            require(data['id'] not in state['accounts'], 'Account already exists')
            state['accounts'][data['id']] = dict(data)
            return state['accounts'][data['id']]
        if op == 'period.create':
            fields(data, {'id': text, 'start': integer, 'end': integer})
            require(data['end'] > data['start'], 'Invalid period range')
            require(data['id'] not in state['periods'], 'Period already exists')
            require(all(data['end'] <= p['start'] or data['start'] >= p['end'] for p in state['periods'].values()), 'Overlapping period')
            period = dict(data, status='open', revision=1)
            state['periods'][data['id']] = period
            return period
        if op in ('period.close', 'period.reopen'):
            fields(data, {'id': text, 'expected_revision': integer})
            period = get_record(state['periods'], data['id'])
            compare_revision(period, data['expected_revision'])
            require(period['status'] == ('open' if op == 'period.close' else 'closed'), 'Invalid period status')
            period['status'] = 'closed' if op == 'period.close' else 'open'
            period['revision'] += 1
            return period
        if op == 'journal.post':
            post(data)
            return idempotent(state, data['key'], op, data, lambda: self.add_entry(state, data))
        if op == 'journal.import':
            fields(data, {'entries': sequence(post)})
            for entry in data['entries']:
                self.handle(state, 'journal.post', entry)
            return {'imported': len(data['entries'])}
        if op == 'journal.reverse':
            fields(data, {'id': text, 'reversal_id': text, 'date': integer, 'key': text})
            def reverse():
                original = get_record(state['entries'], data['id'])
                require(original['status'] == 'posted', 'Already reversed')
                require(not any(e['reversal'] == original['id'] for e in state['entries'].values()), 'Cannot reverse a reversal')
                result = self.add_entry(state, dict(id=data['reversal_id'], date=data['date'], lines=[dict(account=x['account'], debit=x['credit'], credit=x['debit']) for x in original['lines']]))
                original['status'] = 'reversed'
                original['reversal'] = result['id']
                return result
            return idempotent(state, data['key'], op, data, reverse)
        if op == 'journal.get':
            fields(data, {'id': text})
            return get_record(state['entries'], data['id'])
        if op == 'journal.list':
            fields(data, {}, optional={'period': text, 'account': text})
            if 'period' in data:
                get_record(state['periods'], data['period'])
            if 'account' in data:
                get_record(state['accounts'], data['account'])
            return sorted((e for e in state['entries'].values() if ('period' not in data or e['period'] == data['period']) and ('account' not in data or any(x['account'] == data['account'] for x in e['lines']))), key=lambda e: (e['date'], e['id']))
        if op == 'account.balance':
            fields(data, {'id': text})
            get_record(state['accounts'], data['id'])
            return self.balance(state, data['id'])
        if op == 'trial_balance':
            fields(data, {})
            return [dict(account=a, **self.balance(state, a)) for a in sorted(state['accounts'])]
        raise ValueError('Unknown operation')


if __name__ == '__main__':
    Service.main()
