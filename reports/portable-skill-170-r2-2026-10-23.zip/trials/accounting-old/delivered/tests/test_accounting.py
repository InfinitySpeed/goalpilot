import copy
import unittest
from app import Service
from goalpilot_support import JourneyMixin, rejects


def entry(id='j', date=1, key='k', amount=123456789012345678901):
    return dict(id=id, date=date, key=key, lines=[dict(account='cash', debit=amount, credit=0), dict(account='sales', debit=0, credit=amount)])


class Accounting(JourneyMixin, unittest.TestCase):
    def setUp(self):
        self.open_service(Service)

    def seed(self):
        for id, kind in [('cash', 'asset'), ('sales', 'income')]:
            self.c('account.create', id=id, name='café '+id, kind=kind)
        self.c('period.create', id='p', start=0, end=10)

    def test_journey(self):
        def flow(c):
            for id, kind in [('cash', 'asset'), ('sales', 'income'), ('zero', 'expense')]:
                self.assertEqual(c('account.create', id=id, name='café '+id, kind=kind)['id'], id)
            self.assertEqual(c('period.create', id='p', start=0, end=10), dict(id='p', start=0, end=10, status='open', revision=1))
            rejects(lambda: c('period.create', id='bad', start=9, end=11))
            posted = c('journal.post', **entry())
            self.assertEqual(posted, dict(id='j', date=1, period='p', lines=entry()['lines'], status='posted', reversal=None))
            self.assertEqual(c('account.balance', id='cash'), dict(debit=entry()['lines'][0]['debit'], credit=0, net=entry()['lines'][0]['debit']))
            rejects(lambda: c('journal.post', **entry(id='conflict')))
            self.assertEqual(c('period.close', id='p', expected_revision=1)['revision'], 2)
            rejects(lambda: c('journal.post', **entry(id='late', key='late')))
            rejects(lambda: c('journal.reverse', id='j', reversal_id='r', date=2, key='r'))
            rejects(lambda: c('period.reopen', id='p', expected_revision=1))
            self.assertEqual(c('period.reopen', id='p', expected_revision=2)['revision'], 3)
            reversal = c('journal.reverse', id='j', reversal_id='r', date=2, key='r')
            self.assertEqual(reversal['lines'], [dict(account=x['account'], debit=x['credit'], credit=x['debit']) for x in entry()['lines']])
            self.assertEqual(c('journal.reverse', id='j', reversal_id='r', date=2, key='r'), reversal)
            self.assertEqual(c('journal.post', **entry()), posted)
            self.assertEqual(c('journal.get', id='j')['status'], 'reversed')
            rejects(lambda: c('journal.reverse', id='j', reversal_id='r2', date=2, key='r2'))
            rejects(lambda: c('journal.reverse', id='r', reversal_id='r3', date=2, key='r3'))
            self.assertEqual([x['id'] for x in c('journal.list', period='p', account='cash')], ['j', 'r'])
            self.assertEqual([x['net'] for x in c('trial_balance')], [0, 0, 0])
            snapshot = c('backup')
            self.assertEqual(c('journal.import', entries=[entry('b', 3, 'b', 17), entry('a', 3, 'a', 19)]), {'imported': 2})
            self.assertEqual([x['id'] for x in c('journal.list')], ['j', 'r', 'a', 'b'])
            rejects(lambda: c('journal.import', entries=[entry('fresh', 4, 'fresh'), entry('b', 4, 'oops')]))
            self.assertEqual(c('account.balance', id='cash')['net'], 36)
            c('restore', state=snapshot)
            self.assertEqual(c('account.balance', id='cash')['net'], 0)
            c('journal.post', **entry('fresh', 4, 'fresh', 25))
            self.assertEqual(c('account.balance', id='cash')['net'], 25)
        self.assertJourney(flow)

    def test_guards_atomicity_and_detachment(self):
        self.seed()
        for value in [True, 1.5, '1', -1, None]:
            self.assertRejects('journal.post', **entry(date=value))
            bad = entry()
            bad['lines'][0]['debit'] = value
            self.assertRejects('journal.post', **bad)
        for lines in [[], entry()['lines'][:1], [dict(account='cash', debit=1, credit=1), dict(account='sales', debit=0, credit=1)], [dict(account='cash', debit=0, credit=0), dict(account='sales', debit=0, credit=1)], [dict(account='missing', debit=1, credit=0), dict(account='sales', debit=0, credit=1)]]:
            self.assertRejects('journal.post', **dict(entry(), lines=lines))
        self.assertRejects('journal.post', **entry(date=10))
        self.assertRejects('unknown')
        self.assertRejects('account.balance', id='unknown')
        self.assertRejects('account.create', id='cash', name='x', kind='asset')
        self.assertRejects('period.create', id='bad', start=True, end=12)
        payload = entry()
        original = copy.deepcopy(payload)
        result = self.c('journal.post', **payload)
        self.assertEqual(payload, original)
        result['lines'][0]['debit'] = 1
        self.assertEqual(self.c('journal.get', id='j')['lines'], original['lines'])
        backup = self.c('backup')
        self.restart()
        self.assertEqual(self.c('backup'), backup)
        self.assertCorruptions(lambda b: b.clear(), lambda b: b['state']['entries']['j']['lines'][0].update(debit=1), lambda b: b['state']['periods']['p'].update(end=0), lambda b: b['state']['keys'].clear(), lambda b: b['state']['accounts'].pop('cash'))

    def test_concurrent_posts_and_revision(self):
        self.seed()
        outcomes = self.race(*[('journal.post', entry(str(i), 1, str(i), 10)) for i in range(6)])
        self.assertTrue(all(ok for ok, result in outcomes), outcomes)
        self.assertEqual(self.c('account.balance', id='cash')['net'], 60)
        outcomes = self.race(('period.close', dict(id='p', expected_revision=1)), ('period.close', dict(id='p', expected_revision=1)))
        self.assertEqual(sum(ok for ok, result in outcomes), 1)
        self.restart()
        self.assertEqual(len(self.c('journal.list')), 6)
