import copy
import unittest
from app import Service
from goalpilot_support import JourneyMixin, rejects


class Collaboration(JourneyMixin, unittest.TestCase):
    def setUp(self): self.open_service(Service)

    def test_journey(self):
        def flow(c):
            source = {'title': 'café', 'body': ''}
            d = c('document.create', id='d', fields=source)
            self.assertEqual(d, dict(id='d', revision=1, fields=source, status='draft', approved=[], published=0))
            source['title'] = 'caller mutation'
            d['fields']['title'] = 'snapshot mutation'
            self.assertEqual(c('document.get', id='d')['fields']['title'], 'café')
            rejects(lambda: c('document.live', id='d'))
            self.assertEqual(c('document.import', documents=[{'id': 'z', 'fields': {'x': '1'}}]), {'imported': 1})
            rejects(lambda: c('document.import', documents=[{'id': 'a', 'fields': {'x': ''}}, {'id': 'z', 'fields': {'x': ''}}]))
            self.assertEqual(c('document.list'), ['d', 'z'])
            b = c('branch.create', id='b', document='d')
            self.assertEqual(b, dict(id='b', document='d', base_revision=1, revision=1, fields={'title': 'café', 'body': ''}, status='open'))
            c('branch.edit', id='b', expected_revision=1, changes={'title': 'branche'})
            c('document.edit', id='d', expected_revision=1, changes={'body': 'live'})
            merged = c('branch.merge', id='b', expected_revision=2, document_revision=2)
            self.assertEqual(merged['fields'], {'title': 'branche', 'body': 'live'})
            self.assertEqual(merged['revision'], 3)
            self.assertEqual(c('branch.get', id='b')['status'], 'merged')
            rejects(lambda: c('branch.edit', id='b', expected_revision=3, changes={'title': 'bad'}))
            c('branch.create', id='conflict', document='d')
            c('branch.edit', id='conflict', expected_revision=1, changes={'title': 'other'})
            c('document.edit', id='d', expected_revision=3, changes={'title': 'mine'})
            before = c('backup')
            rejects(lambda: c('branch.merge', id='conflict', expected_revision=2, document_revision=4))
            self.assertEqual(c('backup'), before)
            self.assertEqual(c('branch.get', id='conflict')['fields']['title'], 'other')
            c('branch.edit', id='conflict', expected_revision=2, changes={'title': 'mine', 'new': '同じ'})
            self.assertEqual(c('branch.merge', id='conflict', expected_revision=3, document_revision=4)['revision'], 5)
            rejects(lambda: c('document.publish', id='d', expected_revision=5))
            for actor in ['alice', 'alice', 'bob']:
                review = c('document.approve', id='d', actor=actor, expected_revision=5)
                self.assertEqual(review['revision'], 5)
            self.assertEqual(review['approved'], ['alice', 'bob'])
            self.assertEqual(review['status'], 'approved')
            c('document.publish', id='d', expected_revision=5)
            live = c('document.live', id='d')
            snapshot = c('backup')
            edited = c('document.edit', id='d', expected_revision=5, changes={'title': 'next'})
            self.assertEqual((edited['status'], edited['approved'], edited['published']), ('draft', [], 5))
            self.assertEqual(c('document.live', id='d'), live)
            c('restore', state=snapshot)
            self.assertEqual(c('document.get', id='d')['status'], 'published')
            c('document.edit', id='d', expected_revision=5, changes={'title': 'restored edit'})
            self.assertEqual(c('document.get', id='z')['fields'], {'x': '1'})
            for op, data in [('unknown', {}), ('document.get', {'id': 'missing'}),
                             ('document.edit', {'id': 'd', 'expected_revision': True, 'changes': {'x': ''}}),
                             ('document.edit', {'id': 'd', 'expected_revision': 6.0, 'changes': {'x': ''}}),
                             ('document.edit', {'id': 'd', 'expected_revision': 5, 'changes': {'x': ''}}),
                             ('document.create', {'id': '', 'fields': {'a': ''}}),
                             ('document.create', {'id': 'bad', 'fields': {'': ''}}),
                             ('document.edit', {'id': 'd', 'expected_revision': 6, 'changes': {}})]:
                before = c('backup'); rejects(lambda: c(op, **data)); self.assertEqual(c('backup'), before)
        self.assertJourney(flow)

    def test_atomic_races_and_restore(self):
        self.c('document.create', id='d', fields={'a': '0', 'b': '0'})
        results = self.race(*[('document.edit', {'id': 'd', 'expected_revision': 1, 'changes': {'a': str(i)}}) for i in (1, 2)])
        self.assertEqual(sum(ok for ok, _ in results), 1)
        self.restart()
        self.assertEqual(self.c('document.get', id='d')['revision'], 2)
        self.c('branch.create', id='b', document='d')
        self.c('branch.edit', id='b', expected_revision=1, changes={'b': 'branch'})
        results = self.race(('branch.merge', {'id': 'b', 'expected_revision': 2, 'document_revision': 2}),
                            ('document.edit', {'id': 'd', 'expected_revision': 2, 'changes': {'a': 'live'}}))
        self.assertEqual(sum(ok for ok, _ in results), 1)
        d = self.c('document.get', id='d')
        if self.c('branch.get', id='b')['status'] == 'open':
            self.c('branch.merge', id='b', expected_revision=2, document_revision=d['revision'])
            self.assertEqual(self.c('document.get', id='d')['fields'], {'a': 'live', 'b': 'branch'})
        else:
            self.assertEqual(d['fields']['b'], 'branch')
        backup = self.c('backup')
        self.assertRejects('restore', state={})
        for key in ['documents', 'branches', 'history']:
            bad = copy.deepcopy(backup)
            bad['state'][key] = {}
            self.assertRejects('restore', state=bad)
        bad = copy.deepcopy(backup)
        bad['state']['documents']['d']['revision'] = True
        self.assertRejects('restore', state=bad)
        self.assertEqual(self.c('backup'), backup)
