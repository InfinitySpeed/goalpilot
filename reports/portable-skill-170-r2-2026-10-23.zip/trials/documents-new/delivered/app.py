from copy import deepcopy
from goalpilot_runtime import ReplayService, fields, text, integer, mapping, sequence, require, get_record, compare_revision


def banner(): return 'Local Ops — café'


def strings(value):
    require(isinstance(value, dict) and all(isinstance(k, str) and k and isinstance(v, str) for k, v in value.items()))
    return value


def content(value):
    strings(value)
    require(bool(value))
    return value


def create_payload(value):
    return fields(value, {'id': text, 'fields': content})


class Service(ReplayService):
    def initial(self): return {'documents': {}, 'branches': {}, 'history': {}}

    def handle(self, state, op, data):
        docs, branches, history = state['documents'], state['branches'], state['history']
        schemas = {
            'document.create': {'id': text, 'fields': content},
            'document.import': {'documents': sequence(create_payload)},
            'document.list': {},
            'document.get': {'id': text}, 'document.live': {'id': text},
            'document.edit': {'id': text, 'expected_revision': integer, 'changes': content},
            'document.approve': {'id': text, 'actor': text, 'expected_revision': integer},
            'document.publish': {'id': text, 'expected_revision': integer},
            'branch.create': {'id': text, 'document': text},
            'branch.get': {'id': text},
            'branch.edit': {'id': text, 'expected_revision': integer, 'changes': content},
            'branch.merge': {'id': text, 'expected_revision': integer, 'document_revision': integer},
        }
        require(op in schemas, 'Unknown operation')
        fields(data, schemas[op])
        if op == 'document.list': return sorted(docs)
        if op in ('document.create', 'document.import'):
            rows = [data] if op == 'document.create' else data['documents']
            ids = [r['id'] for r in rows]
            require(len(ids) == len(set(ids)) and not any(i in docs for i in ids), 'Duplicate document')
            for r in rows:
                docs[r['id']] = {'id': r['id'], 'revision': 1, 'fields': deepcopy(r['fields']), 'status': 'draft', 'approved': [], 'published': 0}
                history[r['id']] = {}
            return docs[data['id']] if op == 'document.create' else {'imported': len(rows)}
        if op == 'branch.create':
            require(data['id'] not in branches, 'Duplicate branch')
            d = get_record(docs, data['document'])
            b = {'id': data['id'], 'document': d['id'], 'base_revision': d['revision'], 'revision': 1,
                 'fields': deepcopy(d['fields']), 'status': 'open', 'base_fields': deepcopy(d['fields'])}
            branches[b['id']] = b
            return self.branch_view(b)
        if op.startswith('branch.'):
            b = get_record(branches, data['id'])
            if op == 'branch.get': return self.branch_view(b)
            require(b['status'] == 'open', 'Branch closed')
            compare_revision(b, data['expected_revision'])
            if op == 'branch.edit':
                b['fields'].update(data['changes']); b['revision'] += 1
                return self.branch_view(b)
            d = get_record(docs, b['document'])
            compare_revision(d, data['document_revision'])
            changed = {k: v for k, v in b['fields'].items() if k not in b['base_fields'] or b['base_fields'][k] != v}
            for k, v in changed.items():
                require(d['fields'].get(k) == b['base_fields'].get(k) or d['fields'].get(k) == v, 'Field conflict')
            d['fields'].update(changed)
            self.draft(d)
            b['status'] = 'merged'; b['revision'] += 1
            return d
        d = get_record(docs, data['id'])
        if op == 'document.get': return d
        if op == 'document.live':
            require(d['published'] > 0, 'Never published')
            return {'id': d['id'], 'revision': d['published'], 'fields': history[d['id']][str(d['published'])]}
        compare_revision(d, data['expected_revision'])
        if op == 'document.edit':
            d['fields'].update(data['changes']); self.draft(d)
        elif op == 'document.approve':
            require(d['status'] in ('draft', 'approved'), 'Not reviewable')
            d['approved'] = sorted(set(d['approved']) | {data['actor']})
            d['status'] = 'approved' if len(d['approved']) >= 2 else 'draft'
        elif op == 'document.publish':
            require(d['status'] == 'approved', 'Needs two approvals')
            history[d['id']][str(d['revision'])] = deepcopy(d['fields'])
            d['published'] = d['revision']; d['status'] = 'published'
        return d

    @staticmethod
    def draft(d):
        d['revision'] += 1; d['approved'] = []; d['status'] = 'draft'

    @staticmethod
    def branch_view(b): return {k: v for k, v in b.items() if k != 'base_fields'}


if __name__ == '__main__': Service.main()
