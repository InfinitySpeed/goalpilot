import json
from goalpilot_runtime import ReplayService, fields, text, integer, boolean, identifiers, require, get_record


def banner():
    return 'Local Ops — café'


def positive(x):
    return integer(x, minimum=1)


def json_value(value):
    if value is None or type(value) in (str, bool, int):
        return value
    if type(value) is float:
        import math
        require(math.isfinite(value))
        return value
    if type(value) is list:
        for v in value:
            json_value(v)
        return value
    require(type(value) is dict and all(type(k) is str for k in value))
    for v in value.values():
        json_value(v)
    return value


class Service(ReplayService):
    def initial(self):
        return {'datasets': {}, 'annotators': {}}

    def handle(self, state, op, data):
        schemas = {
            'dataset.create': {'id': text, 'labels': lambda v: identifiers(v, nonempty=True), 'reviews': positive},
            'annotator.put': {'id': text, 'active': boolean},
            'item.add': {'dataset': text, 'id': text, 'payload': json_value},
            'claim': {'dataset': text, 'annotator': text, 'now': integer, 'lease': positive},
            'submit': {'dataset': text, 'item': text, 'annotator': text, 'receipt': text, 'now': integer, 'label': text},
            'item.reopen': {'dataset': text, 'id': text, 'expected_revision': positive},
            'item.get': {'dataset': text, 'id': text},
            'item.list': {'dataset': text},
            'history': {'dataset': text, 'id': text},
            'report': {'dataset': text},
            'item.import': {'dataset': text, 'items': lambda v: require(type(v) is list)},
        }
        require(op in schemas, 'Unknown operation')
        fields(data, schemas[op], optional={'status': text} if op == 'item.list' else None)
        datasets = state['datasets']
        if op == 'dataset.create':
            require(data['id'] not in datasets, 'Dataset exists')
            datasets[data['id']] = {'id': data['id'], 'labels': identifiers(data['labels'], nonempty=True), 'reviews': data['reviews'], 'items': {}}
            return {k: datasets[data['id']][k] for k in ('id', 'labels', 'reviews')}
        if op == 'annotator.put':
            state['annotators'][data['id']] = dict(data)
            return dict(data)
        ds = get_record(datasets, data['dataset'])
        items = ds['items']

        def public(item):
            return {k: item[k] for k in ('id', 'dataset', 'payload', 'status', 'votes', 'revision', 'consensus')}

        def add(row):
            require(row['id'] not in items, 'Item exists')
            item = dict(id=row['id'], dataset=ds['id'], payload=row['payload'], status='pending', votes=[], revision=1, consensus=None, claims={}, history=[])
            items[row['id']] = item
            return public(item)

        if op == 'item.add':
            return add(data)
        if op == 'item.import':
            seen = set(items)
            for row in data['items']:
                fields(row, {'id': text, 'payload': json_value})
                require(row['id'] not in seen, 'Duplicate item')
                seen.add(row['id'])
            for row in data['items']:
                add(row)
            return {'imported': len(data['items'])}
        if op == 'item.list':
            status = data.get('status')
            require(status is None or status in ('pending', 'reviewing', 'complete'), 'Unknown status')
            return [public(items[k]) for k in sorted(items) if status is None or items[k]['status'] == status]
        if op == 'report':
            result = dict(pending=0, reviewing=0, complete=0, disputed=0)
            for item in items.values():
                result[item['status']] += 1
                if item['status'] == 'complete' and item['consensus'] is None:
                    result['disputed'] += 1
            return result
        if op in ('claim', 'submit'):
            actor = data['annotator']
            require(get_record(state['annotators'], actor)['active'], 'Inactive annotator')
            now = data['now']
        if op == 'claim':
            for key in sorted(items):
                item = items[key]
                live = {a: c for a, c in item['claims'].items() if now < c['expires']}
                if (item['status'] != 'complete' and len(item['votes']) + len(live) < ds['reviews']
                    and actor not in live and all(v['annotator'] != actor for v in item['votes'])):
                    receipt = self.opaque()
                    expires = now + data['lease']
                    item['claims'] = live
                    item['claims'][actor] = {'receipt': receipt, 'expires': expires}
                    return {'item': public(item), 'receipt': receipt, 'expires': expires}
            return None
        item = get_record(items, data.get('item') if op == 'submit' else data['id'])
        if op == 'item.get':
            return public(item)
        if op == 'history':
            return item['history']
        if op == 'item.reopen':
            require(item['status'] == 'complete', 'Item is not complete')
            require(item['revision'] == data['expected_revision'], 'Revision conflict')
            item['history'].append({'votes': item['votes'], 'consensus': item['consensus']})
            item.update(votes=[], claims={}, consensus=None, status='pending', revision=item['revision'] + 1)
            return public(item)
        require(data['label'] in ds['labels'], 'Unknown label')
        claim = get_record(item['claims'], actor)
        require(claim['receipt'] == data['receipt'] and now < claim['expires'], 'Stale claim')
        require(item['status'] != 'complete' and len(item['votes']) < ds['reviews'], 'Complete item')
        require(all(v['annotator'] != actor for v in item['votes']), 'Duplicate vote')
        item['votes'].append({'annotator': actor, 'label': data['label']})
        item['revision'] += 1
        del item['claims'][actor]
        item['status'] = 'complete' if len(item['votes']) == ds['reviews'] else 'reviewing'
        if item['status'] == 'complete':
            item['consensus'] = data['label'] if all(v['label'] == data['label'] for v in item['votes']) else None
        return public(item)


if __name__ == '__main__':
    Service.main()
