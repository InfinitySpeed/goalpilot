import unittest
from app import Service
from goalpilot_support import JourneyMixin, rejects


class AnnotationTests(JourneyMixin, unittest.TestCase):
    def setUp(self):
        self.open_service(Service)

    def test_journey(self):
        def flow(c):
            c('dataset.create', id='café', labels=['oui', 'non', 'oui'], reviews=2)
            for actor in ['a', 'b', 'c']:
                c('annotator.put', id=actor, active=True)
            item = c('item.add', dataset='café', id='1', payload={'é': [True, None]})
            self.assertEqual(item, dict(id='1', dataset='café', payload={'é': [True, None]}, status='pending', votes=[], revision=1, consensus=None))
            a = c('claim', dataset='café', annotator='a', now=0, lease=5)
            b = c('claim', dataset='café', annotator='b', now=0, lease=10)
            self.assertIsNone(c('claim', dataset='café', annotator='c', now=0, lease=10))
            self.assertIsNone(c('claim', dataset='café', annotator='a', now=1, lease=10))
            replacement = c('claim', dataset='café', annotator='a', now=5, lease=10)
            self.assertNotEqual(a['receipt'], replacement['receipt'])
            rejects(lambda: c('submit', dataset='café', item='1', annotator='a', receipt=a['receipt'], now=5, label='oui'))
            c('annotator.put', id='a', active=False)
            rejects(lambda: c('submit', dataset='café', item='1', annotator='a', receipt=replacement['receipt'], now=6, label='oui'))
            c('annotator.put', id='a', active=True)
            for actor, receipt, label in [('b', b['receipt'], 'non'), ('a', replacement['receipt'], 'oui')]:
                result = c('submit', dataset='café', item='1', annotator=actor, receipt=receipt, now=6, label=label)
            self.assertEqual(result['status'], 'complete')
            self.assertIsNone(result['consensus'])
            self.assertEqual(result['revision'], 3)
            self.assertEqual([v['annotator'] for v in result['votes']], ['b', 'a'])
            self.assertEqual(c('report', dataset='café'), dict(pending=0, reviewing=0, complete=1, disputed=1))
            saved = c('backup')
            rejects(lambda: c('item.reopen', dataset='café', id='1', expected_revision=2))
            c('item.reopen', dataset='café', id='1', expected_revision=3)
            self.assertEqual(c('history', dataset='café', id='1'), [{'votes': result['votes'], 'consensus': None}])
            for actor in ['a', 'b']:
                claim = c('claim', dataset='café', annotator=actor, now=20, lease=10)
                result = c('submit', dataset='café', item='1', annotator=actor, receipt=claim['receipt'], now=21, label='oui')
            self.assertEqual(result['consensus'], 'oui')
            self.assertEqual(result['revision'], 6)
            c('restore', state=saved)
            self.assertEqual(c('item.get', dataset='café', id='1')['revision'], 3)
            self.assertEqual(c('history', dataset='café', id='1'), [])
            self.assertEqual(c('item.import', dataset='café', items=[{'id':'3','payload':3}, {'id':'2','payload':2}]), {'imported':2})
            rejects(lambda: c('item.import', dataset='café', items=[{'id':'4','payload':4}, {'id':'2','payload':2}]))
            self.assertEqual([r['id'] for r in c('item.list', dataset='café', status='pending')], ['2', '3'])
            rejects(lambda: c('dataset.create', id='bad', labels=['x'], reviews=True))
            rejects(lambda: c('claim', dataset='café', annotator='a', now=-1, lease=2))
            rejects(lambda: c('unknown'))
        self.assertJourney(flow)

    def test_atomic_restore_and_detachment(self):
        self.c('dataset.create', id='d', labels=['x'], reviews=1)
        payload = {'list': [1]}
        result = self.c('item.add', dataset='d', id='i', payload=payload)
        payload['list'].append(2)
        result['payload']['list'].append(3)
        self.assertEqual(self.c('item.get', dataset='d', id='i')['payload'], {'list':[1]})
        self.restart()
        self.assertRejects('item.import', dataset='d', items=[{'id':'new','payload':0}, {'id':'i','payload':0}])
        self.assertRejects('restore', state={})
        self.assertCorruptions(lambda b: b['state']['datasets']['d']['items']['i'].update(revision=99),
                               lambda b: b['state']['datasets']['d'].update(reviews=0))
        self.assertEqual(len(self.c('item.list', dataset='d')), 1)

    def test_concurrent_capacity_and_votes(self):
        self.c('dataset.create', id='d', labels=['x'], reviews=2)
        self.c('item.add', dataset='d', id='i', payload=None)
        for actor in ['a','b','c','d']:
            self.c('annotator.put', id=actor, active=True)
        results = self.race(*[('claim', dict(dataset='d', annotator=a, now=0, lease=20)) for a in ['a','b','c','d']])
        claims = [r for ok,r in results if ok and r is not None]
        self.assertEqual(len(claims), 2)
        # Recover claim owners from the persisted state; race results preserve request order.
        submissions = []
        for actor, (ok, result) in zip(['a','b','c','d'], results):
            if ok and result:
                submissions.append(('submit', dict(dataset='d', item='i', annotator=actor, receipt=result['receipt'], now=1, label='x')))
        votes = self.race(*submissions)
        self.assertEqual(sum(ok for ok,_ in votes), 2)
        self.restart()
        self.assertEqual(self.c('item.get', dataset='d', id='i')['consensus'], 'x')
        self.c('annotator.put', id='a', active=False)
        self.restart()
        self.assertRejects('claim', dataset='d', annotator='a', now=30, lease=1)
