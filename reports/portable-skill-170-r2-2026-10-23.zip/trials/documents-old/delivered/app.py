from goalpilot_runtime import ReplayService, require, text, integer, fields


def banner():
    return 'Local Ops — café'


def strings(value):
    require(isinstance(value, dict) and bool(value), 'Expected nonempty fields')
    for key, item in value.items():
        text(key)
        require(isinstance(item, str), 'Field values must be strings')
    return value


def revision(value):
    return integer(value, minimum=1)


class Service(ReplayService):
    def initial(self):
        return {'documents': {}, 'branches': {}, 'published': {}}

    def handle(self, state, op, data):
        docs, branches = state['documents'], state['branches']
        specs = {
            'document.create': {'id': text, 'fields': strings},
            'document.import': {'documents': self.import_rows},
            'document.get': {'id': text}, 'document.live': {'id': text},
            'document.list': {},
            'document.edit': {'id': text, 'expected_revision': revision, 'changes': strings},
            'document.approve': {'id': text, 'actor': text, 'expected_revision': revision},
            'document.publish': {'id': text, 'expected_revision': revision},
            'branch.create': {'id': text, 'document': text},
            'branch.get': {'id': text},
            'branch.edit': {'id': text, 'expected_revision': revision, 'changes': strings},
            'branch.merge': {'id': text, 'expected_revision': revision, 'document_revision': revision},
        }
        require(op in specs, 'Unknown operation')
        fields(data, specs[op])
        if op == 'document.list':
            return sorted(docs)
        if op == 'document.import':
            rows = data['documents']
            ids = [row['id'] for row in rows]
            require(len(ids) == len(set(ids)) and not any(i in docs for i in ids), 'Duplicate document')
            for row in rows:
                self.create(docs, row)
            return {'imported': len(rows)}
        if op == 'document.create':
            return self.create(docs, data)
        if op == 'branch.create':
            require(data['id'] not in branches, 'Duplicate branch')
            doc = self.record(docs, data['document'])
            branch = {'id': data['id'], 'document': doc['id'], 'base_revision': doc['revision'],
                      'revision': 1, 'fields': dict(doc['fields']), 'status': 'open'}
            branches[data['id']] = {'view': branch, 'base': dict(doc['fields'])}
            return branch
        if op.startswith('document.'):
            doc = self.record(docs, data['id'])
            if op == 'document.get':
                return doc
            if op == 'document.live':
                require(doc['published'] > 0, 'Document has never been published')
                return {'id': doc['id'], 'revision': doc['published'],
                        'fields': state['published'][doc['id']][str(doc['published'])]}
            require(doc['revision'] == data['expected_revision'], 'Stale document revision')
            if op == 'document.edit':
                doc['fields'].update(data['changes'])
                self.advance(doc)
            elif op == 'document.approve':
                require(doc['status'] in ('draft', 'approved'), 'Document cannot be reviewed')
                doc['approved'] = sorted(set(doc['approved']) | {data['actor']})
                doc['status'] = 'approved' if len(doc['approved']) >= 2 else 'draft'
            elif op == 'document.publish':
                require(doc['status'] == 'approved', 'Two approvals required')
                state['published'].setdefault(doc['id'], {})[str(doc['revision'])] = dict(doc['fields'])
                doc['published'] = doc['revision']
                doc['status'] = 'published'
            return doc
        entry = self.record(branches, data['id'])
        branch = entry['view']
        if op == 'branch.get':
            return branch
        require(branch['status'] == 'open', 'Branch is closed')
        require(branch['revision'] == data['expected_revision'], 'Stale branch revision')
        if op == 'branch.edit':
            branch['fields'].update(data['changes'])
            branch['revision'] += 1
            return branch
        doc = self.record(docs, branch['document'])
        require(doc['revision'] == data['document_revision'], 'Stale document revision')
        base = entry['base']
        absent = object()
        changes = {key: value for key, value in branch['fields'].items()
                   if base.get(key, absent) != value}
        for key, value in changes.items():
            live = doc['fields'].get(key, absent)
            require(live == base.get(key, absent) or live == value, 'Conflicting field: ' + key)
        doc['fields'].update(changes)
        self.advance(doc)
        branch['status'] = 'merged'
        branch['revision'] += 1
        return doc

    @staticmethod
    def record(records, key):
        require(key in records, 'Missing record')
        return records[key]

    @staticmethod
    def import_rows(rows):
        require(isinstance(rows, list), 'Expected document list')
        for row in rows:
            fields(row, {'id': text, 'fields': strings})
        return rows

    @staticmethod
    def create(docs, data):
        require(data['id'] not in docs, 'Duplicate document')
        doc = {'id': data['id'], 'revision': 1, 'fields': dict(data['fields']),
               'status': 'draft', 'approved': [], 'published': 0}
        docs[data['id']] = doc
        return doc

    @staticmethod
    def advance(doc):
        doc['revision'] += 1
        doc['approved'] = []
        doc['status'] = 'draft'


if __name__ == '__main__':
    Service.main()
