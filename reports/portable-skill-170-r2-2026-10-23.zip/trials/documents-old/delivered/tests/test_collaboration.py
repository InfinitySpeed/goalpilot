import copy
import unittest
from app import Service
from goalpilot_support import JourneyMixin, rejects


class Collaboration(JourneyMixin, unittest.TestCase):
    def setUp(self):
        self.open_service(Service)

    def test_complete_journey(self):
        def flow(c):
            self.assertEqual(c('document.list'), [])
            rejects(lambda: c('document.live', id='missing'))
            original = {'titre': 'café', 'body': 'original'}
            doc = c('document.create', id='d', fields=original)
            self.assertEqual(doc, dict(id='d', revision=1, fields=original,
                                       status='draft', approved=[], published=0))
            c('branch.create', id='b', document='d')
            c('branch.edit', id='b', expected_revision=1, changes={'titre': 'branche'})
            c('document.edit', id='d', expected_revision=1, changes={'body': 'live'})
            doc = c('branch.merge', id='b', expected_revision=2, document_revision=2)
            self.assertEqual(doc['fields'], {'titre': 'branche', 'body': 'live'})
            self.assertEqual(doc['revision'], 3)
            self.assertEqual(c('branch.get', id='b')['status'], 'merged')
            rejects(lambda: c('branch.edit', id='b', expected_revision=3, changes={'x': 'x'}))
            rejects(lambda: c('document.publish', id='d', expected_revision=3))
            c('document.approve', id='d', actor='Zoé', expected_revision=3)
            doc = c('document.approve', id='d', actor='Zoé', expected_revision=3)
            self.assertEqual(doc['approved'], ['Zoé'])
            self.assertEqual(doc['revision'], 3)
            doc = c('document.approve', id='d', actor='Ali', expected_revision=3)
            self.assertEqual(doc['status'], 'approved')
            c('document.publish', id='d', expected_revision=3)
            live = c('document.live', id='d')
            c('document.edit', id='d', expected_revision=3, changes={'titre': 'draft'})
            self.assertEqual(c('document.live', id='d'), live)
            self.assertEqual(c('document.get', id='d')['approved'], [])
            c('branch.create', id='conflict', document='d')
            c('branch.edit', id='conflict', expected_revision=1, changes={'titre': 'other', 'new': 'safe'})
            c('document.edit', id='d', expected_revision=4, changes={'titre': 'winner'})
            before = c('backup')
            rejects(lambda: c('branch.merge', id='conflict', expected_revision=2, document_revision=5))
            self.assertEqual(c('backup'), before)
            c('branch.edit', id='conflict', expected_revision=2, changes={'titre': 'winner'})
            doc = c('branch.merge', id='conflict', expected_revision=3, document_revision=5)
            self.assertEqual(doc['fields']['titre'], 'winner')
            self.assertEqual(doc['fields']['new'], 'safe')
            self.assertEqual(doc['revision'], 6)
            snapshot = c('backup')
            self.assertEqual(c('document.import', documents=[{'id': 'z', 'fields': {'v': ''}},
                                                           {'id': 'a', 'fields': {'v': 'é'}}]), {'imported': 2})
            self.assertEqual(c('document.list'), ['a', 'd', 'z'])
            rejects(lambda: c('document.import', documents=[{'id': 'new', 'fields': {'v': 'x'}},
                                                           {'id': 'd', 'fields': {'v': 'x'}}]))
            self.assertEqual(c('document.list'), ['a', 'd', 'z'])
            c('restore', state=snapshot)
            self.assertEqual(c('document.list'), ['d'])
            self.assertEqual(c('document.live', id='d'), live)
            c('document.edit', id='d', expected_revision=6, changes={'after': 'restore'})
        self.assertJourney(flow)

    def test_guards_and_detachment(self):
        payload = {'id': 'd', 'fields': {'x': 'one'}}
        saved = copy.deepcopy(payload)
        result = self.service.call('document.create', payload)
        self.assertEqual(payload, saved)
        result['fields']['x'] = 'corrupted'
        self.assertEqual(self.c('document.get', id='d')['fields'], {'x': 'one'})
        for value in (True, 1.0, '1', 0, -1, None):
            self.assertRejects('document.edit', id='d', expected_revision=value, changes={'x': 'two'})
        for changes in ({}, {'': 'x'}, {'x': 3}, [], None):
            self.assertRejects('document.edit', id='d', expected_revision=1, changes=changes)
        self.assertRejects('document.create', id='d', fields={'x': 'duplicate'})
        self.assertRejects('document.create', id='', fields={'x': 'bad'})
        self.assertRejects('document.get', id='missing')
        self.assertRejects('unknown')
        self.assertRejects('document.approve', id='d', actor='', expected_revision=1)
        self.assertRejects('document.live', id='d')
        self.assertRejects('document.edit', id='d', expected_revision=2, changes={'x': 'stale'})
        self.assertRejects('restore', state={})
        self.restart()
        self.assertEqual(self.c('document.get', id='d')['fields'], {'x': 'one'})
        backup = self.c('backup')
        backup['state']['documents']['d']['fields']['x'] = 'forged'
        self.assertRejects('restore', state=backup)
        backup = self.c('backup')
        backup['state']['branches']['orphan'] = {'document': 'missing'}
        self.assertRejects('restore', state=backup)

    def test_concurrent_edit_and_merge(self):
        self.c('document.create', id='d', fields={'x': 'old', 'y': 'old'})
        results = self.race(*[('document.edit', {'id': 'd', 'expected_revision': 1,
                                               'changes': {'x': value}}) for value in ('a', 'b')])
        self.assertEqual(sum(ok for ok, _ in results), 1)
        self.assertEqual(self.c('document.get', id='d')['revision'], 2)
        self.c('branch.create', id='b', document='d')
        self.c('branch.edit', id='b', expected_revision=1, changes={'y': 'branch'})
        results = self.race(('branch.merge', {'id': 'b', 'expected_revision': 2, 'document_revision': 2}),
                            ('document.edit', {'id': 'd', 'expected_revision': 2, 'changes': {'x': 'live'}}))
        self.assertEqual(sum(ok for ok, _ in results), 1)
        doc = self.c('document.get', id='d')
        if self.c('branch.get', id='b')['status'] == 'open':
            doc = self.c('branch.merge', id='b', expected_revision=2, document_revision=3)
            self.assertEqual(doc['fields'], {'x': 'live', 'y': 'branch'})
        else:
            self.assertEqual(doc['fields']['y'], 'branch')
