from goalpilot_runtime import ReplayService, require, text, integer, boolean, identifiers, fields, sequence, choice, get_record, compare_revision, idempotent

def banner(): return 'Local Ops — café'

class Service(ReplayService):
 def initial(self): return dict(practitioners={},patients={},appointments={},wait={},keys={})
 def handle(self,s,op,d):
  def schema(required,optional=None): fields(d,required,optional)
  def record(kind,key): return get_record(s[kind],key)
  def interval(v):
   integer(v['start']); integer(v['end']); require(v['end']>v['start'],'Invalid interval')
  def available(a,ignore=None):
   for b in s['appointments'].values():
    if b['id']!=ignore and b['status']!='cancelled' and (a['patient']==b['patient'] or a['practitioner']==b['practitioner']):
     require(a['end']<=b['start'] or b['end']<=a['start'],'Occupied interval')
  if op=='practitioner.put':
   schema({'id':text,'skills':identifiers})
   skills=identifiers(d['skills'])
   require(all(a['skill'] in skills for a in s['appointments'].values() if a['practitioner']==d['id'] and a['status']!='cancelled'),'Referenced skill')
   r=dict(id=d['id'],skills=skills); s['practitioners'][d['id']]=r; return r
  if op=='patient.put':
   schema({'id':text,'consent':boolean}); s['patients'][d['id']]=dict(d); return d
  if op=='appointment.create':
   schema({'id':text,'patient':text,'practitioner':text,'start':integer,'end':integer,'skill':text,'fee':integer,'key':text}); interval(d)
   def create():
    require(d['id'] not in s['appointments'],'Duplicate appointment')
    require(record('patients',d['patient'])['consent'],'Consent required')
    require(d['skill'] in record('practitioners',d['practitioner'])['skills'],'Skill required')
    available(d)
    a={k:v for k,v in d.items() if k!='key'}
    a.update(status='confirmed',revision=1,charged=0); s['appointments'][a['id']]=a; return a
   return idempotent(s,d['key'],op,d,create)
  if op=='appointment.import':
   schema({'appointments':sequence(lambda v: fields(v,{'id':text,'patient':text,'practitioner':text,'start':integer,'end':integer,'skill':text,'fee':integer,'key':text}))})
   for a in d['appointments']: self.handle(s,'appointment.create',a)
   return {'imported':len(d['appointments'])}
  if op in ('appointment.move','appointment.cancel','appointment.finish'):
   spec={'id':text,'expected_revision':integer}
   if op=='appointment.move': spec.update(start=integer,end=integer)
   if op=='appointment.finish': spec['attended']=boolean
   schema(spec); a=record('appointments',d['id']); compare_revision(a,d['expected_revision']); require(a['status']=='confirmed','Appointment is completed')
   if op=='appointment.move':
    interval(d); moved=dict(a,start=d['start'],end=d['end']); available(moved,a['id']); a.update(start=d['start'],end=d['end'])
   elif op=='appointment.cancel': a['status']='cancelled'
   else: a.update(status='attended' if d['attended'] else 'missed',charged=a['fee'] if d['attended'] else a['fee']//2)
   a['revision']+=1; return a
  if op=='appointment.get':
   schema({'id':text}); return record('appointments',d['id'])
  if op=='appointment.list':
   schema({}, {'patient':text,'practitioner':text,'status':choice('confirmed','cancelled','attended','missed')})
   if 'patient' in d: record('patients',d['patient'])
   if 'practitioner' in d: record('practitioners',d['practitioner'])
   return sorted((a for a in s['appointments'].values() if all(a[k]==v for k,v in d.items())),key=lambda a:(a['start'],a['id']))
  if op=='invoice':
   schema({'patient':text}); record('patients',d['patient']); rows=[a for a in s['appointments'].values() if a['patient']==d['patient']]
   return dict(charged=sum(a['charged'] for a in rows),attended=sum(a['status']=='attended' for a in rows),missed=sum(a['status']=='missed' for a in rows))
  if op=='wait.add':
   schema({'id':text,'patient':text,'skill':text}); require(d['id'] not in s['wait'],'Duplicate wait ID'); require(record('patients',d['patient'])['consent'],'Consent required')
   require(not any(w['patient']==d['patient'] and w['skill']==d['skill'] for w in s['wait'].values()),'Duplicate request')
   s['wait'][d['id']]=dict(d); return d
  if op=='wait.list':
   schema({'skill':text}); return [w for w in s['wait'].values() if w['skill']==d['skill']]
  if op=='wait.remove':
   schema({'id':text}); r=record('wait',d['id']); del s['wait'][d['id']]; return r
  raise ValueError('Unknown operation')

if __name__=='__main__': Service.main()
