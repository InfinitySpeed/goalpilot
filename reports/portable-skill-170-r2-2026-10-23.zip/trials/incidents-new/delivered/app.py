from goalpilot_runtime import ReplayService, fields, text, integer, identifiers, require, get_record, compare_revision, idempotent, sequence

def banner():return 'Local Ops — café'

positive=lambda x:integer(x,1)
ids=lambda x:identifiers(x,nonempty=True)
open_schema=dict(id=text,team=text,policy=text,now=integer,title=text,key=text)

class Service(ReplayService):
 def initial(self):return dict(teams={},policies={},incidents={},keys={})
 def public(self,r):
  return {k:r[k] for k in ('id','team','title','status','owner','revision','level','acknowledged','resolved','paused')}
 def elapsed(self,r,now):
  end=r['resolved'] if r['status']=='resolved' else now
  return end-r['start']-r['pause_total']-(end-r['pause_start'] if r['paused'] else 0)
 def inspect(self,r,now):
  require(now>=r['last'])
  e=self.elapsed(r,now); active=r['status']!='resolved'
  return dict(self.public(r),elapsed=e,response_breached=active and r['acknowledged'] is None and e>=r['sla']['response'],resolve_breached=active and e>=r['sla']['resolve'])
 def opening(self,s,d):
  fields(d,open_schema)
  def create():
   require(d['id'] not in s['incidents'])
   get_record(s['teams'],d['team']); p=get_record(s['policies'],d['policy'])
   r=dict(id=d['id'],team=d['team'],title=d['title'],status='open',owner=None,revision=1,level=0,acknowledged=None,resolved=None,paused=False,start=d['now'],last=d['now'],pause_total=0,pause_start=None,sla=dict(p),escalations=[])
   s['incidents'][d['id']]=r
   return self.public(r)
  return idempotent(s,d['key'],'incident.open',d,create)
 def handle(self,s,op,d):
  if op=='team.put':
   fields(d,dict(id=text,members=ids)); members=ids(d['members'])
   require(all(r['owner'] is None or r['owner'] in members for r in s['incidents'].values() if r['team']==d['id'] and r['status']!='resolved'))
   s['teams'][d['id']]=dict(id=d['id'],members=members); return s['teams'][d['id']]
  if op=='policy.put':
   fields(d,dict(id=text,response=positive,resolve=positive)); require(d['resolve']>=d['response'])
   s['policies'][d['id']]=dict(d); return d
  if op=='incident.open':return self.opening(s,d)
  if op=='incident.import':
   fields(d,dict(incidents=sequence(lambda v:fields(v,open_schema))))
   for payload in d['incidents']:self.opening(s,payload)
   return dict(imported=len(d['incidents']))
  if op=='incident.list':
   fields(d,{},dict(team=text,status=text))
   if 'status' in d:require(d['status'] in ('open','acknowledged','resolved'))
   return [self.public(r) for _,r in sorted(s['incidents'].items()) if all(r[k]==v for k,v in d.items())]
  if op=='incident.inspect':
   fields(d,dict(id=text,now=integer)); return self.inspect(get_record(s['incidents'],d['id']),d['now'])
  actions=('incident.assign','incident.ack','incident.pause','incident.resume','incident.resolve','incident.reopen','escalate')
  require(op in actions,'Unknown operation')
  schema=dict(id=text,expected_revision=positive,now=integer)
  if op=='incident.assign':schema['owner']=text
  fields(d,schema); r=get_record(s['incidents'],d['id']); compare_revision(r,d['expected_revision']); now=d['now']; require(now>=r['last'])
  if op=='incident.reopen':
   require(r['status']=='resolved')
   if r['owner'] is not None:require(r['owner'] in s['teams'][r['team']]['members'])
   r.update(status='open',acknowledged=None,resolved=None,paused=False,pause_start=None,pause_total=0,start=now,level=0,escalations=[])
  else:
   require(r['status']!='resolved')
   if op=='incident.assign':
    require(d['owner'] in s['teams'][r['team']]['members']); r['owner']=d['owner']
   elif op=='incident.ack':
    require(r['status']=='open' and r['acknowledged'] is None); r.update(status='acknowledged',acknowledged=now)
   elif op=='incident.pause':
    require(not r['paused']); r.update(paused=True,pause_start=now)
   elif op=='incident.resume':
    require(r['paused']); r['pause_total']+=now-r['pause_start']; r.update(paused=False,pause_start=None)
   elif op=='incident.resolve':
    require(not r['paused']); r.update(status='resolved',resolved=now)
   else:
    view=self.inspect(r,now); e=view['elapsed']; require(view['response_breached'] or view['resolve_breached']); require(e not in r['escalations'])
    r['escalations'].append(e); r['level']+=1
  r['last']=now; r['revision']+=1; return self.public(r)

if __name__=='__main__':Service.main()
