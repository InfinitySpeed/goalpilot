import csv
import io
import re
from copy import deepcopy
from goalpilot_runtime import ReplayService, fields, text, integer, boolean, require, sequence, choice


def banner(): return 'Local Ops — café'


def columns(value):
    sequence(lambda c: fields(c, {'name': text, 'type': choice('text', 'integer', 'money'), 'required': boolean}), nonempty=True)(value)
    require(len({c['name'] for c in value}) == len(value), 'Duplicate columns')


def header(raw, schema):
    reader = csv.reader(io.StringIO(raw, newline=''), strict=True)
    try:
        require(next(reader) == [c['name'] for c in schema['columns']], 'Invalid CSV header')
    except (StopIteration, csv.Error) as e:
        raise ValueError('Invalid CSV header') from e
    return reader


def process(job):
    schema = job['snapshot']
    reader = header(job['csv'], schema)
    rows, rejects, seen = [], [], set()
    while True:
        try:
            cells = next(reader)
        except StopIteration:
            break
        except csv.Error as e:
            rejects.append({'row': reader.line_num, 'reason': str(e) or 'Malformed CSV'})
            continue
        try:
            require(len(cells) == len(schema['columns']), 'Wrong cell count')
            row = {}
            for col, cell in zip(schema['columns'], cells):
                cell = cell.strip()
                require(cell or not col['required'], 'Required cell: ' + col['name'])
                if col['type'] == 'text':
                    value = cell
                elif not cell:
                    value = None
                elif col['type'] == 'integer':
                    require(re.fullmatch(r'[+-]?[0-9]+', cell), 'Invalid integer')
                    value = int(cell)
                else:
                    require(re.fullmatch(r'[0-9]+(?:\.[0-9]{1,2})?', cell), 'Invalid money')
                    whole, _, fraction = cell.partition('.')
                    value = int(whole) * 100 + int((fraction + '00')[:2])
                row[col['name']] = value
            key = row[schema['key']]
            require(key and key not in seen, 'Empty or duplicate primary key')
            seen.add(key)
            rows.append(row)
        except ValueError as e:
            rejects.append({'row': reader.line_num, 'reason': str(e)})
    return dict(id=job['id'], status='processed', accepted=len(rows), rejected=len(rejects), rows=rows, rejects=rejects, schema_revision=schema['revision'])


class Service(ReplayService):
    def initial(self):
        return {'schemas': {}, 'jobs': {}, 'datasets': {}, 'keys': {}}

    def handle(self, state, op, data):
        schemas, jobs = state['schemas'], state['jobs']
        if op == 'schema.put':
            fields(data, {'id': text, 'columns': columns, 'key': text})
            require(any(c['name'] == data['key'] and c['type'] == 'text' and c['required'] for c in data['columns']), 'Key must be required text')
            result = dict(data, revision=schemas.get(data['id'], {}).get('revision', 0) + 1)
            schemas[data['id']] = deepcopy(result)
            return result
        if op in ('job.create', 'job.import'):
            if op == 'job.create':
                entries = [data]
            else:
                fields(data, {'jobs': sequence(lambda v: fields(v, {'id': text, 'schema': text, 'csv': lambda x: require(isinstance(x, str))}))})
                entries = data['jobs']
            created = []
            for entry in entries:
                fields(entry, {'id': text, 'schema': text, 'csv': lambda x: require(isinstance(x, str))})
                require(entry['id'] not in jobs, 'Job already exists')
                require(entry['schema'] in schemas, 'Unknown schema')
                snapshot = deepcopy(schemas[entry['schema']])
                header(entry['csv'], snapshot)
                job = dict(entry, snapshot=snapshot, revision=1, status='draft')
                jobs[entry['id']] = job
                created.append(job)
            return created[0] if op == 'job.create' else {'imported': len(created)}
        if op == 'dataset.get':
            fields(data, {'schema': text})
            require(data['schema'] in state['datasets'], 'No published dataset')
            return state['datasets'][data['schema']]
        specs = {
            'job.get': {'id': text}, 'job.export': {'id': text},
            'job.run': {'id': text, 'key': text},
            'job.retry': {'id': text, 'csv': lambda x: require(isinstance(x, str))},
            'job.publish': {'id': text, 'expected_revision': lambda x: integer(x, minimum=1)},
        }
        require(op in specs, 'Unknown operation')
        fields(data, specs[op])
        if op == 'job.run' and data['key'] in state['keys']:
            prior = state['keys'][data['key']]
            require(prior['request'] == data, 'Idempotency conflict')
            return prior['result']
        require(data['id'] in jobs, 'Unknown job')
        job = jobs[data['id']]
        if op == 'job.get': return job
        if op == 'job.run':
            require(job['status'] == 'draft', 'Job must be draft')
            result = process(job)
            job.update(deepcopy(result))
            state['keys'][data['key']] = {'request': deepcopy(data), 'result': deepcopy(result)}
            return result
        if op == 'job.retry':
            require(job['status'] == 'processed', 'Job must be processed')
            header(data['csv'], job['snapshot'])
            for field in ('accepted', 'rejected', 'rows', 'rejects', 'schema_revision'):
                job.pop(field, None)
            job.update(csv=data['csv'], status='draft')
            return job
        if op == 'job.publish':
            require(job['status'] == 'processed' and job['revision'] == data['expected_revision'], 'Invalid publication revision/status')
            job.update(status='published', revision=2)
            state['datasets'][job['schema']] = {'job': job['id'], 'rows': deepcopy(job['rows']), 'schema_revision': job['schema_revision']}
            return job
        require(job['status'] in ('processed', 'published'), 'Job has no result')
        output = io.StringIO(newline='')
        writer = csv.writer(output)
        names = [c['name'] for c in job['snapshot']['columns']]
        writer.writerow(names)
        writer.writerows([[row[n] if row[n] is not None else '' for n in names] for row in job['rows']])
        return output.getvalue()


if __name__ == '__main__':
    Service.main()
