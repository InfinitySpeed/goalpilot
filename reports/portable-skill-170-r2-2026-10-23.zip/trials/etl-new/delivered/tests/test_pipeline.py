import csv
import io
import unittest
from app import Service
from goalpilot_support import JourneyMixin, rejects

COLS = [{'name': 'id', 'type': 'text', 'required': True}, {'name': 'n', 'type': 'integer', 'required': False}, {'name': 'price', 'type': 'money', 'required': False}]
RAW = 'id,n,price\n a ,bad,1\na,+02,0.29\na,3,2\n"é\nΩ",-4,12345678901234567890.01\nb,,\nc,1,1.001\nd,1\ne,1,2,3\n'

class Pipeline(JourneyMixin, unittest.TestCase):
    def setUp(self): self.open_service(Service)

    def test_journey(self):
        def flow(c):
            schema = c('schema.put', id='s', columns=COLS, key='id')
            self.assertEqual(schema['revision'], 1)
            rejects(lambda: c('schema.put', id='bad', columns=COLS, key='n'))
            rejects(lambda: c('job.create', id='bad', schema='s', csv='n,id,price\n'))
            c('job.create', id='j', schema='s', csv=RAW)
            c('schema.put', id='s', columns=[COLS[0]], key='id')
            r = c('job.run', id='j', key='run')
            self.assertEqual((r['accepted'], r['rejected'], r['schema_revision']), (3, 5, 1))
            self.assertEqual(r['rows'], [{'id': 'a', 'n': 2, 'price': 29}, {'id': 'é\nΩ', 'n': -4, 'price': 1234567890123456789001}, {'id': 'b', 'n': None, 'price': None}])
            self.assertEqual([x['row'] for x in r['rejects']], [2, 4, 8, 9, 10])
            self.assertEqual(c('job.run', id='j', key='run'), r)
            rejects(lambda: c('job.run', id='j', key='different'))
            exported = list(csv.reader(io.StringIO(c('job.export', id='j'))))
            self.assertEqual(exported[2], ['é\nΩ', '-4', '1234567890123456789001'])
            self.assertEqual(c('job.get', id='j')['csv'], RAW)
            c('job.retry', id='j', csv='id,n,price\nz,7,1.20\n')
            self.assertEqual(c('job.run', id='j', key='run'), r)
            self.assertEqual(c('job.get', id='j')['status'], 'draft')
            c('job.run', id='j', key='second')
            rejects(lambda: c('job.publish', id='j', expected_revision=True))
            rejects(lambda: c('job.publish', id='j', expected_revision=2))
            c('job.publish', id='j', expected_revision=1)
            dataset = c('dataset.get', schema='s')
            self.assertEqual(dataset, {'job': 'j', 'rows': [{'id': 'z', 'n': 7, 'price': 120}], 'schema_revision': 1})
            rejects(lambda: c('job.publish', id='j', expected_revision=2))
            rejects(lambda: c('job.retry', id='j', csv='id,n,price\n'))
            snapshot = c('backup')
            rejects(lambda: c('job.import', jobs=[{'id': 'x', 'schema': 's', 'csv': 'id\nx\n'}, {'id': 'y', 'schema': 's', 'csv': 'wrong\n'}]))
            rejects(lambda: c('job.get', id='x'))
            self.assertEqual(c('job.import', jobs=[{'id': 'x', 'schema': 's', 'csv': 'id\nx\n'}]), {'imported': 1})
            c('job.run', id='x', key='x')
            rejects(lambda: c('job.run', id='x', key='run'))
            c('job.publish', id='x', expected_revision=1)
            self.assertEqual(c('dataset.get', schema='s')['job'], 'x')
            c('restore', state=snapshot)
            self.assertEqual(c('dataset.get', schema='s'), dataset)
            c('job.create', id='later', schema='s', csv='id\nlater\n')
        self.assertJourney(flow)

    def test_atomic_restore_and_concurrency(self):
        self.c('schema.put', id='s', columns=COLS, key='id')
        self.c('job.create', id='j', schema='s', csv=RAW)
        self.c('job.run', id='j', key='r')
        self.assertCorruptions(
            lambda b: b['state']['jobs']['j']['rows'][0].update(price=0.29),
            lambda b: b['state']['jobs']['j'].update(accepted=999),
            lambda b: b['state']['schemas']['s'].update(revision=0),
            lambda b: b['state']['datasets'].update(s={'job': 'missing', 'rows': [], 'schema_revision': 1}),
            lambda b: b['state']['keys']['r']['result'].update(rejected=0))
        winners = self.race(*[('job.publish', {'id': 'j', 'expected_revision': 1}) for _ in range(2)])
        self.assertEqual(sum(ok for ok, _ in winners), 1)
        self.restart()
        self.assertEqual(self.c('job.get', id='j')['revision'], 2)
        result = self.c('dataset.get', schema='s')
        result['rows'].clear()
        self.assertEqual(len(self.c('dataset.get', schema='s')['rows']), 3)
        self.assertRejects('schema.put', id='bad', columns=[dict(COLS[0], required=1)], key='id')
        self.assertRejects('job.retry', id='j', csv='wrong\n')
        self.assertRejects('restore', state={})

    def test_exact_lexical_rules(self):
        self.c('schema.put', id='s', columns=COLS, key='id')
        bad = [('1.0', '1'), ('1e2', '1'), ('true', '1'), ('١', '1'), ('1', '-1'), ('1', '1e2'), ('1', '.2'), ('1', '2.000')]
        raw = 'id,n,price\n' + ''.join(f'k{i},{n},{m}\n' for i, (n, m) in enumerate(bad)) + 'ok,-0,0002.01\n'
        self.c('job.create', id='j', schema='s', csv=raw)
        r = self.c('job.run', id='j', key='r')
        self.assertEqual(r['rejected'], len(bad))
        self.assertEqual(r['rows'], [{'id': 'ok', 'n': 0, 'price': 201}])
