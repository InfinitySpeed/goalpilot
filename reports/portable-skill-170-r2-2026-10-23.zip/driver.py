from pathlib import Path
import json,subprocess,sys,time
b=Path('/workspace/goalpilot-research/portable-016');d=b/'paired-180-001';p=json.loads((d/'protocol.json').read_text())
def rows():return [json.loads(f.read_text())for f in(d/'trials').glob('*/result.json')]
def totals(rs):return {'raw':sum(r['usage']['total_tokens']for r in rs),'uncached_plus_output':sum(r['usage']['uncached_tokens']for r in rs),'seconds':sum(r['seconds']for r in rs)}
def stop(why):
 (d/'eliminated.json').write_text(json.dumps({'at':time.time(),'reason':why,'executed':len(rows()),'no_retries':True},indent=2)+'\n');print('STOP',why,flush=True);raise SystemExit(2)
for index,item in enumerate(p['order']):
 for arm in item['arms']:
  rs=rows()
  if any(not r['usage']['usage_complete']for r in rs):stop('Incomplete provider meter')
  if any(not r['success']for r in rs if r['arm']=='new'):stop('Candidate completion failed')
  z=totals(rs)
  if z['raw']>=p['campaign_raw_cap']or z['uncached_plus_output']>=p['campaign_uncached_plus_output_cap']:stop('Research admission cap')
  nz=totals([r for r in rs if r['arm']=='new'])
  if nz['raw']>1417187*1.03 or nz['uncached_plus_output']>325091*1.03 or nz['seconds']>2195.825256901*1.03:stop('Candidate partial cost already exceeds archived full20 safety ceiling')
  trial=d/'trials'/(item['case']+'-'+arm);assert not trial.exists(),'Never restart or replace an outcome'
  print('START',index+1,item['case'],arm,flush=True)
  with(d/('worker-'+item['case']+'-'+arm+'.log')).open('w')as log:
   result=subprocess.run([sys.executable,str(b/'promotion_candidate_worker.py'),'run',d.name,item['case'],arm],stdout=log,stderr=subprocess.STDOUT)
  if not(trial/'result.json').exists():stop('Missing outcome; preserve started evidence')
  r=json.loads((trial/'result.json').read_text());print('RESULT',index+1,r['case'],arm,r['success'],round(r['seconds'],2),r['usage']['total_tokens'],r['usage']['uncached_tokens'],flush=True)
  if result.returncode:stop('Worker error; no retry')
 if index==1:
  v={a:totals([r for r in rows()if r['arm']==a])for a in('old','new')};checks={'correct':all(r['success']for r in rows()),'raw':v['new']['raw']<=v['old']['raw']*.95,'uncached':v['new']['uncached_plus_output']<=v['old']['uncached_plus_output']*.90,'time':v['new']['seconds']<=v['old']['seconds']*1.03};(d/'rapid-screen.json').write_text(json.dumps({'totals':v,'checks':checks,'passed':all(checks.values())},indent=2)+'\n');print('RAPID_SCREEN',checks,flush=True)
  if not all(checks.values()):stop('Fresh rapid screen failed')
print('ALL40_RECORDED',flush=True)
