from pathlib import Path
import json,hashlib,subprocess,sys,time
b=Path('/workspace/goalpilot-research/portable-016');d=b/'paired-180-001';p=json.loads((d/'protocol.json').read_text());amend=json.loads((d/'budget-amendment.json').read_text());halt=json.loads((d/'eliminated.json').read_text());assert halt['reason']=='Research admission cap';assert hashlib.sha256((d/'protocol.json').read_bytes()).hexdigest()==amend['amended_protocol_sha256']
executed=[]
for item in p['order']:
 for arm in item['arms']:
  trial=d/'trials'/(item['case']+'-'+arm)
  if(trial/'result.json').exists():continue
  assert not trial.exists(),'Never restart an already-started trial'
  rows=[json.loads(f.read_text())for f in(d/'trials').glob('*/result.json')]
  assert all(r['usage']['usage_complete']for r in rows);assert all(r['success']for r in rows if r['arm']=='new')
  assert sum(r['usage']['total_tokens']for r in rows)<p['campaign_raw_cap'];assert sum(r['usage']['uncached_tokens']for r in rows)<p['campaign_uncached_plus_output_cap']
  print('RESUME',item['case'],arm,flush=True)
  with(d/('worker-'+item['case']+'-'+arm+'.log')).open('w')as log:r=subprocess.run([sys.executable,str(b/'promotion_candidate_worker.py'),'run',d.name,item['case'],arm],stdout=log,stderr=subprocess.STDOUT)
  assert r.returncode==0 and(trial/'result.json').exists();row=json.loads((trial/'result.json').read_text());print('RESULT',row['case'],arm,row['success'],row['usage']['total_tokens'],row['usage']['uncached_tokens'],flush=True);executed.append(trial.name)
  assert row['usage']['usage_complete']and(arm=='old'or row['success'])
receipt={'at':time.time(),'reason':'Finish only original unstarted callers after old driver admission cap; resource amendment preserves all efficacy conditions and original outcomes.','additional_registered_callers':executed,'total_calls':len(list((d/'trials').glob('*/result.json'))),'no_retries':True};(d/'resource-resume.json').write_text(json.dumps(receipt,indent=2)+'\n');assert receipt['total_calls']==40;print('ALL40_RECORDED',flush=True)
