import hashlib
from copy import deepcopy
from goalpilot_runtime import ReplayService, fields, text, boolean, integer, identifiers, require, get_record


def banner():
    return 'Local Ops — café'


def revision(value):
    return integer(value, minimum=1)


class Service(ReplayService):
    def initial(self):
        return {'environments': {}}

    def handle(self, state, op, data):
        if op == 'environment.create':
            fields(data, {'id': text})
            key = data['id']
            require(key not in state['environments'], 'Environment already exists')
            state['environments'][key] = {'segments': {}, 'flags': {}, 'audit': []}
            return {'id': key}
        schemas = {
            'segment.put': {'environment': text, 'id': text, 'members': identifiers},
            'segment.delete': {'environment': text, 'id': text},
            'flag.create': {'environment': text, 'id': text, 'default': boolean},
            'flag.import': {'environment': text, 'flags': self.import_rows},
            'flag.get': {'environment': text, 'id': text},
            'flag.list': {'environment': text},
            'audit.list': {'environment': text},
            'flag.update': {'environment': text, 'id': text, 'expected_revision': revision,
                            'enabled': boolean, 'rules': self.rules},
            'flag.publish': {'environment': text, 'id': text, 'expected_revision': revision},
            'flag.rollback': {'environment': text, 'id': text, 'expected_revision': revision,
                              'revision': revision},
            'flag.evaluate': {'environment': text, 'id': text, 'user': text},
        }
        require(op in schemas, 'Unknown operation')
        fields(data, schemas[op])
        env = get_record(state['environments'], data['environment'])
        flags = env['flags']
        if op == 'segment.put':
            members = identifiers(data['members'])
            env['segments'][data['id']] = members
            return {'id': data['id'], 'environment': data['environment'], 'members': members}
        if op == 'segment.delete':
            key = data['id']
            get_record(env['segments'], key)
            for entry in flags.values():
                for snapshot in [entry['draft'], *entry['history'].values()]:
                    require(all(r['segment'] != key for r in snapshot['rules']), 'Segment is referenced')
            del env['segments'][key]
            return {'deleted': key}
        if op == 'flag.list':
            return sorted(flags)
        if op == 'audit.list':
            return env['audit']
        if op in ('flag.create', 'flag.import'):
            rows = data['flags'] if op == 'flag.import' else [{'id': data['id'], 'default': data['default']}]
            keys = [row['id'] for row in rows]
            require(len(set(keys)) == len(keys) and all(key not in flags for key in keys), 'Duplicate flag')
            for row in rows:
                draft = dict(id=row['id'], environment=data['environment'], revision=1,
                             published=0, enabled=False, default=row['default'], rules=[])
                flags[row['id']] = {'draft': draft, 'history': {}}
                self.event(env, 'flag.created', draft)
            return {'imported': len(rows)} if op == 'flag.import' else draft
        entry = get_record(flags, data['id'])
        draft, history = entry['draft'], entry['history']
        if op == 'flag.get':
            return draft
        if op == 'flag.evaluate':
            live = history.get(str(draft['published']))
            bucket = int.from_bytes(hashlib.sha256((data['environment'] + '|' + data['id'] + '|' + data['user']).encode('utf-8')).digest()[:8], 'big') % 100
            value = draft['default'] if live is None else live['default']
            if live is not None and live['enabled']:
                for rule in live['rules']:
                    if (rule['segment'] is None or data['user'] in env['segments'][rule['segment']]) and bucket < rule['percent']:
                        value = rule['value']
                        break
            return {'value': value, 'revision': draft['published'], 'bucket': bucket}
        require(draft['revision'] == data['expected_revision'], 'Stale revision')
        if op == 'flag.update':
            for rule in data['rules']:
                require(rule['segment'] is None or rule['segment'] in env['segments'], 'Unknown segment')
            draft.update(revision=draft['revision'] + 1, enabled=data['enabled'], rules=deepcopy(data['rules']))
            self.event(env, 'flag.updated', draft)
        elif op == 'flag.publish':
            if str(draft['revision']) not in history:
                draft['published'] = draft['revision']
                history[str(draft['revision'])] = deepcopy(draft)
                self.event(env, 'flag.published', draft)
        elif op == 'flag.rollback':
            old = get_record(history, str(data['revision']))
            number = draft['revision'] + 1
            draft = deepcopy(old)
            draft.update(revision=number, published=number)
            entry['draft'] = draft
            history[str(number)] = deepcopy(draft)
            self.event(env, 'flag.rolled_back', draft)
        return draft

    @staticmethod
    def rules(value):
        require(isinstance(value, list), 'Rules must be a list')
        for row in value:
            fields(row, {'segment': lambda x: x is None or text(x),
                         'percent': lambda x: integer(x, minimum=0, maximum=100), 'value': boolean})
        return value

    @staticmethod
    def import_rows(value):
        require(isinstance(value, list), 'Flags must be a list')
        for row in value:
            fields(row, {'id': text, 'default': boolean})
        return value

    @staticmethod
    def event(env, kind, draft):
        env['audit'].append({'sequence': len(env['audit']) + 1, 'kind': kind,
                             'flag': draft['id'], 'revision': draft['revision']})


if __name__ == '__main__':
    Service.main()
