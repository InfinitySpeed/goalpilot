import hashlib
import unittest
from app import Service
from goalpilot_support import JourneyMixin, rejects


class Workflows(JourneyMixin, unittest.TestCase):
    def setUp(self):
        self.open_service(Service)

    def test_journey(self):
        def flow(c):
            c('environment.create', id='prod')
            c('environment.create', id='test')
            c('segment.put', environment='prod', id='beta', members=['zoé', 'zoé', 'a'])
            f = c('flag.create', environment='prod', id='café', default=False)
            self.assertEqual(f, dict(id='café', environment='prod', revision=1, published=0, enabled=False, default=False, rules=[]))
            def evaluate(user, value, rev):
                result = c('flag.evaluate', environment='prod', id='café', user=user)
                bucket = int.from_bytes(hashlib.sha256(('prod|café|' + user).encode()).digest()[:8], 'big') % 100
                self.assertEqual(result, dict(value=value, revision=rev, bucket=bucket))
            evaluate('zoé', False, 0)
            rules = [dict(segment='beta', percent=100, value=True), dict(segment=None, percent=0, value=True)]
            c('flag.update', environment='prod', id='café', expected_revision=1, enabled=True, rules=rules)
            evaluate('zoé', False, 0)
            c('flag.publish', environment='prod', id='café', expected_revision=2)
            c('flag.publish', environment='prod', id='café', expected_revision=2)
            evaluate('zoé', True, 2)
            evaluate('outsider', False, 2)
            c('segment.put', environment='prod', id='beta', members=[])
            evaluate('zoé', False, 2)
            c('segment.put', environment='prod', id='beta', members=['zoé'])
            c('flag.update', environment='prod', id='café', expected_revision=2, enabled=False, rules=[])
            evaluate('zoé', True, 2)
            rejects(lambda: c('flag.publish', environment='prod', id='café', expected_revision=2))
            c('flag.publish', environment='prod', id='café', expected_revision=3)
            evaluate('zoé', False, 3)
            c('flag.rollback', environment='prod', id='café', expected_revision=3, revision=2)
            evaluate('zoé', True, 4)
            rejects(lambda: c('segment.delete', environment='prod', id='beta'))
            rejects(lambda: c('flag.rollback', environment='prod', id='café', expected_revision=4, revision=1))
            rejects(lambda: c('flag.update', environment='test', id='café', expected_revision=4, enabled=True, rules=[]))
            c('flag.create', environment='test', id='café', default=True)
            rejects(lambda: c('flag.update', environment='test', id='café', expected_revision=1, enabled=True, rules=rules))
            for bad in [True, 1.5, '2', -1, 101]:
                rejects(lambda: c('flag.update', environment='prod', id='café', expected_revision=4, enabled=True, rules=[dict(segment=None, percent=bad, value=True)]))
            rejects(lambda: c('flag.import', environment='prod', flags=[dict(id='new', default=True), dict(id='café', default=False)]))
            self.assertEqual(c('flag.list', environment='prod'), ['café'])
            self.assertEqual(c('flag.import', environment='prod', flags=[dict(id='z', default=False), dict(id='a', default=True)]), {'imported': 2})
            events = c('audit.list', environment='prod')
            self.assertEqual([e['kind'] for e in events], ['flag.created', 'flag.updated', 'flag.published', 'flag.updated', 'flag.published', 'flag.rolled_back', 'flag.created', 'flag.created'])
            self.assertEqual([e['sequence'] for e in events], list(range(1, 9)))
            snapshot = c('backup')
            c('flag.create', environment='prod', id='temporary', default=False)
            c('restore', state=snapshot)
            self.assertEqual(c('flag.list', environment='prod'), ['a', 'café', 'z'])
            evaluate('zoé', True, 4)
            c('segment.put', environment='prod', id='unused', members=[])
            c('segment.delete', environment='prod', id='unused')
        self.assertJourney(flow)

    def test_atomic_detached_and_race(self):
        self.c('environment.create', id='e')
        self.c('flag.create', environment='e', id='f', default=False)
        rules = [dict(segment=None, percent=50, value=True)]
        self.c('flag.update', environment='e', id='f', expected_revision=1, enabled=True, rules=rules)
        rules[0]['percent'] = 0
        self.assertEqual(self.c('flag.get', environment='e', id='f')['rules'][0]['percent'], 50)
        self.c('flag.publish', environment='e', id='f', expected_revision=2)
        for user in ['a', 'b', 'c', 'é', 'long']:
            bucket = int.from_bytes(hashlib.sha256(('e|f|' + user).encode()).digest()[:8], 'big') % 100
            self.assertEqual(self.c('flag.evaluate', environment='e', id='f', user=user)['value'], bucket < 50)
        self.assertRejects('flag.update', environment='e', id='f', expected_revision=True, enabled=True, rules=[])
        self.assertRejects('flag.update', environment='e', id='f', expected_revision=2, enabled=True, rules=[dict(segment='missing', percent=10, value=True)])
        self.assertCorruptions(lambda b: b['state']['environments']['e']['flags']['f']['draft'].update(revision=99), lambda b: b['state']['environments']['e']['audit'][0].update(sequence=3), lambda b: b['state']['environments']['e']['flags']['f']['history']['2']['rules'][0].update(segment='missing'))
        results = self.race(*[('flag.update', dict(environment='e', id='f', expected_revision=2, enabled=False, rules=[])) for _ in range(3)])
        self.assertEqual(sum(ok for ok, _ in results), 1)
        self.restart()
        self.assertEqual(self.c('flag.get', environment='e', id='f')['revision'], 3)
        snapshot = self.c('backup')
        snapshot['state']['environments'].clear()
        self.assertEqual(self.c('flag.list', environment='e'), ['f'])
