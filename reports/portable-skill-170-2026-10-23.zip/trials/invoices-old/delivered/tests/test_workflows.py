import copy
import os
import sys
import tempfile
import unittest
from app import Service
from goalpilot_support import JourneyMixin, transport_journey


class Workflows(JourneyMixin, unittest.TestCase):
    def setUp(self):
        self.open_service(Service)

    def create(self, id='i'):
        self.c('customer.put', id='c', name='Café')
        return self.c('invoice.create', id=id, customer='c',
                      lines=[{'description': 'Thé', 'quantity': 3, 'unit_cents': 101}], tax_bps=5000)

    def test_money_restore_and_keys(self):
        inv = self.create()
        self.assertSubset(inv, subtotal=303, tax=152, total=455, revision=1)
        self.assertRejects('invoice.pay', id='i', amount=1, key='draft')
        self.assertRejects('invoice.issue', id='i', expected_revision=True)
        self.c('invoice.issue', id='i', expected_revision=1)
        paid = self.c('invoice.pay', id='i', amount=100, key='p')
        saved = self.c('backup')
        self.restart()
        self.assertSubset(self.c('invoice.credit', id='i', amount=355, key='a'),
                          paid=100, credited=355, balance=0, status='paid', revision=4)
        self.assertEqual(self.c('invoice.pay', id='i', amount=100, key='p'), paid)
        self.assertRejects('invoice.credit', id='i', amount=100, key='p')
        self.assertRejects('invoice.pay', id='i', amount=1, key='x')
        self.assertEqual(self.c('statement', customer='c'), {'invoiced':455,'paid':100,'credited':355,'due':0})
        self.c('restore', state=saved)
        self.assertSubset(self.c('invoice.get', id='i'), balance=355, revision=3)
        self.assertCorruptions(lambda b: b['state']['invoices']['i'].__setitem__('total', 9),
                               lambda b: b['state']['customers'].clear(),
                               lambda b: b['state']['keys'].clear())
        self.assertSubset(self.c('invoice.pay', id='i', amount=355, key='end'), status='paid')

    def test_atomic_import_and_void(self):
        self.create()
        self.c('invoice.issue', id='i', expected_revision=1)
        self.assertRejects('payment.import', payments=[{'id':'i','amount':200,'key':'a'}, {'id':'i','amount':300,'key':'b'}])
        self.assertEqual(self.c('payment.import', payments=[{'id':'i','amount':200,'key':'a'}, {'id':'i','amount':255,'key':'b'}]), {'imported':2})
        self.assertRejects('invoice.void', id='i', expected_revision=4)
        self.create('v')
        self.assertSubset(self.c('invoice.void', id='v', expected_revision=1), status='void', balance=0)
        self.create('credit')
        self.c('invoice.issue', id='credit', expected_revision=1)
        self.assertSubset(self.c('invoice.credit', id='credit', amount=455, key='full'), status='credited')
        self.assertEqual([x['id'] for x in self.c('invoice.list')], ['credit','i','v'])
        for value in (True, 1.5, '2', -1):
            self.assertRejects('invoice.create', id='bad', customer='c', lines=[{'description':'x','quantity':value,'unit_cents':10}], tax_bps=0)

    def test_concurrent_payments(self):
        self.create()
        self.c('invoice.issue', id='i', expected_revision=1)
        results = self.race(*[('invoice.pay', {'id':'i','amount':300,'key':k}) for k in ('a','b')])
        self.assertEqual(sum(ok for ok, result in results), 1)
        self.assertSubset(self.c('invoice.get', id='i'), paid=300, balance=155, revision=3)

    def test_transports(self):
        lines = [{'description':'Thé', 'quantity':2, 'unit_cents':125}]
        draft = dict(id='t', customer='é', lines=lines, status='draft', subtotal=250,
                     tax=25, total=275, paid=0, credited=0, balance=275, revision=1)
        issued = dict(draft, status='issued', revision=2)
        paid = dict(issued, status='partial', paid=100, balance=175, revision=3)
        credited = dict(paid, status='paid', credited=175, balance=0, revision=4)
        transport_journey([sys.executable, os.path.abspath('app.py'), '--file', os.path.join(tempfile.mkdtemp(), 'transport.json')], [
            ('customer.put', {'id':'é','name':'Café'}, {'id':'é','name':'Café'}),
            ('customer.list', {}, [{'id':'é','name':'Café'}]),
            ('invoice.create', {'id':'t','customer':'é','lines':lines,'tax_bps':1000}, draft),
            ('invoice.issue', {'id':'t','expected_revision':1}, issued),
            ('invoice.pay', {'id':'t','amount':100,'key':'p'}, paid),
            ('invoice.credit', {'id':'t','amount':175,'key':'a'}, credited),
            ('invoice.get', {'id':'t'}, credited),
            ('statement', {'customer':'é'}, {'invoiced':275,'paid':100,'credited':175,'due':0}),
        ])
