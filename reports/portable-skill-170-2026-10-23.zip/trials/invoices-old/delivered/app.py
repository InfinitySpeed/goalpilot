from goalpilot_runtime import ReplayService, require, text, integer, fields, sequence, get_record, compare_revision, idempotent


def banner():
    return 'Local Ops — café'


def line(value):
    return fields(value, {'description': text, 'quantity': lambda x: integer(x, 1),
                          'unit_cents': integer})


class Service(ReplayService):
    def initial(self):
        return {'customers': {}, 'invoices': {}, 'keys': {}}

    def handle(self, state, op, data):
        customers, invoices = state['customers'], state['invoices']
        if op == 'customer.put':
            fields(data, {'id': text, 'name': text})
            customers[data['id']] = dict(data)
            return customers[data['id']]
        if op == 'customer.list':
            fields(data, {})
            return [customers[k] for k in sorted(customers)]
        if op == 'invoice.create':
            fields(data, {'id': text, 'customer': text, 'lines': sequence(line, nonempty=True),
                          'tax_bps': lambda x: integer(x, 0, 10000)})
            require(data['id'] not in invoices, 'Invoice already exists')
            get_record(customers, data['customer'])
            subtotal = sum(x['quantity'] * x['unit_cents'] for x in data['lines'])
            tax = (subtotal * data['tax_bps'] + 5000) // 10000
            inv = dict(data, status='draft', subtotal=subtotal, tax=tax, total=subtotal + tax,
                       paid=0, credited=0, balance=subtotal + tax, revision=1)
            inv.pop('tax_bps')
            invoices[data['id']] = inv
            return inv
        if op in ('invoice.issue', 'invoice.void'):
            fields(data, {'id': text, 'expected_revision': lambda x: integer(x, 1)})
            inv = get_record(invoices, data['id'])
            compare_revision(inv, data['expected_revision'])
            if op == 'invoice.issue':
                require(inv['status'] == 'draft', 'Only drafts can be issued')
                inv['status'] = 'issued'
            else:
                require(inv['status'] in ('draft', 'issued') and inv['paid'] == inv['credited'] == 0,
                        'Invoice cannot be voided')
                inv.update(status='void', balance=0)
            inv['revision'] += 1
            return inv
        if op in ('invoice.pay', 'invoice.credit'):
            fields(data, {'id': text, 'amount': lambda x: integer(x, 1), 'key': text})
            def apply():
                inv = get_record(invoices, data['id'])
                allowed = ('issued', 'partial') if op == 'invoice.pay' else ('issued', 'partial', 'paid')
                require(inv['status'] in allowed, 'Invalid invoice status')
                require(data['amount'] <= inv['balance'], 'Amount exceeds balance')
                inv['paid' if op == 'invoice.pay' else 'credited'] += data['amount']
                inv['balance'] = inv['total'] - inv['paid'] - inv['credited']
                inv['status'] = ('paid' if inv['paid'] else 'credited') if inv['balance'] == 0 else 'partial'
                inv['revision'] += 1
                return inv
            return idempotent(state, data['key'], op, data, apply)
        if op == 'invoice.get':
            fields(data, {'id': text})
            return get_record(invoices, data['id'])
        if op == 'invoice.list':
            fields(data, {}, {'customer': text, 'status': text})
            if 'customer' in data:
                get_record(customers, data['customer'])
            if 'status' in data:
                require(data['status'] in ('draft', 'issued', 'partial', 'paid', 'credited', 'void'), 'Invalid status')
            return [invoices[k] for k in sorted(invoices)
                    if all(invoices[k][f] == data[f] for f in ('customer', 'status') if f in data)]
        if op == 'payment.import':
            fields(data, {'payments': sequence(lambda x: fields(x, {'id': text, 'amount': lambda v: integer(v, 1), 'key': text}))})
            for payment in data['payments']:
                self.handle(state, 'invoice.pay', payment)
            return {'imported': len(data['payments'])}
        if op == 'statement':
            fields(data, {'customer': text})
            get_record(customers, data['customer'])
            rows = [v for v in invoices.values() if v['customer'] == data['customer']]
            return {'invoiced': sum(v['total'] for v in rows if v['status'] != 'void'),
                    'paid': sum(v['paid'] for v in rows), 'credited': sum(v['credited'] for v in rows),
                    'due': sum(v['balance'] for v in rows)}
        raise ValueError('Unknown operation')


if __name__ == '__main__':
    Service.main()
