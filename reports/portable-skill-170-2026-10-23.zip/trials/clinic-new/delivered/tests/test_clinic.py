import copy
import unittest
from app import Service
from goalpilot_support import JourneyMixin, rejects


class ClinicTests(JourneyMixin, unittest.TestCase):
    def setUp(self):
        self.open_service(Service)

    def seed(self):
        self.c('practitioner.put', id='dr', skills=['soin'])
        self.c('practitioner.put', id='dr2', skills=['soin'])
        for p in ('a', 'b', 'c'):
            self.c('patient.put', id=p, consent=True)

    def payload(self, **kw):
        return dict(dict(id='r', patient='a', practitioner='dr', start=10, end=20,
                         skill='soin', fee=101, key='k'), **kw)

    def test_journey(self):
        def flow(c):
            self.assertEqual(c('practitioner.put', id='médecin', skills=['soin', 'soin']),
                             dict(id='médecin', skills=['soin']))
            for p in ('Ana', 'Béa'):
                c('patient.put', id=p, consent=True)
            d = self.payload(patient='Ana', practitioner='médecin')
            first = c('appointment.create', **d)
            self.assertEqual(first, dict(id='r', patient='Ana', practitioner='médecin',
                start=10, end=20, skill='soin', fee=101, status='confirmed', revision=1, charged=0))
            rejects(lambda: c('appointment.create', **dict(d, id='bad', key='bad', patient='Béa')))
            moved = c('appointment.move', id='r', start=20, end=30, expected_revision=1)
            self.assertEqual((moved['revision'], moved['start']), (2, 20))
            self.assertEqual(c('appointment.create', **d), first)
            rejects(lambda: c('appointment.move', id='r', start=40, end=50, expected_revision=1))
            c('wait.add', id='z', patient='Béa', skill='soin')
            c('wait.add', id='a', patient='Ana', skill='soin')
            self.assertEqual([r['id'] for r in c('wait.list', skill='soin')], ['z', 'a'])
            rejects(lambda: c('wait.add', id='duplicate', patient='Ana', skill='soin'))
            c('wait.remove', id='z')
            c('patient.put', id='Ana', consent=False)
            rejects(lambda: c('appointment.create', **dict(d, id='new', key='new', start=50, end=60)))
            done = c('appointment.finish', id='r', expected_revision=2, attended=False)
            self.assertEqual((done['status'], done['charged'], done['revision']), ('missed', 50, 3))
            self.assertEqual(c('invoice', patient='Ana'), dict(charged=50, attended=0, missed=1))
            rejects(lambda: c('practitioner.put', id='médecin', skills=[]))
            rejects(lambda: c('appointment.create', **dict(d, id='history', key='history', patient='Béa', start=25, end=35)))
            other = dict(d, id='other', key='other', patient='Béa', start=30, end=40)
            c('appointment.create', **other)
            c('appointment.cancel', id='other', expected_revision=1)
            other.update(id='attended', key='attended')
            c('appointment.create', **other)
            c('appointment.finish', id='attended', expected_revision=1, attended=True)
            self.assertEqual(c('invoice', patient='Béa'), dict(charged=101, attended=1, missed=0))
            self.assertEqual([r['id'] for r in c('appointment.list', practitioner='médecin', status='attended')], ['attended'])
            snap = c('backup')
            c('wait.remove', id='a')
            c('restore', state=snap)
            self.assertEqual([r['id'] for r in c('wait.list', skill='soin')], ['a'])
        self.assertJourney(flow)

    def test_atomic_import_validation_and_snapshots(self):
        self.seed()
        d = self.payload()
        for key, value in [('fee', True), ('start', 1.0), ('end', '20'), ('skill', ''), ('key', None)]:
            self.assertRejects('appointment.create', **dict(d, **{key: value}))
        self.assertRejects('patient.put', id='a', consent=1)
        self.assertRejects('appointment.import', appointments=[d, dict(d, id='x', key='x')])
        self.assertEqual(self.c('appointment.list'), [])
        self.assertEqual(self.c('appointment.import', appointments=[d, dict(d, id='x', key='x', start=20, end=30)]), {'imported': 2})
        self.assertRejects('appointment.create', **dict(d, fee=102))
        self.assertRejects('appointment.create', **dict(d, id='y', key='y', practitioner='dr2'))
        self.assertRejects('appointment.move', id='x', start=15, end=25, expected_revision=1)
        self.assertRejects('appointment.finish', id='r', expected_revision=True, attended=True)
        self.assertRejects('appointment.cancel', id='missing', expected_revision=1)
        self.assertRejects('wat')
        snapshot = self.c('appointment.get', id='r')
        snapshot['fee'] = 0
        d['fee'] = 0
        self.restart()
        self.assertEqual(self.c('appointment.get', id='r')['fee'], 101)
        backup = self.c('backup')
        self.assertRejects('restore', state={})
        corrupt = copy.deepcopy(backup)
        corrupt['state']['appointments']['r']['charged'] = 999
        self.assertRejects('restore', state=corrupt)
        corrupt = copy.deepcopy(backup)
        corrupt['state']['patients']['a']['consent'] = 'yes'
        self.assertRejects('restore', state=corrupt)
        self.c('appointment.cancel', id='x', expected_revision=1)
        self.c('restore', state=backup)
        self.assertEqual(self.c('appointment.get', id='x')['status'], 'confirmed')

    def test_concurrent_capacity_and_revision(self):
        self.seed()
        result = self.race(('appointment.create', self.payload()),
                           ('appointment.create', self.payload(id='x', key='x', patient='b')))
        self.assertEqual(sum(ok for ok, _ in result), 1)
        row = self.c('appointment.list')[0]
        result = self.race(('appointment.move', dict(id=row['id'], start=30, end=40, expected_revision=1)),
                           ('appointment.cancel', dict(id=row['id'], expected_revision=1)))
        self.assertEqual(sum(ok for ok, _ in result), 1)
        self.assertEqual(self.c('appointment.get', id=row['id'])['revision'], 2)
        # A different practitioner still cannot reserve the same patient twice.
        result = self.race(('appointment.create', self.payload(id='p1', key='p1', start=100, end=110)),
                           ('appointment.create', self.payload(id='p2', key='p2', practitioner='dr2', start=100, end=110)))
        self.assertEqual(sum(ok for ok, _ in result), 1)
