from goalpilot_runtime import (ReplayService, fields, text, integer, boolean, identifiers,
                                get_record, require, compare_revision, idempotent, choice)


def banner():
    return 'Local Ops — café'


def interval(data):
    integer(data['start'])
    integer(data['end'])
    require(data['end'] > data['start'], 'End must follow start')


CREATE = dict(id=text, patient=text, practitioner=text, start=integer, end=integer,
              skill=text, fee=integer, key=text)


class Service(ReplayService):
    def initial(self):
        return dict(practitioners={}, patients={}, appointments={}, waits={}, keys={})

    def available(self, state, candidate, ignore=None):
        for old in state['appointments'].values():
            if old['id'] == ignore or old['status'] == 'cancelled':
                continue
            if (old['patient'] == candidate['patient'] or
                    old['practitioner'] == candidate['practitioner']):
                require(candidate['end'] <= old['start'] or candidate['start'] >= old['end'],
                        'Appointment overlaps occupied history')

    def create(self, state, data):
        fields(data, CREATE)
        interval(data)
        def commit():
            require(data['id'] not in state['appointments'], 'Appointment already exists')
            patient = get_record(state['patients'], data['patient'])
            practitioner = get_record(state['practitioners'], data['practitioner'])
            require(patient['consent'], 'Patient consent required')
            require(data['skill'] in practitioner['skills'], 'Practitioner lacks skill')
            self.available(state, data)
            row = {k: v for k, v in data.items() if k != 'key'}
            row.update(status='confirmed', revision=1, charged=0)
            state['appointments'][row['id']] = row
            return row
        return idempotent(state, data['key'], 'appointment.create', data, commit)

    def handle(self, state, op, data):
        if op == 'practitioner.put':
            fields(data, dict(id=text, skills=identifiers))
            skills = identifiers(data['skills'])
            for row in state['appointments'].values():
                if row['practitioner'] == data['id'] and row['status'] != 'cancelled':
                    require(row['skill'] in skills, 'Skill used by appointment history')
            row = dict(id=data['id'], skills=skills)
            state['practitioners'][row['id']] = row
            return row
        if op == 'patient.put':
            fields(data, dict(id=text, consent=boolean))
            row = dict(data)
            state['patients'][row['id']] = row
            return row
        if op == 'appointment.create':
            return self.create(state, data)
        if op == 'appointment.import':
            from goalpilot_runtime import sequence
            fields(data, dict(appointments=sequence(lambda x: fields(x, CREATE))))
            for row in data['appointments']:
                self.create(state, row)
            return dict(imported=len(data['appointments']))
        if op in ('appointment.move', 'appointment.cancel', 'appointment.finish'):
            schema = dict(id=text, expected_revision=integer)
            if op.endswith('move'):
                schema.update(start=integer, end=integer)
            if op.endswith('finish'):
                schema.update(attended=boolean)
            fields(data, schema)
            row = get_record(state['appointments'], data['id'])
            compare_revision(row, data['expected_revision'])
            require(row['status'] == 'confirmed', 'Appointment is not confirmed')
            if op.endswith('move'):
                interval(data)
                candidate = dict(row, start=data['start'], end=data['end'])
                self.available(state, candidate, row['id'])
                row.update(start=data['start'], end=data['end'])
            elif op.endswith('cancel'):
                row['status'] = 'cancelled'
            else:
                row['status'] = 'attended' if data['attended'] else 'missed'
                row['charged'] = row['fee'] if data['attended'] else row['fee'] // 2
            row['revision'] += 1
            return row
        if op == 'appointment.get':
            fields(data, dict(id=text))
            return get_record(state['appointments'], data['id'])
        if op == 'appointment.list':
            fields(data, {}, dict(patient=text, practitioner=text,
                                  status=choice('confirmed', 'cancelled', 'attended', 'missed')))
            return sorted((row for row in state['appointments'].values()
                           if all(row[key] == value for key, value in data.items())),
                          key=lambda row: (row['start'], row['id']))
        if op == 'invoice':
            fields(data, dict(patient=text))
            get_record(state['patients'], data['patient'])
            rows = [r for r in state['appointments'].values() if r['patient'] == data['patient']]
            return dict(charged=sum(r['charged'] for r in rows),
                        attended=sum(r['status'] == 'attended' for r in rows),
                        missed=sum(r['status'] == 'missed' for r in rows))
        if op == 'wait.add':
            fields(data, dict(id=text, patient=text, skill=text))
            require(get_record(state['patients'], data['patient'])['consent'], 'Patient consent required')
            require(data['id'] not in state['waits'], 'Wait ID already exists')
            require(not any(r['patient'] == data['patient'] and r['skill'] == data['skill']
                            for r in state['waits'].values()), 'Duplicate wait request')
            state['waits'][data['id']] = dict(data)
            return data
        if op == 'wait.list':
            fields(data, dict(skill=text))
            return [r for r in state['waits'].values() if r['skill'] == data['skill']]
        if op == 'wait.remove':
            fields(data, dict(id=text))
            get_record(state['waits'], data['id'])
            return state['waits'].pop(data['id'])
        raise ValueError('Unknown operation')


if __name__ == '__main__':
    Service.main()
