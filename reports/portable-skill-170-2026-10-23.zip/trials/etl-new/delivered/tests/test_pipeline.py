import copy
import csv
import io
import unittest
from app import Service
from goalpilot_support import JourneyMixin, rejects

COLS = [{'name': 'id', 'type': 'text', 'required': True},
        {'name': 'n', 'type': 'integer', 'required': False},
        {'name': 'price', 'type': 'money', 'required': False}]

class Pipeline(JourneyMixin, unittest.TestCase):
    def setUp(self):
        self.open_service(Service)

    def test_journey(self):
        def flow(c):
            schema = c('schema.put', id='café', columns=COLS, key='id')
            self.assertEqual(schema['revision'], 1)
            rejects(lambda: c('schema.put', id='bad', columns=COLS, key='n'))
            rejects(lambda: c('job.create', id='wrong', schema='café', csv='n,id,price\n'))
            raw = 'id,n,price\na,no,2\na, +2 , 12.30 \na,3,4\nb,,\n"é\nx",-1,0.01\nz,1,1.234\nq,1\nr,1,2,3\n'
            c('job.create', id='one', schema='café', csv=raw)
            c('schema.put', id='café', columns=COLS[:1], key='id')
            result = c('job.run', id='one', key='run1')
            self.assertEqual(result['rows'], [{'id': 'a', 'n': 2, 'price': 1230}, {'id': 'b', 'n': None, 'price': None}, {'id': 'é\nx', 'n': -1, 'price': 1}])
            self.assertEqual((result['accepted'], result['rejected'], result['schema_revision']), (3, 5, 1))
            self.assertEqual([r['row'] for r in result['rejects']], [2, 4, 8, 9, 10])
            self.assertEqual(c('job.run', id='one', key='run1'), result)
            rejects(lambda: c('job.run', id='missing', key='run1'))
            self.assertEqual(list(csv.reader(io.StringIO(c('job.export', id='one'))))[1], ['a', '2', '1230'])
            saved = c('backup')
            c('job.retry', id='one', csv='id,n,price\nnew,7,9.99\n')
            self.assertEqual(c('job.run', id='one', key='run1'), result)
            self.assertEqual(c('job.get', id='one')['status'], 'draft')
            c('job.run', id='one', key='run2')
            rejects(lambda: c('job.publish', id='one', expected_revision=True))
            rejects(lambda: c('job.publish', id='one', expected_revision=2))
            self.assertEqual(c('job.publish', id='one', expected_revision=1)['revision'], 2)
            self.assertEqual(c('dataset.get', schema='café')['rows'][0]['price'], 999)
            rejects(lambda: c('job.retry', id='one', csv='id,n,price\n'))
            rejects(lambda: c('job.publish', id='one', expected_revision=2))
            c('restore', state=saved)
            self.assertEqual(c('job.get', id='one')['csv'], raw)
            rejects(lambda: c('dataset.get', schema='café'))
            rejects(lambda: c('job.import', jobs=[{'id': 'two', 'schema': 'café', 'csv': 'id\nx\n'}, {'id': 'three', 'schema': 'café', 'csv': 'bad\n'}]))
            rejects(lambda: c('job.get', id='two'))
            self.assertEqual(c('job.import', jobs=[{'id': 'two', 'schema': 'café', 'csv': 'id\nx\n'}]), {'imported': 1})
            c('job.run', id='two', key='run3')
            c('job.publish', id='two', expected_revision=1)
            self.assertEqual(c('dataset.get', schema='café'), {'job': 'two', 'rows': [{'id': 'x'}], 'schema_revision': 2})
        self.assertJourney(flow)

    def test_atomic_restore_and_concurrency(self):
        self.c('schema.put', id='s', columns=COLS, key='id')
        self.c('job.create', id='j', schema='s', csv='id,n,price\nx,1,0.10\n')
        self.c('job.run', id='j', key='k')
        self.restart()
        self.assertEqual(self.c('job.get', id='j')['rows'][0]['price'], 10)
        snapshot = self.c('backup')
        self.assertRejects('restore', state={})
        self.assertCorruptions(lambda b: b['state']['jobs']['j']['rows'][0].update(price=999),
                               lambda b: b['state']['schemas']['s'].update(revision=0),
                               lambda b: b['state']['keys']['k']['result'].update(accepted=99))
        outcomes = self.race(*[('job.publish', {'id': 'j', 'expected_revision': 1})] * 2)
        self.assertEqual(sum(ok for ok, _ in outcomes), 1)
        self.assertEqual(self.c('dataset.get', schema='s')['job'], 'j')
        self.c('restore', state=snapshot)
        self.assertEqual(self.c('job.get', id='j')['status'], 'processed')
        got = self.c('job.get', id='j')
        got['rows'].clear()
        self.assertEqual(len(self.c('job.get', id='j')['rows']), 1)
        self.assertRejects('job.retry', id='j', csv='bad\n')
        outcomes = self.race(('schema.put', {'id': 's', 'columns': COLS, 'key': 'id'}), ('schema.put', {'id': 's', 'columns': COLS, 'key': 'id'}))
        self.assertTrue(all(ok for ok, _ in outcomes))
        self.assertEqual(sorted(result['revision'] for ok, result in outcomes), [2, 3])

    def test_numeric_and_schema_guards(self):
        for cols, key in [(COLS + [COLS[0]], 'id'), ([{'name':'id','type':'float','required':True}], 'id'), ([{'name':'id','type':'text','required':1}], 'id')]:
            self.assertRejects('schema.put', id='s', columns=cols, key=key)
        self.c('schema.put', id='s', columns=COLS, key='id')
        raw = 'id,n,price\na,1e2,1\na,1,-1\na,1,1.001\na,1.0,1\na,true,1\na,1,9007199254740993.99\nb,+001,\n,1,2\n'
        self.c('job.create', id='j', schema='s', csv=raw)
        result = self.c('job.run', id='j', key='k')
        self.assertEqual(result['rows'], [{'id': 'a', 'n': 1, 'price': 900719925474099399}, {'id': 'b', 'n': 1, 'price': None}])
        self.assertEqual(result['rejected'], 6)
        self.assertRejects('job.run', id='j', key='other')
        self.assertRejects('unknown')
