import csv
import io
import re
from copy import deepcopy
from goalpilot_runtime import ReplayService, fields, text, integer, boolean, require


def banner():
    return 'Local Ops — café'


def columns(value):
    require(isinstance(value, list) and bool(value), 'Columns required')
    names = []
    for col in value:
        fields(col, {'name': text, 'type': text, 'required': boolean})
        require(col['type'] in ('text', 'integer', 'money'), 'Invalid column type')
        names.append(col['name'])
    require(len(set(names)) == len(names), 'Duplicate columns')


def header(raw, schema):
    reader = csv.reader(io.StringIO(raw, newline=''), strict=True)
    try:
        require(next(reader, None) == [c['name'] for c in schema['columns']], 'Invalid CSV header')
    except csv.Error as exc:
        raise ValueError('Invalid CSV header') from exc
    return reader


def normalize(raw, schema):
    reader = header(raw, schema)
    rows, rejects, seen = [], [], set()
    while True:
        try:
            cells = next(reader)
        except StopIteration:
            break
        except csv.Error:
            rejects.append({'row': reader.line_num, 'reason': 'Malformed CSV'})
            break
        try:
            require(len(cells) == len(schema['columns']), 'Wrong cell count')
            row = {}
            for col, cell in zip(schema['columns'], cells):
                cell = cell.strip()
                require(bool(cell) or not col['required'], 'Required value: ' + col['name'])
                if col['type'] == 'text':
                    value = cell
                elif not cell:
                    value = None
                elif col['type'] == 'integer':
                    require(re.fullmatch(r'[+-]?[0-9]+', cell) is not None, 'Invalid integer: ' + col['name'])
                    value = int(cell)
                else:
                    require(re.fullmatch(r'[0-9]+(?:\.[0-9]{1,2})?', cell) is not None, 'Invalid money: ' + col['name'])
                    whole, _, frac = cell.partition('.')
                    value = int(whole) * 100 + int((frac + '00')[:2])
                row[col['name']] = value
            key = row[schema['key']]
            require(key not in seen, 'Duplicate primary key')
            seen.add(key)
            rows.append(row)
        except ValueError as exc:
            rejects.append({'row': reader.line_num, 'reason': str(exc)})
    return rows, rejects


class Service(ReplayService):
    def initial(self):
        return {'schemas': {}, 'jobs': {}, 'datasets': {}, 'keys': {}}

    def handle(self, state, op, data):
        if op == 'schema.put':
            fields(data, {'id': text, 'columns': columns, 'key': text})
            require(any(c['name'] == data['key'] and c['type'] == 'text' and c['required'] for c in data['columns']), 'Key must be required text')
            previous = state['schemas'].get(data['id'])
            result = dict(deepcopy(data), revision=previous['revision'] + 1 if previous else 1)
            state['schemas'][data['id']] = result
            return result
        if op in ('job.create', 'job.import'):
            if op == 'job.create':
                entries = [data]
            else:
                fields(data, {'jobs': lambda v: require(isinstance(v, list), 'Jobs must be a list')})
                entries = data['jobs']
            created = []
            for entry in entries:
                fields(entry, {'id': text, 'schema': text, 'csv': lambda v: require(isinstance(v, str), 'CSV must be text')})
                require(entry['id'] not in state['jobs'], 'Job already exists')
                require(entry['schema'] in state['schemas'], 'Unknown schema')
                snapshot = deepcopy(state['schemas'][entry['schema']])
                header(entry['csv'], snapshot)
                job = dict(deepcopy(entry), status='draft', revision=1, snapshot=snapshot)
                state['jobs'][entry['id']] = job
                created.append(job)
            return self.public(created[0]) if op == 'job.create' else {'imported': len(created)}
        if op == 'dataset.get':
            fields(data, {'schema': text})
            require(data['schema'] in state['datasets'], 'No publication')
            return state['datasets'][data['schema']]
        if op == 'job.run':
            fields(data, {'id': text, 'key': text})
            if data['key'] in state['keys']:
                prior = state['keys'][data['key']]
                require(prior['operation'] == op and prior['data'] == data, 'Idempotency conflict')
                return prior['result']
            job = self.job(state, data['id'])
            require(job['status'] == 'draft', 'Job must be draft')
            rows, rejects = normalize(job['csv'], job['snapshot'])
            result = {'id': job['id'], 'status': 'processed', 'accepted': len(rows), 'rejected': len(rejects), 'rows': rows, 'rejects': rejects, 'schema_revision': job['snapshot']['revision']}
            job.update(deepcopy(result))
            state['keys'][data['key']] = {'operation': op, 'data': deepcopy(data), 'result': deepcopy(result)}
            return result
        if op == 'job.publish':
            fields(data, {'id': text, 'expected_revision': lambda v: integer(v, minimum=1)})
            job = self.job(state, data['id'])
            require(job['revision'] == data['expected_revision'], 'Revision conflict')
            require(job['status'] == 'processed', 'Job must be processed')
            job.update(status='published', revision=2)
            state['datasets'][job['schema']] = {'job': job['id'], 'rows': deepcopy(job['rows']), 'schema_revision': job['schema_revision']}
            return self.public(job)
        if op == 'job.retry':
            fields(data, {'id': text, 'csv': lambda v: require(isinstance(v, str), 'CSV must be text')})
            job = self.job(state, data['id'])
            require(job['status'] == 'processed', 'Job must be processed')
            header(data['csv'], job['snapshot'])
            for key in ('accepted', 'rejected', 'rows', 'rejects', 'schema_revision'):
                del job[key]
            job.update(csv=data['csv'], status='draft')
            return self.public(job)
        if op in ('job.get', 'job.export'):
            fields(data, {'id': text})
            job = self.job(state, data['id'])
            if op == 'job.get':
                return self.public(job)
            require(job['status'] in ('processed', 'published'), 'Job has no result')
            output = io.StringIO(newline='')
            writer = csv.writer(output)
            names = [c['name'] for c in job['snapshot']['columns']]
            writer.writerow(names)
            for row in job['rows']:
                writer.writerow(['' if row[n] is None else row[n] for n in names])
            return output.getvalue()
        raise ValueError('Unknown operation')

    @staticmethod
    def job(state, ident):
        require(ident in state['jobs'], 'Unknown job')
        return state['jobs'][ident]

    @staticmethod
    def public(job):
        return {k: deepcopy(v) for k, v in job.items() if k != 'snapshot'}


if __name__ == '__main__':
    Service.main()
