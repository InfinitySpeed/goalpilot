from goalpilot_runtime import ReplayService, require, text, integer, get_record, compare_revision


def banner():
    return 'Local Ops — café'


def string_fields(value):
    require(isinstance(value, dict) and bool(value), 'Expected nonempty fields')
    require(all(isinstance(k, str) and k and isinstance(v, str) for k, v in value.items()), 'Invalid fields')
    return dict(value)


class Service(ReplayService):
    def initial(self):
        return {'documents': {}, 'branches': {}}

    def handle(self, state, op, data):
        require(isinstance(data, dict), 'Expected object')
        specs = {
            'document.create': ('id', 'fields'), 'document.edit': ('id', 'expected_revision', 'changes'),
            'document.get': ('id',), 'document.list': (), 'document.live': ('id',),
            'document.approve': ('id', 'actor', 'expected_revision'),
            'document.publish': ('id', 'expected_revision'), 'document.import': ('documents',),
            'branch.create': ('id', 'document'), 'branch.get': ('id',),
            'branch.edit': ('id', 'expected_revision', 'changes'),
            'branch.merge': ('id', 'expected_revision', 'document_revision')}
        require(isinstance(op, str) and op in specs, 'Unknown operation')
        require(set(data) == set(specs[op]), 'Invalid request fields')
        docs, branches = state['documents'], state['branches']
        if op == 'document.list':
            return sorted(docs)
        if op == 'document.import':
            rows = data['documents']
            require(isinstance(rows, list), 'Expected documents list')
            for row in rows:
                self.handle(state, 'document.create', row)
            return {'imported': len(rows)}
        identity = text(data['id'])
        if op == 'document.create':
            require(identity not in docs, 'Document already exists')
            fields = string_fields(data['fields'])
            doc = dict(id=identity, revision=1, fields=fields, status='draft', approved=[], published=0)
            docs[identity] = {'current': doc, 'history': {}}
            return doc
        if op == 'branch.create':
            require(identity not in branches, 'Branch already exists')
            document = text(data['document'])
            doc = get_record(docs, document)['current']
            branch = dict(id=identity, document=document, base_revision=doc['revision'],
                          revision=1, fields=dict(doc['fields']), status='open')
            branches[identity] = {'current': branch, 'base': dict(doc['fields'])}
            return branch
        if op.startswith('document.'):
            entry = get_record(docs, identity)
            doc = entry['current']
            if op == 'document.get':
                return doc
            if op == 'document.live':
                require(doc['published'] > 0, 'Document never published')
                return dict(id=identity, revision=doc['published'], fields=entry['history'][str(doc['published'])])
            compare_revision(doc, integer(data['expected_revision'], minimum=1))
            if op == 'document.edit':
                doc['fields'].update(string_fields(data['changes']))
                self.draft(doc)
            elif op == 'document.approve':
                actor = text(data['actor'])
                require(doc['status'] in ('draft', 'approved'), 'Document is published')
                doc['approved'] = sorted(set(doc['approved']) | {actor})
                doc['status'] = 'approved' if len(doc['approved']) >= 2 else 'draft'
            elif op == 'document.publish':
                require(doc['status'] == 'approved', 'Two approvals required')
                entry['history'][str(doc['revision'])] = dict(doc['fields'])
                doc['published'] = doc['revision']
                doc['status'] = 'published'
            return doc
        entry = get_record(branches, identity)
        branch = entry['current']
        if op == 'branch.get':
            return branch
        require(branch['status'] == 'open', 'Branch is closed')
        compare_revision(branch, integer(data['expected_revision'], minimum=1))
        if op == 'branch.edit':
            branch['fields'].update(string_fields(data['changes']))
            branch['revision'] += 1
            return branch
        doc = docs[branch['document']]['current']
        compare_revision(doc, integer(data['document_revision'], minimum=1))
        base = entry['base']
        changed = {k: v for k, v in branch['fields'].items() if k not in base or base[k] != v}
        for k, v in changed.items():
            live_changed = (k in doc['fields']) != (k in base) or doc['fields'].get(k) != base.get(k)
            require(not live_changed or doc['fields'].get(k) == v, 'Field conflict: ' + k)
        doc['fields'].update(changed)
        self.draft(doc)
        branch['revision'] += 1
        branch['status'] = 'merged'
        return doc

    @staticmethod
    def draft(doc):
        doc['revision'] += 1
        doc['approved'] = []
        doc['status'] = 'draft'


if __name__ == '__main__':
    Service.main()
