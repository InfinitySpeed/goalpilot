import json
import os
import subprocess
import sys
import unittest
from app import Service
from goalpilot_support import JourneyMixin, transport_journey


class Workflows(JourneyMixin, unittest.TestCase):
    def setUp(self):
        self.open_service(Service)

    def create(self):
        return self.c('document.create', id='café', fields={'title': 'Initial', 'body': ''})

    def test_merge_review_publish_history(self):
        self.create()
        self.c('branch.create', id='b', document='café')
        self.c('branch.edit', id='b', expected_revision=1, changes={'title': 'Branche'})
        self.c('document.edit', id='café', expected_revision=1, changes={'body': 'Live'})
        merged = self.c('branch.merge', id='b', expected_revision=2, document_revision=2)
        self.assertEqual(merged['fields'], {'title': 'Branche', 'body': 'Live'})
        self.assertEqual(merged['revision'], 3)
        self.assertRejects('branch.edit', id='b', expected_revision=3, changes={'title': 'lost'})
        self.assertRejects('document.publish', id='café', expected_revision=3)
        for actor in ['Zoé', 'Zoé', 'Ana']:
            result = self.c('document.approve', id='café', actor=actor, expected_revision=3)
            self.assertEqual(result['revision'], 3)
        self.assertEqual(result['approved'], ['Ana', 'Zoé'])
        self.c('document.publish', id='café', expected_revision=3)
        live = self.c('document.live', id='café')
        self.c('document.edit', id='café', expected_revision=3, changes={'title': 'Draft'})
        self.assertEqual(self.c('document.live', id='café'), live)
        self.restart()
        self.assertEqual(self.c('document.live', id='café'), live)
        snapshot = self.c('backup')
        self.c('document.create', id='extra', fields={'x': 'y'})
        self.c('restore', state=snapshot)
        self.assertEqual(self.c('document.list'), ['café'])
        self.assertEqual(self.c('document.get', id='café')['revision'], 4)
        self.c('document.edit', id='café', expected_revision=4, changes={'new': ''})

    def test_conflicts_and_equal_changes(self):
        self.create()
        self.c('branch.create', id='b', document='café')
        self.c('branch.edit', id='b', expected_revision=1, changes={'title': 'Branch', 'new': 'a'})
        self.c('document.edit', id='café', expected_revision=1, changes={'title': 'Other'})
        self.assertRejects('branch.merge', id='b', expected_revision=2, document_revision=2)
        self.assertEqual(self.c('document.get', id='café')['fields']['title'], 'Other')
        self.assertEqual(self.c('branch.get', id='b')['status'], 'open')
        self.c('document.edit', id='café', expected_revision=2, changes={'title': 'Branch'})
        self.assertEqual(self.c('branch.merge', id='b', expected_revision=2, document_revision=3)['fields']['new'], 'a')

    def test_rejections_import_and_detachment(self):
        result = self.create()
        result['fields']['title'] = 'tampered'
        self.assertEqual(self.c('document.get', id='café')['fields']['title'], 'Initial')
        for revision in [True, 1.0, '1', 0, 2]:
            self.assertRejects('document.edit', id='café', expected_revision=revision, changes={'x': 'y'})
        for changes in [{}, {'': 'x'}, {'a': 1}, []]:
            self.assertRejects('document.edit', id='café', expected_revision=1, changes=changes)
        self.assertRejects('document.live', id='café')
        self.assertRejects('document.import', documents=[{'id': 'new', 'fields': {'x': 'y'}}, {'id': 'café', 'fields': {'x': 'z'}}])
        self.assertEqual(self.c('document.list'), ['café'])
        self.assertEqual(self.c('document.import', documents=[{'id': 'a', 'fields': {'x': ''}}]), {'imported': 1})
        self.assertEqual(self.c('document.list'), ['a', 'café'])
        self.assertCorruptions(lambda b: b['state']['documents']['café']['current'].update(revision=100),
                               lambda b: b['state']['documents']['café']['current']['fields'].update(title='forged'),
                               lambda b: b['state']['branches'].update(orphan={}))

    def test_concurrent_edits(self):
        self.create()
        outcomes = self.race(*[('document.edit', dict(id='café', expected_revision=1, changes={'title': v})) for v in ['one', 'two']])
        self.assertEqual(sum(ok for ok, _ in outcomes), 1)
        self.assertEqual(self.c('document.get', id='café')['revision'], 2)

    def test_merge_races_live_edit(self):
        self.create()
        self.c('branch.create', id='b', document='café')
        self.c('branch.edit', id='b', expected_revision=1, changes={'title': 'Branch'})
        outcomes = self.race(
            ('branch.merge', dict(id='b', expected_revision=2, document_revision=1)),
            ('document.edit', dict(id='café', expected_revision=1, changes={'body': 'Live'})))
        self.assertEqual(sum(ok for ok, _ in outcomes), 1)
        doc = self.c('document.get', id='café')
        if outcomes[0][0]:
            self.assertEqual(doc['fields'], {'title': 'Branch', 'body': ''})
            self.c('document.edit', id='café', expected_revision=2, changes={'body': 'Live'})
        else:
            self.assertEqual(doc['fields'], {'title': 'Initial', 'body': 'Live'})
            self.c('branch.merge', id='b', expected_revision=2, document_revision=2)
        self.assertEqual(self.c('document.get', id='café')['fields'], {'title': 'Branch', 'body': 'Live'})

    def test_real_transports(self):
        doc = dict(id='é', revision=1, fields={'x': 'été'}, status='draft', approved=[], published=0)
        transport_journey([sys.executable, os.path.abspath('app.py'), '--file', str(self.path)], [
            ('document.create', {'id': 'é', 'fields': {'x': 'été'}}, doc),
            ('branch.create', {'id': 'b', 'document': 'é'}, dict(id='b', document='é', base_revision=1, revision=1, fields={'x': 'été'}, status='open')),
            ('document.get', {'id': 'é'}, doc),
            ('document.list', {}, ['é'])])

    def test_fresh_process(self):
        self.create()
        packet = json.dumps({'operation': 'document.get', 'data': {'id': 'café'}})
        result = subprocess.run([sys.executable, 'app.py', '--file', str(self.path), 'jsonl'], input=packet+'\n', text=True, capture_output=True, check=True)
        self.assertEqual(json.loads(result.stdout)['result']['fields']['title'], 'Initial')
