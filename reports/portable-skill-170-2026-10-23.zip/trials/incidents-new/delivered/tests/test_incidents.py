import copy
import unittest
from app import Service
from goalpilot_support import JourneyMixin, rejects


class Incidents(JourneyMixin, unittest.TestCase):
    def setUp(self):
        self.open_service(Service)

    def seed(self):
        self.c('team.put', id='équipe', members=['Zoé', 'Ada', 'Ada'])
        self.c('policy.put', id='sla', response=5, resolve=10)

    @staticmethod
    def opening(id='i', **changes):
        return dict(dict(id=id, team='équipe', policy='sla', now=100,
                         title='Panne café', key='key-' + id), **changes)

    def test_journey(self):
        def flow(c):
            self.assertEqual(c('team.put', id='équipe', members=['Zoé', 'Ada', 'Ada']),
                             {'id': 'équipe', 'members': ['Ada', 'Zoé']})
            c('policy.put', id='sla', response=5, resolve=10)
            opened = c('incident.open', **self.opening())
            self.assertEqual(opened, dict(id='i', team='équipe', title='Panne café',
                             status='open', owner=None, revision=1, level=0,
                             acknowledged=None, resolved=None, paused=False))
            c('policy.put', id='sla', response=500, resolve=1000)
            self.assertEqual(c('incident.open', **self.opening()), opened)
            rejects(lambda: c('incident.open', **self.opening(title='conflict')))
            rejects(lambda: c('incident.open', **self.opening(key='different')))
            c('incident.assign', id='i', owner='Ada', now=101, expected_revision=1)
            rejects(lambda: c('team.put', id='équipe', members=['Zoé']))
            rejects(lambda: c('incident.assign', id='i', owner='Zoé', now=102, expected_revision=1))
            c('incident.pause', id='i', now=103, expected_revision=2)
            paused = c('incident.inspect', id='i', now=1000)
            self.assertEqual(paused['elapsed'], 3)
            self.assertFalse(paused['response_breached'])
            rejects(lambda: c('incident.resolve', id='i', now=105, expected_revision=3))
            c('incident.resume', id='i', now=113, expected_revision=3)
            self.assertEqual(c('incident.inspect', id='i', now=114)['elapsed'], 4)
            self.assertTrue(c('incident.inspect', id='i', now=115)['response_breached'])
            r = c('escalate', id='i', now=115, expected_revision=4)
            self.assertEqual((r['level'], r['revision']), (1, 5))
            rejects(lambda: c('escalate', id='i', now=115, expected_revision=5))
            c('incident.ack', id='i', now=116, expected_revision=5)
            self.assertFalse(c('incident.inspect', id='i', now=120)['response_breached'])
            self.assertTrue(c('incident.inspect', id='i', now=120)['resolve_breached'])
            c('escalate', id='i', now=120, expected_revision=6)
            c('incident.resolve', id='i', now=121, expected_revision=7)
            inspected = c('incident.inspect', id='i', now=1000)
            self.assertEqual(inspected['elapsed'], 11)
            self.assertFalse(inspected['resolve_breached'])
            backup = c('backup')
            c('incident.reopen', id='i', now=130, expected_revision=8)
            new = c('incident.inspect', id='i', now=131)
            self.assertEqual((new['elapsed'], new['owner'], new['level'], new['status']),
                             (1, 'Ada', 0, 'open'))
            self.assertIsNone(new['acknowledged'])
            self.assertIsNone(new['resolved'])
            c('restore', state=backup)
            self.assertEqual(c('incident.inspect', id='i', now=1000), inspected)
            c('incident.reopen', id='i', now=140, expected_revision=8)
            self.assertTrue(c('incident.inspect', id='i', now=145)['response_breached'])
            self.assertEqual(len(c('incident.list', team='équipe', status='open')), 1)
            self.assertEqual(c('incident.list', status='resolved'), [])
        self.assertJourney(flow)

    def test_guards_atomic_import_and_snapshots(self):
        self.seed()
        payload = self.opening()
        original = copy.deepcopy(payload)
        result = self.c('incident.open', **payload)
        self.assertEqual(payload, original)
        result['title'] = 'changed'
        self.assertEqual(self.c('incident.list')[0]['title'], 'Panne café')
        for operation, data in [
            ('unknown', {}), ('incident.inspect', {'id': 'missing', 'now': 100}),
            ('incident.inspect', {'id': 'i', 'now': 99}),
            ('incident.inspect', {'id': 'i', 'now': True}),
            ('policy.put', {'id': 'bad', 'response': 2, 'resolve': 1}),
            ('team.put', {'id': 'bad', 'members': []}),
            ('incident.list', {'status': 'bad'}),
            ('incident.open', self.opening('bad', team='missing')),
            ('incident.open', self.opening('bad', now=100.0)),
            ('incident.import', {'incidents': [self.opening('a'), self.opening('b', policy='missing')]}),
            ('incident.import', {'incidents': [self.opening('a'), self.opening('a', key='other')]}),
        ]:
            self.assertRejects(operation, **data)
        for value in [True, 1.0, '1', 0]:
            self.assertRejects('incident.ack', id='i', now=100, expected_revision=value)
        for op in ['incident.resume', 'incident.reopen', 'escalate']:
            self.assertRejects(op, id='i', now=100, expected_revision=1)
        self.assertRejects('incident.assign', id='i', owner='outsider', now=100, expected_revision=1)
        self.assertEqual(self.c('incident.import', incidents=[self.opening('z'), self.opening('a')]),
                         {'imported': 2})
        self.assertEqual([r['id'] for r in self.c('incident.list')], ['a', 'i', 'z'])
        snapshot = self.c('backup')
        snapshot['state']['incidents']['i']['title'] = 'detached'
        self.assertEqual(self.c('incident.list')[1]['title'], 'Panne café')
        self.restart()
        self.assertEqual(len(self.c('incident.list')), 3)

    def test_persisted_history_corruptions(self):
        self.seed()
        self.c('incident.open', **self.opening())
        self.c('escalate', id='i', now=105, expected_revision=1)
        self.c('incident.pause', id='i', now=105, expected_revision=2)
        self.restart()
        self.assertEqual(self.c('incident.inspect', id='i', now=999)['elapsed'], 5)
        self.assertRejects('escalate', id='i', now=999, expected_revision=3)
        self.assertRejects('incident.pause', id='i', now=106, expected_revision=3)
        self.c('incident.resume', id='i', now=110, expected_revision=3)
        self.assertRejects('escalate', id='i', now=110, expected_revision=4)
        self.assertRejects('incident.ack', id='i', now=109, expected_revision=4)
        self.c('incident.ack', id='i', now=111, expected_revision=4)
        self.assertRejects('incident.ack', id='i', now=112, expected_revision=5)
        self.assertRejects('escalate', id='i', now=112, expected_revision=5)
        self.assertCorruptions(
            lambda b: b['state']['incidents']['i'].update(owner='outsider'),
            lambda b: b['state']['incidents']['i'].update(revision=100),
            lambda b: b['state']['incidents']['i'].update(last=0),
            lambda b: b['state']['incidents']['i'].update(pause_total=-1),
            lambda b: b['state']['incidents']['i'].update(status='invalid'),
            lambda b: b['state']['incidents']['i']['policy'].update(response=1),
            lambda b: b['state']['incidents']['i']['escalated'].append(6),
            lambda b: b['state']['teams'].clear(),
            lambda b: b['events'].pop(),
        )
        self.c('incident.resolve', id='i', now=115, expected_revision=5)
        for op in ['incident.ack', 'incident.pause', 'incident.resolve', 'escalate']:
            self.assertRejects(op, id='i', now=116, expected_revision=6)
        self.c('team.put', id='équipe', members=['Zoé'])
        self.c('incident.reopen', id='i', now=116, expected_revision=6)
        self.assertEqual(self.c('incident.inspect', id='i', now=116)['elapsed'], 0)

    def test_concurrent_revisions_and_unrelated_updates(self):
        self.seed()
        self.c('incident.open', **self.opening())
        outcomes = self.race(
            ('incident.assign', dict(id='i', owner='Ada', now=101, expected_revision=1)),
            ('incident.assign', dict(id='i', owner='Zoé', now=101, expected_revision=1)),
        )
        self.assertEqual(sum(accepted for accepted, _ in outcomes), 1)
        self.assertEqual(self.c('incident.inspect', id='i', now=101)['revision'], 2)
        outcomes = self.race(
            ('incident.open', self.opening('x')),
            ('incident.open', self.opening('y')),
        )
        self.assertTrue(all(accepted for accepted, _ in outcomes))
        self.restart()
        self.assertEqual([r['id'] for r in self.c('incident.list')], ['i', 'x', 'y'])
