from goalpilot_runtime import (
    ReplayService, fields, text, integer, identifiers, require,
    get_record, compare_revision, idempotent,
)


def banner():
    return 'Local Ops — café'


def positive(value):
    return integer(value, 1)


class Service(ReplayService):
    def initial(self):
        return {'teams': {}, 'policies': {}, 'incidents': {}, 'keys': {}}

    @staticmethod
    def public(record):
        return {key: record[key] for key in (
            'id', 'team', 'title', 'status', 'owner', 'revision', 'level',
            'acknowledged', 'resolved', 'paused',
        )}

    @staticmethod
    def elapsed(record, now):
        end = record['resolved'] if record['status'] == 'resolved' else now
        if record['paused']:
            end = record['pause_start']
        return end - record['start'] - record['pause_total']

    def inspect(self, record, now):
        elapsed = self.elapsed(record, now)
        unresolved = record['status'] != 'resolved'
        return dict(self.public(record), elapsed=elapsed,
                    response_breached=(unresolved and record['acknowledged'] is None
                                       and elapsed >= record['policy']['response']),
                    resolve_breached=(unresolved and elapsed >= record['policy']['resolve']))

    def open_incident(self, state, data):
        fields(data, {'id': text, 'team': text, 'policy': text, 'now': integer,
                      'title': text, 'key': text})

        def create():
            require(data['id'] not in state['incidents'], 'Incident already exists')
            get_record(state['teams'], data['team'])
            policy = dict(get_record(state['policies'], data['policy']))
            record = dict(id=data['id'], team=data['team'], title=data['title'],
                          status='open', owner=None, revision=1, level=0,
                          acknowledged=None, resolved=None, paused=False,
                          start=data['now'], last=data['now'], policy=policy,
                          pause_start=None, pause_total=0, escalated=[])
            state['incidents'][record['id']] = record
            return self.public(record)

        return idempotent(state, data['key'], 'incident.open', dict(data), create)

    def handle(self, state, operation, data):
        if operation == 'team.put':
            fields(data, {'id': text, 'members': lambda x: identifiers(x, nonempty=True)})
            members = identifiers(data['members'], nonempty=True)
            require(all(r['owner'] is None or r['owner'] in members
                        for r in state['incidents'].values()
                        if r['team'] == data['id'] and r['status'] != 'resolved'),
                    'Cannot remove an assigned owner')
            result = dict(id=data['id'], members=members)
            state['teams'][data['id']] = result
            return result
        if operation == 'policy.put':
            fields(data, {'id': text, 'response': positive, 'resolve': positive})
            require(data['resolve'] >= data['response'], 'Resolve SLA precedes response SLA')
            state['policies'][data['id']] = dict(data)
            return data
        if operation == 'incident.open':
            return self.open_incident(state, data)
        if operation == 'incident.import':
            fields(data, {'incidents': lambda x: require(isinstance(x, list), 'Expected list')})
            for item in data['incidents']:
                self.open_incident(state, item)
            return {'imported': len(data['incidents'])}
        if operation == 'incident.list':
            fields(data, {}, optional={'team': text, 'status': text})
            if 'status' in data:
                require(data['status'] in ('open', 'acknowledged', 'resolved'), 'Invalid status')
            return [self.public(record) for _, record in sorted(state['incidents'].items())
                    if all(record[key] == value for key, value in data.items())]
        if operation == 'incident.inspect':
            fields(data, {'id': text, 'now': integer})
            record = get_record(state['incidents'], data['id'])
            require(data['now'] >= record['last'], 'Time moved backwards')
            return self.inspect(record, data['now'])
        actions = ('incident.assign', 'incident.ack', 'incident.pause', 'incident.resume',
                   'incident.resolve', 'incident.reopen', 'escalate')
        require(operation in actions, 'Unknown operation')
        schema = {'id': text, 'expected_revision': positive, 'now': integer}
        if operation == 'incident.assign':
            schema['owner'] = text
        fields(data, schema)
        record = get_record(state['incidents'], data['id'])
        compare_revision(record, data['expected_revision'])
        now = data['now']
        require(now >= record['last'], 'Time moved backwards')
        if operation == 'incident.reopen':
            require(record['status'] == 'resolved', 'Incident is not resolved')
            # Membership may have changed while the incident was resolved. Retaining
            # an owner must still respect the unresolved-owner invariant.
            require(record['owner'] is None or record['owner'] in
                    state['teams'][record['team']]['members'], 'Owner is no longer a team member')
            record.update(status='open', acknowledged=None, resolved=None, paused=False,
                          start=now, pause_start=None, pause_total=0, level=0, escalated=[])
        else:
            require(record['status'] != 'resolved', 'Incident is resolved')
            if operation == 'incident.assign':
                require(data['owner'] in state['teams'][record['team']]['members'],
                        'Owner is not a team member')
                record['owner'] = data['owner']
            elif operation == 'incident.ack':
                require(record['status'] == 'open' and record['acknowledged'] is None,
                        'Incident already acknowledged')
                record.update(status='acknowledged', acknowledged=now)
            elif operation == 'incident.pause':
                require(not record['paused'], 'Incident already paused')
                record.update(paused=True, pause_start=now)
            elif operation == 'incident.resume':
                require(record['paused'], 'Incident is not paused')
                record['pause_total'] += now - record['pause_start']
                record.update(paused=False, pause_start=None)
            elif operation == 'incident.resolve':
                require(not record['paused'], 'Cannot resolve a paused incident')
                record.update(status='resolved', resolved=now)
            else:
                inspected = self.inspect(record, now)
                require(inspected['response_breached'] or inspected['resolve_breached'],
                        'No SLA breach')
                elapsed = inspected['elapsed']
                require(elapsed not in record['escalated'], 'Already escalated at this elapsed time')
                record['escalated'].append(elapsed)
                record['level'] += 1
        record['last'] = now
        record['revision'] += 1
        return self.public(record)


if __name__ == '__main__':
    Service.main()
