Run with Python 3.11+ and the standard library:

```
python app.py --file incidents.json jsonl
python app.py --file incidents.json serve --port 0
```

JSONL accepts one packet per line, for example
`{"operation":"team.put","data":{"id":"ops","members":["Ada"]}}`.
Create a policy with `policy.put`, then an incident with `incident.open` using a
unique key and explicit integer `now`. Use the returned revision as
`expected_revision` for assignment, acknowledgment, pause/resume, escalation,
resolution and reopening. `incident.inspect` takes `id` and `now` without a
revision; `incident.list` optionally filters by team/status.

HTTP announces its localhost port on stdout; POST the same packets to `/api`.
GET `/health` checks readiness. Errors return a JSON error envelope.

`backup` with `{}` returns the full replayable JSON snapshot. Pass it unchanged
as `{"state": snapshot}` to `restore`. Restore replaces the complete application
with that snapshot; it rejects inconsistent state or history atomically.
Pauses stop both clocks, policy changes affect future incidents, and reopening
starts a new SLA cycle while preserving the incident revision sequence.
