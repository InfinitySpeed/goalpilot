import copy
import csv
import io
import unittest
import sys
import tempfile
from app import Service
from goalpilot_support import JourneyMixin, transport_journey


COLUMNS = [{'name': 'id', 'type': 'text', 'required': True},
           {'name': 'n', 'type': 'integer', 'required': False},
           {'name': 'price', 'type': 'money', 'required': True}]
SCHEMA = {'id': 's', 'columns': COLUMNS, 'key': 'id'}
RAW = 'id,n,price\n a ,bad,1\na,+02,0.10\na,3,4\n"bé\nx",-3,12.34\nc,,2.001\nd,,0\ne,1,2,extra\n'


class Pipeline(JourneyMixin, unittest.TestCase):
    def setUp(self):
        self.open_service(Service)

    def schema(self):
        return self.c('schema.put', **SCHEMA)

    def test_workflow(self):
        self.schema()
        draft = self.c('job.create', id='j', schema='s', csv=RAW)
        self.assertEqual((draft['status'], draft['revision']), ('draft', 1))
        self.c('schema.put', **SCHEMA)
        result = self.c('job.run', id='j', key='k')
        expected = [{'id': 'a', 'n': 2, 'price': 10}, {'id': 'bé\nx', 'n': -3, 'price': 1234},
                    {'id': 'd', 'n': None, 'price': 0}]
        self.assertEqual(result['rows'], expected)
        self.assertEqual([r['row'] for r in result['rejects']], [2, 4, 7, 9])
        self.assertEqual((result['accepted'], result['rejected'], result['schema_revision']), (3, 4, 1))
        result['rows'].clear()
        self.assertEqual(self.c('job.run', id='j', key='k')['rows'], expected)
        self.assertRejects('job.run', id='j', key='other')
        self.assertRejects('job.publish', id='j', expected_revision=True)
        exported = self.c('job.export', id='j')
        self.assertEqual(list(csv.reader(io.StringIO(exported)))[1], ['a', '2', '10'])
        backup = self.c('backup')
        self.c('job.publish', id='j', expected_revision=1)
        self.restart()
        self.assertEqual(self.c('dataset.get', schema='s'), {'job': 'j', 'rows': expected, 'schema_revision': 1})
        self.assertRejects('job.retry', id='j', csv=RAW)
        self.assertRejects('job.publish', id='j', expected_revision=2)
        self.c('restore', state=backup)
        self.assertRejects('dataset.get', schema='s')
        self.c('job.retry', id='j', csv='id,n,price\nz,,2.50\n')
        self.assertEqual(self.c('job.run', id='j', key='k')['rows'], expected)
        self.assertEqual(self.c('job.get', id='j')['status'], 'draft')
        self.assertEqual(self.c('job.run', id='j', key='new')['rows'], [{'id': 'z', 'n': None, 'price': 250}])
        self.c('job.publish', id='j', expected_revision=1)
        self.assertEqual(self.c('dataset.get', schema='s')['rows'][0]['id'], 'z')
        bad = copy.deepcopy(self.c('backup'))
        bad['state']['jobs']['j']['rows'][0]['price'] = -1
        self.assertRejects('restore', state=bad)

    def test_atomic_import_and_rejections(self):
        self.schema()
        self.assertRejects('job.create', id='x', schema='s', csv='n,id,price\n')
        self.assertRejects('job.import', jobs=[{'id': 'a', 'schema': 's', 'csv': RAW},
                                            {'id': 'b', 'schema': 's', 'csv': 'bad'}])
        self.assertRejects('job.get', id='a')
        self.assertEqual(self.c('job.import', jobs=[{'id': 'a', 'schema': 's', 'csv': RAW}]), {'imported': 1})
        self.assertRejects('schema.put', id='s', columns=[COLUMNS[0], COLUMNS[0]], key='id')
        self.c('job.run', id='a', key='global')
        self.c('job.create', id='b', schema='s', csv=RAW)
        self.assertRejects('job.run', id='b', key='global')

    def test_numeric_formats_and_independent_publications(self):
        self.schema()
        values = [('1', '0', True), ('-0', '001.2', True), ('+3', '2.99', True),
                  ('', '0.01', True), ('1.0', '2', False), ('1e2', '2', False),
                  ('true', '2', False), ('٢', '2', False), ('2', '-1', False),
                  ('2', '1.234', False), ('2', 'NaN', False), ('2', '', False)]
        raw = 'id,n,price\n' + ''.join(f'{i},{n},{price}\n' for i, (n, price, _) in enumerate(values))
        self.c('job.create', id='numbers', schema='s', csv=raw)
        result = self.c('job.run', id='numbers', key='numbers')
        self.assertEqual((result['accepted'], result['rejected']), (4, 8))
        self.assertEqual([r['price'] for r in result['rows']], [0, 120, 299, 1])
        self.c('job.publish', id='numbers', expected_revision=1)
        old = self.c('dataset.get', schema='s')
        self.c('schema.put', **dict(SCHEMA, id='other'))
        self.c('job.create', id='other', schema='other', csv='id,n,price\nx,,1\n')
        self.c('job.run', id='other', key='other')
        self.c('job.publish', id='other', expected_revision=1)
        self.assertEqual(self.c('dataset.get', schema='s'), old)
        self.c('schema.put', **SCHEMA)
        self.c('job.create', id='replacement', schema='s', csv='id,n,price\ny,,2\n')
        self.c('job.run', id='replacement', key='replacement')
        self.c('job.publish', id='replacement', expected_revision=1)
        self.assertEqual(self.c('dataset.get', schema='s'), {
            'job': 'replacement', 'rows': [{'id': 'y', 'n': None, 'price': 200}], 'schema_revision': 2})
        self.assertEqual(self.c('dataset.get', schema='other')['job'], 'other')
        self.assertEqual(self.c('job.get', id='numbers')['csv'], raw)

    def test_concurrency(self):
        self.schema()
        outcomes = self.race(*[('job.create', {'id': 'j', 'schema': 's', 'csv': RAW}) for _ in range(2)])
        self.assertEqual(sum(ok for ok, _ in outcomes), 1)
        self.c('job.run', id='j', key='k')
        outcomes = self.race(*[('job.publish', {'id': 'j', 'expected_revision': 1}) for _ in range(2)])
        self.assertEqual(sum(ok for ok, _ in outcomes), 1)
        self.assertEqual(self.c('dataset.get', schema='s')['job'], 'j')

    def test_transports(self):
        with tempfile.TemporaryDirectory() as directory:
            self.transport_checks(directory)

    def transport_checks(self, directory):
        transport_journey([sys.executable, 'app.py', '--file', directory + '/state.json'], [
            ('schema.put', SCHEMA, dict(SCHEMA, revision=1)),
            ('job.import', {'jobs': [{'id': 'j', 'schema': 's', 'csv': 'id,n,price\na,2,1.23\n'}]}, {'imported': 1}),
            ('job.run', {'id': 'j', 'key': 'k'}, {'id': 'j', 'status': 'processed', 'accepted': 1,
             'rejected': 0, 'rows': [{'id': 'a', 'n': 2, 'price': 123}], 'rejects': [], 'schema_revision': 1}),
        ])
