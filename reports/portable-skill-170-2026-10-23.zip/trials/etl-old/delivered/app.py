import copy
import csv
import io
import re
from goalpilot_runtime import ReplayService, require, text, integer


def banner():
    return 'Local Ops — café'


def packet(data, names):
    require(isinstance(data, dict) and set(data) == set(names), 'Invalid fields')


def read_csv(raw, columns):
    require(isinstance(raw, str), 'CSV must be text')
    reader = csv.reader(io.StringIO(raw, newline=''), strict=True)
    try:
        require(next(reader, None) == [c['name'] for c in columns], 'CSV header mismatch')
    except csv.Error as exc:
        raise ValueError('Invalid CSV header') from exc
    return reader


def process(job):
    schema = job['snapshot']
    reader = read_csv(job['csv'], schema['columns'])
    rows, rejects, seen = [], [], set()
    while True:
        try:
            cells = next(reader)
        except StopIteration:
            break
        except csv.Error:
            rejects.append({'row': reader.line_num, 'reason': 'Malformed CSV'})
            continue
        try:
            require(len(cells) == len(schema['columns']), 'Wrong cell count')
            row = {}
            for column, cell in zip(schema['columns'], cells):
                value = cell.strip()
                kind = column['type']
                require(value != '' or not column['required'], 'Required value: ' + column['name'])
                if kind == 'text':
                    row[column['name']] = value
                elif value == '':
                    row[column['name']] = None
                elif kind == 'integer':
                    require(re.fullmatch(r'[+-]?[0-9]+', value) is not None, 'Invalid integer')
                    row[column['name']] = int(value)
                else:
                    require(re.fullmatch(r'[0-9]+(?:\.[0-9]{1,2})?', value) is not None, 'Invalid money')
                    whole, _, fraction = value.partition('.')
                    row[column['name']] = int(whole) * 100 + int((fraction + '00')[:2])
            key = row[schema['key']]
            require(key and key not in seen, 'Empty or duplicate primary key')
            seen.add(key)
            rows.append(row)
        except ValueError as exc:
            rejects.append({'row': reader.line_num, 'reason': str(exc) or 'Invalid row'})
    return {'id': job['id'], 'status': 'processed', 'accepted': len(rows),
            'rejected': len(rejects), 'rows': rows, 'rejects': rejects,
            'schema_revision': schema['revision']}


class Service(ReplayService):
    def initial(self):
        return {'schemas': {}, 'jobs': {}, 'datasets': {}, 'keys': {}}

    def handle(self, state, operation, data):
        require(isinstance(data, dict), 'Data must be an object')
        schemas, jobs = state['schemas'], state['jobs']
        if operation == 'schema.put':
            packet(data, ('id', 'columns', 'key'))
            ident, key = text(data['id']), text(data['key'])
            require(isinstance(data['columns'], list) and data['columns'], 'Columns required')
            columns, names = [], set()
            for col in data['columns']:
                packet(col, ('name', 'type', 'required'))
                name = text(col['name'])
                require(name not in names, 'Duplicate column')
                require(col['type'] in ('text', 'integer', 'money'), 'Invalid type')
                require(type(col['required']) is bool, 'Invalid required flag')
                names.add(name)
                columns.append(copy.deepcopy(col))
            require(any(c['name'] == key and c['type'] == 'text' and c['required'] for c in columns), 'Invalid primary key')
            result = {'id': ident, 'revision': schemas.get(ident, {}).get('revision', 0) + 1,
                      'columns': columns, 'key': key}
            schemas[ident] = result
            return result
        if operation in ('job.create', 'job.import'):
            if operation == 'job.create':
                entries = [data]
            else:
                packet(data, ('jobs',))
                entries = data['jobs']
                require(isinstance(entries, list), 'Jobs must be a list')
            for entry in entries:
                packet(entry, ('id', 'schema', 'csv'))
                ident, schema_id = text(entry['id']), text(entry['schema'])
                require(ident not in jobs, 'Job already exists')
                require(schema_id in schemas, 'Unknown schema')
                snapshot = copy.deepcopy(schemas[schema_id])
                read_csv(entry['csv'], snapshot['columns'])
                jobs[ident] = {'id': ident, 'schema': schema_id, 'csv': entry['csv'],
                               'snapshot': snapshot, 'status': 'draft', 'revision': 1}
            return copy.deepcopy(jobs[data['id']]) if operation == 'job.create' else {'imported': len(entries)}
        if operation == 'dataset.get':
            packet(data, ('schema',))
            ident = text(data['schema'])
            require(ident in state['datasets'], 'No publication')
            return state['datasets'][ident]
        if operation in ('job.get', 'job.run', 'job.publish', 'job.retry', 'job.export'):
            expected = {'job.get': ('id',), 'job.run': ('id', 'key'),
                        'job.publish': ('id', 'expected_revision'), 'job.retry': ('id', 'csv'),
                        'job.export': ('id',)}[operation]
            packet(data, expected)
            ident = text(data['id'])
            if operation == 'job.run':
                key = text(data['key'])
                if key in state['keys']:
                    prior = state['keys'][key]
                    require(prior['operation'] == operation and prior['data'] == data, 'Idempotency conflict')
                    return prior['result']
            require(ident in jobs, 'Unknown job')
            job = jobs[ident]
            if operation == 'job.get':
                return job
            if operation == 'job.run':
                require(job['status'] == 'draft', 'Job must be draft')
                result = process(job)
                job.update(result)
                state['keys'][key] = {'operation': operation, 'data': copy.deepcopy(data), 'result': copy.deepcopy(result)}
                return result
            if operation == 'job.publish':
                revision = integer(data['expected_revision'], minimum=1)
                require(revision == job['revision'], 'Revision conflict')
                require(job['status'] == 'processed', 'Job must be processed')
                job['status'], job['revision'] = 'published', 2
                state['datasets'][job['schema']] = {'job': ident, 'rows': copy.deepcopy(job['rows']),
                                                  'schema_revision': job['schema_revision']}
                return job
            if operation == 'job.retry':
                require(job['status'] == 'processed', 'Job must be processed')
                read_csv(data['csv'], job['snapshot']['columns'])
                for name in ('accepted', 'rejected', 'rows', 'rejects', 'schema_revision'):
                    job.pop(name, None)
                job.update(csv=data['csv'], status='draft')
                return job
            require(job['status'] in ('processed', 'published'), 'Job must be processed')
            output = io.StringIO(newline='')
            writer = csv.writer(output)
            names = [c['name'] for c in job['snapshot']['columns']]
            writer.writerow(names)
            writer.writerows([[row[name] if row[name] is not None else '' for name in names] for row in job['rows']])
            return output.getvalue()
        raise ValueError('Unknown operation')


if __name__ == '__main__':
    Service.main()
