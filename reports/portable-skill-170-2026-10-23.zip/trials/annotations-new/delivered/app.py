import json
from goalpilot_runtime import ReplayService, fields, text, integer, boolean, identifiers, require, get_record


def banner():
    return 'Local Ops — café'


def positive(v):
    return integer(v, minimum=1)


def payload(v):
    def check(x):
        if x is None or type(x) in (str, bool, int):
            return
        if type(x) is float:
            import math
            require(math.isfinite(x))
            return
        if type(x) is list:
            for child in x:
                check(child)
            return
        require(type(x) is dict and all(type(k) is str for k in x))
        for child in x.values():
            check(child)
    check(v)
    return v


class Service(ReplayService):
    def initial(self):
        return {'datasets': {}, 'annotators': {}}

    def handle(self, state, op, data):
        if op == 'dataset.create':
            fields(data, {'id': text, 'labels': lambda x: identifiers(x, nonempty=True), 'reviews': positive})
            require(data['id'] not in state['datasets'], 'Dataset already exists')
            row = dict(id=data['id'], labels=identifiers(data['labels'], nonempty=True), reviews=data['reviews'], items={})
            state['datasets'][row['id']] = row
            return {k: row[k] for k in ('id', 'labels', 'reviews')}
        if op == 'annotator.put':
            fields(data, {'id': text, 'active': boolean})
            state['annotators'][data['id']] = dict(data)
            return data
        schemas = {
            'item.add': {'dataset': text, 'id': text, 'payload': payload},
            'item.import': {'dataset': text, 'items': lambda v: self._imports(v)},
            'item.get': {'dataset': text, 'id': text},
            'item.list': {'dataset': text},
            'history': {'dataset': text, 'id': text},
            'report': {'dataset': text},
            'claim': {'dataset': text, 'annotator': text, 'now': integer, 'lease': positive},
            'submit': {'dataset': text, 'item': text, 'annotator': text, 'receipt': text, 'now': integer, 'label': text},
            'item.reopen': {'dataset': text, 'id': text, 'expected_revision': positive},
        }
        require(op in schemas, 'Unknown operation')
        fields(data, schemas[op], optional={'status': text} if op == 'item.list' else None)
        ds = get_record(state['datasets'], data['dataset'])
        items = ds['items']
        if op in ('item.add', 'item.import'):
            rows = [{'id': data['id'], 'payload': data['payload']}] if op == 'item.add' else data['items']
            ids = [r['id'] for r in rows]
            require(len(set(ids)) == len(ids) and not any(i in items for i in ids), 'Duplicate item')
            for row in rows:
                items[row['id']] = {'public': dict(id=row['id'], dataset=ds['id'], payload=row['payload'], status='pending', votes=[], revision=1, consensus=None), 'claims': {}, 'history': []}
            return items[data['id']]['public'] if op == 'item.add' else {'imported': len(rows)}
        if op == 'item.list':
            status = data.get('status')
            require(status is None or status in ('pending', 'reviewing', 'complete'), 'Invalid status')
            return [items[i]['public'] for i in sorted(items) if status is None or items[i]['public']['status'] == status]
        if op == 'report':
            result = dict(pending=0, reviewing=0, complete=0, disputed=0)
            for row in items.values():
                p = row['public']
                result[p['status']] += 1
                if p['status'] == 'complete' and p['consensus'] is None:
                    result['disputed'] += 1
            return result
        if op == 'claim':
            actor = get_record(state['annotators'], data['annotator'])
            require(actor['active'], 'Inactive annotator')
            for key in sorted(items):
                row = items[key]
                p = row['public']
                live = {a: c for a, c in row['claims'].items() if c['expires'] > data['now']}
                if p['status'] == 'complete' or any(v['annotator'] == actor['id'] for v in p['votes']) or actor['id'] in live or len(p['votes']) + len(live) >= ds['reviews']:
                    continue
                receipt = self.opaque()
                expires = data['now'] + data['lease']
                live[actor['id']] = dict(receipt=receipt, expires=expires)
                row['claims'] = live
                p['status'] = 'reviewing'
                return dict(item=p, receipt=receipt, expires=expires)
            return None
        row = get_record(items, data.get('id', data.get('item')))
        p = row['public']
        if op == 'item.get':
            return p
        if op == 'history':
            return row['history']
        if op == 'item.reopen':
            require(p['status'] == 'complete' and p['revision'] == data['expected_revision'], 'Revision or status mismatch')
            row['history'].append(dict(votes=p['votes'], consensus=p['consensus']))
            p.update(votes=[], consensus=None, status='pending', revision=p['revision'] + 1)
            row['claims'] = {}
            return p
        actor = get_record(state['annotators'], data['annotator'])
        require(actor['active'], 'Inactive annotator')
        require(data['label'] in ds['labels'], 'Unknown label')
        claim = row['claims'].get(actor['id'])
        require(claim is not None and claim['receipt'] == data['receipt'] and data['now'] < claim['expires'], 'Invalid or expired receipt')
        require(p['status'] != 'complete' and len(p['votes']) < ds['reviews'] and not any(v['annotator'] == actor['id'] for v in p['votes']), 'Duplicate or excess vote')
        p['votes'].append(dict(annotator=actor['id'], label=data['label']))
        del row['claims'][actor['id']]
        p['revision'] += 1
        p['status'] = 'complete' if len(p['votes']) == ds['reviews'] else 'reviewing'
        p['consensus'] = p['votes'][0]['label'] if p['status'] == 'complete' and len({v['label'] for v in p['votes']}) == 1 else None
        return p

    @staticmethod
    def _imports(value):
        require(type(value) is list)
        for row in value:
            fields(row, {'id': text, 'payload': payload})
        return value


if __name__ == '__main__':
    Service.main()
