import copy
import unittest
from app import Service
from goalpilot_support import JourneyMixin, rejects


class Annotation(JourneyMixin, unittest.TestCase):
    def setUp(self):
        self.open_service(Service)

    def test_journey(self):
        def flow(c):
            c('dataset.create', id='café', labels=['oui', 'non', 'oui'], reviews=2)
            for a in ['a', 'b', 'c']:
                c('annotator.put', id=a, active=True)
            self.assertEqual(c('item.import', dataset='café', items=[dict(id='z', payload=None), dict(id='a', payload={'é': [1, True]})]), {'imported': 2})
            rejects(lambda: c('item.import', dataset='café', items=[dict(id='x', payload=1), dict(id='a', payload=2)]))
            self.assertEqual([x['id'] for x in c('item.list', dataset='café')], ['a', 'z'])
            a = c('claim', dataset='café', annotator='a', now=0, lease=5)
            b = c('claim', dataset='café', annotator='b', now=0, lease=5)
            self.assertEqual(a['item']['id'], 'a')
            self.assertEqual(b['item']['id'], 'a')
            self.assertEqual(c('claim', dataset='café', annotator='c', now=0, lease=5)['item']['id'], 'z')
            c('annotator.put', id='a', active=False)
            args = dict(dataset='café', item='a', annotator='a', receipt=a['receipt'], now=1, label='oui')
            rejects(lambda: c('submit', **args))
            c('annotator.put', id='a', active=True)
            rejects(lambda: c('submit', **dict(args, now=5)))
            replacement = c('claim', dataset='café', annotator='a', now=5, lease=10)
            self.assertNotEqual(a['receipt'], replacement['receipt'])
            rejects(lambda: c('submit', **dict(args, now=6)))
            p = c('submit', **dict(args, receipt=replacement['receipt'], now=6))
            self.assertEqual(p['revision'], 2)
            b = c('claim', dataset='café', annotator='b', now=6, lease=10)
            p = c('submit', dataset='café', item='a', annotator='b', receipt=b['receipt'], now=7, label='non')
            self.assertEqual((p['status'], p['consensus'], p['revision']), ('complete', None, 3))
            self.assertEqual(c('report', dataset='café')['disputed'], 1)
            saved = c('backup')
            rejects(lambda: c('item.reopen', dataset='café', id='a', expected_revision=2))
            p = c('item.reopen', dataset='café', id='a', expected_revision=3)
            self.assertEqual((p['status'], p['votes'], p['revision']), ('pending', [], 4))
            self.assertEqual(c('history', dataset='café', id='a'), [dict(votes=[dict(annotator='a', label='oui'), dict(annotator='b', label='non')], consensus=None)])
            for actor in ('a', 'b'):
                lease = c('claim', dataset='café', annotator=actor, now=20, lease=10)
                p = c('submit', dataset='café', item='a', annotator=actor, receipt=lease['receipt'], now=21, label='oui')
            self.assertEqual(p['consensus'], 'oui')
            c('restore', state=saved)
            self.assertEqual(c('item.get', dataset='café', id='a')['revision'], 3)
            self.assertEqual(c('history', dataset='café', id='a'), [])
            rejects(lambda: c('claim', dataset='café', annotator='a', now=True, lease=1))
            rejects(lambda: c('dataset.create', id='bad', labels=[], reviews=1))
            rejects(lambda: c('unknown'))
        self.assertJourney(flow)

    def test_atomic_persistence_and_corruption(self):
        self.c('dataset.create', id='d', labels=['yes'], reviews=1)
        self.c('annotator.put', id='a', active=True)
        original = {'nested': [1]}
        self.c('item.add', dataset='d', id='i', payload=original)
        original['nested'].append(2)
        lease = self.c('claim', dataset='d', annotator='a', now=0, lease=10)
        self.restart()
        self.assertEqual(self.c('item.get', dataset='d', id='i')['payload'], {'nested': [1]})
        self.c('annotator.put', id='a', active=False)
        self.restart()
        self.assertRejects('submit', dataset='d', item='i', annotator='a', receipt=lease['receipt'], now=1, label='yes')
        self.c('annotator.put', id='a', active=True)
        self.c('submit', dataset='d', item='i', annotator='a', receipt=lease['receipt'], now=1, label='yes')
        self.restart()
        self.assertEqual(self.c('item.get', dataset='d', id='i')['votes'], [{'annotator': 'a', 'label': 'yes'}])
        self.assertCorruptions(lambda b: b['state']['datasets']['d']['items']['i']['public'].update(consensus='bad'), lambda b: b['state']['annotators']['a'].update(active=False))
        snapshot = self.c('backup')
        snapshot['state']['datasets'].clear()
        self.assertEqual(self.c('report', dataset='d')['complete'], 1)

    def test_concurrent_capacity(self):
        self.c('dataset.create', id='d', labels=['x'], reviews=1)
        self.c('item.add', dataset='d', id='i', payload=None)
        for a in ['a', 'b']:
            self.c('annotator.put', id=a, active=True)
        outcomes = self.race(*[('claim', dict(dataset='d', annotator=a, now=0, lease=10)) for a in ['a', 'b']])
        winners = [r for ok, r in outcomes if ok and r is not None]
        self.assertEqual(len(winners), 1)
        winner = winners[0]
        actor = next(a for a in ['a', 'b'] if self.c('claim', dataset='d', annotator=a, now=0, lease=10) is None and True) if False else None
        backup = self.c('backup')
        actor = next(iter(backup['state']['datasets']['d']['items']['i']['claims']))
        args = dict(dataset='d', item='i', annotator=actor, receipt=winner['receipt'], now=1, label='x')
        results = self.race(('submit', args), ('submit', args))
        self.assertEqual(sum(ok for ok, _ in results), 1)
        self.assertEqual(len(self.c('item.get', dataset='d', id='i')['votes']), 1)
