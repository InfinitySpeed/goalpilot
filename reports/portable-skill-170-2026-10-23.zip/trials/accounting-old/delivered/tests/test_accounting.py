import copy
import os
import sys
import tempfile
import unittest

from app import Service
from goalpilot_support import JourneyMixin, transport_journey


class Accounting(JourneyMixin, unittest.TestCase):
    def setUp(self):
        self.open_service(Service)

    def setup_books(self):
        self.c('account.create', id='cash', name='Caisse café', kind='asset')
        self.c('account.create', id='sales', name='Ventes', kind='income')
        self.c('account.create', id='zero', name='Vide', kind='expense')
        self.c('period.create', id='p', start=0, end=100)

    def payload(self, ident='e', date=5, amount=123):
        return dict(id=ident, date=date, key='key-' + ident, lines=[
            dict(account='cash', debit=amount, credit=0),
            dict(account='sales', debit=0, credit=amount)])

    def test_complete_history(self):
        self.setup_books()
        payload = self.payload()
        saved = copy.deepcopy(payload)
        entry = self.c('journal.post', **payload)
        self.assertEqual(payload, saved)
        self.assertEqual(entry, dict(id='e', date=5, period='p', lines=payload['lines'], status='posted', reversal=None))
        entry['lines'][0]['debit'] = 1
        self.assertEqual(self.c('journal.post', **payload)['lines'][0]['debit'], 123)
        self.assertEqual(self.c('account.balance', id='cash'), dict(debit=123, credit=0, net=123))
        self.assertEqual(self.c('period.close', id='p', expected_revision=1)['revision'], 2)
        self.assertRejects('journal.post', **self.payload('closed'))
        self.assertRejects('journal.reverse', id='e', reversal_id='r', date=6, key='reverse')
        self.assertRejects('period.reopen', id='p', expected_revision=1)
        self.c('period.reopen', id='p', expected_revision=2)
        reversal = self.c('journal.reverse', id='e', reversal_id='r', date=6, key='reverse')
        self.assertEqual(reversal['lines'], [dict(account='cash', debit=0, credit=123), dict(account='sales', debit=123, credit=0)])
        self.assertEqual(self.c('journal.post', **payload)['status'], 'posted')
        self.assertEqual(self.c('journal.get', id='e')['status'], 'reversed')
        self.assertEqual(self.c('journal.reverse', id='e', reversal_id='r', date=6, key='reverse'), reversal)
        self.assertRejects('journal.reverse', id='e', reversal_id='r2', date=7, key='another')
        self.assertRejects('journal.reverse', id='r', reversal_id='r2', date=7, key='another')
        self.assertEqual([e['id'] for e in self.c('journal.list', account='cash', period='p')], ['e', 'r'])
        self.assertEqual(self.c('trial_balance'), [dict(account='cash', debit=123, credit=123, net=0), dict(account='sales', debit=123, credit=123, net=0), dict(account='zero', debit=0, credit=0, net=0)])
        self.restart()
        self.assertEqual(self.c('journal.get', id='r'), reversal)
        snapshot = self.c('backup')
        self.c('journal.post', **self.payload('later'))
        self.c('restore', state=snapshot)
        self.assertRejects('journal.get', id='later')
        self.c('journal.post', **self.payload('later'))
        bad = copy.deepcopy(snapshot)
        bad['state']['entries']['e']['lines'][0]['debit'] += 1
        self.assertRejects('restore', state=bad)
        bad = copy.deepcopy(snapshot)
        bad['state']['keys'] = {}
        self.assertRejects('restore', state=bad)

    def test_guards_and_atomic_import(self):
        self.setup_books()
        self.assertRejects('period.create', id='overlap', start=99, end=101)
        self.c('period.create', id='next', start=100, end=200)
        for bad in (True, 1.5, '4', -1):
            p = self.payload()
            p['lines'][0]['debit'] = bad
            self.assertRejects('journal.post', **p)
        for change in ({'date': 200}, {'date': True}, {'lines': []}):
            p = self.payload()
            p.update(change)
            self.assertRejects('journal.post', **p)
        p = self.payload('bad')
        p['lines'][1]['credit'] += 1
        self.assertRejects('journal.import', entries=[self.payload(), p])
        self.assertEqual(self.c('journal.list'), [])
        self.assertEqual(self.c('journal.import', entries=[self.payload(), self.payload('b', 100)]), {'imported': 2})
        self.assertRejects('journal.post', **self.payload('other', amount=124) | {'key': 'key-e'})
        self.assertRejects('account.balance', id='missing')
        self.assertRejects('journal.list', account='missing')
        self.assertRejects('unknown')
        # Repeated account lines accumulate exactly, including arbitrarily large cents.
        p = self.payload('big', amount=10**30)
        p['lines'].insert(1, dict(account='cash', debit=2, credit=0))
        p['lines'][-1]['credit'] += 2
        self.c('journal.post', **p)
        self.assertEqual(self.c('account.balance', id='cash')['net'], 10**30 + 248)

    def test_concurrent_processes(self):
        self.setup_books()
        outcomes = self.race(*[('journal.post', self.payload('e' + str(i))) for i in range(6)])
        self.assertEqual(sum(ok for ok, _ in outcomes), 6)
        self.assertEqual(self.c('account.balance', id='cash')['net'], 738)
        outcomes = self.race(*[('period.close', dict(id='p', expected_revision=1)) for _ in range(3)])
        self.assertEqual(sum(ok for ok, _ in outcomes), 1)

    def test_real_transports(self):
        p = self.payload()
        expected = dict(id='e', date=5, period='p', lines=p['lines'], status='posted', reversal=None)
        directory = tempfile.TemporaryDirectory()
        self.addCleanup(directory.cleanup)
        transport_journey([sys.executable, os.path.abspath('app.py'), '--file', os.path.join(directory.name, 'ledger.json')], [
            ('account.create', dict(id='cash', name='Café', kind='asset'), dict(id='cash', name='Café', kind='asset')),
            ('account.create', dict(id='sales', name='Ventes', kind='income'), dict(id='sales', name='Ventes', kind='income')),
            ('period.create', dict(id='p', start=0, end=100), dict(id='p', start=0, end=100, status='open', revision=1)),
            ('journal.post', p, expected),
            ('account.balance', dict(id='cash'), dict(debit=123, credit=0, net=123)),
            ('journal.get', dict(id='e'), expected),
        ])
