from goalpilot_runtime import ReplayService, require, text, integer, fields, choice, sequence, get_record, idempotent


def banner():
    return 'Local Ops — café'


class Service(ReplayService):
    def initial(self):
        return {'accounts': {}, 'periods': {}, 'entries': {}, 'reversals': {}, 'keys': {}}

    def handle(self, s, op, d):
        def valid_line(v):
            fields(v, {'account': text, 'debit': integer, 'credit': integer})
            require((v['debit'] > 0) != (v['credit'] > 0), 'Exactly one positive side required')
        def post_fields(v):
            fields(v, {'id': text, 'date': integer, 'lines': sequence(valid_line, nonempty=True), 'key': text})
            require(len(v['lines']) >= 2, 'At least two lines required')
        def open_period(date):
            matches = [p for p in s['periods'].values() if p['start'] <= date < p['end']]
            require(len(matches) == 1 and matches[0]['status'] == 'open', 'Date must belong to an open period')
            return matches[0]['id']
        def create_entry(ident, date, lines):
            require(ident not in s['entries'], 'Duplicate entry')
            period = open_period(date)
            for row in lines:
                get_record(s['accounts'], row['account'])
            debit = sum(row['debit'] for row in lines)
            credit = sum(row['credit'] for row in lines)
            require(debit == credit and debit > 0, 'Unbalanced entry')
            entry = {'id': ident, 'date': date, 'period': period, 'lines': lines, 'status': 'posted', 'reversal': None}
            s['entries'][ident] = entry
            return entry
        def post(v):
            post_fields(v)
            return idempotent(s, v['key'], 'journal.post', v, lambda: create_entry(v['id'], v['date'], v['lines']))
        def balance(ident):
            rows = [r for e in s['entries'].values() for r in e['lines'] if r['account'] == ident]
            debit = sum(r['debit'] for r in rows)
            credit = sum(r['credit'] for r in rows)
            return {'debit': debit, 'credit': credit, 'net': debit - credit}

        if op == 'account.create':
            fields(d, {'id': text, 'name': text, 'kind': choice('asset', 'liability', 'income', 'expense')})
            require(d['id'] not in s['accounts'], 'Duplicate account')
            s['accounts'][d['id']] = dict(d)
            return s['accounts'][d['id']]
        if op == 'period.create':
            fields(d, {'id': text, 'start': integer, 'end': integer})
            require(d['end'] > d['start'], 'Invalid period range')
            require(d['id'] not in s['periods'], 'Duplicate period')
            require(all(d['end'] <= p['start'] or d['start'] >= p['end'] for p in s['periods'].values()), 'Overlapping periods')
            p = dict(d, status='open', revision=1)
            s['periods'][d['id']] = p
            return p
        if op in ('period.close', 'period.reopen'):
            fields(d, {'id': text, 'expected_revision': integer})
            p = get_record(s['periods'], d['id'])
            expected = 'open' if op == 'period.close' else 'closed'
            require(p['status'] == expected and p['revision'] == d['expected_revision'], 'Period status or revision conflict')
            p['status'] = 'closed' if expected == 'open' else 'open'
            p['revision'] += 1
            return p
        if op == 'journal.post':
            return post(d)
        if op == 'journal.reverse':
            fields(d, {'id': text, 'reversal_id': text, 'date': integer, 'key': text})
            def reverse():
                original = get_record(s['entries'], d['id'])
                require(original['status'] == 'posted', 'Entry already reversed')
                require(d['id'] not in s['reversals'], 'Cannot reverse a reversal')
                rows = [{'account': r['account'], 'debit': r['credit'], 'credit': r['debit']} for r in original['lines']]
                result = create_entry(d['reversal_id'], d['date'], rows)
                original['status'] = 'reversed'
                original['reversal'] = result['id']
                s['reversals'][result['id']] = original['id']
                return result
            return idempotent(s, d['key'], op, d, reverse)
        if op == 'journal.import':
            fields(d, {'entries': sequence(post_fields)})
            for entry in d['entries']:
                post(entry)
            return {'imported': len(d['entries'])}
        if op == 'journal.get':
            fields(d, {'id': text})
            return get_record(s['entries'], d['id'])
        if op == 'journal.list':
            fields(d, {}, optional={'period': text, 'account': text})
            if 'period' in d:
                get_record(s['periods'], d['period'])
            if 'account' in d:
                get_record(s['accounts'], d['account'])
            return sorted((e for e in s['entries'].values()
                           if ('period' not in d or e['period'] == d['period'])
                           and ('account' not in d or any(r['account'] == d['account'] for r in e['lines']))),
                          key=lambda e: (e['date'], e['id']))
        if op == 'account.balance':
            fields(d, {'id': text})
            get_record(s['accounts'], d['id'])
            return balance(d['id'])
        if op == 'trial_balance':
            fields(d, {})
            return [dict(account=ident, **balance(ident)) for ident in sorted(s['accounts'])]
        raise ValueError('Unknown operation')


if __name__ == '__main__':
    Service.main()
