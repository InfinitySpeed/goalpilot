from copy import deepcopy
from goalpilot_runtime import ReplayService, fields, text, integer, choice, require


def banner():
    return 'Local Ops — café'


def signed(value):
    require(type(value) is int, 'Expected integer')
    return value


def line(value):
    fields(value, {'account': text, 'debit': integer, 'credit': integer})
    require((value['debit'] > 0) != (value['credit'] > 0), 'Exactly one positive side required')
    return value


def lines(value):
    require(isinstance(value, list) and len(value) >= 2, 'At least two lines required')
    for item in value:
        line(item)
    require(sum(x['debit'] for x in value) == sum(x['credit'] for x in value), 'Unbalanced entry')
    return value


def post_fields(value):
    fields(value, {'id': text, 'date': signed, 'lines': lines, 'key': text})
    return value


class Service(ReplayService):
    def initial(self):
        return {'accounts': {}, 'periods': {}, 'entries': {}, 'keys': {}}

    def record(self, records, identifier):
        require(identifier in records, 'Unknown record: ' + identifier)
        return records[identifier]

    def keyed(self, state, operation, data, action):
        previous = state['keys'].get(data['key'])
        if previous is not None:
            require(previous['operation'] == operation and previous['payload'] == data,
                    'Idempotency key conflict')
            return deepcopy(previous['result'])
        result = action()
        state['keys'][data['key']] = {'operation': operation, 'payload': deepcopy(data),
                                    'result': deepcopy(result)}
        return result

    def posting(self, state, identifier, date, entry_lines):
        require(identifier not in state['entries'], 'Entry ID already exists')
        periods = [p for p in state['periods'].values() if p['start'] <= date < p['end']]
        require(len(periods) == 1 and periods[0]['status'] == 'open', 'Date must be in an open period')
        for item in entry_lines:
            self.record(state['accounts'], item['account'])
        entry = {'id': identifier, 'date': date, 'period': periods[0]['id'],
                 'lines': deepcopy(entry_lines), 'status': 'posted', 'reversal': None}
        state['entries'][identifier] = entry
        return deepcopy(entry)

    def handle(self, state, op, data):
        require(isinstance(data, dict), 'Expected object')
        if op == 'account.create':
            fields(data, {'id': text, 'name': text, 'kind': choice('asset', 'liability', 'income', 'expense')})
            require(data['id'] not in state['accounts'], 'Account already exists')
            state['accounts'][data['id']] = deepcopy(data)
            return deepcopy(data)
        if op == 'period.create':
            fields(data, {'id': text, 'start': integer, 'end': signed})
            require(data['end'] > data['start'], 'Invalid period range')
            require(data['id'] not in state['periods'], 'Period already exists')
            require(all(data['end'] <= p['start'] or data['start'] >= p['end']
                        for p in state['periods'].values()), 'Overlapping period')
            period = dict(data, status='open', revision=1)
            state['periods'][data['id']] = period
            return deepcopy(period)
        if op in ('period.close', 'period.reopen'):
            fields(data, {'id': text, 'expected_revision': integer})
            period = self.record(state['periods'], data['id'])
            require(period['revision'] == data['expected_revision'], 'Revision conflict')
            require(period['status'] == ('open' if op == 'period.close' else 'closed'), 'Invalid period status')
            period['status'] = 'closed' if op == 'period.close' else 'open'
            period['revision'] += 1
            return deepcopy(period)
        if op == 'journal.post':
            post_fields(data)
            return self.keyed(state, op, data, lambda: self.posting(state, data['id'], data['date'], data['lines']))
        if op == 'journal.reverse':
            fields(data, {'id': text, 'reversal_id': text, 'date': signed, 'key': text})
            def reverse():
                original = self.record(state['entries'], data['id'])
                require(original['status'] == 'posted', 'Entry already reversed')
                require(not any(e['reversal'] == data['id'] for e in state['entries'].values()),
                        'Cannot reverse a reversal')
                swapped = [{'account': x['account'], 'debit': x['credit'], 'credit': x['debit']}
                           for x in original['lines']]
                result = self.posting(state, data['reversal_id'], data['date'], swapped)
                original['status'] = 'reversed'
                original['reversal'] = data['reversal_id']
                return result
            return self.keyed(state, op, data, reverse)
        if op == 'journal.import':
            fields(data, {'entries': lambda value: require(isinstance(value, list), 'Expected entries list')})
            working = deepcopy(state)
            for payload in data['entries']:
                self.handle(working, 'journal.post', payload)
            state.clear()
            state.update(working)
            return {'imported': len(data['entries'])}
        if op == 'journal.get':
            fields(data, {'id': text})
            return deepcopy(self.record(state['entries'], data['id']))
        if op == 'journal.list':
            fields(data, {}, optional={'period': text, 'account': text})
            if 'period' in data:
                self.record(state['periods'], data['period'])
            if 'account' in data:
                self.record(state['accounts'], data['account'])
            return deepcopy(sorted((e for e in state['entries'].values()
                if ('period' not in data or e['period'] == data['period'])
                and ('account' not in data or any(x['account'] == data['account'] for x in e['lines']))),
                key=lambda e: (e['date'], e['id'])))
        if op in ('account.balance', 'trial_balance'):
            fields(data, {'id': text} if op == 'account.balance' else {})
            accounts = sorted(state['accounts']) if op == 'trial_balance' else [data['id']]
            result = []
            for account in accounts:
                self.record(state['accounts'], account)
                debit = credit = 0
                for entry in state['entries'].values():
                    for item in entry['lines']:
                        if item['account'] == account:
                            debit += item['debit']
                            credit += item['credit']
                row = {'debit': debit, 'credit': credit, 'net': debit - credit}
                if op == 'account.balance':
                    return row
                result.append(dict(row, account=account))
            return result
        raise ValueError('Unknown operation')


if __name__ == '__main__':
    Service.main()
