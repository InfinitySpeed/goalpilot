import copy
import unittest
from app import Service
from goalpilot_support import JourneyMixin, rejects


def posting(identifier='sale', key='sale-key', date=5, amount=123):
    return {'id': identifier, 'key': key, 'date': date, 'lines': [
        {'account': 'cash', 'debit': amount, 'credit': 0},
        {'account': 'income', 'debit': 0, 'credit': amount}]}


class Accounting(JourneyMixin, unittest.TestCase):
    def setUp(self):
        self.open_service(Service)

    def seed(self):
        self.c('account.create', id='cash', name='Caisse café', kind='asset')
        self.c('account.create', id='income', name='Ventes', kind='income')
        self.c('period.create', id='jan', start=0, end=10)

    def test_journey(self):
        def flow(c):
            for identifier, kind in [('cash', 'asset'), ('income', 'income'), ('zero', 'liability'), ('cost', 'expense')]:
                self.assertEqual(c('account.create', id=identifier, name='Café ' + identifier, kind=kind),
                                 {'id': identifier, 'name': 'Café ' + identifier, 'kind': kind})
            self.assertEqual(c('period.create', id='jan', start=0, end=10),
                             {'id': 'jan', 'start': 0, 'end': 10, 'status': 'open', 'revision': 1})
            c('period.create', id='feb', start=10, end=20)
            rejects(lambda: c('period.create', id='overlap', start=9, end=11))
            payload = posting(amount=10**25 + 7)
            original = c('journal.post', **payload)
            self.assertEqual(original, {'id': 'sale', 'date': 5, 'period': 'jan', 'lines': payload['lines'],
                                        'status': 'posted', 'reversal': None})
            self.assertEqual(c('journal.post', **payload), original)
            rejects(lambda: c('journal.post', **dict(payload, date=6)))
            self.assertEqual(c('account.balance', id='cash'), {'debit': 10**25 + 7, 'credit': 0, 'net': 10**25 + 7})
            self.assertEqual(c('period.close', id='jan', expected_revision=1)['revision'], 2)
            rejects(lambda: c('journal.post', **posting('closed', 'closed')))
            rejects(lambda: c('journal.reverse', id='sale', reversal_id='undo', date=5, key='undo'))
            rejects(lambda: c('period.reopen', id='jan', expected_revision=1))
            self.assertEqual(c('period.reopen', id='jan', expected_revision=2)['revision'], 3)
            c('period.close', id='jan', expected_revision=3)
            reversal = c('journal.reverse', id='sale', reversal_id='undo', date=10, key='undo')
            self.assertEqual(reversal['lines'], [{'account': 'cash', 'debit': 0, 'credit': 10**25 + 7},
                                                {'account': 'income', 'debit': 10**25 + 7, 'credit': 0}])
            self.assertEqual(c('journal.reverse', id='sale', reversal_id='undo', date=10, key='undo'), reversal)
            self.assertEqual(c('journal.post', **payload), original)
            self.assertEqual(c('journal.get', id='sale')['status'], 'reversed')
            self.assertEqual(c('journal.get', id='sale')['reversal'], 'undo')
            rejects(lambda: c('journal.reverse', id='sale', reversal_id='twice', date=11, key='twice'))
            rejects(lambda: c('journal.reverse', id='undo', reversal_id='third', date=11, key='third'))
            self.assertEqual([e['id'] for e in c('journal.list', account='cash')], ['sale', 'undo'])
            self.assertEqual([e['id'] for e in c('journal.list', period='jan')], ['sale'])
            trial = c('trial_balance')
            self.assertEqual([r['account'] for r in trial], ['cash', 'cost', 'income', 'zero'])
            self.assertTrue(all(r['net'] == 0 for r in trial))
            self.assertEqual(trial[0]['debit'], 10**25 + 7)
            prior = c('backup')
            self.assertEqual(c('journal.import', entries=[posting('b', 'b', 12), posting('a', 'a', 12)]), {'imported': 2})
            self.assertEqual([e['id'] for e in c('journal.list')], ['sale', 'undo', 'a', 'b'])
            rejects(lambda: c('journal.import', entries=[posting('candidate', 'candidate', 13), posting('b', 'other', 13)]))
            self.assertEqual(c('account.balance', id='cash')['net'], 246)
            c('journal.post', **posting('candidate', 'candidate', 13))
            c('restore', state=prior)
            self.assertEqual(c('journal.list'), [dict(original, status='reversed', reversal='undo'), reversal])
            c('journal.post', **posting('a', 'a', 12))
            self.assertEqual(c('account.balance', id='cash')['net'], 123)
        self.assertJourney(flow)

    def test_rejections_and_detachment(self):
        self.seed()
        for value in [True, 1.5, '1', -1]:
            bad = posting()
            bad['lines'][0]['debit'] = value
            self.assertRejects('journal.post', **bad)
        for bad in [dict(posting(), lines=[]), dict(posting(), lines=[{'account': 'cash', 'debit': 1, 'credit': 1}]*2),
                    dict(posting(), lines=[{'account': 'cash', 'debit': 0, 'credit': 0}]*2),
                    dict(posting(), date=True), dict(posting(), date=10), dict(posting(), key=''),
                    dict(posting(), extra=1)]:
            self.assertRejects('journal.post', **bad)
        bad = posting()
        bad['lines'][1]['credit'] = 124
        self.assertRejects('journal.post', **bad)
        bad = posting()
        bad['lines'][1]['account'] = 'absent'
        self.assertRejects('journal.post', **bad)
        self.assertRejects('account.create', id='cash', name='duplicate', kind='asset')
        self.assertRejects('period.create', id='invalid', start=True, end=9)
        self.assertRejects('period.close', id='jan', expected_revision=True)
        self.assertRejects('journal.get', id='absent')
        self.assertRejects('journal.list', account='absent')
        self.assertRejects('unknown')
        request = posting()
        before = copy.deepcopy(request)
        result = self.c('journal.post', **request)
        self.assertEqual(request, before)
        result['lines'][0]['debit'] = 999
        request['lines'][0]['debit'] = 999
        self.assertEqual(self.c('journal.get', id='sale')['lines'][0]['debit'], 123)
        backup = self.c('backup')
        backup['state']['accounts']['cash']['name'] = 'changed'
        self.assertEqual(self.c('backup')['state']['accounts']['cash']['name'], 'Caisse café')
        self.restart()
        self.assertEqual(self.c('account.balance', id='cash')['net'], 123)
        self.assertRejects('journal.reverse', id='sale', reversal_id='sale', date=6, key='reverse')
        self.assertRejects('journal.reverse', id='sale', reversal_id='undo', date=6, key='sale-key')
        self.c('journal.reverse', id='sale', reversal_id='undo', date=6, key='reverse')
        self.assertEqual(self.c('account.balance', id='cash')['net'], 0)

    def test_restore_integrity(self):
        self.seed()
        self.c('journal.post', **posting())
        self.c('journal.reverse', id='sale', reversal_id='undo', date=6, key='reverse')
        self.assertCorruptions(
            lambda b: b['state']['accounts'].pop('cash'),
            lambda b: b['state']['periods']['jan'].update(end=1),
            lambda b: b['state']['periods'].update(other={'id': 'other', 'start': 1, 'end': 9, 'status': 'open', 'revision': 1}),
            lambda b: b['state']['entries']['sale']['lines'][0].update(debit=124),
            lambda b: b['state']['entries']['sale'].update(reversal='missing'),
            lambda b: b['state']['entries']['undo']['lines'][0].update(credit=124),
            lambda b: b['state']['keys']['sale-key']['result'].update(date=9),
            lambda b: b['state']['periods']['jan'].update(revision=True))
        self.assertRejects('restore', state={})
        self.assertEqual(self.c('account.balance', id='cash')['net'], 0)

    def test_repeated_lines_import_and_order(self):
        self.seed()
        payload = posting('split', 'split')
        payload['lines'] = [{'account': 'cash', 'debit': 1, 'credit': 0},
                            {'account': 'cash', 'debit': 2, 'credit': 0},
                            {'account': 'income', 'debit': 0, 'credit': 3}]
        self.assertEqual(self.c('journal.post', **payload)['lines'], payload['lines'])
        self.assertEqual(self.c('account.balance', id='cash')['net'], 3)
        self.assertRejects('journal.import', entries=[posting('new', 'key'), posting('other', 'key')])
        self.assertEqual(self.c('journal.import', entries=[posting('new', 'key')]), {'imported': 1})
        self.assertEqual(self.c('account.balance', id='cash')['net'], 126)
        self.assertEqual(self.c('journal.import', entries=[]), {'imported': 0})

    def test_concurrent_posts_and_revision(self):
        self.seed()
        results = self.race(*[('journal.post', posting(str(i), str(i))) for i in range(6)])
        self.assertEqual(sum(ok for ok, _ in results), 6)
        self.assertEqual(self.c('account.balance', id='cash')['net'], 738)
        self.assertEqual(len(self.c('journal.list')), 6)
        results = self.race(*[('period.close', {'id': 'jan', 'expected_revision': 1}) for _ in range(3)])
        self.assertEqual(sum(ok for ok, _ in results), 1)
        self.assertRejects('journal.post', **posting('late', 'late'))
        self.c('period.reopen', id='jan', expected_revision=2)
        results = self.race(*[('journal.post', posting('same', 'same')) for _ in range(3)])
        self.assertEqual(sum(ok for ok, _ in results), 3)
        self.assertEqual(len(self.c('journal.list')), 7)
        self.assertEqual(self.c('account.balance', id='cash')['net'], 861)


if __name__ == '__main__':
    unittest.main()
