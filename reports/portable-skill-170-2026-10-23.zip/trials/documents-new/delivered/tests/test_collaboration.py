import copy
import unittest
from app import Service
from goalpilot_support import JourneyMixin, rejects


class Collaboration(JourneyMixin, unittest.TestCase):
    def setUp(self):
        self.open_service(Service)

    def test_complete_journey(self):
        def flow(c):
            original = {'title': 'café', 'body': ''}
            created = c('document.create', id='doc', fields=original)
            self.assertEqual(created, dict(id='doc', revision=1, fields=original,
                                          status='draft', approved=[], published=0))
            rejects(lambda: c('document.live', id='doc'))
            branch = c('branch.create', id='feature', document='doc')
            self.assertEqual(branch, dict(id='feature', document='doc', base_revision=1,
                                         revision=1, fields=original, status='open'))
            self.assertEqual(c('branch.get', id='feature'), branch)
            c('branch.edit', id='feature', expected_revision=1, changes={'title': 'révisé'})
            c('document.edit', id='doc', expected_revision=1, changes={'body': 'live'})
            rejects(lambda: c('branch.merge', id='feature', expected_revision=2, document_revision=1))
            merged = c('branch.merge', id='feature', expected_revision=2, document_revision=2)
            self.assertEqual(merged['fields'], {'title': 'révisé', 'body': 'live'})
            self.assertEqual(merged['revision'], 3)
            self.assertEqual(c('branch.get', id='feature')['status'], 'merged')
            rejects(lambda: c('branch.edit', id='feature', expected_revision=3, changes={'x': 'y'}))
            rejects(lambda: c('document.publish', id='doc', expected_revision=3))
            first = c('document.approve', id='doc', expected_revision=3, actor='Zoé')
            self.assertEqual(c('document.approve', id='doc', expected_revision=3, actor='Zoé'), first)
            self.assertEqual(first['status'], 'draft')
            approved = c('document.approve', id='doc', expected_revision=3, actor='Alice')
            self.assertEqual(approved['approved'], ['Alice', 'Zoé'])
            self.assertEqual(approved['status'], 'approved')
            self.assertEqual(approved['revision'], 3)
            c('document.publish', id='doc', expected_revision=3)
            live = c('document.live', id='doc')
            self.assertEqual(live, dict(id='doc', revision=3, fields=merged['fields']))
            c('document.edit', id='doc', expected_revision=3, changes={'body': 'new draft'})
            self.assertEqual(c('document.live', id='doc'), live)
            draft = c('document.get', id='doc')
            self.assertEqual((draft['status'], draft['approved'], draft['published']), ('draft', [], 3))
            c('branch.create', id='conflict', document='doc')
            c('branch.edit', id='conflict', expected_revision=1, changes={'body': 'branch'})
            c('document.edit', id='doc', expected_revision=4, changes={'body': 'existing'})
            before = c('backup')
            rejects(lambda: c('branch.merge', id='conflict', expected_revision=2, document_revision=5))
            self.assertEqual(c('backup'), before)
            c('branch.edit', id='conflict', expected_revision=2, changes={'body': 'existing', 'extra': ''})
            equal = c('branch.merge', id='conflict', expected_revision=3, document_revision=5)
            self.assertEqual(equal['fields']['body'], 'existing')
            self.assertEqual(equal['fields']['extra'], '')
            rejects(lambda: c('document.import', documents=[{'id': 'temporary', 'fields': {'a': 'b'}},
                                                          {'id': 'doc', 'fields': {'a': 'b'}}]))
            self.assertEqual(c('document.list'), ['doc'])
            self.assertEqual(c('document.import', documents=[{'id': 'other', 'fields': {'a': 'b'}}]), {'imported': 1})
            snapshot = c('backup')
            c('document.edit', id='other', expected_revision=1, changes={'a': 'later'})
            c('restore', state=snapshot)
            self.assertEqual(c('document.get', id='other')['fields'], {'a': 'b'})
            c('document.edit', id='other', expected_revision=1, changes={'a': 'after restore'})
            self.assertEqual(c('document.list'), ['doc', 'other'])
        self.assertJourney(flow)

    def test_guards_detachment_persistence(self):
        payload = {'id': 'd', 'fields': {'a': 'original'}}
        saved = copy.deepcopy(payload)
        result = self.service.call('document.create', payload)
        self.assertEqual(payload, saved)
        result['fields']['a'] = 'external'
        self.restart()
        self.assertEqual(self.c('document.get', id='d')['fields']['a'], 'original')
        for changes in ({}, {'': 'x'}, {'a': 3}, [], None):
            self.assertRejects('document.edit', id='d', expected_revision=1, changes=changes)
        for rev in (True, 1.0, '1', 0, 2):
            self.assertRejects('document.edit', id='d', expected_revision=rev, changes={'a': 'x'})
        self.assertRejects('document.create', id='d', fields={'b': 'x'})
        self.assertRejects('document.get', id='missing')
        self.assertRejects('document.get', id='d', extra=1)
        self.assertRejects('unknown')
        self.assertRejects('document.approve', id='d', actor='', expected_revision=1)
        self.assertRejects('branch.create', id='b', document='missing')
        self.assertRejects('restore', state={})
        self.assertCorruptions(
            lambda b: b['state']['documents']['d'].__setitem__('revision', 99),
            lambda b: b['state']['documents']['d'].__setitem__('approved', ['same', 'same']),
            lambda b: b['state']['history']['d'].__setitem__('1', {'a': 'forged'}),
            lambda b: b['state']['branches'].__setitem__('bad', {'document': 'missing'}),
        )

    def test_concurrent_revision_and_merge(self):
        self.c('document.create', id='d', fields={'a': 'base', 'b': 'base'})
        results = self.race(
            ('document.edit', dict(id='d', expected_revision=1, changes={'a': 'one'})),
            ('document.edit', dict(id='d', expected_revision=1, changes={'a': 'two'})))
        self.assertEqual(sum(ok for ok, _ in results), 1)
        self.assertEqual(self.c('document.get', id='d')['revision'], 2)
        self.c('branch.create', id='b', document='d')
        self.c('branch.edit', id='b', expected_revision=1, changes={'b': 'branch'})
        results = self.race(
            ('document.edit', dict(id='d', expected_revision=2, changes={'a': 'live'})),
            ('branch.merge', dict(id='b', expected_revision=2, document_revision=2)))
        self.assertEqual(sum(ok for ok, _ in results), 1)
        current = self.c('document.get', id='d')
        if results[0][0]:
            self.assertEqual(current['fields']['a'], 'live')
            self.c('branch.merge', id='b', expected_revision=2, document_revision=3)
        else:
            self.c('document.edit', id='d', expected_revision=3, changes={'a': 'live'})
        self.assertEqual(self.c('document.get', id='d')['fields'], {'a': 'live', 'b': 'branch'})
