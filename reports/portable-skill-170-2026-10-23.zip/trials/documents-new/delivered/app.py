from goalpilot_runtime import ReplayService, fields, text, integer, require, mapping, sequence, get_record, compare_revision


def banner():
    return 'Local Ops — café'


def string(value):
    require(isinstance(value, str), 'Expected string')
    return value


def content(value):
    mapping(string)(value)
    require(all(text(key) for key in value), 'Empty field name')
    require(bool(value), 'At least one field required')
    return value


def revision(value):
    return integer(value, minimum=1)


def creation(value):
    return fields(value, {'id': text, 'fields': content})


class Service(ReplayService):
    def initial(self):
        return {'documents': {}, 'branches': {}, 'history': {}}

    def handle(self, state, op, data):
        docs, branches, history = state['documents'], state['branches'], state['history']
        if op == 'document.create':
            creation(data)
            require(data['id'] not in docs, 'Document already exists')
            document = {'id': data['id'], 'revision': 1, 'fields': dict(data['fields']),
                        'status': 'draft', 'approved': [], 'published': 0}
            docs[data['id']] = document
            history[data['id']] = {}
            return document
        if op == 'document.import':
            fields(data, {'documents': sequence(creation)})
            for item in data['documents']:
                self.handle(state, 'document.create', item)
            return {'imported': len(data['documents'])}
        if op == 'document.list':
            fields(data, {})
            return sorted(docs)
        if op in ('document.get', 'document.live', 'branch.get'):
            fields(data, {'id': text})
            record = get_record(branches if op == 'branch.get' else docs, data['id'])
            if op == 'document.live':
                require(record['published'] > 0, 'Document never published')
                return {'id': record['id'], 'revision': record['published'],
                        'fields': history[record['id']][str(record['published'])]}
            return self.branch_view(record) if op == 'branch.get' else record
        if op == 'branch.create':
            fields(data, {'id': text, 'document': text})
            require(data['id'] not in branches, 'Branch already exists')
            document = get_record(docs, data['document'])
            branch = {'id': data['id'], 'document': document['id'],
                      'base_revision': document['revision'], 'revision': 1,
                      'fields': dict(document['fields']), 'status': 'open',
                      'base_fields': dict(document['fields'])}
            branches[branch['id']] = branch
            return self.branch_view(branch)
        if op in ('document.edit', 'branch.edit'):
            fields(data, {'id': text, 'expected_revision': revision, 'changes': content})
            record = get_record(docs if op == 'document.edit' else branches, data['id'])
            compare_revision(record, data['expected_revision'])
            if op == 'branch.edit':
                require(record['status'] == 'open', 'Branch is closed')
            record['fields'].update(data['changes'])
            record['revision'] += 1
            if op == 'document.edit':
                self.draft(record)
                return record
            return self.branch_view(record)
        if op == 'branch.merge':
            fields(data, {'id': text, 'expected_revision': revision, 'document_revision': revision})
            branch = get_record(branches, data['id'])
            compare_revision(branch, data['expected_revision'])
            require(branch['status'] == 'open', 'Branch is closed')
            document = get_record(docs, branch['document'])
            compare_revision(document, data['document_revision'])
            changes = {key: value for key, value in branch['fields'].items()
                       if key not in branch['base_fields'] or value != branch['base_fields'][key]}
            for key, value in changes.items():
                base, live = branch['base_fields'], document['fields']
                live_changed = (key in live) != (key in base) or live.get(key) != base.get(key)
                require(not live_changed or live.get(key) == value, 'Conflicting field: ' + key)
            document['fields'].update(changes)
            document['revision'] += 1
            self.draft(document)
            branch['status'] = 'merged'
            branch['revision'] += 1
            return document
        if op in ('document.approve', 'document.publish'):
            schema = {'id': text, 'expected_revision': revision}
            if op == 'document.approve':
                schema['actor'] = text
            fields(data, schema)
            document = get_record(docs, data['id'])
            compare_revision(document, data['expected_revision'])
            if op == 'document.approve':
                require(document['status'] in ('draft', 'approved'), 'Document is published')
                document['approved'] = sorted(set(document['approved']) | {data['actor']})
                document['status'] = 'approved' if len(document['approved']) >= 2 else 'draft'
            else:
                require(document['status'] == 'approved', 'Two approvals required')
                history[document['id']][str(document['revision'])] = dict(document['fields'])
                document['published'] = document['revision']
                document['status'] = 'published'
            return document
        raise ValueError('Unknown operation')

    @staticmethod
    def draft(document):
        document['approved'] = []
        document['status'] = 'draft'

    @staticmethod
    def branch_view(branch):
        return {key: value for key, value in branch.items() if key != 'base_fields'}


if __name__ == '__main__':
    Service.main()
