from goalpilot_runtime import ReplayService, fields, text, integer, boolean, identifiers, require, get_record, compare_revision, choice


def banner():
    return 'Local Ops — café'


class Service(ReplayService):
    def initial(self):
        return {'practitioners': {}, 'patients': {}, 'appointments': {}, 'keys': {}, 'wait': []}

    def handle(self, s, op, d):
        appointments = s['appointments']
        if op == 'practitioner.put':
            fields(d, {'id': text, 'skills': identifiers})
            skills = identifiers(d['skills'])
            require(all(a['skill'] in skills for a in appointments.values()
                        if a['practitioner'] == d['id'] and a['status'] != 'cancelled'), 'Skill is in use')
            r = {'id': d['id'], 'skills': skills}
            s['practitioners'][d['id']] = r
            return r
        if op == 'patient.put':
            fields(d, {'id': text, 'consent': boolean})
            r = dict(d)
            s['patients'][d['id']] = r
            return r
        if op == 'appointment.create':
            fields(d, {'id': text, 'patient': text, 'practitioner': text,
                       'start': integer, 'end': integer, 'skill': text, 'fee': integer, 'key': text})
            require(d['end'] > d['start'], 'Invalid interval')
            if d['key'] in s['keys']:
                saved = s['keys'][d['key']]
                require(saved['request'] == d, 'Conflicting key')
                return saved['result']
            require(d['id'] not in appointments, 'Duplicate appointment')
            patient = get_record(s['patients'], d['patient'])
            practitioner = get_record(s['practitioners'], d['practitioner'])
            require(patient['consent'], 'Consent required')
            require(d['skill'] in practitioner['skills'], 'Skill unavailable')
            r = {k: v for k, v in d.items() if k != 'key'}
            r.update(status='confirmed', revision=1, charged=0)
            self.available(s, r)
            appointments[r['id']] = r
            s['keys'][d['key']] = {'request': dict(d), 'result': dict(r)}
            return r
        if op == 'appointment.import':
            fields(d, {'appointments': lambda x: require(isinstance(x, list), 'Expected list')})
            for payload in d['appointments']:
                self.handle(s, 'appointment.create', payload)
            return {'imported': len(d['appointments'])}
        if op in ('appointment.move', 'appointment.cancel', 'appointment.finish'):
            spec = {'id': text, 'expected_revision': integer}
            if op.endswith('move'):
                spec.update(start=integer, end=integer)
            if op.endswith('finish'):
                spec['attended'] = boolean
            fields(d, spec)
            r = get_record(appointments, d['id'])
            compare_revision(r, d['expected_revision'])
            require(r['status'] == 'confirmed', 'Appointment is not confirmed')
            if op.endswith('move'):
                require(d['end'] > d['start'], 'Invalid interval')
                candidate = dict(r, start=d['start'], end=d['end'])
                self.available(s, candidate, r['id'])
                r.update(start=d['start'], end=d['end'])
            elif op.endswith('cancel'):
                r['status'] = 'cancelled'
            else:
                r['status'] = 'attended' if d['attended'] else 'missed'
                r['charged'] = r['fee'] if d['attended'] else r['fee'] // 2
            r['revision'] += 1
            return r
        if op == 'appointment.get':
            fields(d, {'id': text})
            return get_record(appointments, d['id'])
        if op == 'appointment.list':
            fields(d, {}, {'patient': text, 'practitioner': text,
                           'status': choice('confirmed', 'cancelled', 'attended', 'missed')})
            return sorted((a for a in appointments.values() if all(a[k] == v for k, v in d.items())),
                          key=lambda a: (a['start'], a['id']))
        if op == 'invoice':
            fields(d, {'patient': text})
            get_record(s['patients'], d['patient'])
            rows = [a for a in appointments.values() if a['patient'] == d['patient']]
            return {'charged': sum(a['charged'] for a in rows),
                    'attended': sum(a['status'] == 'attended' for a in rows),
                    'missed': sum(a['status'] == 'missed' for a in rows)}
        if op == 'wait.add':
            fields(d, {'id': text, 'patient': text, 'skill': text})
            require(get_record(s['patients'], d['patient'])['consent'], 'Consent required')
            require(not any(w['id'] == d['id'] for w in s['wait']), 'Duplicate wait ID')
            require(not any(w['patient'] == d['patient'] and w['skill'] == d['skill']
                            for w in s['wait']), 'Duplicate wait request')
            s['wait'].append(dict(d))
            return d
        if op == 'wait.list':
            fields(d, {'skill': text})
            return [w for w in s['wait'] if w['skill'] == d['skill']]
        if op == 'wait.remove':
            fields(d, {'id': text})
            r = next((w for w in s['wait'] if w['id'] == d['id']), None)
            require(r is not None, 'Missing wait request')
            s['wait'].remove(r)
            return r
        raise ValueError('Unknown operation')

    def available(self, s, candidate, ignore=None):
        for a in s['appointments'].values():
            if a['id'] == ignore or a['status'] == 'cancelled':
                continue
            if (a['patient'] == candidate['patient'] or a['practitioner'] == candidate['practitioner']):
                require(candidate['end'] <= a['start'] or candidate['start'] >= a['end'],
                        'Appointment overlap')


if __name__ == '__main__':
    Service.main()
