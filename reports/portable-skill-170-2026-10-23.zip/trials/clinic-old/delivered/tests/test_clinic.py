import copy
import json
import os
import subprocess
import sys
import tempfile
import unittest
from app import Service
from goalpilot_support import JourneyMixin, transport_journey


class Clinic(JourneyMixin, unittest.TestCase):
    def setUp(self):
        self.open_service(Service)
        self.c('practitioner.put', id='dr', skills=['soin', 'soin'])
        self.c('practitioner.put', id='dr2', skills=['soin'])
        for p in ['élise', 'paul', 'luc']:
            self.c('patient.put', id=p, consent=True)

    def booking(self, **kw):
        d = dict(id='a', patient='élise', practitioner='dr', start=10, end=20,
                 skill='soin', fee=101, key='k')
        d.update(kw)
        return d

    def test_lifecycle(self):
        payload = self.booking()
        a = self.c('appointment.create', **payload)
        self.assertEqual(a['revision'], 1)
        a['status'] = 'tampered'
        self.c('appointment.move', id='a', start=20, end=30, expected_revision=1)
        self.assertEqual(self.c('appointment.create', **payload)['start'], 10)
        self.assertRejects('appointment.move', id='a', start=0, end=10, expected_revision=1)
        self.c('appointment.finish', id='a', expected_revision=2, attended=False)
        self.assertEqual(self.c('invoice', patient='élise'), {'charged': 50, 'attended': 0, 'missed': 1})
        self.assertRejects('appointment.create', **self.booking(id='b', key='b', start=25, end=35))
        self.assertRejects('practitioner.put', id='dr', skills=[])
        self.c('patient.put', id='élise', consent=False)
        self.assertRejects('appointment.create', **self.booking(id='b', key='b', start=30, end=40))
        self.restart()
        self.assertEqual(self.c('appointment.get', id='a')['status'], 'missed')
        self.assertEqual(payload, self.booking())

    def test_wait_cancel_import_restore(self):
        self.c('wait.add', id='z', patient='élise', skill='soin')
        self.c('wait.add', id='a', patient='paul', skill='soin')
        self.restart()
        self.assertEqual([x['id'] for x in self.c('wait.list', skill='soin')], ['z', 'a'])
        self.assertRejects('wait.add', id='b', patient='élise', skill='soin')
        self.c('appointment.create', **self.booking())
        self.c('appointment.cancel', id='a', expected_revision=1)
        self.c('appointment.create', **self.booking(id='b', key='b'))
        self.assertRejects('appointment.import', appointments=[self.booking(id='c', key='c', start=30, end=40), self.booking(id='d', key='d', start=35, end=45)])
        self.assertEqual(len(self.c('appointment.list')), 2)
        snap = self.c('backup')
        self.c('wait.remove', id='z')
        self.c('restore', state=snap)
        self.assertEqual(len(self.c('wait.list', skill='soin')), 2)
        bad = copy.deepcopy(snap)
        bad['state']['appointments']['b']['charged'] = 999
        self.assertRejects('restore', state=bad)
        self.c('appointment.finish', id='b', expected_revision=1, attended=True)
        self.assertEqual(self.c('invoice', patient='élise')['charged'], 101)

    def test_rejections_and_race(self):
        for field, value in [('start', True), ('end', 10.5), ('fee', '10'), ('patient', ''), ('key', None)]:
            self.assertRejects('appointment.create', **self.booking(**{field: value}))
        self.assertRejects('patient.put', id='x', consent=1)
        results = self.race(*[('appointment.create', self.booking(id=str(i), key=str(i), patient=p))
                              for i, p in enumerate(['élise', 'paul'])])
        self.assertEqual(sum(ok for ok, _ in results), 1)
        self.assertEqual(len(self.c('appointment.list')), 1)
        winner = self.c('appointment.list')[0]
        results = self.race(*[('appointment.move', dict(id=winner['id'], start=t, end=t+10, expected_revision=1)) for t in [30, 50]])
        self.assertEqual(sum(ok for ok, _ in results), 1)

    def test_real_transports(self):
        a = self.booking()
        expected = {k: v for k, v in a.items() if k != 'key'}
        expected.update(status='confirmed', revision=1, charged=0)
        transport_journey([sys.executable, os.path.abspath('app.py'), '--file', os.path.join(tempfile.gettempdir(), 'clinic-transport-test.json')], [
            ('practitioner.put', {'id': 'dr', 'skills': ['soin']}, {'id': 'dr', 'skills': ['soin']}),
            ('patient.put', {'id': 'élise', 'consent': True}, {'id': 'élise', 'consent': True}),
            ('appointment.create', a, expected),
            ('appointment.list', {}, [expected]),
            ('invoice', {'patient': 'élise'}, {'charged': 0, 'attended': 0, 'missed': 0}),
        ])

    def test_fresh_process(self):
        with tempfile.TemporaryDirectory() as folder:
            path = os.path.join(folder, 'data.json')
            s = Service(path)
            s.call('patient.put', {'id': 'é', 'consent': True})
            result = subprocess.run([sys.executable, 'app.py', '--file', path, 'jsonl'],
                                    input=json.dumps({'operation': 'backup', 'data': {}}), text=True,
                                    capture_output=True, check=True)
            state = json.loads(result.stdout)['result']['state']
            self.assertTrue(state['patients']['é']['consent'])
