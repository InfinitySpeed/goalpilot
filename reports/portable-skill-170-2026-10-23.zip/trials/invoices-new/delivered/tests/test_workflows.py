import copy
import json
import subprocess
import sys
import unittest
from app import Service
from goalpilot_support import JourneyMixin, rejects, jsonl, json_http


class Workflows(JourneyMixin, unittest.TestCase):
    def setUp(self):
        self.open_service(Service)

    def test_complete_journey(self):
        def flow(c):
            self.assertEqual(c('customer.put', id='café', name='Élodie'), {'id': 'café', 'name': 'Élodie'})
            c('customer.put', id='other', name='Other')
            lines = [{'description': 'Thé', 'quantity': 3, 'unit_cents': 101},
                     {'description': 'Service', 'quantity': 1, 'unit_cents': 2}]
            invoice = c('invoice.create', id='a', customer='café', lines=lines, tax_bps=1000)
            self.assertEqual(invoice, dict(id='a', customer='café', status='draft', lines=lines,
                             subtotal=305, tax=31, total=336, paid=0, credited=0, balance=336, revision=1))
            rejects(lambda: c('invoice.pay', id='a', amount=1, key='draft'))
            rejects(lambda: c('invoice.issue', id='a', expected_revision=2))
            self.assertEqual(c('invoice.issue', id='a', expected_revision=1)['revision'], 2)
            paid = c('invoice.pay', id='a', amount=100, key='p1')
            self.assertEqual((paid['balance'], paid['status'], paid['revision']), (236, 'partial', 3))
            credited = c('invoice.credit', id='a', amount=36, key='credit')
            self.assertEqual((credited['credited'], credited['balance']), (36, 200))
            self.assertEqual(c('invoice.pay', id='a', amount=100, key='p1'), paid)
            rejects(lambda: c('invoice.credit', id='a', amount=100, key='p1'))
            rejects(lambda: c('invoice.pay', id='a', amount=101, key='p1'))
            before = c('backup')
            rejects(lambda: c('payment.import', payments=[{'id': 'a', 'amount': 50, 'key': 'batch'},
                                                          {'id': 'a', 'amount': 151, 'key': 'overflow'}]))
            self.assertEqual(c('backup'), before)
            self.assertEqual(c('payment.import', payments=[{'id': 'a', 'amount': 50, 'key': 'batch'},
                                                           {'id': 'a', 'amount': 150, 'key': 'last'}]), {'imported': 2})
            self.assertEqual(c('invoice.get', id='a')['status'], 'paid')
            self.assertEqual(c('statement', customer='café'), {'invoiced': 336, 'paid': 300, 'credited': 36, 'due': 0})
            rejects(lambda: c('invoice.credit', id='a', amount=1, key='too-much'))
            c('invoice.create', id='b', customer='café', lines=[{'description': 'B', 'quantity': 1, 'unit_cents': 10}], tax_bps=0)
            c('invoice.issue', id='b', expected_revision=1)
            self.assertEqual(c('invoice.credit', id='b', amount=10, key='all-credit')['status'], 'credited')
            rejects(lambda: c('invoice.pay', id='b', amount=1, key='forbidden'))
            c('invoice.create', id='v', customer='other', lines=lines, tax_bps=0)
            self.assertEqual(c('invoice.void', id='v', expected_revision=1)['balance'], 0)
            rejects(lambda: c('invoice.issue', id='v', expected_revision=2))
            self.assertEqual([r['id'] for r in c('invoice.list', customer='café')], ['a', 'b'])
            self.assertEqual([r['id'] for r in c('invoice.list', status='void')], ['v'])
            self.assertEqual([r['id'] for r in c('customer.list')], ['café', 'other'])
            c('restore', state=before)
            self.assertEqual(c('invoice.get', id='a')['balance'], 200)
            self.assertEqual(len(c('customer.list')), 2)
            self.assertEqual(c('invoice.pay', id='a', amount=100, key='p1'), paid)
            self.assertEqual(c('invoice.pay', id='a', amount=200, key='after-restore')['status'], 'paid')
        self.assertJourney(flow)

    def test_guards_snapshots_corruption_and_restart(self):
        self.c('customer.put', id='c', name='Customer')
        data = dict(id='i', customer='c', lines=[dict(description='Half', quantity=1, unit_cents=1)], tax_bps=5000)
        original = copy.deepcopy(data)
        created = self.service.call('invoice.create', data)
        self.assertEqual(data, original)
        self.assertEqual(created['total'], 2)
        created['lines'][0]['unit_cents'] = 999
        self.assertEqual(self.c('invoice.get', id='i')['subtotal'], 1)
        for bad in (True, 1.0, '1', -1):
            self.assertRejects('invoice.create', **{**data, 'id': 'bad', 'tax_bps': bad})
            self.assertRejects('invoice.pay', id='i', amount=bad, key='bad')
        for bad in ([], [{'description': '', 'quantity': 1, 'unit_cents': 1}],
                    [{'description': 'x', 'quantity': 0, 'unit_cents': 1}],
                    [{'description': 'x', 'quantity': True, 'unit_cents': 1}]):
            self.assertRejects('invoice.create', **{**data, 'id': 'bad', 'lines': bad})
        self.assertRejects('invoice.get', id='missing')
        self.assertRejects('nonsense')
        self.assertRejects('customer.put', id='x', name='x', unknown=1)
        self.assertRejects('restore', state={})
        saved = self.c('backup')
        def corrupt_state(b):
            b['state']['invoices']['i']['total'] = 999
        def corrupt_reference(b):
            b['state']['invoices']['i']['customer'] = 'missing'
        self.assertCorruptions(corrupt_state, corrupt_reference)
        self.assertEqual(self.c('backup'), saved)
        self.restart()
        self.assertEqual(self.c('invoice.get', id='i')['total'], 2)
        self.c('invoice.issue', id='i', expected_revision=1)
        self.c('invoice.pay', id='i', amount=1, key='once')
        backup = self.c('backup')
        backup['state']['keys']['once']['result']['balance'] = 999
        self.assertRejects('restore', state=backup)
        output = subprocess.check_output([sys.executable, 'app.py', '--file', str(self.path), 'jsonl'],
                     input='{"operation":"invoice.get","data":{"id":"i"}}\n', text=True)
        self.assertEqual(json.loads(output)['result']['paid'], 1)

    def test_concurrent_limits_and_revision(self):
        self.c('customer.put', id='c', name='C')
        self.c('invoice.create', id='i', customer='c', lines=[dict(description='X', quantity=1, unit_cents=100)], tax_bps=0)
        outcomes = self.race(*[('invoice.issue', dict(id='i', expected_revision=1)) for _ in range(3)])
        self.assertEqual(sum(ok for ok, _ in outcomes), 1)
        outcomes = self.race(*[('invoice.pay', dict(id='i', amount=60, key='k'+str(n))) for n in range(3)])
        self.assertEqual(sum(ok for ok, _ in outcomes), 1)
        self.assertEqual(self.c('invoice.get', id='i')['balance'], 40)
        outcomes = self.race(*[('customer.put', dict(id='c'+str(n), name='C')) for n in range(3)])
        self.assertTrue(all(ok for ok, _ in outcomes))
        self.assertEqual(len(self.c('customer.list')), 4)

    def test_protocol_recovery(self):
        argv = [sys.executable, 'app.py', '--file', str(self.path)]
        responses = jsonl(argv, ['{bad', {'operation': 'unknown', 'data': {}},
                                 {'operation': 'customer.list', 'data': {}}])
        self.assertFalse(responses[0]['ok'])
        self.assertFalse(responses[1]['ok'])
        self.assertEqual(responses[2], {'ok': True, 'result': []})
        with json_http(argv) as request:
            self.assertEqual(request('GET', '/health'), {'ok': True})
            self.assertFalse(request('GET', '/missing', status=404)['ok'])
            self.assertFalse(request('POST', '/api', {'operation': 'unknown', 'data': {}}, status=400)['ok'])
