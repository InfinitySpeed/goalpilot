from copy import deepcopy
from goalpilot_runtime import ReplayService, fields, text, integer, sequence, require, get_record, compare_revision


def banner():
    return 'Local Ops — café'


def positive(value):
    return integer(value, minimum=1)


def line(value):
    return fields(value, {'description': text, 'quantity': positive, 'unit_cents': integer})


class Service(ReplayService):
    def initial(self):
        return {'customers': {}, 'invoices': {}, 'keys': {}}

    def handle(self, state, op, data):
        customers, invoices = state['customers'], state['invoices']
        if op == 'customer.put':
            fields(data, {'id': text, 'name': text})
            customers[data['id']] = deepcopy(data)
            return customers[data['id']]
        if op == 'customer.list':
            fields(data, {})
            return [customers[k] for k in sorted(customers)]
        if op == 'invoice.create':
            fields(data, {'id': text, 'customer': text, 'lines': sequence(line, nonempty=True),
                          'tax_bps': lambda x: integer(x, maximum=10000)})
            require(data['id'] not in invoices, 'Invoice already exists')
            get_record(customers, data['customer'])
            subtotal = sum(x['quantity'] * x['unit_cents'] for x in data['lines'])
            tax = (subtotal * data['tax_bps'] + 5000) // 10000
            record = {'id': data['id'], 'customer': data['customer'], 'status': 'draft',
                      'lines': deepcopy(data['lines']), 'subtotal': subtotal, 'tax': tax,
                      'total': subtotal + tax, 'paid': 0, 'credited': 0,
                      'balance': subtotal + tax, 'revision': 1}
            invoices[data['id']] = record
            return record
        if op == 'invoice.get':
            fields(data, {'id': text})
            return get_record(invoices, data['id'])
        if op == 'invoice.list':
            fields(data, {}, optional={'customer': text, 'status': text})
            if 'customer' in data:
                get_record(customers, data['customer'])
            if 'status' in data:
                require(data['status'] in ('draft', 'issued', 'partial', 'paid', 'credited', 'void'))
            return [invoices[k] for k in sorted(invoices)
                    if all(invoices[k][f] == v for f, v in data.items())]
        if op in ('invoice.issue', 'invoice.void'):
            fields(data, {'id': text, 'expected_revision': positive})
            record = get_record(invoices, data['id'])
            compare_revision(record, data['expected_revision'])
            if op == 'invoice.issue':
                require(record['status'] == 'draft', 'Only drafts may be issued')
                record['status'] = 'issued'
            else:
                require(record['status'] in ('draft', 'issued') and
                        record['paid'] == record['credited'] == 0, 'Cannot void invoice')
                record['status'], record['balance'] = 'void', 0
            record['revision'] += 1
            return record
        if op in ('invoice.pay', 'invoice.credit'):
            fields(data, {'id': text, 'amount': positive, 'key': text})
            previous = state['keys'].get(data['key'])
            if previous is not None:
                require(previous['operation'] == op and previous['data'] == data,
                        'Idempotency key conflict')
                return previous['result']
            record = get_record(invoices, data['id'])
            allowed = ('issued', 'partial') if op == 'invoice.pay' else ('issued', 'partial', 'paid')
            require(record['status'] in allowed, 'Invoice cannot receive money operations')
            require(data['amount'] <= record['balance'], 'Amount exceeds balance')
            field = 'paid' if op == 'invoice.pay' else 'credited'
            record[field] += data['amount']
            record['balance'] = record['total'] - record['paid'] - record['credited']
            record['status'] = ('credited' if record['paid'] == 0 else 'paid') if record['balance'] == 0 else 'partial'
            record['revision'] += 1
            result = deepcopy(record)
            state['keys'][data['key']] = {'operation': op, 'data': deepcopy(data), 'result': result}
            return result
        if op == 'payment.import':
            fields(data, {'payments': sequence(lambda x: fields(x, {'id': text, 'amount': positive, 'key': text}))})
            for payment in data['payments']:
                self.handle(state, 'invoice.pay', payment)
            return {'imported': len(data['payments'])}
        if op == 'statement':
            fields(data, {'customer': text})
            get_record(customers, data['customer'])
            records = [r for r in invoices.values() if r['customer'] == data['customer']]
            return {'invoiced': sum(r['total'] for r in records if r['status'] != 'void'),
                    'paid': sum(r['paid'] for r in records),
                    'credited': sum(r['credited'] for r in records),
                    'due': sum(r['balance'] for r in records)}
        raise ValueError('Unknown operation')


if __name__ == '__main__':
    Service.main()
