from goalpilot_runtime import ReplayService, require, text, integer, identifiers, fields, get_record, compare_revision, idempotent


def banner():
    return 'Local Ops — café'


class Service(ReplayService):
    def initial(self):
        return {'teams': {}, 'policies': {}, 'incidents': {}, 'keys': {}}

    def public(self, r):
        return {k: r[k] for k in ('id', 'team', 'title', 'status', 'owner', 'revision', 'level',
                                  'acknowledged', 'resolved', 'paused')}

    def elapsed(self, r, now):
        end = r['resolved'] if r['status'] == 'resolved' else now
        return end - r['start'] - r['pause_total'] - (end - r['pause_start'] if r['paused'] else 0)

    def inspect(self, r, now):
        elapsed = self.elapsed(r, now)
        active = r['status'] != 'resolved'
        return dict(self.public(r), elapsed=elapsed,
                    response_breached=active and r['acknowledged'] is None and elapsed >= r['sla']['response'],
                    resolve_breached=active and elapsed >= r['sla']['resolve'])

    def open_incident(self, s, d):
        fields(d, {'id': text, 'team': text, 'policy': text, 'now': integer, 'title': text, 'key': text})
        def create():
            require(d['id'] not in s['incidents'], 'Incident already exists')
            get_record(s['teams'], d['team'])
            sla = get_record(s['policies'], d['policy']).copy()
            r = dict(id=d['id'], team=d['team'], title=d['title'], status='open', owner=None,
                     revision=1, level=0, acknowledged=None, resolved=None, paused=False,
                     start=d['now'], last=d['now'], pause_total=0, pause_start=None,
                     sla=sla, escalations=[], history=[{'operation': 'incident.open', 'now': d['now']}])
            s['incidents'][d['id']] = r
            return self.public(r)
        return idempotent(s, d['key'], 'incident.open', d, create)

    def handle(self, s, op, d):
        require(isinstance(d, dict), 'Data must be an object')
        if op == 'team.put':
            fields(d, {'id': text, 'members': lambda v: identifiers(v, nonempty=True)})
            members = identifiers(d['members'], nonempty=True)
            for r in s['incidents'].values():
                require(r['team'] != d['id'] or r['status'] == 'resolved' or
                        r['owner'] is None or r['owner'] in members, 'Assigned owner must remain a member')
            s['teams'][d['id']] = {'id': d['id'], 'members': members}
            return s['teams'][d['id']]
        if op == 'policy.put':
            fields(d, {'id': text, 'response': lambda v: integer(v, minimum=1),
                       'resolve': lambda v: integer(v, minimum=1)})
            require(d['resolve'] >= d['response'], 'Resolve must be at least response')
            s['policies'][d['id']] = d.copy()
            return s['policies'][d['id']]
        if op == 'incident.open':
            return self.open_incident(s, d)
        if op == 'incident.import':
            fields(d, {'incidents': lambda v: require(isinstance(v, list), 'Expected list')})
            for item in d['incidents']:
                self.open_incident(s, item)
            return {'imported': len(d['incidents'])}
        if op == 'incident.list':
            fields(d, {}, {'team': text, 'status': lambda v: require(v in ('open', 'acknowledged', 'resolved'), 'Invalid status')})
            return [self.public(r) for _, r in sorted(s['incidents'].items())
                    if all(r[k] == v for k, v in d.items())]
        if op == 'incident.inspect':
            fields(d, {'id': text, 'now': integer})
            r = get_record(s['incidents'], d['id'])
            require(d['now'] >= r['last'], 'Time moved backwards')
            return self.inspect(r, d['now'])
        allowed = ('incident.assign', 'incident.ack', 'incident.pause', 'incident.resume',
                   'incident.resolve', 'incident.reopen', 'escalate')
        require(op in allowed, 'Unknown operation')
        required = {'id': text, 'expected_revision': lambda v: integer(v, minimum=1), 'now': integer}
        if op == 'incident.assign':
            required['owner'] = text
        fields(d, required)
        r = get_record(s['incidents'], d['id'])
        compare_revision(r, d['expected_revision'])
        now = d['now']
        require(now >= r['last'], 'Time moved backwards')
        if op == 'incident.reopen':
            require(r['status'] == 'resolved', 'Incident must be resolved')
            # A resolved owner may have left the team; reopening cannot create an invalid assignment.
            require(r['owner'] is None or r['owner'] in s['teams'][r['team']]['members'], 'Owner is no longer a member')
            r.update(status='open', acknowledged=None, resolved=None, paused=False, start=now,
                     pause_total=0, pause_start=None, level=0, escalations=[])
        else:
            require(r['status'] != 'resolved', 'Incident is resolved')
            if op == 'incident.assign':
                require(d['owner'] in s['teams'][r['team']]['members'], 'Owner must be a member')
                r['owner'] = d['owner']
            elif op == 'incident.ack':
                require(r['status'] == 'open' and r['acknowledged'] is None, 'Already acknowledged')
                r.update(status='acknowledged', acknowledged=now)
            elif op == 'incident.pause':
                require(not r['paused'], 'Already paused')
                r.update(paused=True, pause_start=now)
            elif op == 'incident.resume':
                require(r['paused'], 'Not paused')
                r['pause_total'] += now - r['pause_start']
                r.update(paused=False, pause_start=None)
            elif op == 'incident.resolve':
                require(not r['paused'], 'Incident is paused')
                r.update(status='resolved', resolved=now)
            elif op == 'escalate':
                view = self.inspect(r, now)
                require(view['response_breached'] or view['resolve_breached'], 'SLA not breached')
                require(view['elapsed'] not in r['escalations'], 'Already escalated at this elapsed time')
                r['escalations'].append(view['elapsed'])
                r['level'] += 1
        r['last'] = now
        r['revision'] += 1
        r['history'].append(dict(d, operation=op))
        return self.public(r)


if __name__ == '__main__':
    Service.main()
