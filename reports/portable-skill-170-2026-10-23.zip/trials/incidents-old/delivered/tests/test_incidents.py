import os
import sys
import tempfile
import unittest
from app import Service
from goalpilot_support import JourneyMixin, transport_journey


class Incidents(JourneyMixin, unittest.TestCase):
    def setUp(self):
        self.open_service(Service)

    def seed(self):
        self.c('team.put', id='ops', members=['zoé', 'ali', 'ali'])
        self.c('policy.put', id='sla', response=5, resolve=10)
        return self.c('incident.open', id='i', team='ops', policy='sla', now=10, title='Panne café', key='k')

    def test_lifecycle(self):
        original = self.seed()
        self.assertSubset(original, status='open', revision=1, owner=None)
        self.c('incident.assign', id='i', owner='zoé', now=11, expected_revision=1)
        self.assertRejects('team.put', id='ops', members=['ali'])
        self.c('incident.pause', id='i', now=13, expected_revision=2)
        self.restart()
        self.assertSubset(self.c('incident.inspect', id='i', now=100), elapsed=3, response_breached=False)
        self.c('incident.resume', id='i', now=20, expected_revision=3)
        self.assertSubset(self.c('incident.inspect', id='i', now=22), elapsed=5, response_breached=True)
        self.c('escalate', id='i', now=22, expected_revision=4)
        self.assertRejects('escalate', id='i', now=22, expected_revision=5)
        self.c('incident.ack', id='i', now=23, expected_revision=5)
        self.c('policy.put', id='sla', response=100, resolve=200)
        self.assertSubset(self.c('incident.inspect', id='i', now=27), elapsed=10, resolve_breached=True)
        self.c('incident.resolve', id='i', now=27, expected_revision=6)
        self.assertSubset(self.c('incident.inspect', id='i', now=90), elapsed=10, resolve_breached=False)
        snapshot = self.c('backup')
        self.c('incident.reopen', id='i', now=30, expected_revision=7)
        self.assertSubset(self.c('incident.inspect', id='i', now=30), elapsed=0, level=0, owner='zoé', acknowledged=None)
        self.c('restore', state=snapshot)
        self.restart()
        self.assertSubset(self.c('incident.inspect', id='i', now=90), status='resolved', revision=7)
        self.assertEqual(self.c('incident.open', id='i', team='ops', policy='sla', now=10, title='Panne café', key='k'), original)
        self.assertCorruptions(lambda b: b['state']['incidents']['i'].__setitem__('revision', 99),
                               lambda b: b['state']['incidents']['i']['sla'].__setitem__('response', 0))

    def test_atomic_rejections_and_race(self):
        self.seed()
        for bad in (True, 1.0, '1', -1):
            self.assertRejects('incident.ack', id='i', now=bad, expected_revision=1)
        self.assertRejects('incident.assign', id='i', owner='outsider', now=10, expected_revision=1)
        self.assertRejects('incident.import', incidents=[dict(id='j', team='ops', policy='sla', now=10, title='j', key='j'), {}])
        self.assertEqual(len(self.c('incident.list')), 1)
        results = self.race(*[('incident.assign', dict(id='i', owner=owner, now=10, expected_revision=1)) for owner in ['ali', 'zoé']])
        self.assertEqual(sum(ok for ok, _ in results), 1)
        self.restart()
        self.assertEqual(self.c('incident.inspect', id='i', now=10)['revision'], 2)

    def test_transports(self):
        with tempfile.TemporaryDirectory() as tmp:
            transport_journey([sys.executable, os.path.abspath('app.py'), '--file', os.path.join(tmp, 'db.json')], [
                ('team.put', {'id':'t', 'members':['é']}, {'id':'t', 'members':['é']}),
                ('policy.put', {'id':'p','response':2,'resolve':4}, {'id':'p','response':2,'resolve':4}),
                ('incident.open', {'id':'i','team':'t','policy':'p','now':0,'title':'café','key':'k'},
                 {'id':'i','team':'t','title':'café','status':'open','owner':None,'revision':1,'level':0,'acknowledged':None,'resolved':None,'paused':False}),
            ])

    def test_batch_time_and_pause_guards(self):
        self.seed()
        batch = [{'id': name, 'team': 'ops', 'policy': 'sla', 'now': 0,
                  'title': name, 'key': name} for name in ['b', 'a']]
        self.assertEqual(self.c('incident.import', incidents=batch), {'imported': 2})
        self.assertEqual([r['id'] for r in self.c('incident.list', team='ops', status='open')], ['a', 'b', 'i'])
        self.c('incident.inspect', id='i', now=1000)
        self.c('incident.ack', id='i', now=11, expected_revision=1)
        self.assertRejects('incident.pause', id='i', now=10, expected_revision=2)
        self.assertRejects('incident.ack', id='i', now=11, expected_revision=2)
        self.c('incident.pause', id='i', now=12, expected_revision=2)
        self.assertRejects('incident.resolve', id='i', now=13, expected_revision=3)
        self.assertRejects('incident.pause', id='i', now=13, expected_revision=3)
        self.c('incident.resume', id='i', now=30, expected_revision=3)
        self.assertSubset(self.c('incident.inspect', id='i', now=38), elapsed=10, resolve_breached=True)
        self.c('escalate', id='i', now=38, expected_revision=4)
        self.c('incident.pause', id='i', now=38, expected_revision=5)
        self.assertRejects('escalate', id='i', now=40, expected_revision=6)
        self.c('incident.resume', id='i', now=41, expected_revision=6)
        self.assertRejects('escalate', id='i', now=41, expected_revision=7)
        self.c('escalate', id='i', now=42, expected_revision=7)
        backup = self.c('backup')
        backup['state']['teams']['ops']['members'].clear()
        self.assertEqual(self.c('team.put', id='ops', members=['ali', 'zoé'])['members'], ['ali', 'zoé'])
        self.assertRejects('restore', state=backup)
        self.assertRejects('incident.open', id='other', team='ops', policy='sla', now=10, title='x', key='k')
