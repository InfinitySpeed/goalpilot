import copy
import sys
import tempfile
import os
import unittest
from app import Service
from goalpilot_support import JourneyMixin, transport_journey


class Workflows(JourneyMixin, unittest.TestCase):
    def setUp(self):
        self.open_service(Service)

    def setup_dataset(self, reviews=2):
        self.c('dataset.create', id='jeu', labels=['oui', 'non', 'oui'], reviews=reviews)
        for a in ['a', 'b', 'c']:
            self.c('annotator.put', id=a, active=True)
        return self.c('item.add', dataset='jeu', id='é', payload={'texte': 'café'})

    def claim(self, a, now=0):
        return self.c('claim', dataset='jeu', annotator=a, now=now, lease=10)

    def submit(self, a, claim, label='oui', now=1):
        return self.c('submit', dataset='jeu', item='é', annotator=a,
                      receipt=claim['receipt'], now=now, label=label)

    def test_rounds_and_restore(self):
        original = self.setup_dataset()
        self.assertEqual(original['revision'], 1)
        a, b = self.claim('a'), self.claim('b')
        self.assertIsNone(self.claim('c'))
        self.assertRejects('submit', dataset='jeu', item='é', annotator='a', receipt=a['receipt'], now=10, label='oui')
        self.assertEqual(self.submit('a', a)['status'], 'reviewing')
        self.restart()
        self.c('annotator.put', id='b', active=False)
        self.assertRejects('submit', dataset='jeu', item='é', annotator='b', receipt=b['receipt'], now=1, label='non')
        self.c('annotator.put', id='b', active=True)
        done = self.submit('b', b, 'non')
        self.assertEqual((done['status'], done['consensus'], done['revision']), ('complete', None, 3))
        backup = self.c('backup')
        self.assertRejects('item.reopen', dataset='jeu', id='é', expected_revision=2)
        self.c('item.reopen', dataset='jeu', id='é', expected_revision=3)
        self.assertEqual(self.c('history', dataset='jeu', id='é'), [{'votes': done['votes'], 'consensus': None}])
        self.assertEqual(self.c('item.get', dataset='jeu', id='é')['revision'], 4)
        self.c('restore', state=backup)
        self.assertEqual(self.c('item.get', dataset='jeu', id='é'), done)
        corrupt = copy.deepcopy(backup)
        corrupt['state']['datasets']['jeu']['items']['é']['votes'][0]['label'] = 'invalid'
        self.assertRejects('restore', state=corrupt)
        done['votes'].clear()
        self.assertEqual(len(self.c('item.get', dataset='jeu', id='é')['votes']), 2)

    def test_expiry_import_rejections(self):
        self.setup_dataset(1)
        first = self.claim('a')
        second = self.claim('b', 10)
        self.assertNotEqual(first['receipt'], second['receipt'])
        self.assertRejects('submit', dataset='jeu', item='é', annotator='a', receipt=first['receipt'], now=11, label='oui')
        self.assertEqual(self.submit('b', second, now=11)['consensus'], 'oui')
        self.assertRejects('item.import', dataset='jeu', items=[{'id': 'new', 'payload': None}, {'id': 'é', 'payload': 1}])
        self.assertEqual(len(self.c('item.list', dataset='jeu')), 1)
        for invalid in [True, 1.0, '1', 0]:
            self.assertRejects('dataset.create', id='bad', labels=['x'], reviews=invalid)
        self.assertEqual(self.c('report', dataset='jeu'), {'pending': 0, 'reviewing': 0, 'complete': 1, 'disputed': 0})

    def test_process_claim_capacity(self):
        self.setup_dataset(1)
        results = self.race(*[('claim', {'dataset': 'jeu', 'annotator': a, 'now': 0, 'lease': 10}) for a in ['a', 'b', 'c']])
        self.assertEqual(sum(ok and result is not None for ok, result in results), 1)

    def test_transports(self):
        with tempfile.TemporaryDirectory() as directory:
            self.transport_checks(os.path.join(directory, 'state.json'))

    def transport_checks(self, path):
        transport_journey([sys.executable, 'app.py', '--file', path], [
            ('dataset.create', {'id': 'd', 'labels': ['é'], 'reviews': 1}, {'id': 'd', 'labels': ['é'], 'reviews': 1}),
            ('item.import', {'dataset': 'd', 'items': [{'id': 'i', 'payload': 'café'}]}, {'imported': 1}),
            ('report', {'dataset': 'd'}, {'pending': 1, 'reviewing': 0, 'complete': 0, 'disputed': 0}),
        ])
