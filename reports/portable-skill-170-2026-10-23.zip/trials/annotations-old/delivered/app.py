from goalpilot_runtime import ReplayService, require, text, integer, boolean, identifiers, get_record, fields


def banner():
    return 'Local Ops — café'


class Service(ReplayService):
    def initial(self):
        return {'datasets': {}, 'annotators': {}}

    def handle(self, state, op, d):
        schemas = {
            'dataset.create': ({'id': text, 'labels': lambda x: identifiers(x, nonempty=True), 'reviews': lambda x: integer(x, 1)}, {}),
            'annotator.put': ({'id': text, 'active': boolean}, {}),
            'item.add': ({'dataset': text, 'id': text, 'payload': lambda x: x}, {}),
            'item.import': ({'dataset': text, 'items': lambda x: require(isinstance(x, list))}, {}),
            'claim': ({'dataset': text, 'annotator': text, 'now': integer, 'lease': lambda x: integer(x, 1)}, {}),
            'submit': ({'dataset': text, 'item': text, 'annotator': text, 'receipt': text, 'now': integer, 'label': text}, {}),
            'item.reopen': ({'dataset': text, 'id': text, 'expected_revision': lambda x: integer(x, 1)}, {}),
            'item.get': ({'dataset': text, 'id': text}, {}),
            'item.list': ({'dataset': text}, {'status': text}),
            'history': ({'dataset': text, 'id': text}, {}),
            'report': ({'dataset': text}, {}),
        }
        require(op in schemas, 'Unknown operation')
        required, optional = schemas[op]
        fields(d, required, optional)
        if op == 'dataset.create':
            require(d['id'] not in state['datasets'], 'Dataset exists')
            result = {'id': d['id'], 'labels': identifiers(d['labels'], nonempty=True), 'reviews': d['reviews']}
            state['datasets'][d['id']] = dict(result, items={})
            return result
        if op == 'annotator.put':
            state['annotators'][d['id']] = dict(d)
            return dict(d)
        ds = get_record(state['datasets'], d['dataset'])
        items = ds['items']
        def public(item):
            return {k: v for k, v in item.items() if k not in ('claims', 'history')}
        def add(row):
            fields(row, {'id': text, 'payload': lambda x: x})
            require(row['id'] not in items, 'Item exists')
            item = dict(row, dataset=d['dataset'], status='pending', votes=[], revision=1, consensus=None, claims={}, history=[])
            items[row['id']] = item
            return public(item)
        if op == 'item.add':
            return add({'id': d['id'], 'payload': d['payload']})
        if op == 'item.import':
            for row in d['items']:
                add(row)
            return {'imported': len(d['items'])}
        if op == 'item.list':
            require('status' not in d or d['status'] in ('pending', 'reviewing', 'complete'), 'Invalid status')
            return [public(items[k]) for k in sorted(items) if 'status' not in d or items[k]['status'] == d['status']]
        if op == 'report':
            result = {k: 0 for k in ('pending', 'reviewing', 'complete', 'disputed')}
            for item in items.values():
                result[item['status']] += 1
                if item['status'] == 'complete' and item['consensus'] is None:
                    result['disputed'] += 1
            return result
        if op in ('claim', 'submit'):
            actor = get_record(state['annotators'], d['annotator'])
            require(actor['active'], 'Inactive annotator')
        if op == 'claim':
            for key in sorted(items):
                item = items[key]
                live = {a: c for a, c in item['claims'].items() if c['expires'] > d['now']}
                if (item['status'] != 'complete' and len(item['votes']) + len(live) < ds['reviews']
                        and d['annotator'] not in live
                        and all(v['annotator'] != d['annotator'] for v in item['votes'])):
                    receipt = self.opaque()
                    expires = d['now'] + d['lease']
                    item['claims'] = live
                    live[d['annotator']] = {'receipt': receipt, 'expires': expires}
                    return {'item': public(item), 'receipt': receipt, 'expires': expires}
            return None
        item = get_record(items, d.get('item', d.get('id')))
        if op == 'item.get':
            return public(item)
        if op == 'history':
            return item['history']
        if op == 'item.reopen':
            require(item['status'] == 'complete', 'Item not complete')
            require(item['revision'] == d['expected_revision'], 'Revision conflict')
            item['history'].append({'votes': item['votes'], 'consensus': item['consensus']})
            item.update(votes=[], claims={}, consensus=None, status='pending', revision=item['revision'] + 1)
            return public(item)
        if op == 'submit':
            require(d['label'] in ds['labels'], 'Unknown label')
            claim = item['claims'].get(d['annotator'])
            require(claim is not None and claim['receipt'] == d['receipt'] and d['now'] < claim['expires'], 'Invalid or expired claim')
            require(item['status'] != 'complete' and len(item['votes']) < ds['reviews'], 'Item complete')
            require(all(v['annotator'] != d['annotator'] for v in item['votes']), 'Already voted')
            del item['claims'][d['annotator']]
            item['votes'].append({'annotator': d['annotator'], 'label': d['label']})
            item['revision'] += 1
            item['status'] = 'complete' if len(item['votes']) == ds['reviews'] else 'reviewing'
            if item['status'] == 'complete':
                item['consensus'] = d['label'] if all(v['label'] == d['label'] for v in item['votes']) else None
                item['claims'] = {}
            return public(item)


if __name__ == '__main__':
    Service.main()
