import copy
import hashlib
import os
import sys
import tempfile
import unittest
from app import Service
from goalpilot_support import JourneyMixin, transport_journey


class Workflows(JourneyMixin, unittest.TestCase):
    def setUp(self):
        self.open_service(Service)

    def setup_flag(self):
        self.c('environment.create', id='prod')
        self.c('environment.create', id='dev')
        self.c('segment.put', environment='prod', id='beta', members=['alice', 'alice'])
        return self.c('flag.create', environment='prod', id='café', default=False)

    def test_lifecycle(self):
        f = self.setup_flag()
        self.assertEqual(f, dict(id='café', environment='prod', revision=1, published=0, enabled=False, default=False, rules=[]))
        self.assertRejects('flag.get', environment='dev', id='café')
        rule = dict(segment='beta', percent=100, value=True)
        self.c('flag.update', environment='prod', id='café', expected_revision=1, enabled=True, rules=[rule])
        self.assertFalse(self.c('flag.evaluate', environment='prod', id='café', user='alice')['value'])
        self.c('flag.publish', environment='prod', id='café', expected_revision=2)
        self.c('flag.publish', environment='prod', id='café', expected_revision=2)
        self.assertTrue(self.c('flag.evaluate', environment='prod', id='café', user='alice')['value'])
        self.c('segment.put', environment='prod', id='beta', members=[])
        self.assertFalse(self.c('flag.evaluate', environment='prod', id='café', user='alice')['value'])
        self.c('segment.put', environment='prod', id='beta', members=['alice'])
        self.c('flag.update', environment='prod', id='café', expected_revision=2, enabled=False, rules=[])
        self.assertTrue(self.c('flag.evaluate', environment='prod', id='café', user='alice')['value'])
        self.c('flag.publish', environment='prod', id='café', expected_revision=3)
        self.assertFalse(self.c('flag.evaluate', environment='prod', id='café', user='alice')['value'])
        self.c('flag.rollback', environment='prod', id='café', revision=2, expected_revision=3)
        self.restart()
        self.assertTrue(self.c('flag.evaluate', environment='prod', id='café', user='alice')['value'])
        self.assertRejects('segment.delete', environment='prod', id='beta')
        events = self.c('audit.list', environment='prod')
        self.assertEqual([e['sequence'] for e in events], list(range(1, 7)))
        self.assertEqual(events[-1], dict(sequence=6, kind='flag.rolled_back', flag='café', revision=4))
        self.assertEqual(self.c('audit.list', environment='dev'), [])

    def test_validation_restore_and_race(self):
        self.setup_flag()
        for bad in [True, 1.0, '1', -1, 101]:
            self.assertRejects('flag.update', environment='prod', id='café', expected_revision=1, enabled=True, rules=[dict(segment=None, percent=bad, value=True)])
        self.assertRejects('flag.update', environment='dev', id='café', expected_revision=1, enabled=True, rules=[])
        self.assertRejects('flag.import', environment='prod', flags=[dict(id='new', default=True), dict(id='café', default=True)])
        self.assertEqual(self.c('flag.list', environment='prod'), ['café'])
        backup = self.c('backup')
        self.c('flag.import', environment='prod', flags=[dict(id='new', default=True)])
        self.c('restore', state=backup)
        self.assertEqual(self.c('flag.list', environment='prod'), ['café'])
        damaged = copy.deepcopy(backup)
        damaged['state']['environments']['prod']['flags']['café']['draft']['revision'] = 99
        self.assertRejects('restore', state=damaged)
        results = self.race(*[('flag.update', dict(environment='prod', id='café', expected_revision=1, enabled=True, rules=[])) for _ in range(2)])
        self.assertEqual(sum(ok for ok, result in results), 1)
        self.assertEqual(self.c('flag.get', environment='prod', id='café')['revision'], 2)

    def test_rollout_and_transports(self):
        self.setup_flag()
        self.c('flag.update', environment='prod', id='café', expected_revision=1, enabled=True, rules=[dict(segment=None, percent=35, value=True), dict(segment=None, percent=100, value=False)])
        self.c('flag.publish', environment='prod', id='café', expected_revision=2)
        for user in ['alice', 'bob', 'éva', 'x', 'y']:
            bucket = int.from_bytes(hashlib.sha256(('prod|café|' + user).encode()).digest()[:8], 'big') % 100
            self.assertEqual(self.c('flag.evaluate', environment='prod', id='café', user=user), dict(value=bucket < 35, revision=2, bucket=bucket))
        transport_journey([sys.executable, os.path.abspath('app.py'), '--file', os.path.join(tempfile.gettempdir(), 'flags-transport-' + str(os.getpid()) + '.json')], [
            ('environment.create', {'id': 'http'}, {'id': 'http'}),
            ('flag.import', {'environment': 'http', 'flags': [{'id': 'été', 'default': True}]}, {'imported': 1}),
            ('flag.list', {'environment': 'http'}, ['été']),
        ])
