import copy
import hashlib
from goalpilot_runtime import ReplayService, fields, text, boolean, integer, identifiers, require


def banner():
    return 'Local Ops — café'


def revision(value):
    return integer(value, minimum=1)


class Service(ReplayService):
    def initial(self):
        return {'environments': {}}

    def handle(self, state, op, data):
        if op == 'environment.create':
            fields(data, {'id': text})
            key = data['id']
            require(key not in state['environments'], 'Environment exists')
            state['environments'][key] = {'segments': {}, 'flags': {}, 'audit': []}
            return {'id': key}
        schemas = {
            'segment.put': {'id': text, 'members': identifiers},
            'segment.delete': {'id': text},
            'flag.create': {'id': text, 'default': boolean},
            'flag.import': {'flags': self.import_rows},
            'flag.update': {'id': text, 'expected_revision': revision, 'enabled': boolean, 'rules': self.rule_rows},
            'flag.publish': {'id': text, 'expected_revision': revision},
            'flag.rollback': {'id': text, 'revision': revision, 'expected_revision': revision},
            'flag.evaluate': {'id': text, 'user': text},
            'flag.get': {'id': text},
            'flag.list': {},
            'audit.list': {},
        }
        require(op in schemas, 'Unknown operation')
        fields(data, dict(environment=text, **schemas[op]))
        env_id = data['environment']
        require(env_id in state['environments'], 'Unknown environment')
        env = state['environments'][env_id]
        flags, segments = env['flags'], env['segments']

        def event(kind, flag):
            env['audit'].append({'sequence': len(env['audit']) + 1, 'kind': kind,
                                 'flag': flag['id'], 'revision': flag['revision']})

        def create(row):
            require(row['id'] not in flags, 'Flag exists')
            flag = {'id': row['id'], 'environment': env_id, 'revision': 1,
                    'published': 0, 'enabled': False, 'default': row['default'], 'rules': []}
            flags[row['id']] = {'draft': flag, 'history': {}}
            event('flag.created', flag)
            return flag

        if op == 'segment.put':
            segments[data['id']] = identifiers(data['members'])
            return {'id': data['id'], 'environment': env_id, 'members': segments[data['id']]}
        if op == 'segment.delete':
            require(data['id'] in segments, 'Unknown segment')
            for record in flags.values():
                for snapshot in [record['draft'], *record['history'].values()]:
                    require(all(rule['segment'] != data['id'] for rule in snapshot['rules']), 'Segment referenced')
            del segments[data['id']]
            return {'deleted': data['id']}
        if op == 'flag.create':
            return create(data)
        if op == 'flag.import':
            rows = data['flags']
            ids = [row['id'] for row in rows]
            require(len(ids) == len(set(ids)) and all(key not in flags for key in ids), 'Duplicate flag')
            for row in rows:
                create(row)
            return {'imported': len(rows)}
        if op == 'flag.list':
            return sorted(flags)
        if op == 'audit.list':
            return env['audit']
        require(data['id'] in flags, 'Unknown flag')
        record = flags[data['id']]
        draft = record['draft']
        history = record['history']
        if op == 'flag.get':
            return draft
        if op == 'flag.evaluate':
            bucket = int.from_bytes(hashlib.sha256((env_id + '|' + data['id'] + '|' + data['user']).encode('utf-8')).digest()[:8], 'big') % 100
            live = history.get(str(draft['published']))
            value = draft['default'] if live is None else live['default']
            if live and live['enabled']:
                for rule in live['rules']:
                    if (rule['segment'] is None or data['user'] in segments[rule['segment']]) and bucket < rule['percent']:
                        value = rule['value']
                        break
            return {'value': value, 'revision': draft['published'], 'bucket': bucket}
        require(draft['revision'] == data['expected_revision'], 'Stale revision')
        if op == 'flag.update':
            for rule in data['rules']:
                require(rule['segment'] is None or rule['segment'] in segments, 'Unknown segment')
            draft.update(revision=draft['revision'] + 1, enabled=data['enabled'], rules=copy.deepcopy(data['rules']))
            event('flag.updated', draft)
        elif op == 'flag.publish':
            if draft['published'] != draft['revision']:
                draft['published'] = draft['revision']
                history[str(draft['revision'])] = copy.deepcopy(draft)
                event('flag.published', draft)
        elif op == 'flag.rollback':
            require(str(data['revision']) in history, 'Unknown published revision')
            restored = copy.deepcopy(history[str(data['revision'])])
            restored.update(revision=draft['revision'] + 1, published=draft['revision'] + 1)
            record['draft'] = restored
            history[str(restored['revision'])] = copy.deepcopy(restored)
            draft = restored
            event('flag.rolled_back', draft)
        return draft

    @staticmethod
    def import_rows(rows):
        require(isinstance(rows, list), 'Expected flags list')
        for row in rows:
            fields(row, {'id': text, 'default': boolean})
        return rows

    @staticmethod
    def rule_rows(rows):
        require(isinstance(rows, list), 'Expected rules list')
        def segment(value):
            if value is not None:
                text(value)
        def percent(value):
            return integer(value, minimum=0, maximum=100)
        for row in rows:
            fields(row, {'segment': segment, 'percent': percent, 'value': boolean})
        return rows


if __name__ == '__main__':
    Service.main()
