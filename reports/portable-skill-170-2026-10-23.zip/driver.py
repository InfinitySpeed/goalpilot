from pathlib import Path
import hashlib,json,subprocess,sys,time
ROOT=Path(__file__).resolve().parent;name=sys.argv[1];d=ROOT/name;p=json.loads((d/'protocol.json').read_text());assert hashlib.sha256(Path(__file__).read_bytes()).hexdigest()==p['driver_sha256']
def readrows():return [json.loads(f.read_text())for f in (d/'trials').glob('*/result.json')]
def total(rows):return {'seconds':sum(r['seconds']for r in rows),'raw':sum(r['usage']['total_tokens']for r in rows),'uncached':sum(r['usage']['uncached_tokens']for r in rows)}
def stop(reason):
 rows=readrows();(d/'eliminated.json').write_text(json.dumps({'at':time.time(),'reason':reason,'executed':len(rows),'planned_calls':40,'correct':{a:sum(r['success']for r in rows if r['arm']==a)for a in ('old','new')},'no_retries':True},indent=2)+'\n');print('STOP',reason,flush=True);raise SystemExit(2)
for index,item in enumerate(p['order']):
 for arm in item['arms']:
  rows=readrows()
  if any(not r['usage']['usage_complete']for r in rows):stop('Incomplete provider meter')
  if any(not r['success']for r in rows if r['arm']=='new'):stop('New independent completion failed;20/20 impossible without changing source')
  ident=item['case']+'-'+arm;trial=d/'trials'/ident
  if(trial/'result.json').exists():continue
  assert not trial.exists(),'Never restart a started trial missing its outcome'
  print('START',index+1,ident,flush=True)
  try:proc=subprocess.run([sys.executable,str(ROOT/'paired_skill_clean.py'),'run',name,item['case'],arm],capture_output=True,text=True,timeout=780)
  except subprocess.TimeoutExpired:stop('Caller worker timeout: retained partial evidence; meter unknown')
  (d/('worker-'+ident+'.log')).write_text(proc.stdout+'\n'+proc.stderr)
  if not(trial/'result.json').exists():stop('Missing outcome; retain started record: '+ident+' '+proc.stderr[-500:])
  row=json.loads((trial/'result.json').read_text());print('RESULT',ident,row['success'],round(row['seconds'],3),row['usage']['total_tokens'],row['usage']['uncached_tokens'],flush=True)
  if proc.returncode:stop('Worker failed; no automatic retry')
 if index==1:
  rows=readrows();v={a:total([r for r in rows if r['arm']==a])for a in ('old','new')}
  screen={'correct':all(r['success']for r in rows if r['arm']=='new'),'meters':all(r['usage']['usage_complete']for r in rows),'time':v['new']['seconds']<=v['old']['seconds']*1.03,'raw':v['new']['raw']<=v['old']['raw']*.85,'uncached':v['new']['uncached']<=v['old']['uncached']*.85}
  (d/'rapid-screen.json').write_text(json.dumps({'at':time.time(),'pairs':2,'totals':v,'checks':screen,'passed':all(screen.values()),'protocol_unchanged':True},indent=2)+'\n')
  print('RAPID_SCREEN',screen,flush=True)
  if not all(screen.values()):stop('Predeclared two-pair rapid screen failed; do not spend remaining36calls')
print('ALL40_RECORDED',flush=True)
