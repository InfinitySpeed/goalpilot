GO_REFERENCE='''package quota
import("errors";"sync")
type event struct{at int64; weight int}
type bucket struct{events []event; last int64}
type Quota struct{mu sync.Mutex;limit int;window int64; buckets map[string]bucket}
func New(limit int,window int64)(*Quota,error){if limit<=0||window<=0{return nil,errors.New("invalid")};return &Quota{limit:limit,window:window,buckets:map[string]bucket{}},nil}
func(q *Quota)Allow(key string,now int64,weight int)(bool,error){q.mu.Lock();defer q.mu.Unlock();b,has:=q.buckets[key];if key==""||now<0||weight<=0||weight>q.limit||has&&now<b.last{return false,errors.New("invalid")};used:=0;keep:=[]event{};for _,v:=range b.events{if v.at>now-q.window{used+=v.weight;keep=append(keep,v)}};if weight>q.limit-used{return false,nil};keep=append(keep,event{now,weight});q.buckets[key]=bucket{keep,now};return true,nil}
func(q *Quota)Reset(key string){q.mu.Lock();defer q.mu.Unlock();delete(q.buckets,key)}
'''
TS_REFERENCE='''function clone(v:unknown,seen=new Set<object>()):any {
 if(v===null||typeof v==='boolean'||typeof v==='string')return v;
 if(typeof v==='number'&&Number.isFinite(v))return v;
 if(typeof v!=='object'||seen.has(v))throw Error('invalid JSON');
 if(!Array.isArray(v)&&Object.getPrototypeOf(v)!==Object.prototype&&Object.getPrototypeOf(v)!==null)throw Error('exotic');
 seen.add(v);let out:any;
 if(Array.isArray(v)){out=[];for(let i=0;i<v.length;i++){if(!(i in v))throw Error('sparse');out.push(clone(v[i],seen));}}
 else {out={};for(const key of Object.keys(v))Object.defineProperty(out,key,{value:clone((v as any)[key],seen),enumerable:true,writable:true,configurable:true});}
 seen.delete(v);return out;
}
function key(k:unknown):asserts k is string {if(typeof k!=='string'||!k)throw Error('key');}
export class Store {
 revision=0;private data=new Map<string,{value:unknown,version:number}>();
 get(k:string){key(k);let v=this.data.get(k);return v?{value:clone(v.value),version:v.version}:undefined;}
 keys(){return [...this.data.keys()];}
 apply(ops:unknown){if(!Array.isArray(ops))throw Error('ops');if(!ops.length)return {revision:this.revision,changed:[]};let next=new Map(this.data),rev=this.revision+1,changed=new Set<string>();
 for(let op of ops){if(!op||typeof op!=='object')throw Error('op');key(op.key);if(op.expectedVersion!==undefined&&(!Number.isInteger(op.expectedVersion)||op.expectedVersion<0||op.expectedVersion!==(next.get(op.key)?.version??0)))throw Error('CAS');if(op.type==='put')next.set(op.key,{value:clone(op.value),version:rev});else if(op.type==='delete')next.delete(op.key);else throw Error('type');changed.add(op.key);}
 this.data=next;this.revision=rev;return {revision:rev,changed:[...changed]};
 }
}
'''
