"""Deterministic dependency planning."""

import heapq


def plan(graph):
    if not isinstance(graph, dict):
        raise ValueError("graph must be a dict")
    for node, dependencies in graph.items():
        if not isinstance(node, str) or not node:
            raise ValueError("node names must be nonempty strings")
        if not isinstance(dependencies, list) or any(
            not isinstance(dep, str) or not dep for dep in dependencies
        ):
            raise ValueError("dependencies must be lists of nonempty strings")

    edges = {node: set(deps) for node, deps in graph.items()}
    nodes = set(edges)
    for deps in edges.values():
        nodes.update(deps)
    for node in nodes:
        edges.setdefault(node, set())
    dependents = {node: set() for node in nodes}
    for node, deps in edges.items():
        for dep in deps:
            dependents[dep].add(node)
    remaining = {node: len(deps) for node, deps in edges.items()}
    ready = [node for node in nodes if not remaining[node]]
    heapq.heapify(ready)
    result = []
    while ready:
        node = heapq.heappop(ready)
        result.append(node)
        for dependent in dependents[node]:
            remaining[dependent] -= 1
            if not remaining[dependent]:
                heapq.heappush(ready, dependent)
    if len(result) == len(nodes):
        return result

    # Iterative Kosaraju traversal isolates actual strongly connected cycles.
    seen = set()
    finished = []
    for node in nodes:
        if node in seen:
            continue
        seen.add(node)
        stack = [(node, iter(edges[node]))]
        while stack:
            current, children = stack[-1]
            child = next(children, None)
            if child is None:
                finished.append(current)
                stack.pop()
            elif child not in seen:
                seen.add(child)
                stack.append((child, iter(edges[child])))
    seen.clear()
    cyclic = set()
    for node in reversed(finished):
        if node in seen:
            continue
        component = set()
        pending = [node]
        seen.add(node)
        while pending:
            current = pending.pop()
            component.add(current)
            for child in dependents[current]:
                if child not in seen:
                    seen.add(child)
                    pending.append(child)
        if len(component) > 1 or node in edges[node]:
            cyclic.update(component)
    raise ValueError("cycle: " + ",".join(sorted(cyclic)))
