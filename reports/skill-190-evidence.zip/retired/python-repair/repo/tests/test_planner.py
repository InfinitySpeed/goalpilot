import unittest
from planner import plan
class Existing(unittest.TestCase):
 def test_empty(self):self.assertEqual(plan({}),[])
 def test_single(self):self.assertEqual(plan({"a":[]}),["a"])
