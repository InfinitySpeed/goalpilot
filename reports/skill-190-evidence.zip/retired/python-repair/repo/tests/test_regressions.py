import copy
import unittest

from planner import plan


class PlannerRegressions(unittest.TestCase):
    def test_ready_order_and_value_only_nodes(self):
        for graph, expected in [
            ({}, []),
            ({"z": ["b", "a", "b"], "c": ["a"]}, ["a", "b", "c", "z"]),
            ({"b": [], "a": ["b"], "z": []}, ["b", "a", "z"]),
            ({"c": ["b"], "b": ["a"]}, ["a", "b", "c"]),
        ]:
            with self.subTest(graph=graph):
                original = copy.deepcopy(graph)
                self.assertEqual(plan(graph), expected)
                self.assertEqual(plan(dict(reversed(list(graph.items())))), expected)
                self.assertEqual(graph, original)

    def test_cycles_exclude_dependents(self):
        for graph, message in [
            ({"a": ["b"], "b": ["a"], "c": ["a"], "d": ["c"]}, "cycle: a,b"),
            ({"x": ["x", "x"], "y": ["x"], "a": []}, "cycle: x"),
            ({"z": ["y"], "y": ["z"], "b": ["a"], "a": ["b"],
              "tail": ["a", "z"], "leaf": []}, "cycle: a,b,y,z"),
        ]:
            with self.subTest(graph=graph):
                original = copy.deepcopy(graph)
                with self.assertRaises(ValueError) as caught:
                    plan(graph)
                self.assertEqual(str(caught.exception), message)
                self.assertEqual(graph, original)

    def test_malformed_inputs(self):
        for graph in [None, [], "a", 1, {1: []}, {"": []}, {None: []},
                      {"a": "b"}, {"a": ("b",)}, {"a": {"b"}},
                      {"a": None}, {"a": [""]}, {"a": [1]},
                      {"a": [[]]}, {"a": [None]},
                      {"a": ["a"], "z": [False]}]:
            with self.subTest(graph=graph):
                original = copy.deepcopy(graph)
                with self.assertRaises(ValueError):
                    plan(graph)
                self.assertEqual(graph, original)

    def test_deep_cycle_does_not_depend_on_recursion_limit(self):
        graph = {str(i): [str(i + 1)] for i in range(1500)}
        graph["1500"] = ["1499"]
        with self.assertRaises(ValueError) as caught:
            plan(graph)
        self.assertEqual(str(caught.exception), "cycle: 1499,1500")
