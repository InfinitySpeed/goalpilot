import java.util.*;
import java.math.BigInteger;
public class RegressionRanges {
 static List<long[]> ranges(long... v) {
  List<long[]> a = new ArrayList<>();
  for(int i=0;i<v.length;i+=2) a.add(new long[]{v[i],v[i+1]});
  return a;
 }
 static void eq(List<long[]> got, long... want) {
  List<long[]> expected=ranges(want);
  if(got.size()!=expected.size()) throw new AssertionError("size");
  for(int i=0;i<got.size();i++) if(!Arrays.equals(got.get(i),expected.get(i))) throw new AssertionError("range");
 }
 static void invalid(Runnable f) {
  try { f.run(); } catch(IllegalArgumentException e) { return; }
  throw new AssertionError("accepted invalid input");
 }
 static boolean covers(List<long[]> a, int x) {
  for(long[] r:a) if(r[0]<=x && x<r[1]) return true;
  return false;
 }
 public static void main(String[] args) {
  var a=ranges(8,10,1,3,3,5,2,4,6,6);
  eq(Ranges.normalize(a),1,5,8,10);
  eq(Ranges.subtract(ranges(8,12,0,10),ranges(9,11,3,5,4,7)),0,3,7,9,11,12);
  eq(Ranges.subtract(ranges(0,2,4,6),ranges(-1,5)),5,6);
  eq(Ranges.subtract(ranges(0,2),ranges(2,3)),0,2);
  eq(Ranges.normalize(ranges(1,1)));
  eq(Ranges.subtract(ranges(),ranges()));
  if(!Ranges.length(ranges(Long.MIN_VALUE,Long.MAX_VALUE)).equals(BigInteger.ONE.shiftLeft(64).subtract(BigInteger.ONE))) throw new AssertionError("overflow");
  eq(Ranges.subtract(ranges(Long.MIN_VALUE,Long.MAX_VALUE),ranges(-1,1)),Long.MIN_VALUE,-1,1,Long.MAX_VALUE);
  if(!Ranges.length(a).equals(BigInteger.valueOf(6))) throw new AssertionError("union length");
  var n=Ranges.normalize(a); n.get(0)[0]=99;
  eq(a,8,10,1,3,3,5,2,4,6,6);
  var b=ranges(2,3); var s=Ranges.subtract(a,b); s.get(0)[0]=99;
  eq(a,8,10,1,3,3,5,2,4,6,6); eq(b,2,3);
  List<List<long[]>> bad=new ArrayList<>();
  bad.add(null); bad.add(Arrays.asList((long[])null));
  bad.add(Collections.singletonList(new long[0])); bad.add(Collections.singletonList(new long[1]));
  bad.add(Collections.singletonList(new long[3])); bad.add(ranges(2,1));
  for(var v:bad) {
   invalid(()->Ranges.normalize(v)); invalid(()->Ranges.length(v));
   invalid(()->Ranges.subtract(v,ranges())); invalid(()->Ranges.subtract(ranges(),v));
  }
  Random random=new Random(42);
  for(int t=0;t<300;t++) {
   var x=ranges(); var y=ranges();
   for(var list:List.of(x,y)) for(int i=0;i<8;i++) {
    int p=random.nextInt(21)-10,q=random.nextInt(21)-10;
    list.add(new long[]{Math.min(p,q),Math.max(p,q)});
   }
   var norm=Ranges.normalize(x); var diff=Ranges.subtract(x,y); int count=0;
   for(int z=-10;z<10;z++) {
    boolean covered=covers(x,z);
    if(covers(norm,z)!=covered || covers(diff,z)!=(covered&&!covers(y,z))) throw new AssertionError("membership");
    if(covered) count++;
   }
   if(!Ranges.length(x).equals(BigInteger.valueOf(count))) throw new AssertionError("length");
   for(var list:List.of(norm,diff)) for(int i=0;i<list.size();i++) {
    if(list.get(i).length!=2 || list.get(i)[0]>=list.get(i)[1] || (i>0 && list.get(i-1)[1]>=list.get(i)[0])) throw new AssertionError("canonical");
   }
  }
 }
}
