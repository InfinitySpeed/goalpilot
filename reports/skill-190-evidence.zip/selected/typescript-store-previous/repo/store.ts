function copy(value: unknown, ancestors = new Set<object>()): unknown {
  if (value === null || typeof value === 'string' || typeof value === 'boolean') return value;
  if (typeof value === 'number' && Number.isFinite(value)) return value;
  if (typeof value !== 'object' || value === null || ancestors.has(value)) throw Error('Invalid JSON value');
  const array = Array.isArray(value);
  if (!array && Object.getPrototypeOf(value) !== Object.prototype && Object.getPrototypeOf(value) !== null) throw Error('Invalid JSON object');
  ancestors.add(value);
  try {
    if (array) {
      const source = value as unknown[];
      if (Reflect.ownKeys(source).length !== source.length + 1) throw Error('Invalid array');
      return Array.from({length: source.length}, (_, i) => {
        const d = Object.getOwnPropertyDescriptor(source, String(i));
        if (!d || !('value' in d)) throw Error('Invalid array entry');
        return copy(d.value, ancestors);
      });
    }
    const result: Record<string, unknown> = {};
    for (const key of Reflect.ownKeys(value)) {
      const d = Object.getOwnPropertyDescriptor(value, key)!;
      if (typeof key !== 'string' || !d.enumerable || !('value' in d)) throw Error('Invalid object entry');
      Object.defineProperty(result, key, {value: copy(d.value, ancestors), enumerable: true, writable: true, configurable: true});
    }
    return result;
  } finally { ancestors.delete(value); }
}

export class Store {
  revision = 0;
  private entries = new Map<string, {value: unknown, version: number}>();
  get(key: string): {value: unknown, version: number} | undefined {
    const entry = this.entries.get(key);
    return entry && {value: copy(entry.value), version: entry.version};
  }
  keys(): string[] { return [...this.entries.keys()]; }
  apply(ops: unknown): {revision: number, changed: string[]} {
    if (!Array.isArray(ops)) throw Error('Expected operations array');
    const staged = new Map(this.entries);
    const changed = new Set<string>();
    const revision = this.revision + (ops.length ? 1 : 0);
    for (const raw of ops) {
      if (!raw || typeof raw !== 'object' || Array.isArray(raw)) throw Error('Invalid operation');
      const op = raw as Record<string, unknown>;
      if ((op.type !== 'put' && op.type !== 'delete') || typeof op.key !== 'string' || !op.key.length) throw Error('Invalid operation');
      if ('expectedVersion' in op) {
        if (typeof op.expectedVersion !== 'number' || !Number.isInteger(op.expectedVersion) || op.expectedVersion < 0) throw Error('Invalid version');
        if (op.expectedVersion !== (staged.get(op.key)?.version ?? 0)) throw Error('Version mismatch');
      }
      if (op.type === 'put') staged.set(op.key, {value: copy(op.value), version: revision});
      else staged.delete(op.key);
      changed.add(op.key);
    }
    this.entries = staged;
    this.revision = revision;
    return {revision, changed: [...changed]};
  }
}
