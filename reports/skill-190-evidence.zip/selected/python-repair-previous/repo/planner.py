"""Deterministic dependency planning."""

import heapq


def plan(graph):
    if not isinstance(graph, dict):
        raise ValueError("graph must be a dict")
    for node, dependencies in graph.items():
        if not isinstance(node, str) or not node:
            raise ValueError("node names must be nonempty strings")
        if not isinstance(dependencies, list):
            raise ValueError("dependencies must be lists")
        if any(not isinstance(dep, str) or not dep for dep in dependencies):
            raise ValueError("node names must be nonempty strings")

    dependencies = {node: set(deps) for node, deps in graph.items()}
    for deps in graph.values():
        for dep in deps:
            dependencies.setdefault(dep, set())
    dependents = {node: set() for node in dependencies}
    for node, deps in dependencies.items():
        for dep in deps:
            dependents[dep].add(node)
    counts = {node: len(deps) for node, deps in dependencies.items()}
    ready = [node for node, count in counts.items() if count == 0]
    heapq.heapify(ready)
    result = []
    while ready:
        node = heapq.heappop(ready)
        result.append(node)
        for dependent in dependents[node]:
            counts[dependent] -= 1
            if counts[dependent] == 0:
                heapq.heappush(ready, dependent)
    if len(result) == len(dependencies):
        return result

    # Find strongly connected components without relying on recursion depth.
    seen = set()
    finished = []
    for start in dependencies:
        if start in seen:
            continue
        seen.add(start)
        stack = [(start, iter(dependencies[start]))]
        while stack:
            node, edges = stack[-1]
            neighbor = next(edges, None)
            if neighbor is None:
                finished.append(node)
                stack.pop()
            elif neighbor not in seen:
                seen.add(neighbor)
                stack.append((neighbor, iter(dependencies[neighbor])))
    seen.clear()
    cyclic = set()
    for start in reversed(finished):
        if start in seen:
            continue
        component = []
        pending = [start]
        seen.add(start)
        while pending:
            node = pending.pop()
            component.append(node)
            for neighbor in dependents[node]:
                if neighbor not in seen:
                    seen.add(neighbor)
                    pending.append(neighbor)
        if len(component) > 1 or start in dependencies[start]:
            cyclic.update(component)
    raise ValueError("cycle: " + ",".join(sorted(cyclic)))
