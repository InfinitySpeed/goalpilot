import copy
import unittest

from planner import plan


class PlannerRegressions(unittest.TestCase):
    def test_order_and_value_only_nodes(self):
        cases = [
            ({}, []),
            ({"z": ["b"], "b": ["a"], "c": []}, ["a", "b", "c", "z"]),
            ({"a": ["z"], "b": []}, ["b", "z", "a"]),
            ({"z": ["b", "b", "a"], "a": []}, ["a", "b", "z"]),
        ]
        for graph, expected in cases:
            with self.subTest(graph=graph):
                before = copy.deepcopy(graph)
                self.assertEqual(plan(graph), expected)
                self.assertEqual(plan(dict(reversed(list(graph.items())))), expected)
                self.assertEqual(graph, before)

    def test_exact_cycle_members(self):
        cases = [
            ({"a": ["b"], "b": ["a"], "c": ["a"], "d": ["c"]}, "a,b"),
            ({"self": ["self", "self"], "tail": ["self"]}, "self"),
            ({"z": ["y"], "y": ["z", "leaf"], "b": ["a"],
              "a": ["b"], "tail": ["z"], "ok": []}, "a,b,y,z"),
        ]
        for graph, names in cases:
            with self.subTest(graph=graph):
                before = copy.deepcopy(graph)
                with self.assertRaises(ValueError) as error:
                    plan(graph)
                self.assertEqual(str(error.exception), "cycle: " + names)
                self.assertEqual(graph, before)

    def test_malformed_inputs(self):
        invalid = [None, [], "a", 1, {"": []}, {1: []}, {None: []},
                   {"a": None}, {"a": "b"}, {"a": ("b",)},
                   {"a": {"b"}}, {"a": {}}, {"a": [""]},
                   {"a": [1]}, {"a": [None]}, {"a": [["b"]]},
                   {"a": ["a"], "later": [False]}]
        for graph in invalid:
            with self.subTest(graph=graph):
                with self.assertRaises(ValueError):
                    plan(graph)

    def test_deep_cycle_and_downstream_chain(self):
        graph = {str(i): [str(i + 1)] for i in range(2000)}
        graph["2000"] = ["1999"]
        with self.assertRaises(ValueError) as error:
            plan(graph)
        self.assertEqual(str(error.exception), "cycle: 1999,2000")
