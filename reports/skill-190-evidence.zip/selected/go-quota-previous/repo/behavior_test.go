package quota

import (
	"sync"
	"testing"
)

func request(t *testing.T, q *Quota, key string, now int64, weight int, want, bad bool) {
	t.Helper()
	got, err := q.Allow(key, now, weight)
	if got != want || (err != nil) != bad {
		t.Fatalf("Allow(%q,%d,%d) = %v,%v; want %v error=%v", key, now, weight, got, err, want, bad)
	}
}

func TestValidationAndAtomicity(t *testing.T) {
	for _, p := range []struct {
		limit  int
		window int64
	}{{0, 1}, {-1, 1}, {1, 0}, {1, -1}} {
		if q, e := New(p.limit, p.window); e == nil || q != nil {
			t.Fatal("invalid constructor accepted")
		}
	}
	q, _ := New(10, 10)
	request(t, q, "a", 0, 6, true, false)
	request(t, q, "a", 5, 4, true, false)
	for _, p := range []struct {
		key    string
		now    int64
		weight int
	}{{"", 100, 1}, {"a", -1, 1}, {"a", 100, 0}, {"a", 100, -1}, {"a", 100, 11}, {"a", 4, 1}} {
		request(t, q, p.key, p.now, p.weight, false, true)
	}
	request(t, q, "a", 10, 7, false, false) // Would expire the first entry, but must not commit.
	request(t, q, "a", 5, 1, false, false)  // Still full, and denial did not advance the clock.
	request(t, q, "a", 10, 6, true, false)  // Exactly the lower boundary is excluded.
	request(t, q, "a", 10, 1, false, false)
	request(t, q, "b", 0, 10, true, false)
	q.Reset("")
	request(t, q, "b", 0, 1, false, false)
	q.Reset("a")
	request(t, q, "a", 0, 10, true, false)
	request(t, q, "b", 0, 1, false, false)
	q.Reset("missing")
}

func TestWindowWeightsAndOverflow(t *testing.T) {
	q, _ := New(7, 3)
	request(t, q, "x", 1, 2, true, false)
	request(t, q, "x", 2, 3, true, false)
	request(t, q, "x", 3, 3, false, false)
	request(t, q, "x", 3, 2, true, false)
	request(t, q, "x", 4, 2, true, false)
	request(t, q, "x", 5, 3, true, false)
	max := int(^uint(0) >> 1)
	large, _ := New(max, int64(1<<63-1))
	request(t, large, "x", 0, max, true, false)
	request(t, large, "x", 0, 1, false, false)
	request(t, large, "x", 1<<63-1, max, true, false)
}

func TestConcurrentCallersAndReset(t *testing.T) {
	q, _ := New(20, 10)
	var wg sync.WaitGroup
	accepted := make(chan bool, 100)
	for i := 0; i < 100; i++ {
		wg.Add(1)
		go func() {
			defer wg.Done()
			ok, e := q.Allow("x", 0, 1)
			if e != nil {
				t.Error(e)
			}
			accepted <- ok
		}()
	}
	wg.Wait()
	close(accepted)
	n := 0
	for ok := range accepted {
		if ok {
			n++
		}
	}
	if n != 20 {
		t.Fatalf("accepted %d", n)
	}
	for i := 0; i < 100; i++ {
		wg.Add(1)
		go func() { defer wg.Done(); q.Reset("x"); q.Allow("x", 0, 1) }()
	}
	wg.Wait()
	q.Reset("x")
	request(t, q, "x", 0, 20, true, false)
}
