package quota

import (
	"errors"
	"sync"
)

type entry struct {
	time   int64
	weight int
}
type keyState struct {
	last    int64
	entries []entry
}
type Quota struct {
	mu     sync.Mutex
	limit  int
	window int64
	states map[string]keyState
}

func New(limit int, window int64) (*Quota, error) {
	if limit <= 0 || window <= 0 {
		return nil, errors.New("capacity and window must be positive")
	}
	return &Quota{limit: limit, window: window, states: make(map[string]keyState)}, nil
}

func (q *Quota) Allow(key string, now int64, weight int) (bool, error) {
	q.mu.Lock()
	defer q.mu.Unlock()
	if key == "" || now < 0 || weight <= 0 || weight > q.limit {
		return false, errors.New("invalid quota request")
	}
	s, exists := q.states[key]
	if exists && now < s.last {
		return false, errors.New("timestamp precedes last acceptance")
	}
	cutoff := now - q.window
	first, used := 0, 0
	for first < len(s.entries) && s.entries[first].time <= cutoff {
		first++
	}
	for _, e := range s.entries[first:] {
		used += e.weight
	}
	if weight > q.limit-used {
		return false, nil
	}
	// Commit expiration and clock advancement only after accepting the request.
	live := append([]entry(nil), s.entries[first:]...)
	live = append(live, entry{now, weight})
	q.states[key] = keyState{now, live}
	return true, nil
}

func (q *Quota) Reset(key string) {
	q.mu.Lock()
	defer q.mu.Unlock()
	delete(q.states, key)
}
