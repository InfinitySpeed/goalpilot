const assert = require('node:assert/strict');
const { Store } = require(process.env.STORE_MODULE);
const put = (key, value, expectedVersion) => expectedVersion === undefined
  ? { type: 'put', key, value } : { type: 'put', key, value, expectedVersion };
const del = (key, expectedVersion) => ({ type: 'delete', key, expectedVersion });
const s = new Store();
assert.deepEqual(s.apply([]), { revision: 0, changed: [] });
const input = { nested: [{ x: 1 }] };
assert.deepEqual(s.apply([put('a', input, 0), put('b', 2)]), { revision: 1, changed: ['a', 'b'] });
input.nested[0].x = 99;
const output = s.get('a');
output.value.nested[0].x = 88;
output.version = 90;
assert.deepEqual(s.get('a'), { value: { nested: [{ x: 1 }] }, version: 1 });
const keys = s.keys(); keys.reverse();
assert.deepEqual(s.keys(), ['a', 'b']);
const snapshot = () => ({ revision: s.revision, entries: s.keys().map(k => [k, s.get(k)]) });
const before = snapshot();
const cycle = {}; cycle.self = cycle;
for (const bad of [put('bad', cycle), put('bad', undefined), put('bad', NaN),
  put('bad', Infinity), put('bad', 1n), put('bad', () => {}), put('bad', new Date()),
  put('bad', { x: undefined }), put('bad', [, 1]), put('', 1),
  { type: 'other', key: 'bad' }, null, del('a', 0), del('a', -1), del('a', 0.5),
  { type: 'delete', key: 'a', expectedVersion: undefined }]) {
  assert.throws(() => s.apply([del('a', 1), put('c', 3), put('a', 4), bad]));
  assert.deepEqual(snapshot(), before);
}
for (const bad of [null, {}, 'ops', [put('c', 1), ,]]) {
  assert.throws(() => s.apply(bad));
  assert.deepEqual(snapshot(), before);
}
assert.deepEqual(s.apply([put('a', 3, 1), put('a', 4, 2), del('b', 1),
  put('b', 5, 0), put('temp', true), del('temp', 2), del('missing', 0)]),
  { revision: 2, changed: ['a', 'b', 'temp', 'missing'] });
assert.deepEqual(s.keys(), ['a', 'b']);
assert.deepEqual(s.get('a'), { value: 4, version: 2 });
assert.equal(s.get('temp'), undefined);
s.apply([del('a', 2), put('a', null, 0)]);
assert.deepEqual(s.keys(), ['b', 'a']);
const revision = s.revision;
assert.deepEqual(s.apply([]), { revision, changed: [] });
const special = JSON.parse('{"__proto__":{"safe":true},"constructor":1}');
s.apply([put('__proto__', special), put('constructor', false)]);
assert.deepEqual(s.get('__proto__').value, special);
assert.equal(Object.getPrototypeOf(s.get('__proto__').value), Object.prototype);
const shared = { x: [1] };
s.apply([put('shared', { a: shared, b: shared })]);
const read = s.get('shared').value;
read.a.x.push(2);
assert.deepEqual(read.b, { x: [1] });
assert.deepEqual(s.get('shared').value.a, { x: [1] });
for (const bad of [Object.create({ x: 1 }), { [Symbol('x')]: 1 },
  Object.defineProperty({}, 'x', { get() { throw Error('getter ran'); }, enumerable: true })]) {
  assert.throws(() => s.apply([put('invalid', bad)]));
}
