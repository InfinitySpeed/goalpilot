type Entry = { value: unknown; version: number };

function plainObject(value: unknown): value is Record<string, unknown> {
  if (value === null || typeof value !== "object") return false;
  const prototype: unknown = Object.getPrototypeOf(value);
  return prototype === Object.prototype || prototype === null;
}

// Track ancestors, rather than all visited objects: shared subtrees are valid JSON.
function copyJSON(value: unknown, ancestors = new Set<object>()): unknown {
  if (value === null || typeof value === "string" || typeof value === "boolean") return value;
  if (typeof value === "number" && Number.isFinite(value)) return value;
  if (typeof value !== "object" || value === null ||
      (!Array.isArray(value) && !plainObject(value))) throw Error("Invalid JSON value");
  if (ancestors.has(value)) throw Error("Cyclic JSON value");
  ancestors.add(value);
  try {
    const array = Array.isArray(value);
    const result: Record<string, unknown> | unknown[] = array ? [] : {};
    const names = Reflect.ownKeys(value);
    if (array && names.length !== (value as unknown[]).length + 1) {
      throw Error("Invalid JSON array");
    }
    for (const key of names) {
      if (array && key === "length") continue;
      if (typeof key !== "string") throw Error("Invalid JSON property");
      if (array && (!/^(0|[1-9][0-9]*)$/.test(key) || Number(key) >= (value as unknown[]).length)) {
        throw Error("Invalid JSON array property");
      }
      const descriptor = Object.getOwnPropertyDescriptor(value, key)!;
      if (!descriptor.enumerable || !("value" in descriptor)) throw Error("Invalid JSON property");
      Object.defineProperty(result, key, {
        value: copyJSON(descriptor.value, ancestors), enumerable: true, writable: true, configurable: true,
      });
    }
    return result;
  } finally {
    ancestors.delete(value);
  }
}

function field(op: Record<string, unknown>, key: string, required = true): unknown {
  const descriptor = Object.getOwnPropertyDescriptor(op, key);
  if (!descriptor) {
    if (required) throw Error(`Missing ${key}`);
    return undefined;
  }
  if (!("value" in descriptor)) throw Error(`Invalid ${key}`);
  return descriptor.value;
}

export class Store {
  revision = 0;
  private entries = new Map<string, Entry>();

  get(key: string): Entry | undefined {
    const entry = this.entries.get(key);
    return entry === undefined ? undefined : { value: copyJSON(entry.value), version: entry.version };
  }

  keys(): string[] {
    return [...this.entries.keys()];
  }

  apply(ops: unknown): { revision: number; changed: string[] } {
    if (!Array.isArray(ops)) throw Error("Operations must be an array");
    if (ops.length === 0) return { revision: this.revision, changed: [] };
    const staged = new Map(this.entries);
    const revision = this.revision + 1;
    const changed = new Set<string>();
    for (let index = 0; index < ops.length; index++) {
      const operation = Object.getOwnPropertyDescriptor(ops, String(index));
      if (!operation || !("value" in operation)) throw Error("Invalid operation");
      const op: unknown = operation.value;
      if (!plainObject(op)) throw Error("Invalid operation");
      const type = field(op, "type");
      const key = field(op, "key");
      if ((type !== "put" && type !== "delete") || typeof key !== "string" || key.length === 0) {
        throw Error("Invalid operation");
      }
      if (Object.prototype.hasOwnProperty.call(op, "expectedVersion")) {
        const expected = field(op, "expectedVersion");
        if (typeof expected !== "number" || !Number.isInteger(expected) || expected < 0) {
          throw Error("Invalid expected version");
        }
        if (expected !== (staged.get(key)?.version ?? 0)) throw Error("Version conflict");
      }
      if (type === "put") staged.set(key, { value: copyJSON(field(op, "value")), version: revision });
      else staged.delete(key);
      changed.add(key);
    }
    this.entries = staged;
    this.revision = revision;
    return { revision, changed: [...changed] };
  }
}
