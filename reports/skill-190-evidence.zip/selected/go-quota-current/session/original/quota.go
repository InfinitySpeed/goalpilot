package quota
import "errors"
type Quota struct{}
func New(limit int, window int64)(*Quota,error){return nil,errors.New("unfinished")}
func(q *Quota)Allow(key string,now int64,weight int)(bool,error){return false,errors.New("unfinished")}
func(q *Quota)Reset(key string){}
