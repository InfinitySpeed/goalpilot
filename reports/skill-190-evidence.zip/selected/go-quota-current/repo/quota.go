package quota

import (
	"errors"
	"sync"
)

type entry struct {
	time   int64
	weight int
}
type keyState struct {
	last    int64
	entries []entry
}
type Quota struct {
	mu     sync.Mutex
	limit  int
	window int64
	keys   map[string]keyState
}

func New(limit int, window int64) (*Quota, error) {
	if limit <= 0 || window <= 0 {
		return nil, errors.New("capacity and window must be positive")
	}
	return &Quota{limit: limit, window: window, keys: make(map[string]keyState)}, nil
}

func (q *Quota) Allow(key string, now int64, weight int) (bool, error) {
	q.mu.Lock()
	defer q.mu.Unlock()
	if key == "" || now < 0 || weight <= 0 || weight > q.limit {
		return false, errors.New("invalid key, timestamp or weight")
	}
	s, exists := q.keys[key]
	if exists && now < s.last {
		return false, errors.New("timestamp precedes last acceptance")
	}
	// Compute expiration without modifying storage until acceptance is certain.
	cutoff := now - q.window
	first, used := 0, 0
	for first < len(s.entries) && s.entries[first].time <= cutoff {
		first++
	}
	for _, e := range s.entries[first:] {
		used += e.weight
	}
	if weight > q.limit-used {
		return false, nil
	}
	kept := make([]entry, len(s.entries)-first, len(s.entries)-first+1)
	copy(kept, s.entries[first:])
	kept = append(kept, entry{now, weight})
	q.keys[key] = keyState{last: now, entries: kept}
	return true, nil
}

func (q *Quota) Reset(key string) {
	q.mu.Lock()
	defer q.mu.Unlock()
	delete(q.keys, key)
}
