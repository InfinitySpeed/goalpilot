import subprocess
subprocess.run(['/workspace/goalpilot-research/universal-study/toolchains/go/bin/go',"test","./..."],check=True)
