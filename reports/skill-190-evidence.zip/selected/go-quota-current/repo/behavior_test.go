package quota

import (
	"reflect"
	"sync"
	"testing"
)

func TestValidationAndWindow(t *testing.T) {
	for _, a := range []struct {
		l int
		w int64
	}{{0, 1}, {-1, 1}, {1, 0}, {1, -1}} {
		if q, e := New(a.l, a.w); e == nil || q != nil {
			t.Fatal("invalid constructor", a)
		}
	}
	q, _ := New(5, 10)
	call := func(k string, n int64, w int, want bool, err bool) {
		t.Helper()
		got, e := q.Allow(k, n, w)
		if got != want || (e != nil) != err {
			t.Fatalf("Allow(%q,%d,%d) = %v,%v", k, n, w, got, e)
		}
	}
	call("a", 0, 3, true, false)
	call("a", 0, 2, true, false)
	call("b", 0, 5, true, false)
	before := q.keys["a"]
	for _, a := range []struct {
		k string
		n int64
		w int
	}{{"", 1, 1}, {"a", -1, 1}, {"a", 1, 0}, {"a", 1, -1}, {"a", 100, 6}} {
		call(a.k, a.n, a.w, false, true)
		if !reflect.DeepEqual(q.keys["a"], before) || len(q.keys) != 2 {
			t.Fatal("invalid request mutated state")
		}
	}
	call("a", 9, 1, false, false)
	if !reflect.DeepEqual(q.keys["a"], before) {
		t.Fatal("denial mutated state")
	}
	call("a", 0, 1, false, false) // Denial did not advance clock.
	call("a", 10, 4, true, false) // Exact boundary expires timestamp zero.
	call("a", 9, 1, false, true)
	call("a", 19, 2, false, false)
	call("a", 10, 1, true, false)
	call("a", 20, 5, true, false)
	q.Reset("")
	q.Reset("a")
	q.Reset("a")
	call("a", 0, 5, true, false)
	call("b", 0, 1, false, false)
}

func TestDeniedExpirationIsAtomic(t *testing.T) {
	q, _ := New(5, 10)
	q.Allow("a", 0, 2)
	q.Allow("a", 5, 3)
	before := append([]entry(nil), q.keys["a"].entries...)
	if ok, e := q.Allow("a", 10, 3); ok || e != nil {
		t.Fatal(ok, e)
	}
	if !reflect.DeepEqual(before, q.keys["a"].entries) || q.keys["a"].last != 5 {
		t.Fatal("denial expired data or advanced time")
	}
	if ok, e := q.Allow("a", 5, 1); ok || e != nil {
		t.Fatal(ok, e)
	}
}

func TestConcurrent(t *testing.T) {
	q, _ := New(50, 10)
	var wg sync.WaitGroup
	var mu sync.Mutex
	accepted := 0
	for i := 0; i < 200; i++ {
		wg.Add(1)
		go func() {
			defer wg.Done()
			ok, e := q.Allow("a", 0, 1)
			if e != nil {
				t.Error(e)
			}
			if ok {
				mu.Lock()
				accepted++
				mu.Unlock()
			}
			q.Reset("other")
		}()
	}
	wg.Wait()
	if accepted != 50 {
		t.Fatal("accepted", accepted)
	}
}

func TestLargeValues(t *testing.T) {
	max := int(^uint(0) >> 1)
	q, _ := New(max, 1<<63-1)
	if ok, e := q.Allow("x", 0, max); !ok || e != nil {
		t.Fatal(ok, e)
	}
	if ok, e := q.Allow("x", 1, 1); ok || e != nil {
		t.Fatal(ok, e)
	}
	if ok, e := q.Allow("x", 1<<63-1, max); !ok || e != nil {
		t.Fatal(ok, e)
	}
}
