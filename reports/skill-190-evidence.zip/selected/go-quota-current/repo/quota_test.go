package quota
import "testing"
func TestAPI(t *testing.T){var _ func(int,int64)(*Quota,error)=New}
