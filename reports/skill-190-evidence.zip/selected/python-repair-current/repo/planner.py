"""Deterministic dependency planning."""
import heapq


def plan(graph):
    if not isinstance(graph, dict):
        raise ValueError("graph must be a dict")
    for node, dependencies in graph.items():
        if not isinstance(node, str) or not node:
            raise ValueError("invalid node")
        if not isinstance(dependencies, list) or any(
            not isinstance(dep, str) or not dep for dep in dependencies
        ):
            raise ValueError("invalid dependencies")

    dependencies = {node: set(deps) for node, deps in graph.items()}
    for deps in graph.values():
        for dep in deps:
            dependencies.setdefault(dep, set())
    followers = {node: set() for node in dependencies}
    for node, deps in dependencies.items():
        for dep in deps:
            followers[dep].add(node)
    remaining = {node: len(deps) for node, deps in dependencies.items()}
    ready = [node for node, count in remaining.items() if not count]
    heapq.heapify(ready)
    result = []
    while ready:
        node = heapq.heappop(ready)
        result.append(node)
        for follower in followers[node]:
            remaining[follower] -= 1
            if not remaining[follower]:
                heapq.heappush(ready, follower)
    if len(result) == len(dependencies):
        return result

    # Iterative Kosaraju traversal avoids recursion limits on long graphs.
    pending = {node for node, count in remaining.items() if count}
    seen, finished = set(), []
    for start in pending:
        if start in seen:
            continue
        seen.add(start)
        stack = [(start, iter(dependencies[start] & pending))]
        while stack:
            node, edges = stack[-1]
            nxt = next(edges, None)
            if nxt is None:
                finished.append(node)
                stack.pop()
            elif nxt not in seen:
                seen.add(nxt)
                stack.append((nxt, iter(dependencies[nxt] & pending)))
    seen, cyclic = set(), set()
    for start in reversed(finished):
        if start in seen:
            continue
        component, stack = set(), [start]
        seen.add(start)
        while stack:
            node = stack.pop()
            component.add(node)
            for nxt in followers[node] & pending:
                if nxt not in seen:
                    seen.add(nxt)
                    stack.append(nxt)
        if len(component) > 1 or start in dependencies[start]:
            cyclic.update(component)
    raise ValueError("cycle: " + ",".join(sorted(cyclic)))
