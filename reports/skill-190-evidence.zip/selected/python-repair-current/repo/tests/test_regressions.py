import copy
import unittest
from planner import plan


class Regressions(unittest.TestCase):
    def test_order_and_input(self):
        graph = {"z": ["b", "b"], "b": ["a"], "c": [], "d": ["c"]}
        before = copy.deepcopy(graph)
        self.assertEqual(plan(graph), ["a", "b", "c", "d", "z"])
        self.assertEqual(graph, before)
        self.assertEqual(plan(dict(reversed(list(graph.items())))),
                         ["a", "b", "c", "d", "z"])
        self.assertEqual(plan({"z": ["x", "a"]}), ["a", "x", "z"])
        self.assertEqual(plan({}), [])

    def test_cycles_only(self):
        for graph, message in [
            ({"a": ["b"], "b": ["a"], "c": ["a"], "d": ["c"]}, "cycle: a,b"),
            ({"s": ["s"], "tail": ["s"], "free": []}, "cycle: s"),
            ({"a": ["b"], "b": ["a"], "x": ["x"], "z": ["a", "x"]}, "cycle: a,b,x"),
        ]:
            with self.subTest(graph=graph):
                before = copy.deepcopy(graph)
                with self.assertRaises(ValueError) as error:
                    plan(graph)
                self.assertEqual(str(error.exception), message)
                self.assertEqual(graph, before)

    def test_validation(self):
        for graph in [None, [], "", {1: []}, {"": []}, {"a": None},
                      {"a": "b"}, {"a": ("b",)}, {"a": {"b"}},
                      {"a": [1]}, {"a": [""]}, {"a": [[]]},
                      {"ok": [], "bad": [None]},
                      {"cycle": ["cycle"], "bad": [False]}]:
            with self.subTest(graph=graph), self.assertRaises(ValueError):
                plan(graph)

    def test_long_graph(self):
        graph = {str(i): [str(i + 1)] for i in range(1500)}
        self.assertEqual(plan(graph), [str(i) for i in range(1500, -1, -1)])
        graph["1500"] = ["1499"]
        with self.assertRaisesRegex(ValueError, "^cycle: 1499,1500$"):
            plan(graph)
