"""Deterministic dependency planning using only the Python standard library."""

import heapq


def plan(graph):
    """Return dependencies first, choosing the smallest available node each time.

    Invalid graphs and graphs containing cycles raise ValueError. The input is
    only read; duplicate dependencies are treated as a single edge.
    """
    if not isinstance(graph, dict):
        raise ValueError("graph must be a dict")
    for node, dependencies in graph.items():
        if not isinstance(node, str) or not node:
            raise ValueError("node names must be nonempty strings")
        if not isinstance(dependencies, list):
            raise ValueError("dependencies must be lists")
        if any(not isinstance(dep, str) or not dep for dep in dependencies):
            raise ValueError("node names must be nonempty strings")

    dependencies = {node: set(deps) for node, deps in graph.items()}
    for deps in list(dependencies.values()):
        for dep in deps:
            dependencies.setdefault(dep, set())
    dependents = {node: set() for node in dependencies}
    for node, deps in dependencies.items():
        for dep in deps:
            dependents[dep].add(node)

    remaining = {node: len(deps) for node, deps in dependencies.items()}
    ready = [node for node, count in remaining.items() if count == 0]
    heapq.heapify(ready)
    result = []
    while ready:
        node = heapq.heappop(ready)
        result.append(node)
        for dependent in dependents[node]:
            remaining[dependent] -= 1
            if remaining[dependent] == 0:
                heapq.heappush(ready, dependent)
    if len(result) == len(dependencies):
        return result

    # Find strongly connected components with iterative DFS, avoiding Python's
    # recursion limit for long chains. Only nontrivial components or self-loops
    # belong in the cycle diagnostic.
    visited = set()
    finished = []
    for start in dependencies:
        if start in visited:
            continue
        visited.add(start)
        stack = [(start, iter(dependencies[start]))]
        while stack:
            node, neighbors = stack[-1]
            neighbor = next(neighbors, None)
            if neighbor is None:
                finished.append(node)
                stack.pop()
            elif neighbor not in visited:
                visited.add(neighbor)
                stack.append((neighbor, iter(dependencies[neighbor])))

    visited.clear()
    cyclic = set()
    for start in reversed(finished):
        if start in visited:
            continue
        visited.add(start)
        component = []
        stack = [start]
        while stack:
            node = stack.pop()
            component.append(node)
            for neighbor in dependents[node]:
                if neighbor not in visited:
                    visited.add(neighbor)
                    stack.append(neighbor)
        if len(component) > 1 or start in dependencies[start]:
            cyclic.update(component)
    raise ValueError("cycle: " + ",".join(sorted(cyclic)))
