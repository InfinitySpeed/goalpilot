import copy
import unittest

from planner import plan


class PlannerRegressions(unittest.TestCase):
    def test_smallest_ready_node_including_newly_ready_nodes(self):
        self.assertEqual(plan({"z": [], "b": ["a"], "a": []}),
                         ["a", "b", "z"])

    def test_value_only_nodes_duplicates_and_no_mutation(self):
        graph = {"z": ["b", "a", "b"], "b": ["a", "a"]}
        original = copy.deepcopy(graph)
        self.assertEqual(plan(graph), ["a", "b", "z"])
        self.assertEqual(graph, original)
        self.assertEqual(plan(graph), ["a", "b", "z"])

    def test_insertion_order_does_not_affect_result(self):
        self.assertEqual(plan({"z": ["c", "a"], "b": []}),
                         plan({"b": [], "z": ["a", "c"]}))

    def test_only_cycle_members_are_reported(self):
        graph = {"a": ["b", "root"], "b": ["a"],
                 "downstream": ["a"], "further": ["downstream"],
                 "self": ["self"], "x": ["y"], "y": ["x"]}
        original = copy.deepcopy(graph)
        with self.assertRaisesRegex(ValueError, r"^cycle: a,b,self,x,y$"):
            plan(graph)
        self.assertEqual(graph, original)

    def test_malformed_graphs(self):
        invalid = [None, [], "graph", {1: []}, {"": []},
                   {"a": None}, {"a": "b"}, {"a": ("b",)},
                   {"a": {"b"}}, {"a": [""]}, {"a": [1]},
                   {"a": [[]]}, {"a": [None]},
                   {"cycle": ["cycle"], "bad": [False]}]
        for graph in invalid:
            with self.subTest(graph=graph):
                with self.assertRaises(ValueError):
                    plan(graph)

    def test_long_graphs_do_not_require_recursive_traversal(self):
        graph = {str(i): [str(i + 1)] for i in range(1500)}
        self.assertEqual(plan(graph), [str(i) for i in range(1500, -1, -1)])
        graph["1500"] = ["1500"]
        with self.assertRaisesRegex(ValueError, r"^cycle: 1500$"):
            plan(graph)
