import java.lang.reflect.InvocationTargetException;
import java.math.BigInteger;
import java.net.URL;
import java.net.URLClassLoader;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;
import javax.tools.ToolProvider;

class TestRangesRegression {
    private static Class<?> ranges;

    @SafeVarargs
    @SuppressWarnings("unchecked")
    private static <T> T call(String method, List<long[]>... inputs) throws Exception {
        Class<?>[] types = new Class<?>[inputs.length];
        Arrays.fill(types, List.class);
        try {
            return (T) ranges.getMethod(method, types).invoke(null, (Object[]) inputs);
        } catch (InvocationTargetException e) {
            if (e.getCause() instanceof IllegalArgumentException invalid) throw invalid;
            throw e;
        }
    }

    private static List<long[]> pairs(long... endpoints) {
        List<long[]> result = new ArrayList<>();
        for (int i = 0; i < endpoints.length; i += 2)
            result.add(new long[] {endpoints[i], endpoints[i + 1]});
        return result;
    }

    private static void equal(List<long[]> actual, long... expected) {
        List<long[]> wanted = pairs(expected);
        if (actual.size() != wanted.size()) throw new AssertionError("Range count");
        for (int i = 0; i < actual.size(); i++)
            if (!Arrays.equals(actual.get(i), wanted.get(i)))
                throw new AssertionError("Range mismatch at " + i);
    }

    private static void check(boolean condition) {
        if (!condition) throw new AssertionError();
    }

    @SafeVarargs
    private static void invalid(String method, List<long[]>... inputs) throws Exception {
        try {
            call(method, inputs);
            throw new AssertionError("Expected IllegalArgumentException: " + method);
        } catch (IllegalArgumentException expected) { }
    }

    private static void tests() throws Exception {
        List<long[]> input = pairs(8, 10, 1, 3, 3, 5, 2, 4, 7, 7, 8, 9);
        List<long[]> normalized = call("normalize", input);
        equal(normalized, 1, 5, 8, 10);
        equal(input, 8, 10, 1, 3, 3, 5, 2, 4, 7, 7, 8, 9);
        normalized.get(0)[0] = 100;
        equal(input, 8, 10, 1, 3, 3, 5, 2, 4, 7, 7, 8, 9);
        equal(call("normalize", List.of()));
        equal(call("subtract", pairs(10, 20, 0, 5, 5, 10), pairs(12, 15, 2, 4, 4, 6)),
                0, 2, 6, 12, 15, 20);
        equal(call("subtract", pairs(0, 2, 4, 6, 8, 10), pairs(1, 9)), 0, 1, 9, 10);
        equal(call("subtract", pairs(0, 2), pairs(-2, 0, 2, 4)), 0, 2);
        equal(call("subtract", pairs(0, 2), pairs(-1, 3)));
        equal(call("subtract", List.of(), pairs(0, 2)));
        List<long[]> cuts = pairs(2, 3);
        List<long[]> source = pairs(0, 5);
        List<long[]> difference = call("subtract", source, cuts);
        equal(difference, 0, 2, 3, 5);
        difference.get(0)[1] = 99;
        equal(source, 0, 5);
        equal(cuts, 2, 3);
        check(difference.get(0) != difference.get(1));

        long lo = Long.MIN_VALUE, hi = Long.MAX_VALUE;
        equal(call("normalize", pairs(0, hi, lo, 0)), lo, hi);
        equal(call("subtract", pairs(lo, hi), pairs(lo, lo + 1, hi - 1, hi)), lo + 1, hi - 1);
        check(call("length", pairs(lo, hi)).equals(BigInteger.ONE.shiftLeft(64).subtract(BigInteger.ONE)));
        check(call("length", pairs(lo, -1, 0, hi)).equals(BigInteger.ONE.shiftLeft(64).subtract(BigInteger.TWO)));
        check(call("length", pairs(1, 5, 2, 7, 7, 7)).equals(BigInteger.valueOf(6)));
        check(call("length", List.of()).equals(BigInteger.ZERO));

        List<List<long[]>> bad = new ArrayList<>();
        bad.add(null);
        bad.add(Arrays.asList((long[]) null));
        bad.add(Collections.singletonList(new long[0]));
        bad.add(Collections.singletonList(new long[1]));
        bad.add(Collections.singletonList(new long[3]));
        bad.add(pairs(5, 4));
        for (List<long[]> value : bad) {
            invalid("normalize", value);
            invalid("length", value);
            invalid("subtract", value, List.of());
            invalid("subtract", List.of(), value);
        }

        Random random = new Random(34983);
        for (int trial = 0; trial < 1000; trial++) {
            List<long[]> a = randomRanges(random), b = randomRanges(random);
            boolean[] covered = coverage(a), removed = coverage(b);
            List<long[]> union = call("normalize", a);
            List<long[]> remainder = call("subtract", a, b);
            boolean[] unionCoverage = coverage(union), remainingCoverage = coverage(remainder);
            int count = 0;
            for (int i = 0; i < covered.length; i++) {
                check(unionCoverage[i] == covered[i]);
                check(remainingCoverage[i] == (covered[i] && !removed[i]));
                if (covered[i]) count++;
            }
            check(call("length", a).equals(BigInteger.valueOf(count)));
            for (List<long[]> result : List.of(union, remainder)) {
                for (int i = 0; i < result.size(); i++) {
                    check(result.get(i).length == 2 && result.get(i)[0] < result.get(i)[1]);
                    if (i > 0) check(result.get(i - 1)[1] < result.get(i)[0]);
                    for (long[] original : a) check(result.get(i) != original);
                    for (long[] original : b) check(result.get(i) != original);
                }
            }
        }
    }

    private static List<long[]> randomRanges(Random random) {
        List<long[]> result = new ArrayList<>();
        for (int i = random.nextInt(12); i > 0; i--) {
            int x = random.nextInt(41) - 20, y = random.nextInt(41) - 20;
            result.add(new long[] {Math.min(x, y), Math.max(x, y)});
        }
        return result;
    }

    private static boolean[] coverage(List<long[]> input) {
        boolean[] result = new boolean[40];
        for (long[] range : input)
            for (long i = range[0]; i < range[1]; i++) result[(int) i + 20] = true;
        return result;
    }

    public static void main(String[] args) throws Exception {
        Path directory = Files.createTempDirectory("ranges-regression");
        try {
            check(ToolProvider.getSystemJavaCompiler().run(null, null, null,
                    "-d", directory.toString(), "Ranges.java") == 0);
            try (var loader = new URLClassLoader(new URL[] {directory.toUri().toURL()})) {
                ranges = loader.loadClass("Ranges");
                tests();
            }
        } finally {
            try (var paths = Files.walk(directory)) {
                for (Path path : paths.sorted(Comparator.reverseOrder()).toList()) Files.delete(path);
            }
        }
        System.out.println("Range regression tests passed");
    }
}
