package quota

import (
	"errors"
	"sync"
)

// Quota limits accepted weight in a rolling window independently for each key.
// A Quota must be created with New and must not be copied after first use.
type Quota struct {
	mu     sync.Mutex
	limit  int
	window int64
	keys   map[string]keyState
}

type entry struct {
	time   int64
	weight int
}

type keyState struct {
	last    int64
	entries []entry
}

func New(limit int, window int64) (*Quota, error) {
	if limit <= 0 || window <= 0 {
		return nil, errors.New("capacity and window must be positive")
	}
	return &Quota{limit: limit, window: window, keys: make(map[string]keyState)}, nil
}

func (q *Quota) Allow(key string, now int64, weight int) (bool, error) {
	q.mu.Lock()
	defer q.mu.Unlock()
	if key == "" || now < 0 || weight <= 0 || weight > q.limit {
		return false, errors.New("nonempty key, nonnegative time, and weight within capacity required")
	}
	state, exists := q.keys[key]
	if exists && now < state.last {
		return false, errors.New("time precedes last accepted request")
	}

	// Inspect without pruning: even expired entries must survive a denial.
	// Subtraction is safe since now >= 0 and window > 0.
	cutoff := now - q.window
	first, total := 0, 0
	for first < len(state.entries) && state.entries[first].time <= cutoff {
		first++
	}
	for _, e := range state.entries[first:] {
		total += e.weight
	}
	// Avoid overflowing int when capacity is close to its maximum value.
	if total > q.limit-weight {
		return false, nil
	}

	entries := make([]entry, len(state.entries)-first+1)
	copy(entries, state.entries[first:])
	entries[len(entries)-1] = entry{time: now, weight: weight}
	q.keys[key] = keyState{last: now, entries: entries}
	return true, nil
}

// Reset forgets the accepted requests and clock for key.
func (q *Quota) Reset(key string) {
	q.mu.Lock()
	defer q.mu.Unlock()
	delete(q.keys, key)
}
