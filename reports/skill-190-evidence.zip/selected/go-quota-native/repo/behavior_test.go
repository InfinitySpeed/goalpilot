package quota

import (
	"reflect"
	"sync"
	"sync/atomic"
	"testing"
)

func mustQuota(t *testing.T, limit int, window int64) *Quota {
	t.Helper()
	q, err := New(limit, window)
	if err != nil {
		t.Fatal(err)
	}
	return q
}

func wantAllow(t *testing.T, q *Quota, key string, now int64, weight int, want bool) {
	t.Helper()
	ok, err := q.Allow(key, now, weight)
	if err != nil || ok != want {
		t.Fatalf("Allow(%q, %d, %d) = %v, %v; want %v, nil", key, now, weight, ok, err, want)
	}
}

func TestConstructorValidation(t *testing.T) {
	for _, args := range []struct {
		limit  int
		window int64
	}{{0, 1}, {-1, 1}, {1, 0}, {1, -1}} {
		if q, err := New(args.limit, args.window); err == nil || q != nil {
			t.Fatalf("New(%d, %d) = %v, %v", args.limit, args.window, q, err)
		}
	}
}

func TestRollingWeightedWindow(t *testing.T) {
	q := mustQuota(t, 5, 10)
	wantAllow(t, q, "a", 0, 2, true)
	wantAllow(t, q, "a", 5, 3, true)
	wantAllow(t, q, "a", 9, 1, false)
	wantAllow(t, q, "a", 10, 2, true) // The entry at zero is excluded.
	wantAllow(t, q, "a", 10, 1, false)
	wantAllow(t, q, "a", 15, 3, true)
	wantAllow(t, q, "b", 0, 5, true)
	wantAllow(t, q, "b", 0, 1, false)
}

func TestRejectionsLeaveStateUnchanged(t *testing.T) {
	q := mustQuota(t, 5, 10)
	wantAllow(t, q, "a", 0, 1, true)
	wantAllow(t, q, "a", 5, 4, true)
	before := keyState{last: q.keys["a"].last, entries: append([]entry(nil), q.keys["a"].entries...)}
	for _, req := range []struct {
		key    string
		now    int64
		weight int
	}{
		{"", 100, 1}, {"a", -1, 1}, {"a", 4, 1}, {"a", 100, 0}, {"a", 100, -1}, {"a", 100, 6}, {"new", 0, 6},
	} {
		if ok, err := q.Allow(req.key, req.now, req.weight); ok || err == nil {
			t.Fatalf("invalid request %+v returned %v, %v", req, ok, err)
		}
		if len(q.keys) != 1 || !reflect.DeepEqual(q.keys["a"], before) {
			t.Fatal("invalid request changed state")
		}
	}
	wantAllow(t, q, "a", 10, 2, false) // Would expire the first entry, but still exceeds capacity.
	if !reflect.DeepEqual(q.keys["a"], before) {
		t.Fatal("denial changed state")
	}
	wantAllow(t, q, "a", 5, 1, false) // Denial did not advance the clock or remove old weight.
	wantAllow(t, q, "a", 10, 1, true)
}

func TestResetForgetsOnlyOneKey(t *testing.T) {
	q := mustQuota(t, 3, 10)
	wantAllow(t, q, "a", 100, 3, true)
	wantAllow(t, q, "b", 100, 3, true)
	q.Reset("")
	q.Reset("missing")
	wantAllow(t, q, "a", 100, 1, false)
	q.Reset("a")
	wantAllow(t, q, "a", 0, 3, true)
	wantAllow(t, q, "b", 100, 1, false)
	q.Reset("a")
	q.Reset("a")
	wantAllow(t, q, "a", 0, 1, true)
}

func TestIntegerLimits(t *testing.T) {
	maxInt := int(^uint(0) >> 1)
	const maxTime int64 = 1<<63 - 1
	q := mustQuota(t, maxInt, maxTime)
	wantAllow(t, q, "a", 0, maxInt-1, true)
	wantAllow(t, q, "a", 0, 2, false)
	wantAllow(t, q, "a", 0, 1, true)
	wantAllow(t, q, "a", maxTime-1, 1, false)
	wantAllow(t, q, "a", maxTime, maxInt, true)
}

func TestConcurrentCapacityAndReset(t *testing.T) {
	q := mustQuota(t, 25, 10)
	var accepted atomic.Int64
	var wg sync.WaitGroup
	for i := 0; i < 100; i++ {
		wg.Add(1)
		go func() {
			defer wg.Done()
			ok, err := q.Allow("shared", 0, 1)
			if err != nil {
				t.Error(err)
			}
			if ok {
				accepted.Add(1)
			}
		}()
	}
	wg.Wait()
	if got := accepted.Load(); got != 25 {
		t.Fatalf("accepted %d; want 25", got)
	}
	for i := 0; i < 100; i++ {
		wg.Add(1)
		go func() {
			defer wg.Done()
			q.Reset("shared")
			q.Allow("shared", 0, 1)
		}()
	}
	wg.Wait()
	q.Reset("shared")
	wantAllow(t, q, "shared", 0, 25, true)
}
