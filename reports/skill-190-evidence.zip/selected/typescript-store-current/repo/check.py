import os,pathlib,subprocess,tempfile
with tempfile.TemporaryDirectory()as d:
 subprocess.run(['/workspace/goalpilot-research/universal-study/toolchains/typescript/node_modules/.bin/tsc','--strict','--target','ES2022','--module','commonjs','--outDir',d,'store.ts'],check=True)
 env=dict(os.environ,STORE_MODULE=str(pathlib.Path(d)/'store.js'))
 for p in sorted(pathlib.Path('tests').glob('*.cjs')):subprocess.run(['node',str(p)],env=env,check=True)
