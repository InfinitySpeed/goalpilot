const assert=require("node:assert/strict");const {Store}=require(process.env.STORE_MODULE);assert.equal(new Store().revision,0);
