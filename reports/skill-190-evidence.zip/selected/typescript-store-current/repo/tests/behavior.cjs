const assert = require('node:assert/strict');
const {Store} = require(process.env.STORE_MODULE);
const put = (key, value, expectedVersion) => expectedVersion === undefined ? {type:'put',key,value} : {type:'put',key,value,expectedVersion};
const s = new Store();
assert.deepEqual(s.apply([]), {revision:0,changed:[]});
const input = {nested:[{x:1}]};
s.apply([put('a',input,0),put('__proto__',JSON.parse('{"__proto__":{"ok":true}}')),put('b',2)]);
input.nested[0].x = 9;
const result = s.get('a'); result.value.nested[0].x = 8; result.version = 9;
assert.deepEqual(s.get('a'),{value:{nested:[{x:1}]},version:1});
assert.equal(Object.hasOwn(s.get('__proto__').value,'__proto__'),true);
s.keys().reverse();
const cycle = {}; cycle.self = cycle;
for (const bad of [undefined,NaN,Infinity,()=>{},1n,new Date(),cycle,{a:undefined},[undefined],new Array(1),Symbol('x')]) {
  const before = s.keys().map(k=>[k,s.get(k)]);
  assert.throws(()=>s.apply([{type:'delete',key:'a'},put('temp',true),put('bad',bad)]));
  assert.equal(s.revision,1);
  assert.deepEqual(s.keys().map(k=>[k,s.get(k)]),before);
}
for (const bad of [null,{},[null],[{type:'oops',key:'a'}],[put('',1)],[{type:'delete',key:1}],[{type:'delete',key:'a',expectedVersion:-1}],[{type:'delete',key:'a',expectedVersion:1.5}],[{type:'delete',key:'a',expectedVersion:undefined}]]) {
  assert.throws(()=>s.apply(bad));
  assert.equal(s.revision,1);
}
assert.throws(()=>s.apply([{type:'delete',key:'a'},put('a',3,1)]));
assert.deepEqual(s.keys(),['a','__proto__','b']);
assert.deepEqual(s.apply([{type:'delete',key:'a',expectedVersion:1},put('a',3,0),put('a',4,2),put('temp',0),{type:'delete',key:'temp',expectedVersion:2},{type:'delete',key:'absent',expectedVersion:0}]),{revision:2,changed:['a','temp','absent']});
assert.deepEqual(s.keys(),['__proto__','b','a']);
assert.deepEqual(s.get('a'),{value:4,version:2});
assert.equal(s.get('temp'),undefined);
assert.deepEqual(s.apply([]),{revision:2,changed:[]});
const shared = {x:[]};
s.apply([put('shared',[shared,shared]),put('json',[null,true,'x',1])]);
const cloned = s.get('shared').value; cloned[0].x.push(1);
assert.deepEqual(s.get('shared').value,[{x:[]},{x:[]}]);
