type Entry = {value: unknown, version: number};

function copyJSON(value: unknown, ancestors = new Set<object>()): unknown {
  if (value === null || typeof value === 'string' || typeof value === 'boolean') return value;
  if (typeof value === 'number' && Number.isFinite(value)) return value;
  if (typeof value !== 'object' || value === null) throw Error('Invalid JSON value');
  const array = Array.isArray(value);
  const proto = Object.getPrototypeOf(value);
  if (!array && proto !== Object.prototype && proto !== null) throw Error('Invalid JSON object');
  if (ancestors.has(value)) throw Error('Cyclic JSON value');
  ancestors.add(value);
  try {
    if (Object.getOwnPropertySymbols(value).length) throw Error('Invalid JSON property');
    const result: any = array ? [] : {};
    const names = Object.getOwnPropertyNames(value);
    if (array && names.length !== (value as unknown[]).length + 1) throw Error('Invalid JSON array');
    for (const key of names) {
      if (array && key === 'length') continue;
      const descriptor = Object.getOwnPropertyDescriptor(value, key)!;
      if (!descriptor.enumerable || !('value' in descriptor)) throw Error('Invalid JSON property');
      if (array && (!/^(0|[1-9][0-9]*)$/.test(key) || Number(key) >= (value as unknown[]).length)) throw Error('Invalid JSON index');
      Object.defineProperty(result, key, {value: copyJSON(descriptor.value, ancestors), enumerable: true, writable: true, configurable: true});
    }
    return result;
  } finally { ancestors.delete(value); }
}

export class Store {
  revision = 0;
  private entries = new Map<string, Entry>();
  get(key: string): Entry | undefined {
    const entry = this.entries.get(key);
    return entry ? {value: copyJSON(entry.value), version: entry.version} : undefined;
  }
  keys(): string[] { return [...this.entries.keys()]; }
  apply(ops: unknown): {revision: number, changed: string[]} {
    if (!Array.isArray(ops)) throw Error('Expected operation array');
    if (!ops.length) return {revision: this.revision, changed: []};
    const staged = new Map(this.entries);
    const changed = new Set<string>();
    const revision = this.revision + 1;
    for (const op of ops) {
      if (!op || typeof op !== 'object' || Array.isArray(op)) throw Error('Invalid operation');
      const {type, key} = op;
      if ((type !== 'put' && type !== 'delete') || typeof key !== 'string' || !key.length) throw Error('Invalid operation');
      if ('expectedVersion' in op) {
        const expected = op.expectedVersion;
        if (!Number.isInteger(expected) || expected < 0 || expected !== (staged.get(key)?.version ?? 0)) throw Error('Version mismatch');
      }
      if (type === 'put') staged.set(key, {value: copyJSON(op.value), version: revision});
      else staged.delete(key);
      changed.add(key);
    }
    this.entries = staged;
    this.revision = revision;
    return {revision, changed: [...changed]};
  }
}
