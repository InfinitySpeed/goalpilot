import java.util.*;
import java.math.BigInteger;
public class RegressionRanges {
 static List<long[]> ranges(long... v) {
  List<long[]> out = new ArrayList<>();
  for (int i=0;i<v.length;i+=2) out.add(new long[]{v[i],v[i+1]});
  return out;
 }
 static void eq(List<long[]> actual, long... expected) {
  if (!Arrays.deepEquals(actual.toArray(), ranges(expected).toArray())) throw new AssertionError("Unexpected ranges");
 }
 static void invalid(Runnable r) {
  try { r.run(); } catch (IllegalArgumentException ok) { return; }
  throw new AssertionError("Expected IllegalArgumentException");
 }
 public static void main(String[] args) {
  eq(Ranges.normalize(ranges(8,10,3,5,1,3,4,9,0,0)),1,10);
  eq(Ranges.normalize(ranges()));
  eq(Ranges.subtract(ranges(8,12,0,5,4,10),ranges(9,11,2,3,3,6)),0,2,6,9,11,12);
  eq(Ranges.subtract(ranges(0,2,4,6),ranges(-1,7)));
  eq(Ranges.subtract(ranges(0,2),ranges(2,3,-1,0)),0,2);
  eq(Ranges.subtract(ranges(0,2,4,6),ranges(1,5)),0,1,5,6);
  long lo=Long.MIN_VALUE, hi=Long.MAX_VALUE;
  eq(Ranges.normalize(ranges(hi-1,hi,lo,0,0,hi-1)),lo,hi);
  eq(Ranges.subtract(ranges(lo,hi),ranges(-1,1)),lo,-1,1,hi);
  if (!Ranges.length(ranges(lo,hi,0,2)).equals(new BigInteger("18446744073709551615"))) throw new AssertionError();
  if (!Ranges.length(ranges()).equals(BigInteger.ZERO)) throw new AssertionError();
  List<List<long[]>> bad = Arrays.asList(null, Arrays.asList((long[])null), Arrays.asList(new long[0]), Arrays.asList(new long[]{1}), Arrays.asList(new long[]{1,2,3}), ranges(2,1));
  for (List<long[]> a : bad) {
   invalid(() -> Ranges.normalize(a)); invalid(() -> Ranges.length(a));
   invalid(() -> Ranges.subtract(a,ranges())); invalid(() -> Ranges.subtract(ranges(),a));
  }
  long[] input={3,8}; List<long[]> a=Collections.singletonList(input);
  List<long[]> n=Ranges.normalize(a), s=Ranges.subtract(a,ranges(4,5));
  eq(a,3,8); n.get(0)[0]=99; s.get(0)[1]=99; eq(a,3,8);
  input[1]=10; eq(n,99,8); eq(s,3,99,5,8);
  // Exhaustive small-domain comparison with a point coverage oracle.
  for(int x=-3;x<=3;x++) for(int y=x;y<=3;y++)
   for(int u=-3;u<=3;u++) for(int v=u;v<=3;v++) {
    List<long[]> left=ranges(x,y,0,1), right=ranges(u,v);
    List<long[]> out=Ranges.subtract(left,right);
    long count=0, end=Long.MIN_VALUE;
    for(long[] r:out) { if(r[0]>=r[1] || r[0]<=end) throw new AssertionError(); end=r[1]; }
    for(int p=-3;p<3;p++) {
     boolean want=(p>=x&&p<y || p==0)&&!(p>=u&&p<v), got=false;
     for(long[] r:out) got |= p>=r[0]&&p<r[1];
     if(want!=got) throw new AssertionError(); if(want) count++;
    }
    if(!Ranges.length(out).equals(BigInteger.valueOf(count))) throw new AssertionError();
   }
 }
}
