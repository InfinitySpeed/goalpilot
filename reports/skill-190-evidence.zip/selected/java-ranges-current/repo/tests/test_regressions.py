import subprocess
subprocess.run(['java', 'tests/RunRegressions.java'], check=True)
