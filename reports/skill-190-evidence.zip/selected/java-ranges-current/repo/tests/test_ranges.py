import subprocess
subprocess.run(["java","TestRanges.java"],check=True)
