import javax.tools.ToolProvider;
import java.net.*;
import java.nio.file.*;
import java.util.Comparator;
class RunRegressions {
 public static void main(String[] args) throws Exception {
  Path d=Files.createTempDirectory("ranges-regressions");
  try {
   if(ToolProvider.getSystemJavaCompiler().run(null,null,null,"-d",d.toString(),"Ranges.java","tests/RegressionRanges.java")!=0) throw new AssertionError("Compilation failed");
   try(var loader=new URLClassLoader(new URL[]{d.toUri().toURL()})) {
    loader.loadClass("RegressionRanges").getMethod("main",String[].class).invoke(null,(Object)new String[0]);
   }
  } finally {
   try(var paths=Files.walk(d)) {
    for(Path p:paths.sorted(Comparator.reverseOrder()).toList()) Files.delete(p);
   }
  }
 }
}
