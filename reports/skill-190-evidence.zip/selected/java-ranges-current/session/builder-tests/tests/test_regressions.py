import subprocess
import tempfile
with tempfile.TemporaryDirectory() as directory:
    subprocess.run(['javac', '-d', directory, 'Ranges.java', 'tests/RegressionRanges.java'], check=True)
    subprocess.run(['java', '-cp', directory, 'RegressionRanges'], check=True)
