import java.util.*;import java.math.BigInteger;
public class Ranges {
 public static List<long[]> normalize(List<long[]> a){throw new UnsupportedOperationException();}
 public static List<long[]> subtract(List<long[]> a,List<long[]> b){throw new UnsupportedOperationException();}
 public static BigInteger length(List<long[]> a){throw new UnsupportedOperationException();}
}
