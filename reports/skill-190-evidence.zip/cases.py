from pathlib import Path
import importlib.util,json
p=Path('/workspace/goalpilot-research/universal-study/cases.py');spec=importlib.util.spec_from_file_location('old_cases',p);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
CASES={k:m.CASES[k]for k in ('java-ranges','python-repair')}
GO='/workspace/goalpilot-research/universal-study/toolchains/go/bin/go'
TSC='/workspace/goalpilot-research/universal-study/toolchains/typescript/node_modules/.bin/tsc'
CASES['go-quota']={
'goal':'Finish this Go rolling-window weighted quota limiter. Enforce a positive capacity and window, independent nonempty keys, positive weights, and monotonic nonnegative timestamps per key. Count only accepted weights in the half-open rolling window (now-window, now]. Reject invalid arguments without state changes; quota denials also leave state unchanged. Support Reset(key), safe concurrent callers, and meaningful native tests. Preserve the API and original tests.',
'contract':'Package quota: New(limit int, window int64) (*Quota,error); (*Quota).Allow(key string, now int64, weight int) (bool,error); (*Quota).Reset(key string). Invalid limit/window <=0 or weight <=0/greater than limit return errors. now must be >=0 and >=the last accepted timestamp for this key. Allow returns false,nil on capacity denial. Rejected/denied requests must not advance time, expire stored entries or otherwise mutate state. Reset forgets one key including its clock. Empty Reset is a no-op. Use a mutex for concurrent safety; only Go stdlib. python3 check.py executes the available Go compiler without downloads.',
'files':{'go.mod':'module quota\n\ngo 1.23\n','quota.go':'package quota\nimport "errors"\ntype Quota struct{}\nfunc New(limit int, window int64)(*Quota,error){return nil,errors.New("unfinished")}\nfunc(q *Quota)Allow(key string,now int64,weight int)(bool,error){return false,errors.New("unfinished")}\nfunc(q *Quota)Reset(key string){}\n','quota_test.go':'package quota\nimport "testing"\nfunc TestAPI(t *testing.T){var _ func(int,int64)(*Quota,error)=New}\n','check.py':f'import subprocess\nsubprocess.run([{GO!r},"test","./..."],check=True)\n'},
'judge_file':'judge_test.go','judge_cmd':[GO,'test','./...'],
'judge':'''package quota
import("testing";"sync";"sync/atomic")
func TestIndependent(t *testing.T){
 q,e:=New(5,10);if e!=nil{t.Fatal(e)}
 check:=func(key string,now int64,w int,want bool,err bool){t.Helper();ok,e:=q.Allow(key,now,w);if ok!=want||(e!=nil)!=err{t.Fatalf("%s %d %d got %v %v",key,now,w,ok,e)}}
 check("a",0,3,true,false);check("a",1,3,false,false);check("a",0,2,true,false);check("a",10,5,true,false);check("a",9,1,false,true);check("b",0,5,true,false)
 check("a",100,0,false,true);check("a",11,1,false,false);q.Reset("a");check("a",0,5,true,false);check("",0,1,false,true);check("x",-1,1,false,true);check("x",0,6,false,true)
 for _,v:=range[][2]int{{0,1},{1,0},{-1,1}}{if _,e:=New(v[0],int64(v[1]));e==nil{t.Fatal("invalid New")}}
 q,_=New(42,10);var n atomic.Int64;var wg sync.WaitGroup;for i:=0;i<100;i++{wg.Add(1);go func(){defer wg.Done();ok,e:=q.Allow("same",0,1);if e!=nil{t.Error(e)};if ok{n.Add(1)}}()};wg.Wait();if n.Load()!=42{t.Fatal(n.Load())}
}
'''}
CASES['typescript-store']={
'goal':'Finish the TypeScript transactional key-value store. Apply put/delete batches atomically with compare-and-swap versions and rollback on any invalid operation. Preserve insertion order for listing keys, return defensive copies of JSON values, reject malformed data and cycles, and support empty batches without incrementing revision. Preserve the API and native test command, and add behavioral tests for rollback and aliasing.',
'contract':'Export class Store with revision:number initially0, get(key:string):{value:unknown,version:number}|undefined, keys():string[], apply(ops:unknown):{revision:number,changed:string[]}. Each op is {type:"put",key:string,value:JSONValue,expectedVersion?:number} or {type:"delete",key:string,expectedVersion?:number}. Keys nonempty strings; arbitrary keys including __proto__ valid. Versions nonnegative integers;0 means absent. Validate before committing; repeated keys within a batch use intermediate state. Nonempty batch increments global revision once; puts use that tentative new revision. Delete of absent key succeeds. changed returns unique keys in first-op order even if put then delete. Failed operations preserve revision, values, versions and insertion order. Accepted JSON values: null, boolean,string,finite numbers, arrays and plain objects recursively; reject cycles, undefined, functions, bigint, exotic objects. Returned/stored values must be deep copied. Test command python3 check.py compiles store.ts strictly and runs all tests/*.cjs with STORE_MODULE environment.',
'files':{'store.ts':'export class Store { revision=0; get(key:string):{value:unknown,version:number}|undefined {throw Error("unfinished")} keys():string[]{return []} apply(ops:unknown):{revision:number,changed:string[]}{throw Error("unfinished")} }\n','tests/test_store.cjs':'const assert=require("node:assert/strict");const {Store}=require(process.env.STORE_MODULE);assert.equal(new Store().revision,0);\n','check.py':f'''import os,pathlib,subprocess,tempfile
with tempfile.TemporaryDirectory()as d:
 subprocess.run([{TSC!r},'--strict','--target','ES2022','--module','commonjs','--outDir',d,'store.ts'],check=True)
 env=dict(os.environ,STORE_MODULE=str(pathlib.Path(d)/'store.js'))
 for p in sorted(pathlib.Path('tests').glob('*.cjs')):subprocess.run(['node',str(p)],env=env,check=True)
'''},
'judge_file':'judge.py','judge_cmd':['python3','judge.py'],
'judge':f'''import os,pathlib,subprocess,tempfile
script=r"""const assert=require('node:assert/strict');const {{Store}}=require(process.env.STORE_MODULE);let s=new Store(),v={{x:[1]}};
assert.deepEqual(s.apply([{{type:'put',key:'a',value:v,expectedVersion:0}}]),{{revision:1,changed:['a']}});v.x.push(2);assert.deepEqual(s.get('a'),{{value:{{x:[1]}},version:1}});let x=s.get('a');x.value.x.push(3);assert.deepEqual(s.get('a').value,{{x:[1]}});
let before=JSON.stringify([s.keys(),s.get('a'),s.revision]);assert.throws(()=>s.apply([{{type:'put',key:'b',value:2}},{{type:'put',key:'a',value:4,expectedVersion:0}}]));assert.equal(JSON.stringify([s.keys(),s.get('a'),s.revision]),before);
assert.deepEqual(s.apply([{{type:'put',key:'b',value:1}},{{type:'delete',key:'b',expectedVersion:2}},{{type:'put',key:'__proto__',value:2}}]),{{revision:2,changed:['b','__proto__']}});assert.deepEqual(s.keys(),['a','__proto__']);assert.equal(s.get('__proto__').value,2);assert.deepEqual(s.apply([]),{{revision:2,changed:[]}});
let cycle={{}};cycle.x=cycle;for(let value of [undefined,NaN,Infinity,1n,()=>1,new Date(),cycle]){{let n=s.revision;assert.throws(()=>s.apply([{{type:'put',key:'x',value}}]));assert.equal(s.revision,n)}}
for(let ops of [null,{{}},[{{type:'wat',key:'x'}}],[{{type:'put',key:'',value:1}}],[{{type:'delete',key:'a',expectedVersion:-1}}]])assert.throws(()=>s.apply(ops));console.log('PASS independent TS');"""
with tempfile.TemporaryDirectory()as d:
 subprocess.run([{TSC!r},'--strict','--target','ES2022','--module','commonjs','--outDir',d,'store.ts'],check=True)
 p=pathlib.Path(d)/'judge.cjs';p.write_text(script);subprocess.run(['node',str(p)],env=dict(os.environ,STORE_MODULE=str(pathlib.Path(d)/'store.js')),check=True)
'''}
def materialize(name,repo):
 c=CASES[name];repo.mkdir(parents=True)
 for name,body in c['files'].items():
  p=repo/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(body)
 (repo/'README.md').write_text(c['goal']+'\n\n'+c['contract']+'\n');return c['goal']
