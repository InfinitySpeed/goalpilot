from pathlib import Path
import json,subprocess,tempfile
from cases import CASES,materialize
from references import GO_REFERENCE,TS_REFERENCE
results={}
for name,filename,reference in [('go-quota','quota.go',GO_REFERENCE),('typescript-store','store.ts',TS_REFERENCE)]:
 case=CASES[name];results[name]={}
 for arm in ('stub','reference'):
  with tempfile.TemporaryDirectory()as d:
   repo=Path(d)/'repo';materialize(name,repo)
   if arm=='reference':(repo/filename).write_text(reference)
   (repo/case['judge_file']).write_text(case['judge'])
   r=subprocess.run(case['judge_cmd'],cwd=repo,capture_output=True,text=True,timeout=90)
   results[name][arm]={'correct':r.returncode==0,'log':r.stdout+r.stderr}
Path(__file__).with_name('judge-controls.json').write_text(json.dumps(results,indent=2)+'\n')
print({k:{a:b['correct']for a,b in v.items()}for k,v in results.items()})
assert all(not v['stub']['correct']and v['reference']['correct']for v in results.values())
