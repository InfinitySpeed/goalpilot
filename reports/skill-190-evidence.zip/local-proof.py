from pathlib import Path
import contextlib,importlib.util,io,json,subprocess,sys,tempfile,unittest
R=Path(__file__).resolve().parent;spec=importlib.util.spec_from_file_location('expanded',R/'candidate/tests/test_native_generalization.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
results={}
for arm in ('control','candidate'):
 m.CLI=R/arm/'integrations/native/native.py';stream=io.StringIO();runner=unittest.TextTestRunner(stream=stream);suite=unittest.defaultTestLoader.loadTestsFromModule(m);r=runner.run(suite)
 failed={t.id().split(' ')[0]for t,_ in r.failures+r.errors};results[arm]={'methods':r.testsRun,'failed_methods':len(failed),'passed_methods':r.testsRun-len(failed),'failures':len(r.failures),'errors':len(r.errors),'log':stream.getvalue()}
with tempfile.TemporaryDirectory()as d:
 root=Path(d);repo=root/'repo';repo.mkdir();deep=repo/('directory_'+'x'*120);deep.mkdir()
 for n in range(2500):(deep/(str(n)+'_'+'y'*80+'.txt')).write_text('x')
 for arm in ('control','candidate'):
  run=root/arm;p=subprocess.run([sys.executable,str(R/arm/'integrations/native/native.py'),'begin','--repo',str(repo),'--run-dir',str(run),'--goal','Inspect this project','--context'],capture_output=True,timeout=30)
  assert p.returncode==0;pout=p.stdout;results[arm]['context_bytes']=len(pout);results[arm]['captured_files']=len(json.loads((run/'session.json').read_text())['original'])
results['context_reduction_pct']=100*(1-results['candidate']['context_bytes']/results['control']['context_bytes'])
(R/'local-proof.json').write_text(json.dumps(results,indent=2)+'\n');print({k:{a:b for a,b in v.items()if a!='log'}if isinstance(v,dict)else v for k,v in results.items()})
assert results['candidate']['passed_methods']==8 and results['control']['passed_methods']==1
