export function formatBytes(value) {
  if (typeof value !== 'number') throw new TypeError('Expected a number');
  if (!Number.isSafeInteger(value) || value < 0) {
    throw new RangeError('Expected a nonnegative safe integer');
  }

  const units = ['B', 'KiB', 'MiB', 'GiB', 'TiB'];
  let unit = 0;
  let divisor = 1;
  while (unit < units.length - 1 && value >= divisor * 1024) {
    divisor *= 1024;
    unit++;
  }
  const size = unit === 0 ? value : Math.round((value / divisor) * 10) / 10;
  return `${size} ${units[unit]}`;
}
