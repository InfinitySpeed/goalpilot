export function slugify(value) {
  if (typeof value !== 'string') {
    throw new TypeError('slugify expects a string');
  }
  return value.replace(/[^A-Za-z0-9]+/g, '-').toLowerCase().replace(/^-+|-+$/g, '');
}
