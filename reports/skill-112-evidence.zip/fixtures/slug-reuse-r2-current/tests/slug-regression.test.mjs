import test from 'node:test';
import assert from 'node:assert/strict';
import {slugify} from '../slug.mjs';

test('non-ASCII case mappings remain separators', () => {
  for (const [input, expected] of [
    ['AKİB', 'a-b'],
    ['Kİ', ''],
    ['__A😀!東京\u0000Z09--', 'a-z09'],
  ]) assert.equal(slugify(input), expected);
});

test('rejects other non-string types without coercion', () => {
  for (const value of [true, 1n, Symbol('slug'), [], new String('slug'), () => 'slug']) {
    assert.throws(() => slugify(value), TypeError);
  }
});
