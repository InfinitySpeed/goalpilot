import test from 'node:test';
import assert from 'node:assert/strict';
import {slugify} from '../slug.mjs';

test('ASCII casing and digit preservation',()=>{
 assert.equal(slugify('Hello WORLD 123'),'hello-world-123');
 assert.equal(slugify('MiXeD 007'),'mixed-007');
});
test('non-ASCII and punctuation runs become one separator',()=>{
 for(const [input,expected] of [['one___two','one-two'],['a!!!b','a-b'],['a  \t\nb','a-b'],['aé東京b','a-b'],['Æß',''],['x@#y','x-y']]) assert.equal(slugify(input),expected);
});
test('edge separators and empty input',()=>{
 for(const [input,expected] of [['__Start---','start'],['---',''],['','']]) assert.equal(slugify(input),expected);
});
test('rejects non-strings',()=>{
 for(const value of [null,1,{},undefined]) assert.throws(()=>slugify(value),TypeError);
});
