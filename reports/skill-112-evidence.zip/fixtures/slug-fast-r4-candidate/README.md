Repair the existing JavaScript slug helper. It must map ASCII letters to lowercase, preserve ASCII digits, replace each run of any other characters with one hyphen, trim edge hyphens, return an empty string for empty or separator-only input, reject non-string input with TypeError, and keep its exported API. Run the existing test suite and keep the change focused.

Export function slugify(value) from slug.mjs. Only ASCII A-Z are case-converted; non-ASCII characters are separators and are not transliterated. Replace any run of characters outside [A-Za-z0-9] with one hyphen and trim hyphens from both ends. Empty and separator-only strings return empty string. Non-string values throw TypeError. Node standard library only; npm test runs node --test. The existing suite covers every criterion.

Noise files under docs/ are unrelated historical notes; preserve them.
