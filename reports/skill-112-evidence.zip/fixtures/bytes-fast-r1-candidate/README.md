Fix the existing JavaScript byte-size formatter. Format nonnegative safe-integer byte counts using binary units, keep byte values as integers, choose the largest available unit, round scaled values to one decimal and omit a trailing .0. Reject non-number values with TypeError and invalid numeric ranges with RangeError. Preserve the exported API and run the existing test suite.

Export formatBytes(value) from bytes.mjs. Type must be number or throw TypeError. Reject non-integers, negative values, NaN, infinities, and unsafe integers with RangeError. Units are B, KiB, MiB, GiB, TiB using powers of 1024. Below 1024 return the exact integer followed by " B". Otherwise choose the largest unit whose divisor is <=value, round to one decimal with Math.round, and omit trailing .0. Do not promote to the next unit after rounding. Node standard library only; npm test runs node --test. Existing suite covers each clause.

Noise files under docs/ are unrelated historical notes; preserve them.
