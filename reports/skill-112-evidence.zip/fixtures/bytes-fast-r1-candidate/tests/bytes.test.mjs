import test from 'node:test';
import assert from 'node:assert/strict';
import {formatBytes} from '../bytes.mjs';
test('exact bytes and unit boundaries',()=>{
 for(const [x,y] of [[0,'0 B'],[1,'1 B'],[1023,'1023 B'],[1024,'1 KiB'],[1048576,'1 MiB'],[1073741824,'1 GiB'],[1099511627776,'1 TiB']])assert.equal(formatBytes(x),y);
});
test('rounds once and omits trailing zero',()=>{
 for(const [x,y] of [[1536,'1.5 KiB'],[10240,'10 KiB'],[1234,'1.2 KiB'],[2047,'2 KiB'],[1048575,'1024 KiB'],[Number.MAX_SAFE_INTEGER,'8192 TiB']])assert.equal(formatBytes(x),y);
});
test('rejects bad types and numeric values distinctly',()=>{
 for(const x of [null,'1',{},undefined])assert.throws(()=>formatBytes(x),TypeError);
 for(const x of [-1,1.5,NaN,Infinity,-Infinity,Number.MAX_SAFE_INTEGER+1])assert.throws(()=>formatBytes(x),RangeError);
});
