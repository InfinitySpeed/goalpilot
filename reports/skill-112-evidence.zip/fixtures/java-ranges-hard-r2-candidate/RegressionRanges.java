import java.util.*;
import java.math.BigInteger;
import java.net.*;
import java.nio.file.*;
import javax.tools.ToolProvider;

class RegressionRanges {
    static Class<?> ranges;
    @SuppressWarnings("unchecked")
    static <T> T call(String name, List<long[]>... args) throws Exception {
        Class<?>[] types = new Class<?>[args.length];
        Arrays.fill(types, List.class);
        try { return (T) ranges.getMethod(name, types).invoke(null, (Object[]) args); }
        catch (java.lang.reflect.InvocationTargetException e) {
            if (e.getCause() instanceof IllegalArgumentException x) throw x;
            throw e;
        }
    }
    static List<long[]> rs(long... endpoints) {
        List<long[]> out = new ArrayList<>();
        for (int i = 0; i < endpoints.length; i += 2)
            out.add(new long[]{endpoints[i], endpoints[i+1]});
        return out;
    }
    static void equal(List<long[]> actual, List<long[]> expected) {
        if (!Arrays.deepEquals(actual.toArray(), expected.toArray()))
            throw new AssertionError("Unexpected intervals");
    }
    static void test() throws Exception {
        List<long[]> input = rs(8,10, 1,4, 3,7, 7,8, 2,2, -5,-3);
        List<long[]> snapshot = rs(8,10, 1,4, 3,7, 7,8, 2,2, -5,-3);
        List<long[]> merged = call("normalize", Collections.unmodifiableList(input));
        equal(merged, rs(-5,-3, 1,10));
        equal(input, snapshot);
        merged.get(0)[0] = 99;
        equal(input, snapshot);
        List<long[]> cuts = rs(7,9, 2,4, 3,5, 20,30, -10,0);
        List<long[]> cutsCopy = rs(7,9, 2,4, 3,5, 20,30, -10,0);
        List<long[]> difference = call("subtract", input, cuts);
        equal(difference, rs(1,2, 5,7, 9,10));
        equal(input, snapshot); equal(cuts, cutsCopy);
        difference.get(0)[0] = 100;
        equal(input, snapshot); equal(cuts, cutsCopy);
        equal(call("subtract", rs(0,2, 4,6), rs(1,5)), rs(0,1, 5,6));
        equal(call("subtract", rs(0,2), rs(2,3)), rs(0,2));
        equal(call("subtract", rs(0,2), rs(-1,3)), rs());
        equal(call("normalize", rs()), rs());
        equal(call("normalize", rs(2,2)), rs());
        equal(call("subtract", rs(), rs()), rs());
        if (!BigInteger.valueOf(11).equals(call("length", input))) throw new AssertionError();
        if (!BigInteger.ZERO.equals(call("length", rs()))) throw new AssertionError();
        long lo = Long.MIN_VALUE, hi = Long.MAX_VALUE;
        if (!new BigInteger("18446744073709551615").equals(call("length", rs(lo,hi))))
            throw new AssertionError("Length overflow");
        equal(call("normalize", rs(0,hi, lo,0)), rs(lo,hi));
        equal(call("subtract", rs(lo,hi), rs(lo,0)), rs(0,hi));
        List<List<long[]>> invalid = new ArrayList<>();
        invalid.add(null);
        invalid.add(Arrays.asList((long[]) null));
        invalid.add(List.of(new long[0]));
        invalid.add(List.of(new long[]{1}));
        invalid.add(List.of(new long[]{1,2,3}));
        invalid.add(rs(2,1));
        for (List<long[]> bad : invalid) {
            for (String method : List.of("normalize", "length", "subtract")) {
                try {
                    if (method.equals("subtract")) call(method, bad, rs());
                    else call(method, bad);
                    throw new AssertionError("Accepted invalid input: " + method);
                } catch (IllegalArgumentException expected) {}
            }
            try { call("subtract", rs(), bad); throw new AssertionError("Invalid right set"); }
            catch (IllegalArgumentException expected) {}
        }
    }
    public static void main(String[] args) throws Exception {
        Path d = Files.createTempDirectory("ranges-regression");
        try {
            if (ToolProvider.getSystemJavaCompiler().run(null,null,null,"-d",d.toString(),"Ranges.java") != 0)
                throw new AssertionError("Compilation failed");
            try (var loader = new URLClassLoader(new URL[]{d.toUri().toURL()})) {
                ranges = loader.loadClass("Ranges"); test();
            }
        } finally {
            try (var paths = Files.walk(d)) {
                for (Path p : paths.sorted(Comparator.reverseOrder()).toList()) Files.delete(p);
            }
        }
    }
}
