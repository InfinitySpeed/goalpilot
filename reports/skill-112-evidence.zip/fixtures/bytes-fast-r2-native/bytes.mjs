export function formatBytes(value) {
  if (typeof value !== 'number') {
    throw new TypeError('Byte count must be a number');
  }
  if (!Number.isSafeInteger(value) || value < 0) {
    throw new RangeError('Byte count must be a nonnegative safe integer');
  }

  const units = ['B', 'KiB', 'MiB', 'GiB', 'TiB'];
  let unit = 0;
  let divisor = 1;
  while (unit < units.length - 1 && value >= divisor * 1024) {
    divisor *= 1024;
    unit += 1;
  }

  const rounded = unit === 0 ? value : Math.round((value / divisor) * 10) / 10;
  return `${rounded} ${units[unit]}`;
}
