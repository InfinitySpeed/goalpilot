import test from 'node:test';
import assert from 'node:assert/strict';
import {formatBytes} from '../bytes.mjs';

test('rounding ties apply in every scaled unit', () => {
  for (const [power, unit] of [[1, 'KiB'], [2, 'MiB'], [3, 'GiB'], [4, 'TiB']]) {
    assert.equal(formatBytes(1.25 * 1024 ** power), `1.3 ${unit}`);
  }
});

test('higher boundaries do not promote after rounding', () => {
  for (const [power, unit] of [[3, 'MiB'], [4, 'GiB']]) {
    assert.equal(formatBytes(1024 ** power - 1), `1024 ${unit}`);
  }
  assert.equal(formatBytes(-0), '0 B');
});

test('rejects other non-number primitives and boxed numbers', () => {
  for (const value of [true, false, 1n, Symbol('bytes'), new Number(1), []]) {
    assert.throws(() => formatBytes(value), TypeError);
  }
});
