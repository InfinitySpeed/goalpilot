import javax.tools.ToolProvider;
import java.net.*;
import java.nio.file.*;
import java.lang.reflect.*;
import java.util.*;
import java.math.BigInteger;

class TestRangesRegression {
    static Class<?> ranges;
    static Object call(String name, Object... args) throws Exception {
        Class<?>[] types = new Class<?>[args.length];
        Arrays.fill(types, List.class);
        try { return ranges.getMethod(name, types).invoke(null, args); }
        catch (InvocationTargetException e) {
            if (e.getCause() instanceof IllegalArgumentException ex) throw ex;
            throw e;
        }
    }
    @SuppressWarnings("unchecked")
    static List<long[]> list(String name, Object... args) throws Exception {
        return (List<long[]>) call(name, args);
    }
    static List<long[]> pairs(long... values) {
        List<long[]> out = new ArrayList<>();
        for (int i = 0; i < values.length; i += 2) out.add(new long[]{values[i], values[i+1]});
        return out;
    }
    static void equal(List<long[]> actual, long... expected) {
        if (!Arrays.deepEquals(actual.toArray(), pairs(expected).toArray()))
            throw new AssertionError(Arrays.deepToString(actual.toArray()));
    }
    static void rejects(String name, Object... args) throws Exception {
        try { call(name, args); } catch (IllegalArgumentException expected) { return; }
        throw new AssertionError("accepted invalid " + name);
    }
    static void check() throws Exception {
        List<long[]> input = List.of(new long[]{8,10}, new long[]{2,5}, new long[]{4,8}, new long[]{2,5}, new long[]{7,7});
        equal(list("normalize", input), 2,10);
        equal(input, 8,10,2,5,4,8,2,5,7,7);
        List<long[]> fresh = list("normalize", input);
        fresh.get(0)[0] = -99;
        equal(input, 8,10,2,5,4,8,2,5,7,7);
        List<long[]> a = pairs(20,30,0,10,8,15);
        List<long[]> b = pairs(12,22,3,5,5,7);
        equal(list("subtract", a,b), 0,3,7,12,22,30);
        equal(a, 20,30,0,10,8,15);
        equal(b, 12,22,3,5,5,7);
        equal(list("subtract", pairs(0,3,5,8), pairs(-1,10)));
        equal(list("subtract", pairs(0,5), pairs(-2,0,5,9)), 0,5);
        List<long[]> copy = list("subtract", a,List.of());
        copy.get(0)[0] = -100;
        equal(a, 20,30,0,10,8,15);
        long lo = Long.MIN_VALUE, hi = Long.MAX_VALUE;
        equal(list("normalize", pairs(0,hi,lo,0)), lo,hi);
        equal(list("subtract", pairs(lo,hi), pairs(-1,1)), lo,-1,1,hi);
        if (!call("length", pairs(lo,hi)).equals(new BigInteger("18446744073709551615"))) throw new AssertionError("overflow");
        if (!call("length", input).equals(BigInteger.valueOf(8))) throw new AssertionError("union length");
        if (!call("length", pairs(3,3)).equals(BigInteger.ZERO)) throw new AssertionError("empty length");
        equal(list("normalize", List.of()));
        equal(list("subtract", List.of(), b));
        for (List<long[]> bad : Arrays.<List<long[]>>asList(null, Arrays.asList((long[]) null), List.of(new long[0]), List.of(new long[]{1}), List.of(new long[]{1,2,3}), pairs(2,1))) {
            rejects("normalize", bad);
            rejects("length", bad);
            rejects("subtract", bad, List.of());
            rejects("subtract", List.of(), bad);
        }
    }
    public static void main(String[] args) throws Exception {
        Path d = Files.createTempDirectory("ranges-regression");
        try {
            if (ToolProvider.getSystemJavaCompiler().run(null,null,null,"-d",d.toString(),"Ranges.java") != 0) throw new AssertionError();
            try (var loader = new URLClassLoader(new URL[]{d.toUri().toURL()})) {
                ranges = loader.loadClass("Ranges");
                check();
            }
        } finally {
            try (var paths = Files.walk(d)) {
                for (Path p : paths.sorted(Comparator.reverseOrder()).toList()) Files.delete(p);
            }
        }
        System.out.println("Ranges regressions passed");
    }
}
