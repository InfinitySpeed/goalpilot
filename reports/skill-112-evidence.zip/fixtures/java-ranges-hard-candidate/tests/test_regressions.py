import subprocess
subprocess.run(["java", "TestRangesRegression.java"], check=True)
