import test from 'node:test';
import assert from 'node:assert/strict';
import { formatBytes } from '../bytes.mjs';

test('rounding ties, higher boundaries, and the unit cap', () => {
  // 1280 / 1024 = 1.25; rounding to tenths gives 1.3.
  assert.equal(formatBytes(1280), '1.3 KiB');
  assert.equal(formatBytes(-0), '0 B');
  for (const [value, expected] of [
    [1024 ** 3 - 1, '1024 MiB'],
    [1024 ** 4 - 1, '1024 GiB'],
    [1024 ** 5, '1024 TiB'],
  ]) assert.equal(formatBytes(value), expected);
});

test('non-number primitives and boxed numbers stay type errors', () => {
  for (const value of [true, 1n, Symbol('bytes'), new Number(1)]) {
    assert.throws(() => formatBytes(value), TypeError);
  }
});
