import json


def _parse_lines(text):
    for number, line in enumerate(text.splitlines(), 1):
        if not line.strip():
            continue
        try:
            event = json.loads(line)
        except Exception as exc:
            raise ValueError(f"line {number}: invalid JSON") from exc
        if not isinstance(event, dict):
            raise ValueError(f"line {number}: expected object")
        yield number, event


def load_events(text):
    return [event for _, event in _parse_lines(text)]


def count_by_type(text):
    counts = {}
    for number, event in _parse_lines(text):
        kind = event.get("type")
        if not isinstance(kind, str):
            raise ValueError(f"line {number}: type must be string")
        counts[kind] = counts.get(kind, 0) + 1
    return counts
