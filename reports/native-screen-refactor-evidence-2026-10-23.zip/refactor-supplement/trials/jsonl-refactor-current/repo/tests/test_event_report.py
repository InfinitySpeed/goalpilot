import unittest
from event_report import load_events,count_by_type
class Existing(unittest.TestCase):
 def test_basic(self):
  text='{\"type\":\"a\"}\n{\"type\":\"b\"}\n'
  self.assertEqual([x['type'] for x in load_events(text)],['a','b'])
  self.assertEqual(count_by_type(text),{'a':1,'b':1})
