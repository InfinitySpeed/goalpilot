import unittest
from unittest.mock import patch

import event_report as report


class ParseLinesTests(unittest.TestCase):
    def test_order_blanks_and_source_numbers(self):
        text = '\n {"type":"b","value":1}\r\n \t\n{"type":"a"}\n{"type":"b"}\n'
        events = [{"type": "b", "value": 1}, {"type": "a"}, {"type": "b"}]
        self.assertEqual(list(report._parse_lines(text)), list(zip([2, 4, 5], events)))
        self.assertEqual(report.load_events(text), events)
        self.assertEqual(list(report.count_by_type(text).items()), [("b", 2), ("a", 1)])
        for text in ('', ' \n\t\r\n'):
            self.assertEqual(report.load_events(text), [])
            self.assertEqual(report.count_by_type(text), {})

    def test_shared_validation_errors(self):
        for function in (report.load_events, report.count_by_type):
            for value, message in [('bad', 'invalid JSON'), ('{"type":', 'invalid JSON'),
                                   ('[]', 'expected object'), ('null', 'expected object'),
                                   ('1', 'expected object'), ('"x"', 'expected object'),
                                   ('true', 'expected object')]:
                with self.subTest(function=function.__name__, value=value):
                    with self.assertRaises(ValueError) as caught:
                        function('{"type":"ok"}\n \n' + value)
                    self.assertEqual(str(caught.exception), 'line 3: ' + message)

    def test_type_validation_and_first_error(self):
        for event in ({}, {"type": None}, {"type": 1}, {"type": True},
                      {"type": []}, {"type": {}}):
            text = '\n' + __import__('json').dumps(event) + '\nbad'
            with self.subTest(event=event):
                self.assertEqual(report.load_events(text.rsplit('\n', 1)[0]), [event])
                with self.assertRaises(ValueError) as caught:
                    report.count_by_type(text)
                self.assertEqual(str(caught.exception), 'line 2: type must be string')
        self.assertEqual(report.count_by_type('{"type":""}'), {"": 1})

    def test_both_public_functions_use_helper(self):
        for function, expected in ((report.load_events, [{"type": "x"}]),
                                   (report.count_by_type, {"x": 1})):
            with self.subTest(function=function.__name__):
                with patch.object(report, '_parse_lines', return_value=iter([(7, {"type": "x"})])) as helper:
                    self.assertEqual(function('input'), expected)
                    helper.assert_called_once_with('input')
