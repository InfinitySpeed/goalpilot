import unittest

from event_report import _parse_lines, count_by_type, load_events


class ParseLinesTests(unittest.TestCase):
    def test_source_numbers_and_objects(self):
        text = '\n {"type":"b"}\r\n\t\r\n{}\n'
        self.assertEqual(list(_parse_lines(text)), [(2, {"type": "b"}), (4, {})])

    def test_public_results_preserve_order_and_duplicates(self):
        events = [{"type": "b"}, {"type": "a"}, {"type": "b"}, {"type": ""}]
        text = '\n{"type":"b"}\n \n{"type":"a"}\n{"type":"b"}\n{"type":""}\n'
        self.assertEqual(load_events(text), events)
        self.assertEqual(list(count_by_type(text).items()), [("b", 2), ("a", 1), ("", 1)])

    def test_empty_and_blank_inputs(self):
        for text in ("", "\n \r\n\t\n"):
            with self.subTest(text=text):
                self.assertEqual(load_events(text), [])
                self.assertEqual(count_by_type(text), {})

    def test_shared_errors_include_original_line_number(self):
        for function in (load_events, count_by_type):
            for value, message in (
                ("{", "invalid JSON"),
                ("[]", "expected object"),
                ("null", "expected object"),
                ('"text"', "expected object"),
                ("1", "expected object"),
                ("true", "expected object"),
            ):
                with self.subTest(function=function.__name__, value=value):
                    with self.assertRaises(ValueError) as raised:
                        function('\n{"type":"a"}\n \n' + value)
                    self.assertEqual(str(raised.exception), "line 4: " + message)

    def test_type_validation_is_only_for_counts(self):
        for event in ('{}', '{"type":null}', '{"type":1}', '{"type":true}', '{"type":[]}'):
            with self.subTest(event=event):
                self.assertEqual(len(load_events("\n" + event)), 1)
                with self.assertRaises(ValueError) as raised:
                    count_by_type("\n" + event)
                self.assertEqual(str(raised.exception), "line 2: type must be string")

    def test_type_error_precedes_later_parse_error(self):
        for later_line in ("{", "[]"):
            with self.subTest(later_line=later_line):
                with self.assertRaises(ValueError) as raised:
                    count_by_type("\n{}\n" + later_line)
                self.assertEqual(str(raised.exception), "line 2: type must be string")
