import ast,pathlib,sys
repo=pathlib.Path(sys.argv[1]);sys.path.insert(0,str(repo));import event_report as m
text='\n{"type":"open","id":1}\n\n{"type":"close","id":2}\n{"type":"open","id":3}\n'
assert m.load_events(text)==[{'type':'open','id':1},{'type':'close','id':2},{'type':'open','id':3}]
assert m.count_by_type(text)=={'open':2,'close':1}
for fn,input_,message in [
 (m.load_events,'\n{','line 2: invalid JSON'),
 (m.count_by_type,'{"type":"ok"}\n{','line 2: invalid JSON'),
 (m.load_events,'{"x":1}\n[]','line 2: expected object'),
 (m.count_by_type,'{"type":"ok"}\n[]','line 2: expected object'),
 (m.count_by_type,'{"x":1}','line 1: type must be string'),
 (m.count_by_type,'{"type":false}','line 1: type must be string')]:
 try:fn(input_)
 except ValueError as e:assert str(e)==message,(str(e),message)
 else:raise AssertionError('bad input accepted')
original=m._parse_lines;calls=[]
def traced(text):calls.append(text);return original(text)
m._parse_lines=traced
m.load_events('{"type":"a"}');m.count_by_type('{"type":"b"}')
assert calls==['{"type":"a"}','{"type":"b"}']
tree=ast.parse((repo/'event_report.py').read_text())
load=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='_parse_lines')
assert sum(isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and n.func.attr=='loads' for n in ast.walk(load))==1
for name in ('load_events','count_by_type'):
 node=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name==name)
 assert any(isinstance(n,ast.Call) and isinstance(n.func,ast.Name) and n.func.id=='_parse_lines' for n in ast.walk(node)),name
print('PASS corrected independent refactor judge')
