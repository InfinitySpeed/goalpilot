from pathlib import Path
import json,subprocess,sys
r=Path(__file__).resolve().parent; protocol=json.loads((r/'protocol.json').read_text())
for case,arm in protocol['order']:
 p=subprocess.run([sys.executable,str(r/'worker.py'),case,arm],capture_output=True,text=True,timeout=240)
 (r/f'{case}-{arm}.log').write_text(p.stdout+p.stderr)
 print(p.stdout,flush=True)
 if p.returncode: print('STOP',p.stderr[-1000:],flush=True);break
